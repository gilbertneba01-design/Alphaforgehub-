<?php
/**
 * ALPHA FORGE HUB - Community Post + Comments (STUDENT)
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

const CP_CATEGORIES = [
    'discussion' => 'Discussion', 'question' => 'Question', 'study_group' => 'Study Group', 'announcement' => 'Announcement',
];

$postId = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT p.*, u.full_name FROM community_posts p JOIN users u ON u.id = p.user_id WHERE p.id = ?');
$stmt->execute([$postId]);
$post = $stmt->fetch();
if (!$post) {
    flash_set('error', 'Post not found.');
    redirect('/community.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (isset($_POST['action']) && $_POST['action'] === 'comment') {
        if (!empty($post['is_locked'])) { flash_set('error', t('com_locked')); redirect('/community_post.php?id=' . $postId); }
        if (!empty($user['community_muted'])) { flash_set('error', t('err_muted')); redirect('/community_post.php?id=' . $postId); }
        $body = post_text('body', 3000);
        $parent = !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null;
        if ($body !== '') {
            db()->prepare('INSERT INTO community_comments (post_id, user_id, parent_id, body) VALUES (?, ?, ?, ?)')->execute([$postId, $userId, $parent, $body]);
            if ((int) $post['user_id'] !== $userId) notify((int) $post['user_id'], 'community_reply', t('notif_community_reply'), mb_substr($body, 0, 150), '/community_post.php?id=' . $postId);
        }
        redirect('/community_post.php?id=' . $postId);
    }
    if (isset($_POST['action']) && $_POST['action'] === 'report') {
        $reason = post_text('reason', 300);
        if ($reason !== '') {
            db()->prepare('INSERT INTO community_reports (reporter_id, post_id, comment_id, reason) VALUES (?,?,?,?)')
                ->execute([$userId, empty($_POST['comment_id']) ? $postId : null, !empty($_POST['comment_id']) ? (int) $_POST['comment_id'] : null, $reason]);
            flash_set('success', t('com_reported'));
        }
        redirect('/community_post.php?id=' . $postId);
    }
    if (isset($_POST['delete_comment_id'])) {
        $sql = is_admin() ? 'DELETE FROM community_comments WHERE id = ?' : 'DELETE FROM community_comments WHERE id = ? AND user_id = ?';
        $params = is_admin() ? [(int) $_POST['delete_comment_id']] : [(int) $_POST['delete_comment_id'], $userId];
        db()->prepare($sql)->execute($params);
        redirect('/community_post.php?id=' . $postId);
    }
    if (isset($_POST['delete_post'])) {
        if (is_admin() || (int) $post['user_id'] === $userId) {
            db()->prepare('DELETE FROM community_posts WHERE id = ?')->execute([$postId]);
            flash_set('success', 'Post deleted.');
        }
        redirect('/community.php');
    }
}

$comments = db()->prepare('SELECT c.*, u.full_name FROM community_comments c JOIN users u ON u.id = c.user_id WHERE c.post_id = ? ORDER BY c.created_at ASC');
$comments->execute([$postId]);
$comments = $comments->fetchAll();

$pageTitle = $post['title'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:760px;">
        <a href="<?= APP_URL ?>/community.php" class="af-muted">&larr; Back to Community</a>

        <div class="af-card" style="margin:16px 0;">
            <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                <h1 style="margin:0;"><?= $post['is_pinned'] ? '&#128204; ' : '' ?><?= e($post['title']) ?><?= !empty($post['is_locked']) ? ' &#128274;' : '' ?></h1>
                <span class="af-badge af-badge-muted"><?= e(CP_CATEGORIES[$post['category']] ?? $post['category']) ?></span>
            </div>
            <p class="af-muted">by <?= e($post['full_name']) ?> &middot; <?= e(date('d M Y H:i', strtotime($post['created_at']))) ?></p>
            <?php if (!empty($post['is_hidden']) && !is_admin()): ?>
                <p class="af-muted"><em><?= te('com_hidden') ?></em></p>
            <?php else: ?>
                <p style="white-space:pre-wrap;"><?= e($post['body']) ?></p>
            <?php endif; ?>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <?php if (is_admin() || (int) $post['user_id'] === $userId): ?>
                <form method="post" data-confirm="Delete this post and all its comments?">
                    <?= csrf_field() ?>
                    <input type="hidden" name="delete_post" value="1">
                    <button type="submit" class="af-btn af-btn-ghost" style="color:var(--red);"><?= te('btn_delete') ?></button>
                </form>
            <?php endif; ?>
            <?php if ((int) $post['user_id'] !== $userId): ?>
                <details><summary class="af-btn af-btn-ghost af-btn-sm" style="cursor:pointer;display:inline-block;"><?= te('btn_report') ?></summary>
                    <form method="post" style="margin-top:8px;">
                        <?= csrf_field() ?><input type="hidden" name="action" value="report">
                        <input type="text" name="reason" maxlength="300" required placeholder="<?= te('com_report_reason') ?>">
                        <button type="submit" class="af-btn af-btn-ghost af-btn-sm"><?= te('btn_send') ?></button>
                    </form>
                </details>
            <?php endif; ?>
            </div>
        </div>

        <h3><?= te('btn_reply') ?> (<?= count($comments) ?>)</h3>
        <?php
        $__byParent = [];
        foreach ($comments as $c) { $__byParent[$c['parent_id'] ?: 0][] = $c; }
        function cp_render(array $byParent, ?int $parentId, int $userId): void {
            foreach (($byParent[$parentId ?: 0] ?? []) as $c) {
                echo '<div class="af-card" style="margin-bottom:10px;">';
                if (!empty($c['is_hidden']) && !is_admin()) {
                    echo '<p class="af-muted"><em>' . e(t('com_hidden')) . '</em></p>';
                } else {
                    echo '<p class="af-muted" style="margin:0 0 6px;">' . e($c['full_name']) . ' &middot; ' . e(date('d M Y H:i', strtotime($c['created_at']))) . '</p>';
                    echo '<p style="margin:0; white-space:pre-wrap;">' . e($c['body']) . '</p>';
                    echo '<div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">';
                    if (is_admin() || (int) $c['user_id'] === $userId) {
                        echo '<form method="post">' . csrf_field()
                           . '<input type="hidden" name="delete_comment_id" value="' . (int) $c['id'] . '">'
                           . '<button type="submit" class="af-btn af-btn-ghost af-btn-sm" style="color:var(--red);">' . te('btn_delete') . '</button></form>';
                    }
                    echo '</div>';
                }
                if (!empty($byParent[$c['id']])) {
                    echo '<div class="af-thread">'; cp_render($byParent, $c['id'], $userId); echo '</div>';
                }
                echo '</div>';
            }
        }
        cp_render($__byParent, null, $userId);
        ?>
        <?php if (!$comments): ?><p class="af-muted"><?= te('com_empty') ?></p><?php endif; ?>

        <?php if (empty($post['is_locked'])): ?>
        <form method="post" class="af-card">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="comment">
            <div class="af-field"><label><?= te('btn_reply') ?></label><textarea name="body" rows="3" maxlength="3000" required placeholder="<?= te('com_write_reply') ?>"></textarea></div>
            <button type="submit" class="af-btn af-btn-gold"><?= te('btn_reply') ?></button>
        </form>
        <?php else: ?>
            <div class="af-alert"><?= te('com_locked') ?></div>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
