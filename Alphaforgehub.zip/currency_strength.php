<?php
/** ALPHA FORGE HUB - Currency Strength (STUDENT) */
require_once __DIR__ . '/config/functions.php';
require_login();

$latestDate = db()->query('SELECT MAX(snapshot_date) FROM currency_strength_snapshots')->fetchColumn();
$rows = [];
if ($latestDate) {
    $stmt = db()->prepare('SELECT * FROM currency_strength_snapshots WHERE snapshot_date = ? ORDER BY strength_score DESC');
    $stmt->execute([$latestDate]);
    $rows = $stmt->fetchAll();
}

$pageTitle = 'Currency Strength';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Currency Strength</h1>
            <p class="af-muted">Relative strength of the major currencies, entered by our team from documented calculation methods. This is a snapshot for study, not a live trading signal.</p>

            <?php if (!$latestDate): ?>
                <div class="af-card" style="padding:24px;">
                    <strong>STATUS:</strong> Currency strength data provider not configured yet. Check back soon, or ask your instructor about this week's manual snapshot.
                </div>
            <?php else: ?>
                <p class="af-muted">Snapshot date: <?= e($latestDate) ?> &middot; Source: <?= e($rows[0]['source'] ?? 'manual') ?></p>
                <div class="af-card" style="padding:20px;">
                    <?php $max = max(array_map(fn($r) => abs((float) $r['strength_score']), $rows)) ?: 1; ?>
                    <?php foreach ($rows as $r): $pct = min(100, (abs((float) $r['strength_score']) / $max) * 100); $positive = $r['strength_score'] >= 0; ?>
                        <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
                            <div style="width:50px; font-weight:700;"><?= e($r['currency']) ?></div>
                            <div style="flex:1; background:rgba(255,255,255,0.06); border-radius:6px; overflow:hidden; height:18px;">
                                <div style="width:<?= $pct ?>%; height:100%; background:<?= $positive ? '#2ecc71' : '#e74c3c' ?>;"></div>
                            </div>
                            <div style="width:60px; text-align:right;"><?= e($r['strength_score']) ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <p class="af-lab-legal" style="margin-top:16px;">Educational tool. Strength shifts intraday — always confirm current conditions before acting on it.</p>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
