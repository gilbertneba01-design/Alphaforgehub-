<?php
/**
 * ALPHA FORGE - Chart Lab API (STUDENT, JSON)
 *
 * POST only. Actions:
 *   submit  - judge a zone the student drew (server-side; the answer never
 *             leaves the server unless the zone is correct)
 *   reveal  - show the answer, but only after the student has really tried
 *             (CHARTLAB_REVEAL_AFTER attempts) or has already solved it
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/chartlab.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function chartlab_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    chartlab_json(['ok' => false, 'error' => 'Method not allowed.'], 405);
}

if (!is_logged_in()) {
    chartlab_json(['ok' => false, 'login' => true, 'error' => 'Your session has expired. Please log in again.'], 401);
}

if (!csrf_verify()) {
    chartlab_json(['ok' => false, 'error' => 'Your page session expired. Reload the page and try again.'], 403);
}

if (!chartlab_available()) {
    chartlab_json(['ok' => false, 'error' => 'Chart Lab is not set up yet.'], 503);
}

$user   = current_user();
$userId = (int) $user['id'];

$action = (string) ($_POST['action'] ?? '');
if (!in_array($action, ['submit', 'reveal'], true)) {
    chartlab_json(['ok' => false, 'error' => 'Unknown action.'], 400);
}

// Generous limit: stops scripts hammering the grader, never a real student.
if (!enforce_rate_limit('chartlab_' . $action, 90, 60, 60)) {
    chartlab_json(['ok' => false, 'error' => 'You are going a little fast. Wait a minute and try again.'], 429);
}

$exercise = chartlab_get_exercise((int) ($_POST['exercise_id'] ?? 0));
if (!$exercise) {
    chartlab_json(['ok' => false, 'error' => 'Exercise not found.'], 404);
}

// Server-side premium gate (same rule as lessons).
if (!chartlab_can_access($exercise, $userId)) {
    chartlab_json(['ok' => false, 'premium' => true, 'error' => 'This exercise needs an active subscription.'], 403);
}

$exerciseId = (int) $exercise['id'];
$targets    = json_decode((string) $exercise['targets'], true);
if (!is_array($targets) || count($targets) === 0) {
    chartlab_json(['ok' => false, 'error' => 'This exercise is not configured correctly.'], 500);
}

// How has this student done so far on this exercise?
function chartlab_history(int $userId, int $exerciseId): array {
    $stmt = db()->prepare(
        "SELECT COALESCE(SUM(result = 'correct'), 0) AS solved,
                COALESCE(SUM(result <> 'correct'), 0) AS failed,
                COUNT(*) AS total
         FROM chartlab_attempts WHERE user_id = ? AND exercise_id = ?"
    );
    $stmt->execute([$userId, $exerciseId]);
    $row = $stmt->fetch();
    return [
        'solved' => (int) $row['solved'] > 0,
        'failed' => (int) $row['failed'],
        'total'  => (int) $row['total'],
    ];
}

/** Id of the next published exercise this student can open, or null. */
function chartlab_next_id(int $currentId, int $userId): ?int {
    $stmt = db()->prepare(
        "SELECT id, is_premium FROM chartlab_exercises
         WHERE status = 'published'
         ORDER BY sort_order, id"
    );
    $stmt->execute();
    $rows = $stmt->fetchAll();
    $found = false;
    foreach ($rows as $r) {
        if ($found) {
            if (!(int) $r['is_premium'] || is_admin() || has_active_subscription($userId)) {
                return (int) $r['id'];
            }
            continue;
        }
        if ((int) $r['id'] === $currentId) {
            $found = true;
        }
    }
    return null;
}

$mode = (string) $exercise['mode'];
$tolP = (float) $exercise['tol_price'];
$tolX = (float) $exercise['tol_candles'];

// ---------------------------------------------------------------
// REVEAL
// ---------------------------------------------------------------
if ($action === 'reveal') {
    $history = chartlab_history($userId, $exerciseId);
    if (!$history['solved'] && $history['failed'] < CHARTLAB_REVEAL_AFTER) {
        chartlab_json([
            'ok'    => false,
            'error' => 'Try the exercise a couple more times first. The answer unlocks after ' . CHARTLAB_REVEAL_AFTER . ' attempts.',
        ], 403);
    }
    chartlab_json([
        'ok'          => true,
        'answers'     => $targets,
        'explanation' => (string) $exercise['explanation'],
    ]);
}

// ---------------------------------------------------------------
// SUBMIT
// ---------------------------------------------------------------
$candles = json_decode((string) $exercise['candles'], true);
$view    = chartlab_view_range(is_array($candles) ? $candles : []);
$count   = is_array($candles) ? count($candles) : 0;

[$zone, $zoneError] = chartlab_parse_zone($_POST, $view, $count, $mode);
if ($zone === null) {
    chartlab_json(['ok' => false, 'error' => $zoneError], 422);
}

$result  = chartlab_evaluate($zone, $targets, $mode, $tolP, $tolX);
$verdict = $result['verdict'];

$ins = db()->prepare(
    'INSERT INTO chartlab_attempts (user_id, exercise_id, result, score, zone_x1, zone_x2, zone_p1, zone_p2)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
);
$ins->execute([
    $userId,
    $exerciseId,
    $verdict,
    (int) $result['score'],
    round($zone['x1'], 3),
    round($zone['x2'], 3),
    round($zone['p1'], 6),
    round($zone['p2'], 6),
]);

$history = chartlab_history($userId, $exerciseId);

$response = [
    'ok'         => true,
    'verdict'    => $verdict,
    'message'    => chartlab_feedback($result),
    'attempts'   => $history['total'],
    'can_reveal' => ($history['solved'] || $history['failed'] >= CHARTLAB_REVEAL_AFTER),
];

if ($verdict === 'correct') {
    $idx = (int) $result['target_index'];
    $response['score']       = (int) $result['score'];
    $response['answers']     = [$targets[$idx] ?? $targets[0]];
    $response['explanation'] = (string) $exercise['explanation'];
    $nextId = chartlab_next_id($exerciseId, $userId);
    $response['next_id']     = $nextId;
    $stats = chartlab_stats($userId);
    $response['stats']       = $stats;
}

chartlab_json($response);
