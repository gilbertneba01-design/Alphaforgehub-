<?php
/** ALPHA FORGE HUB - Secure download gate. Verifies real ownership before serving any file. */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

$type = (string) ($_GET['type'] ?? '');
$id   = (int) ($_GET['id'] ?? 0);

if ($type !== 'store' || $id <= 0) {
    http_response_code(400);
    die('Invalid download request.');
}

$stmt = db()->prepare("SELECT sp.*, p.file_path, p.title FROM store_purchases sp
    JOIN store_products p ON p.id = sp.product_id
    WHERE sp.id = ? AND sp.user_id = ? AND sp.status = 'paid'");
$stmt->execute([$id, $user['id']]);
$row = $stmt->fetch();

if (!$row || !$row['file_path']) {
    http_response_code(403);
    die('You do not have access to this file.');
}

// file_path is stored relative to a private uploads directory outside the web root's direct reach where possible.
$fullPath = __DIR__ . '/uploads/store/' . basename($row['file_path']);
if (!is_file($fullPath)) {
    http_response_code(404);
    die('File not found. Please contact support.');
}

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($row['title']) . '.pdf"');
header('Content-Length: ' . filesize($fullPath));
readfile($fullPath);
exit;
