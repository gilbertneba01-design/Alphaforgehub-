<?php
/** ALPHA FORGE HUB - Store (PUBLIC + STUDENT) - courses, ebooks, subscriptions in one place */
require_once __DIR__ . '/config/functions.php';

$courses = db()->query("SELECT id, title, slug, price, image, is_premium FROM courses WHERE status='published' ORDER BY sort_order LIMIT 12")->fetchAll();
$products = db()->query("SELECT * FROM store_products WHERE status='published' ORDER BY sort_order, title")->fetchAll();
$plans = db()->query('SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price')->fetchAll();

$ebooks = array_filter($products, fn($p) => $p['type'] === 'ebook');
$bundles = array_filter($products, fn($p) => $p['type'] === 'bundle');

$pageTitle = 'Store';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <span class="af-eyebrow">Alpha Forge Store</span>
        <h1>Courses, Ebooks & Subscriptions</h1>
        <p class="af-muted">Everything you can buy on Alpha Forge, in one place.</p>

        <h2 style="margin-top:28px;">Courses</h2>
        <div class="af-grid af-grid-3" style="gap:16px;">
            <?php foreach ($courses as $c): ?>
                <a href="<?= APP_URL ?>/course.php?slug=<?= urlencode($c['slug']) ?>" class="af-card" style="padding:18px; text-decoration:none; color:inherit;">
                    <?php if ($c['is_premium']): ?><span class="af-badge">Premium</span><?php endif; ?>
                    <h3 style="margin:8px 0 6px;"><?= e($c['title']) ?></h3>
                    <p class="af-muted" style="margin:0;"><?= $c['price'] > 0 ? number_format($c['price'], 2) . ' XAF' : 'Included with subscription' ?></p>
                </a>
            <?php endforeach; ?>
        </div>

        <h2 style="margin-top:28px;">Ebooks</h2>
        <?php if (empty($ebooks)): ?>
            <p class="af-muted">No ebooks published yet.</p>
        <?php else: ?>
            <div class="af-grid af-grid-3" style="gap:16px;">
                <?php foreach ($ebooks as $p): ?>
                    <div class="af-card" style="padding:0; overflow:hidden;">
                        <?php if ($p['image']): ?><img src="<?= e(asset_url($p['image'])) ?>" alt="<?= e($p['title']) ?>" style="width:100%; aspect-ratio:3/4; object-fit:cover;"><?php endif; ?>
                        <div style="padding:16px;">
                            <h3 style="margin:0 0 6px;"><?= e($p['title']) ?></h3>
                            <p class="af-muted" style="margin:0 0 10px; font-size:14px;"><?= e(mb_strimwidth($p['description'] ?? '', 0, 100, '...')) ?></p>
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <strong><?= number_format($p['price'], 2) ?> <?= e($p['currency']) ?></strong>
                                <a href="<?= APP_URL ?>/store_checkout.php?product=<?= urlencode($p['slug']) ?>" class="af-btn af-btn-gold af-btn-sm">Buy</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($bundles): ?>
            <h2 style="margin-top:28px;">Bundles</h2>
            <div class="af-grid af-grid-3" style="gap:16px;">
                <?php foreach ($bundles as $p): ?>
                    <div class="af-card" style="padding:18px;">
                        <h3 style="margin:0 0 6px;"><?= e($p['title']) ?></h3>
                        <p class="af-muted" style="margin:0 0 10px; font-size:14px;"><?= e($p['description'] ?? '') ?></p>
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <strong><?= number_format($p['price'], 2) ?> <?= e($p['currency']) ?></strong>
                            <a href="<?= APP_URL ?>/store_checkout.php?product=<?= urlencode($p['slug']) ?>" class="af-btn af-btn-gold af-btn-sm">Buy</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <h2 style="margin-top:28px;">Subscriptions</h2>
        <div class="af-grid af-grid-3" style="gap:16px;">
            <?php foreach ($plans as $p): ?>
                <div class="af-card" style="padding:18px;">
                    <h3 style="margin:0 0 6px;"><?= e($p['name']) ?></h3>
                    <p class="af-muted"><?= (int) $p['duration_days'] ?> days access</p>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <strong><?= number_format($p['price'], 2) ?> <?= e($p['currency']) ?></strong>
                        <a href="<?= APP_URL ?>/subscribe.php?plan=<?= (int) $p['id'] ?>" class="af-btn af-btn-gold af-btn-sm">Subscribe</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
