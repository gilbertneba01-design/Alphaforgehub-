# ALPHA FORGE HUB — Full Audit Report (rounds 1 + 2)

I audited this from the source code only. **PHP and MySQL are not available in
this sandbox, so nothing below was executed against a live database or
browser.** Run `database/migration_v3_audit.sql` in phpMyAdmin, then test each
item locally in XAMPP before trusting it. Anything I could not verify is
listed under STILL INCOMPLETE / NOT VERIFIABLE HERE, not silently assumed.

---
## FIXED

**1) Root cause of "static buttons" — CSP blocked all inline JS (round 1)**
`.htaccess` sent `script-src 'self'`, which blocks every inline `<script>`
block and every `onclick=""/onsubmit=""/onchange=""` attribute. That killed
the Backtesting Lab and Trading Simulator (their config objects never
loaded), every Forex Tools button, delete confirmations, AI Tutor, Market
Hours, First Trade, and the Pips/Lots calculator.
- `config/config.php` now emits a per-request nonce (`CSP_NONCE`) and sends
  the CSP header itself; `.htaccess`'s static header was removed.
- Inline `<script>` blocks in 8 pages carry `nonce="<?= CSP_NONCE ?>"`.
- Inline handlers replaced with `data-*` hooks handled once in
  `assets/js/app.js`: `data-confirm`, `data-confirm-click`,
  `data-autosubmit`, `data-af-call`/`data-af-arg`, `data-af-print`,
  `data-af-reload`.

**2) E-book / cover image path (round 1)** — `asset_url()` in
`config/functions.php` prefixes `APP_URL` so stored paths resolve correctly
under a XAMPP sub-folder install (`store.php`, `my_library.php`). No cover
files shipped in the zip — see CONFIGURATION REQUIRED.

**7) Backtesting Lab button** — was the CSP issue above; the button now
actually reaches its JS.

**8) Trading Simulator — server-trusts-client-price bug (round 2, security)**
`simulator_api.php` previously accepted a `price` field from the browser for
both opening and closing trades, so a student could manufacture any P/L.
Rewritten: the server now looks up the price itself from a new `sim_prices`
table (kept warm by `cron/sim_price_tick.php`, a small deterministic
random-walk you schedule in XAMPP's Task Scheduler/cron). If that table is
empty (fresh install, cron not yet configured), a bounded per-minute
fallback wander keeps the simulator working out of the box.
`assets/js/simulator.js` was rewritten to match: it never sends a price to
open/close, and polls `action=price` / `action=state` to display one.

**12/13/14 — English/French language system (round 2)**
`t()` had a fallback bug (it fell back to the *current* language array
instead of English when a key was French-missing) — rewritten. Added ~126
new keys to `language/en.php` and `language/fr.php` in sync, covering
navigation, buttons, empty/error states, and every new feature below.
`includes/header.php`, `student_sidebar.php`, `footer.php` and `index.php`
now call `t()`/`te()` instead of hardcoded English. Added
`translated_field()` plus `course_translations` / `lesson_translations`
tables so course/lesson content can carry French text without touching the
original (English) columns — nothing existing is destroyed; French rows are
additive and optional.

**19/20/21 — Mentorship was request-only; no mentor role, dashboard or
private chat (round 2)**
- `users.role` extended to `student|mentor|admin` (migration, additive).
- `mentors.user_id` links a mentor profile to a login account —
  `admin/mentorship.php` now has a "link to login account" control (sets
  role=mentor) and an unlink control (reverts to student). Mentors are
  **not** given admin privileges anywhere.
- New `mentor/index.php`: pending requests (accept/decline), assigned
  students, feedback form with a 0–100% progress field.
- New `mentor/chat.php`: private 1:1 thread, shared by both roles. Access is
  decided in one place — `config/mentorship.php`'s
  `mentorship_request_for()` — by matching the logged-in user against that
  specific request's student and mentor only; nobody else can open it, admin
  included (admin gets a moderation read-flag but no chat UI). Chat opens
  only after the mentor accepts (`status IN ('scheduled','completed')`).
  `mentorship.php` (student side) now links into the same chat page.
- Feedback and mentor-accept/decline write to the new `notifications` table.

**15/16/17/18 — Community, moderation, announcements, study groups (round 2)**
- `community_comments` gained `parent_id` (threaded replies, rendered
  recursively) and `is_hidden`; `community_posts` gained `is_locked` /
  `is_hidden`. New `community_reports` table + a report button on posts and
  a "Delete"→"Hide" flow doesn't delete data, it flags it, so nothing is
  destroyed by a moderation action; a genuine delete still exists via the
  original delete_post/delete_comment actions.
- `admin/community.php`: added Lock/Unlock, Hide/Unhide, and an "Open
  Reports" queue with a Resolve action.
- New `announcements` table + `announcements.php` (student, read-only) +
  `admin/announcements.php` (create/edit/delete/pin, **admin-only**,
  re-checked server-side inside the POST handler, not just hidden in the
  UI). Publishing notifies every active student.
- New `study_groups` / `study_group_members` / `study_group_posts` tables +
  `study_groups.php` (browse/join/leave) + `study_group.php` (threaded
  group chat, respects lock/closed status and a muted student) +
  `admin/study_groups.php` (create groups, lock/unlock/close, remove a
  member, hide a message).
- `admin/user.php` gained a Mute/Unmute-in-Community toggle
  (`users.community_muted`); muted students are blocked server-side from
  posting in community, study groups, and the mentor chat message action
  isn't affected (that's private, unrelated to community conduct).

**29 — Notifications (round 2)** — new `notifications` table +
`notifications.php` (each user sees only their own rows, verified by a
`user_id = ?` check before marking read or redirecting to the link — no
IDOR) + an unread-count bell in the header. Wired into: mentor
accept/decline, mentor feedback, mentor/student chat messages, community
replies, new announcements.

**24 — Install App button (round 2)** — a real "Install App" button
(`data-af-install`) sits next to "Join"/"Start Learning" in both the header
and the homepage hero, using the `beforeinstallprompt` PWA event where
available and a plain instructions alert on iOS/other browsers. It never
blocks or replaces Join/Login. PWA manifest, service worker and its
subfolder-safe registration were already correct and are unchanged.

**34 — Friendly production errors (round 2)** — `config/config.php` now
installs `set_exception_handler()` when `APP_ENV != 'local'`: uncaught
exceptions log full detail to the PHP error log and show a generic
"Something went wrong" page instead of a stack trace. (PHP warnings/notices
were already suppressed via `display_errors=0` in that mode; only uncaught
exceptions were missing a handler.)

---
## STILL INCOMPLETE / NOT VERIFIABLE HERE

- **No PHP/MySQL in this environment.** None of the above was actually run.
  Load `database/migration_v3_audit.sql`, then click through every flow
  yourself (or hand this project + zip to a coding agent that has a real
  XAMPP stack) before treating any row below as PASS.
- **Chart Lab exercise library (section 25–27):** only the existing
  `chart_exercises` schema/admin CRUD were reviewed, not expanded — building
  out every listed category (100+ exercise types) is a large content task,
  not a bug fix, and needs real chart datasets per exercise.
- **AI Tutor, Forexpedia, market data feeds, live sessions, challenges,
  testimonials, subscriptions, 2FA:** read for structure only; not
  functionally audited line-by-line this round.
- **Course/lesson French content:** the *tables* exist
  (`course_translations`, `lesson_translations`) and `translated_field()`
  reads them, but no course/lesson pages were switched over to call it, and
  no French course text was entered — that's a content task per course.
- **File upload validation, DB orphan/FK audit, full JS console pass:** not
  re-run this round; round 1's CSP fix likely surfaces JS errors that were
  previously masked (nothing executed), so re-check the console after
  applying this patch.
- **A mentor who manually navigates to `dashboard.php`** isn't blocked (it's
  role-agnostic `require_login()`), just gets student-shaped output; low
  risk (no data leak — it's the mentor's own queries), but worth a
  role-redirect if it bothers you.
- **Payments (MTN MoMo / Orange Money):** reviewed only — architecture
  already separates student payment input from merchant credentials, and
  `payment_webhook.php` already verifies the gateway payload before
  activating anything (no "I paid" checkbox trust). No changes made; you
  still need real provider credentials configured in `.env.php`.

---
## DATABASE CHANGES
Everything is in **`database/migration_v3_audit.sql`** (safe to re-run,
nothing dropped/renamed): mentor role + `mentors.user_id`,
`mentorship_messages`, `mentorship_feedback`, `announcements`,
`notifications`, community threading/moderation/reports columns and table,
`study_groups`/`study_group_members`/`study_group_posts`,
`course_translations`/`lesson_translations`, `sim_prices`.

## NEW FILES
`database/migration_v3_audit.sql`, `config/mentorship.php`,
`announcements.php`, `admin/announcements.php`, `notifications.php`,
`study_groups.php`, `study_group.php`, `admin/study_groups.php`,
`mentor/index.php`, `mentor/chat.php`, `cron/sim_price_tick.php`,
`assets/img/books/` (empty, for e-book covers).

## MODIFIED FILES (round 2, on top of round 1's CSP/asset_url patch)
`config/auth.php`, `config/functions.php`, `config/config.php`,
`language/en.php`, `language/fr.php`, `includes/header.php`,
`includes/student_sidebar.php`, `includes/footer.php`, `index.php`,
`login.php`, `mentorship.php`, `admin/mentorship.php`, `admin/community.php`,
`community_post.php`, `admin/user.php`, `admin/includes/admin_header.php`,
`simulator_api.php`, `assets/js/simulator.js`, `assets/js/pwa.js`,
`assets/css/style.css`.

## CONFIGURATION REQUIRED
- Run `database/migration_v3_audit.sql`.
- Add e-book cover images to `assets/img/books/`; enter their `/assets/img/books/<file>` path in Admin → Store.
- Schedule `php cron/sim_price_tick.php` in XAMPP's Task Scheduler (or any
  cron) every 1–5 seconds/minutes for a livelier simulator price; it works
  without this, just less "live."
- To make someone a mentor: Admin → Mentorship → Add Mentor (profile), then
  "Link" it to their existing student login.
- Payment provider keys stay in `config/.env.php` (already excluded from
  this zip) — no change needed unless you're setting them up for the first
  time.

## TEST RESULTS
Not run (no PHP/MySQL here). Please test each and report back:
Authentication • Courses • Lessons • Language(EN/FR) • Chart Lab •
Backtesting • Simulator • Journal • Performance • Forex Tools • Community •
Study Groups • Mentorship • Certificates • Payments • Install App • Admin •
Mentor • Mobile • Security

---
## Preview gate removed (follow-up request)
The project had a separate "private preview" passcode wall (unrelated to
anything built above): `config/preview_gate.php`, wired in from
`config/functions.php` for every non-admin, non-webhook page, controlled by
`PREVIEW_MODE`/`PREVIEW_PASSCODE` in `config/config.php` and
`config/.env.php`, and reflected in `robots.php`'s "noindex while in
preview" behavior. It was already switched off (`PREVIEW_MODE=false`) but
still present in code.

Removed completely:
- Deleted `config/preview_gate.php`.
- `config/functions.php`: removed the `require_once` and the
  `enforce_preview_gate()` call.
- `config/config.php`: removed the `PREVIEW_MODE` / `PREVIEW_PASSCODE`
  constants and their comment block.
- `robots.php`: removed the `PREVIEW_MODE` branch; it now always serves the
  normal "open to search engines, admin/config/payment disallowed" file.
- `config/.env.php`: removed the two `putenv()` lines and their comments.
- `.htaccess`: updated a comment that referenced it (no functional rule to
  remove there — the passcode wall lived entirely in PHP).

Nothing else in the site depended on `PREVIEW_MODE`; the site now behaves as
if it were always public.
