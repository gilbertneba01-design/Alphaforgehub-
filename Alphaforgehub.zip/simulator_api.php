<?php
/**
 * ALPHA FORGE HUB - Trading Simulator API (STUDENT, JSON)
 * DEMO / SIMULATED TRADING ONLY - virtual balance, never real funds.
 * Price ticks come from sim_prices (server-maintained random walk, see
 * cron/sim_price_tick.php), NOT from the browser. This closes the gap
 * where a student could previously report their own closing price.
 */
require_once __DIR__ . '/config/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function sim_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') sim_json(['ok' => false, 'error' => 'Method not allowed.'], 405);
if (!is_logged_in()) sim_json(['ok' => false, 'login' => true, 'error' => 'Please log in again.'], 401);
if (!csrf_verify()) sim_json(['ok' => false, 'error' => 'Session expired. Reload the page.'], 403);
if (!enforce_rate_limit('simulator', 60, 60, 60)) sim_json(['ok' => false, 'error' => 'Too many requests. Slow down.'], 429);

$userId = (int) current_user()['id'];
$action = (string) ($_POST['action'] ?? '');

const PIP_VALUE_PER_LOT = 10.0; // simplified constant, as used elsewhere in Forex Tools
const STARTING_BALANCE  = 10000.00;
const SIM_BASE_PRICES = [
    'EURUSD' => 1.08500, 'GBPUSD' => 1.26500, 'USDJPY' => 149.500, 'AUDUSD' => 0.65500,
    'USDCAD' => 1.36500, 'USDCHF' => 0.88500, 'NZDUSD' => 0.60500, 'EURJPY' => 162.000,
];

function sim_pip_size(string $pair): float {
    return stripos($pair, 'JPY') !== false ? 0.01 : 0.0001;
}

/**
 * Server-side price for a pair. Reads sim_prices (kept fresh by
 * cron/sim_price_tick.php); if that table is empty or missing (fresh
 * install, migration not run, cron not set up yet), falls back to a
 * bounded per-request synthetic tick around a fixed base price so the
 * simulator still works out of the box.
 */
function sim_current_price(string $pair): float {
    $pair = strtoupper($pair);
    $base = SIM_BASE_PRICES[$pair] ?? 1.00000;
    try {
        $stmt = db()->prepare('SELECT price FROM sim_prices WHERE pair = ?');
        $stmt->execute([$pair]);
        $v = $stmt->fetchColumn();
        if ($v !== false) return (float) $v;
    } catch (Throwable $ex) { /* table not migrated yet: fall through */ }
    $pip = sim_pip_size($pair);
    // Deterministic-ish bounded wander from the current minute, so repeated
    // calls within the same minute return a stable price (no free re-rolls).
    $seedInput = $pair . gmdate('YmdHi');
    mt_srand(crc32($seedInput));
    $wobble = (mt_rand(-500, 500) / 1000.0) * $pip * 20;
    mt_srand();
    return round($base + $wobble, 5);
}

function sim_pip_size_wrap(string $pair): float { return sim_pip_size($pair); }

function sim_get_account(int $userId): array {
    $stmt = db()->prepare('SELECT * FROM simulator_accounts WHERE user_id = ?');
    $stmt->execute([$userId]);
    $acct = $stmt->fetch();
    if (!$acct) {
        db()->prepare('INSERT INTO simulator_accounts (user_id, balance, equity) VALUES (?, ?, ?)')
            ->execute([$userId, STARTING_BALANCE, STARTING_BALANCE]);
        $stmt->execute([$userId]);
        $acct = $stmt->fetch();
    }
    return $acct;
}

$account = sim_get_account($userId);

if ($action === 'price') {
    $pair = strtoupper(trim((string) ($_POST['pair'] ?? 'EURUSD')));
    if (!preg_match('/^[A-Z]{6}$/', $pair)) sim_json(['ok' => false, 'error' => 'Invalid pair.'], 400);
    sim_json(['ok' => true, 'pair' => $pair, 'price' => sim_current_price($pair), 'decimals' => stripos($pair, 'JPY') !== false ? 3 : 5]);
}

if ($action === 'state') {
    $trades = db()->prepare("SELECT * FROM simulator_trades WHERE account_id = ? ORDER BY status = 'open' DESC, opened_at DESC LIMIT 50");
    $trades->execute([$account['id']]);
    $trades = $trades->fetchAll();
    // attach the current server price for each distinct open pair, so the
    // client never has to invent one for floating P/L math.
    $prices = [];
    foreach ($trades as $t) { if ($t['status'] === 'open' && !isset($prices[$t['pair']])) $prices[$t['pair']] = sim_current_price($t['pair']); }
    sim_json(['ok' => true, 'account' => $account, 'trades' => $trades, 'prices' => $prices]);
}

if ($action === 'open') {
    $pair    = strtoupper(trim((string) ($_POST['pair'] ?? 'EURUSD')));
    $dir     = ($_POST['direction'] ?? '') === 'sell' ? 'sell' : 'buy';
    $lots    = round((float) ($_POST['lot_size'] ?? 0), 2);
    $sl      = isset($_POST['stop_loss']) && $_POST['stop_loss'] !== '' ? (float) $_POST['stop_loss'] : null;
    $tp      = isset($_POST['take_profit']) && $_POST['take_profit'] !== '' ? (float) $_POST['take_profit'] : null;

    if ($lots <= 0 || $lots > 50 || !preg_match('/^[A-Z]{6}$/', $pair)) {
        sim_json(['ok' => false, 'error' => 'Invalid trade parameters.'], 400);
    }
    $price = sim_current_price($pair); // server decides the entry price, never the client
    $openCountStmt = db()->prepare("SELECT COUNT(*) FROM simulator_trades WHERE account_id = ? AND status = 'open'");
    $openCountStmt->execute([$account['id']]);
    if ((int) $openCountStmt->fetchColumn() >= 10) {
        sim_json(['ok' => false, 'error' => 'Maximum 10 open simulated positions at a time.'], 400);
    }

    db()->prepare('INSERT INTO simulator_trades (account_id, pair, direction, lot_size, entry_price, stop_loss, take_profit) VALUES (?,?,?,?,?,?,?)')
        ->execute([$account['id'], $pair, $dir, $lots, $price, $sl, $tp]);

    sim_json(['ok' => true, 'message' => 'Position opened (simulated).', 'price' => $price]);
}

if ($action === 'close') {
    $tradeId = (int) ($_POST['trade_id'] ?? 0);

    $stmt = db()->prepare("SELECT * FROM simulator_trades WHERE id = ? AND account_id = ? AND status = 'open'");
    $stmt->execute([$tradeId, $account['id']]);
    $trade = $stmt->fetch();
    if (!$trade) sim_json(['ok' => false, 'error' => 'Trade not found or already closed.'], 404);

    $price = sim_current_price($trade['pair']); // server decides the exit price, never the client
    $pipSize = sim_pip_size($trade['pair']);
    $priceDiff = $trade['direction'] === 'buy' ? ($price - $trade['entry_price']) : ($trade['entry_price'] - $price);
    $pips = $priceDiff / $pipSize;
    $pnl = round($pips * PIP_VALUE_PER_LOT * $trade['lot_size'], 2);

    db()->beginTransaction();
    db()->prepare("UPDATE simulator_trades SET status='closed', exit_price=?, pnl=?, closed_at=NOW() WHERE id=?")
        ->execute([$price, $pnl, $tradeId]);
    db()->prepare('UPDATE simulator_accounts SET balance = balance + ?, equity = equity + ? WHERE id = ?')
        ->execute([$pnl, $pnl, $account['id']]);
    db()->commit();

    sim_json(['ok' => true, 'pnl' => $pnl, 'price' => $price, 'message' => 'Position closed (simulated).']);
}

if ($action === 'reset') {
    db()->beginTransaction();
    db()->prepare("DELETE FROM simulator_trades WHERE account_id = ?")->execute([$account['id']]);
    db()->prepare('UPDATE simulator_accounts SET balance = ?, equity = ? WHERE id = ?')
        ->execute([STARTING_BALANCE, STARTING_BALANCE, $account['id']]);
    db()->commit();
    sim_json(['ok' => true, 'message' => 'Simulator account reset to $10,000.']);
}

sim_json(['ok' => false, 'error' => 'Unknown action.'], 400);
