<?php
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/payment/PaymentManager.php';
require_login();
$user = current_user();

$paymentId = (int) ($_GET['payment_id'] ?? 0);

$stmt = db()->prepare('SELECT * FROM payments WHERE id = ? AND user_id = ?');
$stmt->execute([$paymentId, $user['id']]);
$payment = $stmt->fetch();

if (!$payment) {
    redirect('/dashboard.php');
}

// IMPORTANT: landing on this page proves nothing. We ask the gateway directly.
$status = PaymentManager::verifyAndActivate($paymentId);

$pageTitle = 'Payment Status';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:520px; text-align:center;">
        <?php if ($status === 'successful'): ?>
            <div class="af-card">
                <h1 style="color:var(--green); font-size:26px;">Payment Confirmed</h1>
                <p>Your subscription is now active. Enjoy your Premium lessons.</p>
                <a href="<?= APP_URL ?>/dashboard.php" class="af-btn af-btn-gold">Go to Dashboard</a>
            </div>
        <?php elseif ($status === 'failed'): ?>
            <div class="af-card">
                <h1 style="color:var(--red); font-size:26px;">Payment Failed</h1>
                <p>The payment could not be confirmed. No subscription was activated.</p>
                <a href="<?= APP_URL ?>/pricing.php" class="af-btn af-btn-ghost">Try Again</a>
            </div>
        <?php else: ?>
            <div class="af-card">
                <h1 style="font-size:26px;">Payment Pending</h1>
                <p>We haven't received confirmation yet. If you just approved the prompt on your phone, this can take a minute — refresh this page to check again.</p>
                <a href="<?= APP_URL ?>/payment_return.php?payment_id=<?= $paymentId ?>" class="af-btn af-btn-gold">Check Again</a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
