<?php
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];

$lessonId = (int) ($_GET['lesson_id'] ?? $_POST['lesson_id'] ?? 0);

$lessonStmt = db()->prepare(
    "SELECT l.*, c.title AS course_title, c.is_premium AS course_is_premium FROM lessons l
     JOIN modules m ON m.id = l.module_id
     JOIN courses c ON c.id = m.course_id
     WHERE l.id = ? AND l.status = 'published' LIMIT 1"
);
$lessonStmt->execute([$lessonId]);
$lesson = $lessonStmt->fetch();

if (!$lesson) {
    redirect('/dashboard.php');
}

// Same server-side premium gate as the lesson itself.
if (($lesson['is_premium'] || $lesson['course_is_premium']) && !can_view_premium($userId)) {
    redirect('/pricing.php?reason=premium');
}

$qStmt = db()->prepare('SELECT * FROM quizzes WHERE lesson_id = ? ORDER BY sort_order');
$qStmt->execute([$lessonId]);
$questions = $qStmt->fetchAll();

if (!$questions) {
    redirect('/lesson.php?id=' . $lessonId);
}

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $score = 0;
    foreach ($questions as $q) {
        $answer = strtoupper($_POST['q' . $q['id']] ?? '');
        if ($answer === $q['correct_answer']) {
            $score++;
        }
    }
    $stmt = db()->prepare('INSERT INTO quiz_results (user_id, lesson_id, score, total_questions) VALUES (?, ?, ?, ?)');
    $stmt->execute([$userId, $lessonId, $score, count($questions)]);
    $result = ['score' => $score, 'total' => count($questions)];
}

$pageTitle = 'Quiz — ' . $lesson['title'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:700px;">
        <p class="af-muted"><?= e($lesson['course_title']) ?></p>
        <h1>Quiz: <?= e($lesson['title']) ?></h1>

        <?php if ($result): ?>
            <div class="af-card" style="margin:20px 0;">
                <h3>You scored <?= $result['score'] ?> / <?= $result['total'] ?></h3>
                <p><?= $result['score'] === $result['total'] ? 'Perfect score — well done.' : 'Review the lesson content and try again anytime.' ?></p>
                <a href="<?= APP_URL ?>/lesson.php?id=<?= $lessonId ?>" class="af-btn af-btn-gold">Back to Lesson</a>
            </div>
        <?php else: ?>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="lesson_id" value="<?= $lessonId ?>">
                <?php foreach ($questions as $i => $q): ?>
                    <div class="af-card" data-quiz-question style="margin-bottom:16px;">
                        <h3 style="font-size:16px;"><?= ($i + 1) ?>. <?= e($q['question']) ?></h3>
                        <?php foreach (['A' => $q['option_a'], 'B' => $q['option_b'], 'C' => $q['option_c'], 'D' => $q['option_d']] as $key => $label): ?>
                            <label class="af-quiz-option" style="display:block; padding:10px 12px; border:1px solid var(--border); border-radius:8px; margin-top:8px; cursor:pointer;">
                                <input type="radio" name="q<?= $q['id'] ?>" value="<?= $key ?>" required style="margin-right:8px;"> <?= e($label) ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="af-btn af-btn-gold">Submit Quiz</button>
            </form>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
