<?php
/** ALPHA FORGE HUB - Prop Firm Academy (STUDENT, educational only) */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

$checklist = [
    'daily_loss_limit'  => 'I know my target firm\'s maximum daily loss limit and how it is calculated.',
    'max_drawdown'      => 'I know the maximum overall drawdown allowed and what triggers a breach.',
    'profit_target'     => 'I know the profit target for each evaluation phase and the time limit (if any).',
    'position_rules'    => 'I understand any rules on holding trades over weekends or news events.',
    'risk_per_trade'    => 'I have a fixed risk-per-trade rule I will not break under pressure.',
    'psychology_plan'   => 'I have a written plan for how I will handle a losing streak during the evaluation.',
    'demo_practice'     => 'I have practiced the exact risk parameters in the Trading Simulator before attempting a real evaluation.',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    foreach (array_keys($checklist) as $key) {
        $completed = isset($_POST['item'][$key]) ? 1 : 0;
        db()->prepare('INSERT INTO prop_firm_checklist_progress (user_id, item_key, completed) VALUES (?,?,?)
            ON DUPLICATE KEY UPDATE completed = VALUES(completed)')
            ->execute([$user['id'], $key, $completed]);
    }
    flash_set('success', 'Checklist saved.');
    redirect('/prop_firm_academy.php');
}

$progressStmt = db()->prepare('SELECT item_key, completed FROM prop_firm_checklist_progress WHERE user_id = ?');
$progressStmt->execute([$user['id']]);
$progress = array_column($progressStmt->fetchAll(), 'completed', 'item_key');

$pageTitle = 'Prop Firm Academy';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Prop Firm Academy</h1>
            <p class="af-muted">Prop firm evaluations reward disciplined risk management above all else. This section is educational — we cannot and do not promise that any student will pass a prop-firm evaluation.</p>

            <div class="af-card" style="padding:20px; margin:16px 0;">
                <h2>What is a Prop Firm?</h2>
                <p>A proprietary ("prop") trading firm lets traders manage the firm's capital after passing a paid evaluation, in exchange for a share of profits. Firms differ widely in their rules — always read your chosen firm's terms directly.</p>
            </div>

            <div class="af-card" style="padding:20px; margin-bottom:16px;">
                <h2>Common Evaluation Structures</h2>
                <ul>
                    <li><strong>Profit Target:</strong> typically 8-10% for Phase 1, often lower for Phase 2.</li>
                    <li><strong>Daily Drawdown Limit:</strong> maximum loss allowed in a single day, often 4-5% of the starting balance.</li>
                    <li><strong>Maximum Drawdown:</strong> the overall floor the account equity must never breach, often 8-10%.</li>
                    <li><strong>Minimum Trading Days:</strong> some firms require a minimum number of active trading days.</li>
                </ul>
                <p class="af-muted">Exact numbers vary by firm and by account size — always confirm current rules with your chosen provider before paying for an evaluation.</p>
            </div>

            <div class="af-card" style="padding:20px; margin-bottom:16px;">
                <h2>Psychology & Risk Management</h2>
                <p>Most evaluation failures come from breaking a drawdown rule after a losing streak, not from a lack of market knowledge. Review the Trading Psychology course and practice your exact risk parameters in the <a href="<?= APP_URL ?>/simulator.php">Trading Simulator</a> before risking evaluation fees.</p>
            </div>

            <div class="af-card" style="padding:20px;">
                <h2>Evaluation Readiness Checklist</h2>
                <form method="post">
                    <?= csrf_field() ?>
                    <?php foreach ($checklist as $key => $label): ?>
                        <label style="display:block; margin-bottom:10px;">
                            <input type="checkbox" name="item[<?= e($key) ?>]" <?= !empty($progress[$key]) ? 'checked' : '' ?>>
                            <?= e($label) ?>
                        </label>
                    <?php endforeach; ?>
                    <button type="submit" class="af-btn af-btn-gold">Save Checklist</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
