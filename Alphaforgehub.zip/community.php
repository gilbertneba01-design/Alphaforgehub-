<?php
/**
 * ALPHA FORGE HUB - Community (STUDENT)
 * Discussions, Questions, Study Groups, Announcements. Students can post
 * and delete their own posts; only admins can post Announcements or
 * moderate (delete) other people's content (see admin/community.php).
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

const COMMUNITY_CATEGORIES = [
    'discussion'   => 'Discussion',
    'question'     => 'Question',
    'study_group'  => 'Study Group',
    'announcement' => 'Announcement',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    require_csrf();
    $title    = trim($_POST['title'] ?? '');
    $body     = trim($_POST['body'] ?? '');
    $category = $_POST['category'] ?? 'discussion';
    if ($category === 'announcement' && !is_admin()) {
        $category = 'discussion';
    }
    if (!isset(COMMUNITY_CATEGORIES[$category])) {
        $category = 'discussion';
    }

    if ($title !== '' && $body !== '') {
        db()->prepare('INSERT INTO community_posts (user_id, title, body, category) VALUES (?, ?, ?, ?)')
            ->execute([$userId, $title, $body, $category]);
        flash_set('success', 'Post created.');
    } else {
        flash_set('error', 'Title and message are required.');
    }
    redirect('/community.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_post_id'])) {
    require_csrf();
    // Students may only delete their own post; admins may delete any (also available via admin/community.php).
    $sql = is_admin() ? 'DELETE FROM community_posts WHERE id = ?' : 'DELETE FROM community_posts WHERE id = ? AND user_id = ?';
    $params = is_admin() ? [(int) $_POST['delete_post_id']] : [(int) $_POST['delete_post_id'], $userId];
    db()->prepare($sql)->execute($params);
    flash_set('success', 'Post deleted.');
    redirect('/community.php');
}

$category = (string) ($_GET['category'] ?? '');
$where  = '1=1';
$params = [];
if (isset(COMMUNITY_CATEGORIES[$category])) {
    $where = 'p.category = ?';
    $params[] = $category;
}
$stmt = db()->prepare(
    "SELECT p.*, u.full_name, (SELECT COUNT(*) FROM community_comments c WHERE c.post_id = p.id) AS comment_count
     FROM community_posts p JOIN users u ON u.id = p.user_id
     WHERE $where ORDER BY p.is_pinned DESC, p.created_at DESC LIMIT 100"
);
$stmt->execute($params);
$posts = $stmt->fetchAll();

$pageTitle = 'Community';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <div class="af-lab-hero">
                <div><h1>Community</h1><p class="af-muted">Discussions, questions and study groups with fellow students.</p></div>
            </div>

            <div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px;">
                <a href="<?= APP_URL ?>/community.php" class="af-btn <?= $category === '' ? 'af-btn-gold' : 'af-btn-ghost' ?>">All</a>
                <?php foreach (COMMUNITY_CATEGORIES as $k => $l): ?>
                    <a href="<?= APP_URL ?>/community.php?category=<?= e($k) ?>" class="af-btn <?= $category === $k ? 'af-btn-gold' : 'af-btn-ghost' ?>"><?= e($l) ?></a>
                <?php endforeach; ?>
            </div>

            <?php foreach ($posts as $p): ?>
                <div class="af-card" style="margin-bottom:12px;">
                    <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap;">
                        <a href="<?= APP_URL ?>/community_post.php?id=<?= (int) $p['id'] ?>" style="text-decoration:none;"><h3 style="margin:0;"><?= $p['is_pinned'] ? '&#128204; ' : '' ?><?= e($p['title']) ?></h3></a>
                        <span class="af-badge af-badge-muted"><?= e(COMMUNITY_CATEGORIES[$p['category']] ?? $p['category']) ?></span>
                    </div>
                    <p class="af-muted" style="margin:6px 0;">by <?= e($p['full_name']) ?> &middot; <?= e(date('d M Y', strtotime($p['created_at']))) ?> &middot; <?= (int) $p['comment_count'] ?> repl<?= (int) $p['comment_count'] === 1 ? 'y' : 'ies' ?></p>
                </div>
            <?php endforeach; ?>
            <?php if (!$posts): ?><p class="af-muted">No posts yet - be the first to start a discussion.</p><?php endif; ?>

            <div class="af-card" style="margin-top:20px; max-width:640px;">
                <h3>New Post</h3>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="create">
                    <div class="af-field"><label>Category</label>
                        <select name="category">
                            <?php foreach (COMMUNITY_CATEGORIES as $k => $l): ?>
                                <?php if ($k === 'announcement' && !is_admin()) continue; ?>
                                <option value="<?= e($k) ?>"><?= e($l) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Title</label><input type="text" name="title" required></div>
                    <div class="af-field"><label>Message</label><textarea name="body" rows="4" required></textarea></div>
                    <button type="submit" class="af-btn af-btn-gold">Post</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
