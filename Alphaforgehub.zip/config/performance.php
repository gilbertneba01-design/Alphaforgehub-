<?php
/**
 * ALPHA FORGE HUB - Trading Performance Analytics
 *
 * Computes statistics purely from the student's own trading_journal rows.
 * This is DIFFERENT from course progress (progress.php) - this measures
 * trading performance, not learning progress. Load config/journal.php first
 * for the filter helper and constants.
 */

/**
 * @param array $filters same shape accepted by journal_list()
 * @return array a full stats bundle for the performance page
 */
function performance_compute(int $userId, array $filters = []): array {
    $trades = journal_list($userId, $filters, 5000);

    $closed = array_values(array_filter($trades, fn($t) => $t['result'] !== 'open'));
    $wins   = array_values(array_filter($trades, fn($t) => $t['result'] === 'win'));
    $losses = array_values(array_filter($trades, fn($t) => $t['result'] === 'loss'));
    $be     = array_values(array_filter($trades, fn($t) => $t['result'] === 'breakeven'));

    $totalTrades  = count($trades);
    $totalClosed  = count($closed);
    $winCount     = count($wins);
    $lossCount    = count($losses);
    $winRate      = $totalClosed > 0 ? round(($winCount / $totalClosed) * 100, 1) : 0.0;

    $sumPl = function (array $rows): float {
        return array_sum(array_map(fn($t) => (float) ($t['profit_loss'] ?? 0), $rows));
    };
    $totalPl   = $sumPl($closed);
    $avgWin    = $winCount > 0 ? round($sumPl($wins) / $winCount, 2) : 0.0;
    $avgLoss   = $lossCount > 0 ? round($sumPl($losses) / $lossCount, 2) : 0.0;
    $avgRR     = ($avgLoss != 0.0) ? round(abs($avgWin / $avgLoss), 2) : null;

    // ---- breakdown helper: group by a key, compute count/wins/win-rate/total P&L ----
    $groupBy = function (array $rows, callable $keyFn) {
        $groups = [];
        foreach ($rows as $t) {
            $key = $keyFn($t);
            if ($key === null || $key === '') {
                continue;
            }
            if (!isset($groups[$key])) {
                $groups[$key] = ['label' => $key, 'count' => 0, 'wins' => 0, 'closed' => 0, 'pl' => 0.0];
            }
            $groups[$key]['count']++;
            if ($t['result'] !== 'open') {
                $groups[$key]['closed']++;
                $groups[$key]['pl'] += (float) ($t['profit_loss'] ?? 0);
            }
            if ($t['result'] === 'win') {
                $groups[$key]['wins']++;
            }
        }
        foreach ($groups as &$g) {
            $g['win_rate'] = $g['closed'] > 0 ? round(($g['wins'] / $g['closed']) * 100, 1) : 0.0;
        }
        unset($g);
        return array_values($groups);
    };

    $byPair      = $groupBy($trades, fn($t) => $t['pair']);
    $byStrategy  = $groupBy($trades, fn($t) => $t['strategy']);
    $bySession   = $groupBy($trades, fn($t) => JOURNAL_SESSIONS[$t['session']] ?? null);
    $byTimeframe = $groupBy($trades, fn($t) => $t['timeframe']);
    $byDirection = $groupBy($trades, fn($t) => JOURNAL_DIRECTIONS[$t['direction']] ?? null);

    usort($byPair, fn($a, $b) => $b['pl'] <=> $a['pl']);
    usort($byStrategy, fn($a, $b) => $b['pl'] <=> $a['pl']);

    $bestPair  = $byPair[0] ?? null;
    $worstPair = !empty($byPair) ? $byPair[count($byPair) - 1] : null;
    $bestStrategy = $byStrategy[0] ?? null;

    // ---- psychology: win rate per emotion (before-trade emotion vs outcome) ----
    $psychology = $groupBy($trades, fn($t) => JOURNAL_EMOTIONS[$t['emotion_before']] ?? null);
    usort($psychology, fn($a, $b) => $b['count'] <=> $a['count']);

    return [
        'total_trades'  => $totalTrades,
        'total_closed'  => $totalClosed,
        'wins'          => $winCount,
        'losses'        => $lossCount,
        'breakeven'     => count($be),
        'win_rate'      => $winRate,
        'total_pl'      => round($totalPl, 2),
        'avg_win'       => $avgWin,
        'avg_loss'      => $avgLoss,
        'avg_rr'        => $avgRR,
        'by_pair'       => $byPair,
        'by_strategy'   => $byStrategy,
        'by_session'    => $bySession,
        'by_timeframe'  => $byTimeframe,
        'by_direction'  => $byDirection,
        'best_pair'     => $bestPair,
        'worst_pair'    => $worstPair,
        'best_strategy' => $bestStrategy,
        'psychology'    => $psychology,
    ];
}
