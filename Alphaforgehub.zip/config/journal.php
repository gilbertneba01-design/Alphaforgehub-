<?php
/**
 * ALPHA FORGE HUB - Trading Journal helpers
 *
 * Load config/functions.php first (db(), csrf helpers, e(), current_user()).
 * All queries here are ownership-scoped to the given $userId - never trust
 * a trade id from the client without checking it belongs to the caller.
 */

const JOURNAL_DIRECTIONS = ['buy' => 'Buy', 'sell' => 'Sell'];
const JOURNAL_RESULTS    = ['open' => 'Open', 'win' => 'Win', 'loss' => 'Loss', 'breakeven' => 'Breakeven'];
const JOURNAL_SESSIONS   = [
    'sydney'   => 'Sydney',
    'tokyo'    => 'Tokyo',
    'london'   => 'London',
    'new_york' => 'New York',
    'overlap'  => 'Session Overlap',
];
const JOURNAL_EMOTIONS = [
    'calm'          => 'Calm',
    'confident'     => 'Confident',
    'fearful'       => 'Fearful',
    'greedy'        => 'Greedy',
    'fomo'          => 'FOMO',
    'hesitant'      => 'Hesitant',
    'angry'         => 'Angry',
    'revenge'       => 'Revenge trading',
    'overconfident' => 'Overconfident',
    'distracted'    => 'Distracted',
];

const JOURNAL_UPLOAD_SUBDIR   = '/uploads/journal';
const JOURNAL_MAX_FILE_BYTES  = 3 * 1024 * 1024; // 3 MB
const JOURNAL_ALLOWED_MIME    = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
const JOURNAL_MAX_SCREENSHOTS = 4; // per trade

// -------------------------------------------------------------------
// VALIDATION
// -------------------------------------------------------------------

/** @return string[] list of validation errors (empty = valid) */
function journal_validate(array $data): array {
    $errors = [];

    if (trim((string) ($data['pair'] ?? '')) === '') {
        $errors[] = 'Currency pair is required.';
    }
    if (!isset(JOURNAL_DIRECTIONS[$data['direction'] ?? ''])) {
        $errors[] = 'Choose a valid direction (Buy or Sell).';
    }
    if (!is_numeric($data['entry_price'] ?? null)) {
        $errors[] = 'Entry price must be a number.';
    }
    foreach (['stop_loss', 'take_profit', 'lot_size', 'risk_amount', 'risk_percent', 'profit_loss'] as $numField) {
        $val = $data[$numField] ?? '';
        if ($val !== '' && $val !== null && !is_numeric($val)) {
            $errors[] = ucwords(str_replace('_', ' ', $numField)) . ' must be a number.';
        }
    }
    if (!isset(JOURNAL_RESULTS[$data['result'] ?? 'open'])) {
        $errors[] = 'Invalid trade result.';
    }
    if (!empty($data['session']) && !isset(JOURNAL_SESSIONS[$data['session']])) {
        $errors[] = 'Invalid trading session.';
    }
    foreach (['emotion_before', 'emotion_during', 'emotion_after'] as $emoField) {
        if (!empty($data[$emoField]) && !isset(JOURNAL_EMOTIONS[$data[$emoField]])) {
            $errors[] = 'Invalid emotion value.';
        }
    }
    if (trim((string) ($data['trade_date'] ?? '')) === '' || !strtotime((string) $data['trade_date'])) {
        $errors[] = 'A valid trade date is required.';
    }

    return $errors;
}

// -------------------------------------------------------------------
// CRUD (all ownership-scoped by user_id)
// -------------------------------------------------------------------

function journal_create(int $userId, array $d): int {
    $sql = 'INSERT INTO trading_journal
        (user_id, pair, direction, entry_price, stop_loss, take_profit, lot_size, risk_amount, risk_percent,
         result, profit_loss, strategy, timeframe, session, entry_reason, exit_reason,
         emotion_before, emotion_during, emotion_after, notes, trade_date)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    db()->prepare($sql)->execute([
        $userId,
        trim($d['pair']),
        $d['direction'],
        $d['entry_price'],
        $d['stop_loss'] !== '' ? $d['stop_loss'] : null,
        $d['take_profit'] !== '' ? $d['take_profit'] : null,
        $d['lot_size'] !== '' ? $d['lot_size'] : null,
        $d['risk_amount'] !== '' ? $d['risk_amount'] : null,
        $d['risk_percent'] !== '' ? $d['risk_percent'] : null,
        $d['result'] ?: 'open',
        $d['profit_loss'] !== '' ? $d['profit_loss'] : null,
        $d['strategy'] !== '' ? trim($d['strategy']) : null,
        $d['timeframe'] !== '' ? trim($d['timeframe']) : null,
        $d['session'] !== '' ? $d['session'] : null,
        $d['entry_reason'] ?: null,
        $d['exit_reason'] ?: null,
        $d['emotion_before'] ?: null,
        $d['emotion_during'] ?: null,
        $d['emotion_after'] ?: null,
        $d['notes'] ?: null,
        date('Y-m-d', strtotime($d['trade_date'])),
    ]);
    return (int) db()->lastInsertId();
}

function journal_update(int $userId, int $tradeId, array $d): bool {
    if (!journal_get($userId, $tradeId)) {
        return false;
    }
    $sql = 'UPDATE trading_journal SET
        pair=?, direction=?, entry_price=?, stop_loss=?, take_profit=?, lot_size=?, risk_amount=?, risk_percent=?,
        result=?, profit_loss=?, strategy=?, timeframe=?, session=?, entry_reason=?, exit_reason=?,
        emotion_before=?, emotion_during=?, emotion_after=?, notes=?, trade_date=?
        WHERE id = ? AND user_id = ?';
    db()->prepare($sql)->execute([
        trim($d['pair']),
        $d['direction'],
        $d['entry_price'],
        $d['stop_loss'] !== '' ? $d['stop_loss'] : null,
        $d['take_profit'] !== '' ? $d['take_profit'] : null,
        $d['lot_size'] !== '' ? $d['lot_size'] : null,
        $d['risk_amount'] !== '' ? $d['risk_amount'] : null,
        $d['risk_percent'] !== '' ? $d['risk_percent'] : null,
        $d['result'] ?: 'open',
        $d['profit_loss'] !== '' ? $d['profit_loss'] : null,
        $d['strategy'] !== '' ? trim($d['strategy']) : null,
        $d['timeframe'] !== '' ? trim($d['timeframe']) : null,
        $d['session'] !== '' ? $d['session'] : null,
        $d['entry_reason'] ?: null,
        $d['exit_reason'] ?: null,
        $d['emotion_before'] ?: null,
        $d['emotion_during'] ?: null,
        $d['emotion_after'] ?: null,
        $d['notes'] ?: null,
        date('Y-m-d', strtotime($d['trade_date'])),
        $tradeId,
        $userId,
    ]);
    return true;
}

/** Ownership-checked fetch with its screenshots attached. */
function journal_get(int $userId, int $tradeId): ?array {
    $stmt = db()->prepare('SELECT * FROM trading_journal WHERE id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$tradeId, $userId]);
    $trade = $stmt->fetch();
    if (!$trade) {
        return null;
    }
    $shotStmt = db()->prepare('SELECT id, file_path FROM trading_journal_screenshots WHERE journal_id = ? ORDER BY id');
    $shotStmt->execute([$tradeId]);
    $trade['screenshots'] = $shotStmt->fetchAll();
    return $trade;
}

/** Deletes a trade (and its screenshot files) - ownership-checked. */
function journal_delete(int $userId, int $tradeId): bool {
    $trade = journal_get($userId, $tradeId);
    if (!$trade) {
        return false;
    }
    foreach ($trade['screenshots'] as $shot) {
        $full = __DIR__ . '/..' . $shot['file_path'];
        if (is_file($full)) {
            @unlink($full);
        }
    }
    db()->prepare('DELETE FROM trading_journal WHERE id = ? AND user_id = ?')->execute([$tradeId, $userId]);
    return true;
}

/**
 * @param array $filters pair, strategy, result, session, direction, date_from, date_to
 */
function journal_list(int $userId, array $filters = [], int $limit = 200): array {
    $where  = ['user_id = ?'];
    $params = [$userId];

    if (!empty($filters['pair'])) {
        $where[]  = 'pair = ?';
        $params[] = $filters['pair'];
    }
    if (!empty($filters['strategy'])) {
        $where[]  = 'strategy = ?';
        $params[] = $filters['strategy'];
    }
    if (!empty($filters['result']) && isset(JOURNAL_RESULTS[$filters['result']])) {
        $where[]  = 'result = ?';
        $params[] = $filters['result'];
    }
    if (!empty($filters['session']) && isset(JOURNAL_SESSIONS[$filters['session']])) {
        $where[]  = 'session = ?';
        $params[] = $filters['session'];
    }
    if (!empty($filters['direction']) && isset(JOURNAL_DIRECTIONS[$filters['direction']])) {
        $where[]  = 'direction = ?';
        $params[] = $filters['direction'];
    }
    if (!empty($filters['date_from']) && strtotime($filters['date_from'])) {
        $where[]  = 'trade_date >= ?';
        $params[] = date('Y-m-d', strtotime($filters['date_from']));
    }
    if (!empty($filters['date_to']) && strtotime($filters['date_to'])) {
        $where[]  = 'trade_date <= ?';
        $params[] = date('Y-m-d', strtotime($filters['date_to']));
    }
    if (!empty($filters['search'])) {
        $where[]  = '(pair LIKE ? OR strategy LIKE ? OR notes LIKE ?)';
        $like     = '%' . $filters['search'] . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $sql = 'SELECT * FROM trading_journal WHERE ' . implode(' AND ', $where)
         . ' ORDER BY trade_date DESC, id DESC LIMIT ' . (int) $limit;
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function journal_pairs_used(int $userId): array {
    $stmt = db()->prepare('SELECT DISTINCT pair FROM trading_journal WHERE user_id = ? ORDER BY pair');
    $stmt->execute([$userId]);
    return array_column($stmt->fetchAll(), 'pair');
}

function journal_strategies_used(int $userId): array {
    $stmt = db()->prepare("SELECT DISTINCT strategy FROM trading_journal WHERE user_id = ? AND strategy IS NOT NULL AND strategy <> '' ORDER BY strategy");
    $stmt->execute([$userId]);
    return array_column($stmt->fetchAll(), 'strategy');
}

// -------------------------------------------------------------------
// SCREENSHOT UPLOAD (secure: real-mime check, random filename, capped size,
// stored under a directory with PHP execution disabled - see the .htaccess
// created alongside this feature)
// -------------------------------------------------------------------

/** @return array{success:bool, error:?string} */
function journal_save_screenshot(int $userId, int $tradeId, array $file): array {
    if (!journal_get($userId, $tradeId)) {
        return ['success' => false, 'error' => 'Trade not found.'];
    }

    $countStmt = db()->prepare('SELECT COUNT(*) FROM trading_journal_screenshots WHERE journal_id = ?');
    $countStmt->execute([$tradeId]);
    if ((int) $countStmt->fetchColumn() >= JOURNAL_MAX_SCREENSHOTS) {
        return ['success' => false, 'error' => 'Maximum ' . JOURNAL_MAX_SCREENSHOTS . ' screenshots per trade.'];
    }

    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return ['success' => false, 'error' => null]; // nothing submitted, not an error
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Upload failed. Please try again.'];
    }
    if ($file['size'] > JOURNAL_MAX_FILE_BYTES) {
        return ['success' => false, 'error' => 'Image is too large (max 3 MB).'];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    if (!isset(JOURNAL_ALLOWED_MIME[$mime])) {
        return ['success' => false, 'error' => 'Only JPG, PNG or WEBP images are allowed.'];
    }
    $ext = JOURNAL_ALLOWED_MIME[$mime];

    $dirRel  = JOURNAL_UPLOAD_SUBDIR . '/' . $userId;
    $dirFull = __DIR__ . '/..' . $dirRel;
    if (!is_dir($dirFull)) {
        mkdir($dirFull, 0755, true);
        // Belt-and-braces: make sure PHP can never execute from inside uploads.
        $ht = $dirFull . '/.htaccess';
        if (!is_file($ht)) {
            file_put_contents($ht, "<FilesMatch \"\\.(php|phtml|php3|php4|php5|pht)$\">\n    Require all denied\n</FilesMatch>\n");
        }
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $destFull = $dirFull . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $destFull)) {
        return ['success' => false, 'error' => 'Could not save the uploaded image.'];
    }

    $relPath = $dirRel . '/' . $filename;
    db()->prepare('INSERT INTO trading_journal_screenshots (journal_id, user_id, file_path) VALUES (?, ?, ?)')
        ->execute([$tradeId, $userId, $relPath]);

    return ['success' => true, 'error' => null];
}

function journal_delete_screenshot(int $userId, int $screenshotId): bool {
    $stmt = db()->prepare('SELECT * FROM trading_journal_screenshots WHERE id = ? AND user_id = ?');
    $stmt->execute([$screenshotId, $userId]);
    $shot = $stmt->fetch();
    if (!$shot) {
        return false;
    }
    $full = __DIR__ . '/..' . $shot['file_path'];
    if (is_file($full)) {
        @unlink($full);
    }
    db()->prepare('DELETE FROM trading_journal_screenshots WHERE id = ? AND user_id = ?')->execute([$screenshotId, $userId]);
    return true;
}
