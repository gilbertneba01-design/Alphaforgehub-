<?php
/**
 * ALPHA FORGE HUB - AI Tutor configuration & data access
 *
 * Loaded explicitly by ai_tutor.php and api/ai/chat.php (NOT pulled into
 * every page via functions.php) - same pattern as config/chartlab.php.
 * Load config/functions.php first (it provides db(), csrf helpers, env(), etc.).
 *
 * SECURITY: API keys are only ever read here, server-side, from
 * config/.env.php / real environment variables. They are never sent to
 * the browser and never logged.
 */

// ---- Provider selection & models ----
define('AI_TUTOR_PROVIDER', env('AI_PROVIDER', 'openai')); // 'openai' | 'anthropic'

define('OPENAI_API_KEY', env('OPENAI_API_KEY', ''));
define('OPENAI_MODEL', env('OPENAI_MODEL', 'gpt-4o-mini'));

define('ANTHROPIC_API_KEY', env('ANTHROPIC_API_KEY', ''));
define('ANTHROPIC_MODEL', env('ANTHROPIC_MODEL', 'claude-sonnet-4-6'));

// ---- Usage limits (protect API cost; tune freely) ----
const AI_TUTOR_DAILY_LIMIT_FREE    = 12;   // messages/day for students without an active subscription
const AI_TUTOR_DAILY_LIMIT_PREMIUM = 60;   // messages/day for active subscribers and admins
const AI_TUTOR_MAX_INPUT_CHARS     = 1500; // per-message student input cap
const AI_TUTOR_MAX_HISTORY_TURNS   = 12;   // prior messages replayed to the model for context
const AI_TUTOR_TIMEOUT_SECONDS     = 25;   // AI provider HTTP timeout

const AI_TUTOR_MODES = ['explain', 'beginner', 'intermediate', 'advanced', 'quiz', 'hint', 'mistake'];

const AI_TUTOR_MODE_LABELS = [
    'explain'      => 'Explain',
    'beginner'     => 'Beginner',
    'intermediate' => 'Intermediate',
    'advanced'     => 'Advanced',
    'quiz'         => 'Quiz me',
    'hint'         => 'Give me a hint',
    'mistake'      => 'Explain my mistake',
];

/** True once an API key is actually configured for the selected provider. */
function ai_tutor_available(): bool {
    if (AI_TUTOR_PROVIDER === 'anthropic') {
        return ANTHROPIC_API_KEY !== '';
    }
    return OPENAI_API_KEY !== '';
}

// -------------------------------------------------------------------
// USAGE / QUOTA (per user, per calendar day - server-side, never trust the client)
// -------------------------------------------------------------------

function ai_tutor_daily_limit(int $userId): int {
    return (is_admin() || has_active_subscription($userId)) ? AI_TUTOR_DAILY_LIMIT_PREMIUM : AI_TUTOR_DAILY_LIMIT_FREE;
}

function ai_tutor_messages_used_today(int $userId): int {
    $stmt = db()->prepare(
        "SELECT COUNT(*) FROM ai_messages WHERE user_id = ? AND role = 'user' AND created_at >= CURDATE()"
    );
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

function ai_tutor_quota_remaining(int $userId): int {
    return max(0, ai_tutor_daily_limit($userId) - ai_tutor_messages_used_today($userId));
}

// -------------------------------------------------------------------
// CONVERSATIONS
// -------------------------------------------------------------------

function ai_tutor_create_conversation(int $userId, ?int $courseId, ?int $lessonId, string $mode): int {
    $title = 'New conversation';
    if ($lessonId) {
        $stmt = db()->prepare('SELECT title FROM lessons WHERE id = ?');
        $stmt->execute([$lessonId]);
        $lt = $stmt->fetchColumn();
        if ($lt) {
            $title = (string) $lt;
        }
    }
    $ins = db()->prepare(
        'INSERT INTO ai_conversations (user_id, course_id, lesson_id, title, mode) VALUES (?, ?, ?, ?, ?)'
    );
    $ins->execute([$userId, $courseId ?: null, $lessonId ?: null, $title, $mode]);
    return (int) db()->lastInsertId();
}

/** Ownership-checked fetch. Returns null if it doesn't exist or belongs to someone else. */
function ai_tutor_get_conversation(int $userId, int $conversationId): ?array {
    $stmt = db()->prepare('SELECT * FROM ai_conversations WHERE id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$conversationId, $userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function ai_tutor_list_conversations(int $userId, int $limit = 20): array {
    $stmt = db()->prepare(
        'SELECT id, title, mode, lesson_id, course_id, updated_at
         FROM ai_conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT ' . (int) $limit
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function ai_tutor_touch_conversation(int $conversationId): void {
    db()->prepare('UPDATE ai_conversations SET updated_at = NOW() WHERE id = ?')->execute([$conversationId]);
}

function ai_tutor_rename_conversation_if_default(int $conversationId, string $title): void {
    $stmt = db()->prepare("UPDATE ai_conversations SET title = ? WHERE id = ? AND title = 'New conversation'");
    $stmt->execute([mb_substr($title, 0, 70), $conversationId]);
}

function ai_tutor_get_messages(int $conversationId, int $limit = 200): array {
    $stmt = db()->prepare(
        'SELECT role, content, mode, created_at FROM ai_messages
         WHERE conversation_id = ? ORDER BY id ASC LIMIT ' . (int) $limit
    );
    $stmt->execute([$conversationId]);
    return $stmt->fetchAll();
}

function ai_tutor_add_message(int $conversationId, int $userId, string $role, string $content, ?string $mode = null): void {
    $ins = db()->prepare(
        'INSERT INTO ai_messages (conversation_id, user_id, role, mode, content) VALUES (?, ?, ?, ?, ?)'
    );
    $ins->execute([$conversationId, $userId, $role, $mode, $content]);
}

// -------------------------------------------------------------------
// LESSON CONTEXT (so the tutor "knows" what the student is studying)
// -------------------------------------------------------------------

function ai_tutor_lesson_context(?int $lessonId): ?array {
    if (!$lessonId) {
        return null;
    }
    $stmt = db()->prepare(
        "SELECT l.title AS lesson_title, l.content AS lesson_content,
                m.title AS module_title, c.title AS course_title, c.id AS course_id
         FROM lessons l
         JOIN modules m ON m.id = l.module_id
         JOIN courses c ON c.id = m.course_id
         WHERE l.id = ? LIMIT 1"
    );
    $stmt->execute([$lessonId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

// -------------------------------------------------------------------
// SYSTEM PROMPT (this is what keeps it "Alpha Forge AI Tutor", not a generic chatbot)
// -------------------------------------------------------------------

function ai_tutor_system_prompt(string $mode, ?array $lessonCtx): string {
    $lines   = [];
    $lines[] = 'You are the Alpha Forge AI Tutor, a dedicated Forex education coach built into the '
             . 'Alpha Forge HUB learning platform. You are not a general-purpose assistant - stay '
             . 'focused on Forex trading education: market structure, technical analysis, risk '
             . 'management, trading psychology, the platform\'s Chart Lab exercises, and the '
             . 'student\'s own trading journal and discipline.';
    $lines[] = 'Rules you must always follow:';
    $lines[] = '- Never guarantee profits, promise specific returns, or claim certainty about future price movement.';
    $lines[] = '- Never tell the student to place a specific real trade right now, and never claim to predict the market.';
    $lines[] = '- Keep answers educational: explain concepts, give concrete examples, ask guiding questions, and encourage sound risk management and journaling.';
    $lines[] = '- Keep replies focused and reasonably concise unless the student explicitly asks for a deep dive.';
    $lines[] = '- If the student asks something unrelated to Forex trading education, gently redirect them back to the subject.';

    $modeInstructions = [
        'explain'      => 'Current mode: EXPLAIN. Clearly explain the concept the student is asking about, with a concrete example.',
        'beginner'     => 'Current mode: BEGINNER. Use simple, plain language and everyday analogies. Avoid jargon, or define it the moment you use it.',
        'intermediate' => 'Current mode: INTERMEDIATE. You may use standard technical-analysis terminology without over-explaining the basics.',
        'advanced'     => 'Current mode: ADVANCED. Go deeper into market-structure reasoning and nuanced technical-analysis detail.',
        'quiz'         => 'Current mode: QUIZ ME. Ask the student one educational question (multiple-choice or short-answer) about their current topic or lesson. Wait for their answer before revealing whether they were right, then explain why.',
        'hint'         => 'Current mode: GIVE ME A HINT. Give a short nudge in the right direction WITHOUT revealing the full answer outright.',
        'mistake'      => 'Current mode: EXPLAIN MY MISTAKE. The student got something wrong (a quiz question or a Chart Lab exercise). Explain clearly why their answer was incorrect and what the correct reasoning is, without being discouraging.',
    ];
    $lines[] = $modeInstructions[$mode] ?? $modeInstructions['explain'];

    if ($lessonCtx) {
        $snippet = mb_substr((string) $lessonCtx['lesson_content'], 0, 2000);
        $lines[] = 'The student is currently studying this lesson on Alpha Forge HUB:';
        $lines[] = 'Course: ' . $lessonCtx['course_title'];
        $lines[] = 'Module: ' . $lessonCtx['module_title'];
        $lines[] = 'Lesson: ' . $lessonCtx['lesson_title'];
        $lines[] = 'Lesson content (may be truncated): ' . $snippet;
        $lines[] = 'Prefer answering in the context of this lesson when it is relevant, but still answer general Forex questions the student asks.';
    }

    return implode("\n", $lines);
}
