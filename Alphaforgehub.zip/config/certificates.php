<?php
/**
 * ALPHA FORGE HUB - Certificates
 * A certificate is only ever issued once a student has genuinely reached
 * 100% of a published course's lessons - the same completion rule already
 * used on progress.php. Load config/functions.php first.
 */

/** @return array{total:int, done:int, percent:int} */
function course_completion(int $userId, int $courseId): array {
    $totalStmt = db()->prepare(
        "SELECT COUNT(*) FROM lessons l JOIN modules m ON m.id = l.module_id WHERE m.course_id = ? AND l.status = 'published'"
    );
    $totalStmt->execute([$courseId]);
    $total = (int) $totalStmt->fetchColumn();

    $doneStmt = db()->prepare(
        "SELECT COUNT(*) FROM lesson_progress lp
         JOIN lessons l ON l.id = lp.lesson_id
         JOIN modules m ON m.id = l.module_id
         WHERE m.course_id = ? AND lp.user_id = ?"
    );
    $doneStmt->execute([$courseId, $userId]);
    $done = (int) $doneStmt->fetchColumn();

    return ['total' => $total, 'done' => $done, 'percent' => $total > 0 ? (int) round(($done / $total) * 100) : 0];
}

function course_is_completed(int $userId, int $courseId): bool {
    $c = course_completion($userId, $courseId);
    return $c['total'] > 0 && $c['done'] >= $c['total'];
}

function certificate_generate_code(): string {
    do {
        $code = 'AF-' . strtoupper(bin2hex(random_bytes(4)));
        $stmt = db()->prepare('SELECT COUNT(*) FROM certificates WHERE certificate_code = ?');
        $stmt->execute([$code]);
    } while ((int) $stmt->fetchColumn() > 0);
    return $code;
}

/** Returns the existing certificate for this user+course, or null if not issued. */
function certificate_find(int $userId, int $courseId): ?array {
    $stmt = db()->prepare('SELECT * FROM certificates WHERE user_id = ? AND course_id = ? LIMIT 1');
    $stmt->execute([$userId, $courseId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Issues a certificate if the course is genuinely complete and one doesn't
 * already exist. Returns the certificate row, or null if not eligible.
 */
function certificate_get_or_issue(int $userId, int $courseId): ?array {
    $existing = certificate_find($userId, $courseId);
    if ($existing) {
        return $existing;
    }
    if (!course_is_completed($userId, $courseId)) {
        return null;
    }
    $code = certificate_generate_code();
    db()->prepare('INSERT INTO certificates (user_id, course_id, certificate_code) VALUES (?, ?, ?)')
        ->execute([$userId, $courseId, $code]);
    return certificate_find($userId, $courseId);
}

/** Ownership-checked fetch, with course + student info for display. */
function certificate_get_for_view(int $userId, string $code): ?array {
    $stmt = db()->prepare(
        'SELECT cert.*, c.title AS course_title, u.full_name AS student_name
         FROM certificates cert
         JOIN courses c ON c.id = cert.course_id
         JOIN users u ON u.id = cert.user_id
         WHERE cert.certificate_code = ? AND cert.user_id = ? LIMIT 1'
    );
    $stmt->execute([$code, $userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Public verification (no ownership check) - used by certificate_verify.php. */
function certificate_verify_public(string $code): ?array {
    $stmt = db()->prepare(
        'SELECT cert.certificate_code, cert.issued_at, c.title AS course_title, u.full_name AS student_name
         FROM certificates cert
         JOIN courses c ON c.id = cert.course_id
         JOIN users u ON u.id = cert.user_id
         WHERE cert.certificate_code = ? LIMIT 1'
    );
    $stmt->execute([$code]);
    $row = $stmt->fetch();
    return $row ?: null;
}
