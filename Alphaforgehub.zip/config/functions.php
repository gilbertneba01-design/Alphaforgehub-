<?php
/**
 * ALPHA FORGE - Shared helper functions
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/totp.php';

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . APP_URL . $path);
    exit;
}

function flash_set(string $key, string $message): void {
    $_SESSION['flash'][$key] = $message;
}

function flash_get(string $key): ?string {
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function slugify(string $text): string {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = trim($text, '-');
    $text = iconv('utf-8', 'ascii//TRANSLIT', $text) ?: $text;
    $text = strtolower(preg_replace('~[^-\w]+~', '', $text));
    return $text ?: 'item-' . substr(bin2hex(random_bytes(3)), 0, 6);
}

function valid_email(string $email): bool {
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Returns ['total' => int, 'completed' => int, 'percent' => float] for a student,
 * calculated live from the database (never hard-coded / cached in session).
 */
function get_student_progress(int $userId): array {
    $pdo = db();

    $totalStmt = $pdo->prepare(
        "SELECT COUNT(*) AS c FROM lessons l
         JOIN modules m ON m.id = l.module_id
         JOIN courses c ON c.id = m.course_id
         WHERE l.status = 'published' AND c.status = 'published'"
    );
    $totalStmt->execute();
    $total = (int) $totalStmt->fetch()['c'];

    $completedStmt = $pdo->prepare(
        "SELECT COUNT(*) AS c FROM lesson_progress lp
         JOIN lessons l ON l.id = lp.lesson_id
         WHERE lp.user_id = ? AND l.status = 'published'"
    );
    $completedStmt->execute([$userId]);
    $completed = (int) $completedStmt->fetch()['c'];

    $percent = $total > 0 ? round(($completed / $total) * 100) : 0;

    return ['total' => $total, 'completed' => $completed, 'percent' => $percent];
}

function lesson_is_completed(int $userId, int $lessonId): bool {
    $stmt = db()->prepare('SELECT 1 FROM lesson_progress WHERE user_id = ? AND lesson_id = ? LIMIT 1');
    $stmt->execute([$userId, $lessonId]);
    return (bool) $stmt->fetchColumn();
}

function get_setting(string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $stmt = db()->query('SELECT setting_key, setting_value FROM site_settings');
        foreach ($stmt->fetchAll() as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return $cache[$key] ?? $default;
}

function format_money(float $amount, string $currency = 'XAF'): string {
    return number_format($amount, 0, '.', ',') . ' ' . $currency;
}

/**
 * ---------------------------------------------------------
 * INTERNATIONALIZATION (English / French)
 * ---------------------------------------------------------
 * Strings live in /language/en.php and /language/fr.php as flat
 * key => value arrays. Never hardcode UI text directly in PHP going
 * forward for anything you want translated - add a key to both files
 * and call t('key') instead.
 */
function current_language(): string {
    if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'fr'], true)) {
        $_SESSION['lang'] = $_GET['lang'];
        if (is_logged_in()) {
            db()->prepare('UPDATE users SET preferred_language = ? WHERE id = ?')->execute([$_GET['lang'], current_user()['id']]);
        }
    }
    if (isset($_SESSION['lang'])) {
        return $_SESSION['lang'];
    }
    if (is_logged_in() && !empty(current_user()['preferred_language'])) {
        return current_user()['preferred_language'];
    }
    return 'en';
}

function t(string $key, array $vars = []): string {
    static $strings = [];
    foreach (['en', current_language()] as $l) {
        if (!isset($strings[$l])) {
            $file = __DIR__ . '/../language/' . $l . '.php';
            $strings[$l] = is_file($file) ? (require $file) : [];
        }
    }
    $lang = current_language();
    $text = $strings[$lang][$key] ?? ($strings['en'][$key] ?? $key); // fall back to English, then the key
    foreach ($vars as $k => $v) {
        $text = str_replace('{' . $k . '}', (string) $v, $text);
    }
    return $text;
}

/** Escaped t() for use inside HTML. */
function te(string $key, array $vars = []): string {
    return e(t($key, $vars));
}

/**
 * Picks the translated version of a DB text column when a translation row
 * exists for the current language; otherwise the original (English) text.
 * $table is one of the two whitelisted translation tables.
 */
function translated_field(string $table, int $id, string $field, string $original): string {
    $lang = current_language();
    if ($lang === 'en') return $original;
    $map = ['course_translations' => 'course_id', 'lesson_translations' => 'lesson_id'];
    if (!isset($map[$table]) || !in_array($field, ['title', 'description', 'content'], true)) return $original;
    try {
        $stmt = db()->prepare("SELECT `$field` FROM `$table` WHERE `{$map[$table]}` = ? AND lang = ? LIMIT 1");
        $stmt->execute([$id, $lang]);
        $v = $stmt->fetchColumn();
        return ($v !== false && trim((string) $v) !== '') ? (string) $v : $original;
    } catch (Throwable $ex) {
        return $original; // migration not run yet
    }
}

// -------------------------------------------------------------------
// NOTIFICATIONS (best effort: never break a page if the table is missing)
// -------------------------------------------------------------------
function notify(int $userId, string $type, string $title, string $body = '', string $link = ''): void {
    try {
        db()->prepare('INSERT INTO notifications (user_id, type, title, body, link) VALUES (?,?,?,?,?)')
            ->execute([$userId, $type, mb_substr($title, 0, 190), mb_substr($body, 0, 500), mb_substr($link, 0, 255)]);
    } catch (Throwable $ex) { /* table not migrated yet */ }
}

function notify_all_students(string $type, string $title, string $body = '', string $link = ''): void {
    try {
        db()->prepare("INSERT INTO notifications (user_id, type, title, body, link)
                       SELECT id, ?, ?, ?, ? FROM users WHERE role = 'student' AND status = 'active'")
            ->execute([$type, mb_substr($title, 0, 190), mb_substr($body, 0, 500), mb_substr($link, 0, 255)]);
    } catch (Throwable $ex) { }
}

function unread_notification_count(): int {
    $u = current_user();
    if (!$u) return 0;
    try {
        $s = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
        $s->execute([$u['id']]);
        return (int) $s->fetchColumn();
    } catch (Throwable $ex) { return 0; }
}

/** Reads a POSTed text field, trimmed and length-limited. */
function post_text(string $key, int $max = 5000): string {
    return mb_substr(trim((string) ($_POST[$key] ?? '')), 0, $max);
}

/**
 * Turns a stored asset path into a URL that works when the app lives in a
 * sub-folder (e.g. http://localhost/alpha_forge). A root-relative path such
 * as "/assets/img/books/cover.jpg" would otherwise point at
 * http://localhost/assets/... and 404 under XAMPP.
 */
function asset_url(?string $path): string {
    $path = trim((string) $path);
    if ($path === '') return '';
    if (preg_match('#^(https?:)?//#i', $path) || strpos($path, 'data:') === 0) return $path;
    if (strpos($path, APP_URL . '/') === 0) return $path;
    return APP_URL . '/' . ltrim($path, '/');
}
