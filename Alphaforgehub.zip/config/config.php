<?php
/**
 * ALPHA FORGE - Core configuration
 *
 * Secrets (DB password, payment API keys) are read from environment
 * variables so they never live in source control. On shared hosting
 * without env-var support, you may create a config/.env.php file
 * (excluded from git via .gitignore) that sets getenv()-style values -
 * see the bottom of this file for the local fallback loader.
 */

// ---- Local dev fallback: load a .env.php file if present (NOT committed to git) ----
$envFile = __DIR__ . '/.env.php';
if (file_exists($envFile)) {
    require_once $envFile; // expected to call putenv('KEY=value') for each secret
}

function env(string $key, $default = null) {
    $value = getenv($key);
    return ($value === false || $value === '') ? $default : $value;
}

// ---- Application ----
define('APP_NAME', 'Alpha Forge');
define('APP_URL', env('APP_URL', 'http://localhost/alpha_forge'));
define('APP_ENV', env('APP_ENV', 'local')); // local | production

// ---- Database ----
define('DB_HOST', env('DB_HOST', '127.0.0.1'));
define('DB_NAME', env('DB_NAME', 'alpha_forge'));
define('DB_USER', env('DB_USER', 'root'));
define('DB_PASS', env('DB_PASS', ''));

// ---- Payment gateway credentials (never echoed, never sent to the browser) ----
define('MTN_MOMO_API_KEY', env('MTN_MOMO_API_KEY', ''));
define('MTN_MOMO_API_USER', env('MTN_MOMO_API_USER', ''));
define('MTN_MOMO_SUBSCRIPTION_KEY', env('MTN_MOMO_SUBSCRIPTION_KEY', ''));
define('MTN_MOMO_ENV', env('MTN_MOMO_ENV', 'sandbox')); // sandbox | production
define('MTN_MOMO_CALLBACK_HOST', env('MTN_MOMO_CALLBACK_HOST', APP_URL));

define('ORANGE_MONEY_CLIENT_ID', env('ORANGE_MONEY_CLIENT_ID', ''));
define('ORANGE_MONEY_CLIENT_SECRET', env('ORANGE_MONEY_CLIENT_SECRET', ''));
define('ORANGE_MONEY_MERCHANT_KEY', env('ORANGE_MONEY_MERCHANT_KEY', ''));

// ---- Security ----
define('SESSION_NAME', 'alphaforge_session');
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_MINUTES', 15);


// ---- Content-Security-Policy (per-request nonce) ----
// Inline script blocks must carry a nonce attribute equal to CSP_NONCE.
// Inline on-event attributes are NOT allowed; use data-* hooks handled in assets/js/app.js.
define('CSP_NONCE', rtrim(strtr(base64_encode(random_bytes(16)), '+/', '-_'), '='));
if (!headers_sent()) {
    header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        . "font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; "
        . "script-src 'self' 'nonce-" . CSP_NONCE . "'; connect-src 'self'; object-src 'none'; base-uri 'self'; "
        . "form-action 'self'; frame-ancestors 'self'");
}

// ---- Error display ----
if (APP_ENV === 'local') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

date_default_timezone_set('Africa/Douala');

// ---- Friendly errors in production; details go to the PHP error log ----
if (APP_ENV !== 'local') {
    ini_set('log_errors', '1');
    set_exception_handler(function (Throwable $ex) {
        error_log('[AlphaForge] ' . get_class($ex) . ': ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
        if (!headers_sent()) { http_response_code(500); header('Content-Type: text/html; charset=utf-8'); }
        echo '<!DOCTYPE html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
           . '<body style="font-family:sans-serif;background:#071426;color:#fff;text-align:center;padding:15vh 20px">'
           . '<h1 style="color:#d4af37">Something went wrong</h1><p>Please try again in a moment.</p>'
           . '<p><a style="color:#d4af37" href="' . htmlspecialchars(APP_URL) . '/index.php">Back to home</a></p></body>';
    });
}
