<?php
/**
 * ALPHA FORGE - TOTP (Time-based One-Time Password), RFC 6238
 *
 * Compatible with Google Authenticator, Authy, Microsoft Authenticator,
 * and any other standard authenticator app. Pure PHP, no Composer
 * dependency required.
 */

function totp_generate_secret(int $bytes = 20): string {
    return totp_base32_encode(random_bytes($bytes));
}

function totp_base32_encode(string $data): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($data) as $char) {
        $bits .= str_pad(decbin(ord($char)), 8, '0', STR_PAD_LEFT);
    }
    $output = '';
    foreach (str_split($bits, 5) as $chunk) {
        $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
        $output .= $alphabet[bindec($chunk)];
    }
    return $output;
}

function totp_base32_decode(string $secret): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $secret));
    $bits = '';
    foreach (str_split($secret) as $char) {
        $pos = strpos($alphabet, $char);
        if ($pos === false) {
            continue;
        }
        $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) < 8) {
            continue;
        }
        $bytes .= chr(bindec($byte));
    }
    return $bytes;
}

/** Computes the current 6-digit TOTP code for a given base32 secret. */
function totp_code(string $secretBase32, int $timeStep = 30, int $digits = 6, ?int $forTime = null): string {
    $key = totp_base32_decode($secretBase32);
    $counter = intdiv($forTime ?? time(), $timeStep);
    $counterBytes = str_pad(pack('N', $counter), 8, "\x00", STR_PAD_LEFT); // 64-bit big-endian

    $hash = hash_hmac('sha1', $counterBytes, $key, true);
    $offset = ord($hash[strlen($hash) - 1]) & 0x0F;

    $binary = ((ord($hash[$offset]) & 0x7F) << 24)
        | ((ord($hash[$offset + 1]) & 0xFF) << 16)
        | ((ord($hash[$offset + 2]) & 0xFF) << 8)
        | (ord($hash[$offset + 3]) & 0xFF);

    $code = $binary % (10 ** $digits);
    return str_pad((string) $code, $digits, '0', STR_PAD_LEFT);
}

/**
 * Verifies a user-entered code, allowing +/- $window time steps to absorb
 * clock drift between the server and the user's phone.
 */
function totp_verify(string $secretBase32, string $code, int $window = 1, int $timeStep = 30): bool {
    $code = trim($code);
    for ($i = -$window; $i <= $window; $i++) {
        $expected = totp_code($secretBase32, $timeStep, 6, time() + ($i * $timeStep));
        if (hash_equals($expected, $code)) {
            return true;
        }
    }
    return false;
}

/** Builds the otpauth:// URI an authenticator app can import (typed manually, no QR needed). */
function totp_provisioning_uri(string $secretBase32, string $accountLabel = '', string $issuer = 'Alpha Forge'): string {
    $label = rawurlencode($issuer . ':' . $accountLabel);
    $params = http_build_query([
        'secret' => $secretBase32,
        'issuer' => $issuer,
        'algorithm' => 'SHA1',
        'digits' => 6,
        'period' => 30,
    ]);
    return "otpauth://totp/{$label}?{$params}";
}
