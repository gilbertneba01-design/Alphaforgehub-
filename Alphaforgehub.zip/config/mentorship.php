<?php
/**
 * Mentorship access rules (single source of truth, enforced server-side).
 * A mentorship "relationship" is a mentorship_requests row. Its private chat
 * is open ONLY to that row's student and that row's mentor user, and only
 * once the mentor has accepted (status 'scheduled' or 'completed').
 * Admins can read for moderation but the chat UI is send-only for participants.
 */
require_once __DIR__ . '/functions.php';

/** Returns the request row joined with mentor user id, or null if the user has no access. */
function mentorship_request_for(int $requestId, array $user, bool $allowAdminRead = false): ?array {
    $stmt = db()->prepare(
        'SELECT mr.*, m.name AS mentor_name, m.user_id AS mentor_user_id, s.full_name AS student_name
         FROM mentorship_requests mr
         JOIN mentors m ON m.id = mr.mentor_id
         JOIN users s ON s.id = mr.user_id
         WHERE mr.id = ? LIMIT 1');
    $stmt->execute([$requestId]);
    $r = $stmt->fetch();
    if (!$r) return null;
    $uid = (int) $user['id'];
    $isStudent = (int) $r['user_id'] === $uid;
    $isMentor  = $r['mentor_user_id'] !== null && (int) $r['mentor_user_id'] === $uid && $user['role'] === 'mentor';
    $isAdmin   = $allowAdminRead && $user['role'] === 'admin';
    return ($isStudent || $isMentor || $isAdmin) ? $r : null;
}

function mentorship_chat_open(array $r): bool {
    return in_array($r['status'], ['scheduled', 'completed'], true);
}

/** The mentors.id rows linked to this mentor user. */
function mentor_profile_ids(int $userId): array {
    $s = db()->prepare('SELECT id FROM mentors WHERE user_id = ?');
    $s->execute([$userId]);
    return array_map('intval', $s->fetchAll(PDO::FETCH_COLUMN));
}
