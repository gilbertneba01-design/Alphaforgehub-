<?php
/**
 * ALPHA FORGE - Security helpers
 *
 * IP-based rate limiting and a security event log, used on top of the
 * existing per-account login lockout in config/auth.php. This file must
 * be loaded after config/db.php.
 */

function get_client_ip(): string {
    // Trust REMOTE_ADDR only. X-Forwarded-For is attacker-controllable
    // unless your host's proxy strips/overwrites it - if you're behind a
    // known reverse proxy (e.g. Cloudflare), swap this for that proxy's
    // trusted header instead.
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Checks and records an attempt at a rate-limited action (e.g. 'login',
 * 'register', 'contact'). Returns true if the request is allowed to
 * proceed, false if the caller should be blocked.
 *
 * @param string $action       A short label identifying the action.
 * @param int    $maxAttempts  Attempts allowed within the window.
 * @param int    $windowSeconds Length of the sliding window, in seconds.
 * @param int    $blockSeconds  How long to block once the limit is hit.
 */
function enforce_rate_limit(string $action, int $maxAttempts, int $windowSeconds, int $blockSeconds): bool {
    $pdo = db();
    $ip = get_client_ip();

    $stmt = $pdo->prepare('SELECT * FROM rate_limits WHERE ip_address = ? AND action = ? LIMIT 1');
    $stmt->execute([$ip, $action]);
    $row = $stmt->fetch();

    $now = time();

    if (!$row) {
        $ins = $pdo->prepare(
            'INSERT INTO rate_limits (ip_address, action, attempt_count, window_start) VALUES (?, ?, 1, NOW())'
        );
        $ins->execute([$ip, $action]);
        return true;
    }

    // Currently under an active block
    if ($row['blocked_until'] && strtotime($row['blocked_until']) > $now) {
        return false;
    }

    $windowAge = $now - strtotime($row['window_start']);

    if ($windowAge > $windowSeconds) {
        // Window expired - reset the counter
        $upd = $pdo->prepare('UPDATE rate_limits SET attempt_count = 1, window_start = NOW(), blocked_until = NULL WHERE id = ?');
        $upd->execute([$row['id']]);
        return true;
    }

    $newCount = (int) $row['attempt_count'] + 1;

    if ($newCount > $maxAttempts) {
        $blockedUntil = date('Y-m-d H:i:s', $now + $blockSeconds);
        $upd = $pdo->prepare('UPDATE rate_limits SET attempt_count = ?, blocked_until = ? WHERE id = ?');
        $upd->execute([$newCount, $blockedUntil, $row['id']]);
        log_security_event('rate_limit_block', 'action=' . $action);
        return false;
    }

    $upd = $pdo->prepare('UPDATE rate_limits SET attempt_count = ? WHERE id = ?');
    $upd->execute([$newCount, $row['id']]);
    return true;
}

/** Records a security-relevant event for later review in admin/security_log.php. */
function log_security_event(string $eventType, ?string $detail = null, ?int $userId = null): void {
    try {
        $stmt = db()->prepare(
            'INSERT INTO security_log (event_type, ip_address, user_id, detail) VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$eventType, get_client_ip(), $userId, $detail]);
    } catch (Throwable $e) {
        // Never let logging failures break the request itself.
    }
}

/** Renders the standard "too many attempts" response and stops execution. */
function rate_limit_block_response(): void {
    http_response_code(429);
    die('Too many attempts. Please wait a while before trying again.');
}

/**
 * Enforces a minimum password strength beyond plain length: requires at
 * least one letter and one number. Returns an error string, or null if OK.
 */
function password_strength_error(string $password): ?string {
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.';
    }
    if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        return 'Password must contain both letters and numbers.';
    }
    return null;
}

/**
 * Honeypot check for public forms (register/contact). Add a hidden field
 * named 'website' to the form (see forms for the exact markup) - real
 * visitors never see or fill it, but simple bots often do.
 */
function honeypot_tripped(): bool {
    return !empty($_POST['website'] ?? '');
}
