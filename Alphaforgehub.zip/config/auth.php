<?php
/**
 * ALPHA FORGE - Authentication & authorization
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => (APP_ENV === 'production'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// -------------------------------------------------------------------
// CSRF
// -------------------------------------------------------------------
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_verify(): bool {
    $token = $_POST['csrf_token'] ?? '';
    return !empty($token) && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function require_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_verify()) {
        http_response_code(403);
        die('Invalid or expired form submission. Please go back and try again.');
    }
}

// -------------------------------------------------------------------
// AUTH CORE
// -------------------------------------------------------------------
function current_user(): ?array {
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $stmt = db()->prepare('SELECT id, full_name, email, phone, role, status, preferred_language, created_at FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if (!$user || $user['status'] !== 'active') {
        logout_user();
        return null;
    }
    $cache = $user;
    return $user;
}

function is_logged_in(): bool {
    return current_user() !== null;
}

function is_admin(): bool {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function is_mentor(): bool {
    $u = current_user();
    return $u && $u['role'] === 'mentor';
}

/** Mentor area: mentors only. Admins are deliberately NOT let in by default. */
function require_mentor(): void {
    if (!is_logged_in() || !is_mentor()) {
        http_response_code(403);
        header('Location: ' . APP_URL . '/login.php');
        exit;
    }
}

/** Where a freshly logged-in user of this role should land. */
function home_for_role(string $role): string {
    if ($role === 'admin')  return '/admin/index.php';
    if ($role === 'mentor') return '/mentor/index.php';
    return '/dashboard.php';
}

function require_login(string $redirectTo = '/login.php'): void {
    if (!is_logged_in()) {
        header('Location: ' . APP_URL . $redirectTo);
        exit;
    }
}

function require_admin(): void {
    if (!is_logged_in() || !is_admin()) {
        http_response_code(403);
        header('Location: ' . APP_URL . '/admin/login.php');
        exit;
    }
}

/** Students must never reach admin pages, even if logged in as student. */
function block_students_from_admin(): void {
    $u = current_user();
    if ($u && $u['role'] !== 'admin') {
        http_response_code(403);
        die('Access denied.');
    }
}

function login_user(int $userId): void {
    session_regenerate_id(true); // prevent session fixation
    $_SESSION['user_id'] = $userId;
}

function logout_user(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

// -------------------------------------------------------------------
// LOGIN RATE LIMITING (per-account, stored on the users row)
// -------------------------------------------------------------------
function is_account_locked(array $user): bool {
    return !empty($user['locked_until']) && strtotime($user['locked_until']) > time();
}

function register_failed_login(int $userId, int $currentFailedCount): void {
    $newCount = $currentFailedCount + 1;
    $lockedUntil = null;
    if ($newCount >= MAX_LOGIN_ATTEMPTS) {
        $lockedUntil = date('Y-m-d H:i:s', time() + (LOGIN_LOCKOUT_MINUTES * 60));
        $newCount = 0;
    }
    $stmt = db()->prepare('UPDATE users SET failed_login_count = ?, locked_until = ? WHERE id = ?');
    $stmt->execute([$newCount, $lockedUntil, $userId]);
}

function reset_failed_login(int $userId): void {
    $stmt = db()->prepare('UPDATE users SET failed_login_count = 0, locked_until = NULL WHERE id = ?');
    $stmt->execute([$userId]);
}

// -------------------------------------------------------------------
// SUBSCRIPTION STATUS (server-side; never trust client input)
// -------------------------------------------------------------------

/**
 * Recomputes and returns the *effective* subscription status for a user,
 * flipping any stale 'active' rows whose end date has passed to 'expired'.
 */
function get_effective_subscription(int $userId): ?array {
    $pdo = db();

    // Auto-expire anything whose end date has passed.
    $expireStmt = $pdo->prepare(
        "UPDATE subscriptions SET status = 'expired'
         WHERE user_id = ? AND status = 'active' AND ends_at IS NOT NULL AND ends_at < NOW()"
    );
    $expireStmt->execute([$userId]);

    $stmt = $pdo->prepare(
        "SELECT s.*, p.name AS plan_name, p.code AS plan_code
         FROM subscriptions s
         JOIN subscription_plans p ON p.id = s.plan_id
         WHERE s.user_id = ?
         ORDER BY s.created_at DESC
         LIMIT 1"
    );
    $stmt->execute([$userId]);
    return $stmt->fetch() ?: null;
}

function has_active_subscription(int $userId): bool {
    $sub = get_effective_subscription($userId);
    return $sub && $sub['status'] === 'active';
}

/**
 * Can this user open premium content? Admins can always preview it;
 * students need an active subscription.
 */
function can_view_premium(int $userId): bool {
    return is_admin() || has_active_subscription($userId);
}

/**
 * Server-side gate for premium content. Call at the top of any page/section
 * that must not be visible without an active subscription.
 */
function require_active_subscription(string $redirectTo = '/pricing.php'): void {
    require_login();
    $u = current_user();
    if (!has_active_subscription((int) $u['id'])) {
        header('Location: ' . APP_URL . $redirectTo . '?reason=premium');
        exit;
    }
}
