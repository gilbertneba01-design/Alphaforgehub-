<?php
/**
 * ALPHA FORGE - Chart Lab helpers
 *
 * Everything that decides whether a marked zone is right lives HERE, on the
 * server. The browser never receives the answer zone until the student has
 * solved the exercise (or has legitimately unlocked "Show Answer"), so the
 * result cannot be faked from the page.
 *
 * Load config/functions.php first (it provides db(), csrf helpers, etc.).
 *
 * HOW A ZONE IS JUDGED
 * --------------------
 * A zone is a box in chart coordinates: x = candle index (candle i occupies
 * x from i to i+1) and p = price. For each exercise the database stores one or
 * more "target" boxes (the true zone) plus two tolerances.
 *
 *   coverage  = how much of the TRUE zone the student's box covers
 *   precision = how much of the student's box lies inside the true zone
 *               grown by the tolerance (so a slightly generous box is fine)
 *
 * mode 'band' (support / resistance / flipped levels): judged on PRICE only,
 *   plus the box must stretch across a reasonable part of the candles where
 *   price reacted.
 * mode 'box'  (consolidation, supply / demand): judged on BOTH price and time;
 *   the weaker of the two axes decides.
 *
 * correct   : coverage >= 0.60 and precision >= 0.65
 * close     : coverage >= 0.30 and precision >= 0.25 (or right price, wrong span)
 * incorrect : everything else
 *
 * Tune the constants below if you want it stricter or more forgiving.
 */

const CHARTLAB_COVER_OK      = 0.60;
const CHARTLAB_PREC_OK       = 0.65;
const CHARTLAB_COVER_CLOSE   = 0.30;
const CHARTLAB_PREC_CLOSE    = 0.25;
const CHARTLAB_REVEAL_AFTER  = 2;     // wrong/close attempts before "Show Answer" unlocks
const CHARTLAB_MIN_WIDTH     = 1.5;   // candles (the browser asks for 2; server allows a little slack)
const CHARTLAB_MIN_HEIGHT_PC = 0.015; // fraction of the visible price range

// -------------------------------------------------------------------
// Availability (so the rest of the site keeps working if the migration
// has not been imported yet)
// -------------------------------------------------------------------
function chartlab_available(): bool {
    static $ok = null;
    if ($ok !== null) {
        return $ok;
    }
    try {
        // Select every column the Chart Lab uses, so a missing or outdated
        // table is caught here (and shown as "not set up") instead of crashing.
        db()->query('SELECT id, course_id, title, slug, pair_label, timeframe_label, difficulty, mode,
                            instruction, hint, explanation, price_decimals, candles, targets,
                            tol_price, tol_candles, is_premium, status, sort_order
                     FROM chartlab_exercises LIMIT 1');
        db()->query('SELECT id, user_id, exercise_id, result, score, zone_x1, zone_x2, zone_p1, zone_p2
                     FROM chartlab_attempts LIMIT 1');
        $ok = true;
    } catch (Throwable $e) {
        $ok = false;
    }
    return $ok;
}

// -------------------------------------------------------------------
// Grading (pure functions - no database, no globals)
// -------------------------------------------------------------------
function chartlab_overlap(float $a1, float $a2, float $b1, float $b2): float {
    return max(0.0, min($a2, $b2) - max($a1, $b1));
}

/**
 * Judge one zone against ONE target box.
 * $zone / $target = ['x1'=>, 'x2'=>, 'p1'=>, 'p2'=>] with x1<x2 and p1<p2.
 */
function chartlab_eval_target(array $zone, array $target, string $mode, float $tolP, float $tolX): array {
    $sx1 = (float) $zone['x1'];   $sx2 = (float) $zone['x2'];
    $sp1 = (float) $zone['p1'];   $sp2 = (float) $zone['p2'];
    $tx1 = (float) $target['x1']; $tx2 = (float) $target['x2'];
    $tp1 = (float) $target['p1']; $tp2 = (float) $target['p2'];

    $th = $tp2 - $tp1;
    $tw = $tx2 - $tx1;
    $sh = $sp2 - $sp1;
    $sw = $sx2 - $sx1;

    // Defensive: a broken target or an empty zone can never be "correct".
    if ($th <= 0 || $tw <= 0 || $sh <= 0 || $sw <= 0) {
        return ['verdict' => 'incorrect', 'reason' => 'miss', 'axis' => 'price', 'score' => 0, 'q' => 0.0];
    }

    $priceCov  = chartlab_overlap($sp1, $sp2, $tp1, $tp2) / $th;
    $pricePrec = chartlab_overlap($sp1, $sp2, $tp1 - $tolP * $th, $tp2 + $tolP * $th) / $sh;
    $xOverlap  = chartlab_overlap($sx1, $sx2, $tx1, $tx2);

    if ($mode === 'band') {
        $coverage  = $priceCov;
        $precision = $pricePrec;
        $axis      = 'price';
        $xOk       = $xOverlap >= min(0.35 * $tw, 6.0);
    } else {
        $xCov      = $xOverlap / $tw;
        $xPrec     = chartlab_overlap($sx1, $sx2, $tx1 - $tolX, $tx2 + $tolX) / $sw;
        $coverage  = min($priceCov, $xCov);
        $precision = min($pricePrec, $xPrec);
        $axis      = (min($priceCov, $pricePrec) <= min($xCov, $xPrec)) ? 'price' : 'time';
        $xOk       = true;
    }

    if ($coverage >= CHARTLAB_COVER_OK && $precision >= CHARTLAB_PREC_OK && $xOk) {
        $verdict = 'correct';
        $reason  = 'ok';
    } elseif ($coverage >= CHARTLAB_COVER_OK && $precision >= CHARTLAB_PREC_OK && !$xOk) {
        $verdict = 'close';
        $reason  = 'x_range';
    } elseif ($coverage >= CHARTLAB_COVER_CLOSE && $precision >= CHARTLAB_PREC_CLOSE) {
        $verdict = 'close';
        $reason  = ($precision < $coverage) ? 'too_wide' : 'partial';
    } else {
        $verdict = 'incorrect';
        if ($mode === 'band') {
            $small = ($sh <= 0.5 * $th);
        } else {
            $small = ($sh <= 0.5 * $th || $sw <= 0.5 * $tw);
        }
        if ($coverage >= CHARTLAB_COVER_CLOSE && $precision < CHARTLAB_PREC_CLOSE) {
            $reason = 'far_too_wide';
        } elseif ($coverage > 0 && $small) {
            $reason = 'too_small';
        } else {
            $dp = (($sp1 + $sp2) / 2 - ($tp1 + $tp2) / 2) / $th;
            $dx = (($sx1 + $sx2) / 2 - ($tx1 + $tx2) / 2) / max($tw, 1.0);
            if ($mode === 'band' || abs($dp) >= abs($dx)) {
                $reason = ($dp > 0) ? 'above' : 'below';
            } else {
                $reason = ($dx > 0) ? 'later' : 'earlier';
            }
        }
    }

    $q = max(0.0, min(1.0, min($coverage, $precision)));

    return [
        'verdict' => $verdict,
        'reason'  => $reason,
        'axis'    => $axis,
        'score'   => (int) round(100 * $q),
        'q'       => $q,
    ];
}

// ---------------------------------------------------------------------
// TRENDLINE MODE ("draw the trend")
// A trendline exercise is judged completely differently from band/box:
// the target is a straight line between two swing points (x1,p1)-(x2,p2),
// and the student draws a line, not a filled zone. These functions are
// kept separate from the band/box code above so that existing support /
// resistance / range / supply / demand exercises are never touched.
// ---------------------------------------------------------------------

/**
 * Judge one drawn line against ONE target line.
 * $zone / $target = ['x1'=>,'x2'=>,'p1'=>,'p2'=>] where x1<x2 and (p1,p2)
 * are the literal endpoint prices (NOT sorted) so the slope survives.
 */
function chartlab_eval_trendline_target(array $zone, array $target, float $tolP, float $tolX): array {
    $sx1 = (float) $zone['x1'];   $sx2 = (float) $zone['x2'];
    $sp1 = (float) $zone['p1'];   $sp2 = (float) $zone['p2'];
    $tx1 = (float) $target['x1']; $tx2 = (float) $target['x2'];
    $tp1 = (float) $target['p1']; $tp2 = (float) $target['p2'];

    $tw = $tx2 - $tx1;
    $sw = $sx2 - $sx1;
    $th = $tp2 - $tp1; // signed rise of the target line

    if ($tw <= 0 || $sw <= 0 || abs($th) <= 1e-9) {
        return ['verdict' => 'incorrect', 'reason' => 'miss', 'axis' => 'price', 'score' => 0, 'q' => 0.0];
    }

    $tSign = $th > 0 ? 1 : -1;
    $sh    = $sp2 - $sp1;
    $sSign = $sh > 0 ? 1 : ($sh < 0 ? -1 : 0);

    // A line sloping the wrong way is never "close" - it is a different idea.
    if ($sSign !== $tSign) {
        return ['verdict' => 'incorrect', 'reason' => 'wrong_direction', 'axis' => 'price', 'score' => 0, 'q' => 0.0];
    }

    $absTh = abs($th);
    $slope = $sh / $sw;
    // Extend the student's line (it is a line, not just a segment) and
    // read its price at each of the target's two anchor points.
    $y1 = $sp1 + $slope * ($tx1 - $sx1);
    $y2 = $sp1 + $slope * ($tx2 - $sx1);
    $err1 = abs($y1 - $tp1) / $absTh;
    $err2 = abs($y2 - $tp2) / $absTh;
    $maxErr = max($err1, $err2);

    $xOverlap = chartlab_overlap($sx1, $sx2, $tx1, $tx2);
    $effTw    = max(1.0, $tw - $tolX); // tol_candles forgives a slightly shorter line
    $coverage  = max(0.0, min(1.0, $xOverlap / $effTw));
    $precision = max(0.0, min(1.0, 1 - $maxErr / (2 * max($tolP, 0.05)))); // tol_price forgives a slightly off slope

    if ($coverage >= CHARTLAB_COVER_OK && $precision >= CHARTLAB_PREC_OK) {
        $verdict = 'correct';
        $reason  = 'ok';
    } elseif ($coverage >= CHARTLAB_COVER_CLOSE && $precision >= CHARTLAB_PREC_CLOSE) {
        $verdict = 'close';
        $reason  = ($precision < $coverage) ? 'too_wide' : 'partial';
    } else {
        $verdict = 'incorrect';
        if ($coverage < CHARTLAB_COVER_CLOSE) {
            $reason = 'too_short';
        } else {
            $reason = ((($y1 - $tp1) + ($y2 - $tp2)) > 0) ? 'above' : 'below';
        }
    }

    $q = max(0.0, min(1.0, min($coverage, $precision)));

    return [
        'verdict' => $verdict,
        'reason'  => $reason,
        'axis'    => 'price',
        'score'   => (int) round(100 * $q),
        'q'       => $q,
    ];
}

/** Judge a line against every accepted target line and keep the best match. */
function chartlab_evaluate_trendline(array $zone, array $targets, float $tolP, float $tolX): array {
    $rank = ['correct' => 2, 'close' => 1, 'incorrect' => 0];
    $best = null;
    $bestKey = null;

    foreach ($targets as $i => $target) {
        if (!is_array($target)) {
            continue;
        }
        $r = chartlab_eval_trendline_target($zone, $target, $tolP, $tolX);
        $r['target_index'] = (int) $i;
        $key = [$rank[$r['verdict']], $r['q']];
        if ($best === null || $key[0] > $bestKey[0] || ($key[0] === $bestKey[0] && $key[1] > $bestKey[1])) {
            $best = $r;
            $bestKey = $key;
        }
    }

    if ($best === null) {
        return ['verdict' => 'incorrect', 'reason' => 'miss', 'axis' => 'price', 'score' => 0, 'q' => 0.0, 'target_index' => 0];
    }
    return $best;
}

/** Judge a zone against every accepted target and keep the best match. */
function chartlab_evaluate(array $zone, array $targets, string $mode, float $tolP, float $tolX): array {
    if ($mode === 'trendline') {
        return chartlab_evaluate_trendline($zone, $targets, $tolP, $tolX);
    }
    $rank = ['correct' => 2, 'close' => 1, 'incorrect' => 0];
    $best = null;
    $bestKey = null;

    foreach ($targets as $i => $target) {
        $r = chartlab_eval_target($zone, $target, $mode, $tolP, $tolX);
        $r['target_index'] = (int) $i;
        $key = [$rank[$r['verdict']], $r['q']];
        if ($best === null || $key[0] > $bestKey[0] || ($key[0] === $bestKey[0] && $key[1] > $bestKey[1])) {
            $best = $r;
            $bestKey = $key;
        }
    }

    if ($best === null) {
        return ['verdict' => 'incorrect', 'reason' => 'miss', 'axis' => 'price', 'score' => 0, 'q' => 0.0, 'target_index' => 0];
    }
    return $best;
}

/** Plain-language feedback. Only a genuinely correct zone is ever praised. */
function chartlab_feedback(array $r): string {
    $axis = $r['axis'] ?? 'price';

    switch ($r['reason']) {
        case 'ok':
            return 'That zone matches the area where price reacted.';
        case 'x_range':
            return 'The price area is right, but the zone should stretch across the candles where price reacted. Extend it left and right, then submit again.';
        case 'too_wide':
            return ($axis === 'time')
                ? 'Your zone is in the right place but it is too long. Tighten the left and right edges.'
                : 'Your zone is in the right place but it is too tall. Tighten the top and bottom edges.';
        case 'partial':
            return ($axis === 'time')
                ? 'Your zone covers only part of the candles involved. Adjust the left or right edge.'
                : 'Your zone covers only part of the price area. Adjust the top or bottom edge.';
        case 'far_too_wide':
            return 'That zone is far too large to pinpoint anything. A good zone is tight around where price actually reacted.';
        case 'too_small':
            return 'That zone is too small and misses most of the area. Make it larger so it covers the whole reaction area.';
        case 'above':
            return "That zone is too high on the chart. Price didn't react there.";
        case 'below':
            return "That zone is too low on the chart. Price didn't react there.";
        case 'earlier':
            return 'That zone sits too early on the chart. Look further to the right.';
        case 'later':
            return 'That zone sits too late on the chart. Look further to the left.';
        case 'wrong_direction':
            return 'That line slopes the wrong way. Follow the direction of the actual trend.';
        case 'too_short':
            return 'Your line is too short. Stretch it from an early swing point to a later one, further along the trend.';
        default:
            return "That isn't where price reacted. Read the hint and try again.";
    }
}

// -------------------------------------------------------------------
// Exercise data
// -------------------------------------------------------------------

/** Visible price range for the chart: data range plus 8% padding each side. */
function chartlab_view_range(array $candles): array {
    $min = INF;
    $max = -INF;
    foreach ($candles as $c) {
        $min = min($min, (float) $c[2]);
        $max = max($max, (float) $c[1]);
    }
    if (!is_finite($min) || !is_finite($max) || $max <= $min) {
        return ['min' => 0.0, 'max' => 1.0];
    }
    $pad = ($max - $min) * 0.08;
    return ['min' => $min - $pad, 'max' => $max + $pad];
}

function chartlab_get_exercise(int $id): ?array {
    $stmt = db()->prepare("SELECT * FROM chartlab_exercises WHERE id = ? AND status = 'published' LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** All published exercises with a per-student "solved" flag. */
function chartlab_list_exercises(int $userId): array {
    $stmt = db()->prepare(
        "SELECT e.id, e.title, e.pair_label, e.timeframe_label, e.difficulty, e.is_premium, e.mode,
                (SELECT COUNT(*) FROM chartlab_attempts a
                   WHERE a.exercise_id = e.id AND a.user_id = ? AND a.result = 'correct') AS solved_count
         FROM chartlab_exercises e
         WHERE e.status = 'published'
         ORDER BY e.sort_order, e.id"
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/** ['solved' => n, 'total' => n] for dashboards. Safe if the tables are missing. */
function chartlab_stats(int $userId): array {
    if (!chartlab_available()) {
        return ['solved' => 0, 'total' => 0];
    }
    try {
        $total = (int) db()->query("SELECT COUNT(*) FROM chartlab_exercises WHERE status = 'published'")->fetchColumn();
        $stmt = db()->prepare(
            "SELECT COUNT(DISTINCT a.exercise_id)
             FROM chartlab_attempts a
             JOIN chartlab_exercises e ON e.id = a.exercise_id
             WHERE a.user_id = ? AND a.result = 'correct' AND e.status = 'published'"
        );
        $stmt->execute([$userId]);
        return ['solved' => (int) $stmt->fetchColumn(), 'total' => $total];
    } catch (Throwable $e) {
        return ['solved' => 0, 'total' => 0];
    }
}

/** Can this student open this exercise? (Server-side premium gate.) */
function chartlab_can_access(array $exercise, int $userId): bool {
    if (!(int) $exercise['is_premium']) {
        return true;
    }
    return is_admin() || has_active_subscription($userId);
}

/** What the browser is allowed to know about an exercise. NO answer zones. */
function chartlab_client_payload(array $exercise, int $attempts): array {
    $raw = json_decode((string) $exercise['candles'], true);
    $candles = [];
    if (is_array($raw)) {
        foreach ($raw as $c) {
            if (is_array($c) && count($c) === 4) {
                $candles[] = [(float) $c[0], (float) $c[1], (float) $c[2], (float) $c[3]];
            }
        }
    }
    return [
        'id'          => (int) $exercise['id'],
        'title'       => (string) $exercise['title'],
        'mode'        => (string) $exercise['mode'],
        'pair'        => (string) $exercise['pair_label'],
        'timeframe'   => (string) $exercise['timeframe_label'],
        'instruction' => (string) $exercise['instruction'],
        'hint'        => (string) ($exercise['hint'] ?? ''),
        'decimals'    => (int) $exercise['price_decimals'],
        'candles'     => $candles,
        'view'        => chartlab_view_range($candles),
        'attempts'    => $attempts,
    ];
}

/**
 * Validate a zone submitted by the browser.
 * Returns [zoneArray, null] on success or [null, 'error message'].
 */
function chartlab_parse_zone(array $input, array $view, int $candleCount, string $mode = 'band'): array {
    $vals = [];
    foreach (['x1', 'x2', 'p1', 'p2'] as $k) {
        if (!isset($input[$k]) || !is_numeric($input[$k])) {
            return [null, 'That could not be read. Please draw it again.'];
        }
        $v = (float) $input[$k];
        if (!is_finite($v)) {
            return [null, 'That could not be read. Please draw it again.'];
        }
        $vals[$k] = $v;
    }

    if ($mode === 'trendline') {
        // A line has a direction, so we swap the WHOLE point (not price
        // alone) when the student dragged from right to left - sorting
        // price independently would destroy the slope.
        if ($vals['x1'] <= $vals['x2']) {
            $x1 = $vals['x1']; $x2 = $vals['x2']; $p1 = $vals['p1']; $p2 = $vals['p2'];
        } else {
            $x1 = $vals['x2']; $x2 = $vals['x1']; $p1 = $vals['p2']; $p2 = $vals['p1'];
        }
        $x1 = max(0.0, min((float) $candleCount, $x1));
        $x2 = max(0.0, min((float) $candleCount, $x2));
        $p1 = max($view['min'], min($view['max'], $p1));
        $p2 = max($view['min'], min($view['max'], $p2));

        if (($x2 - $x1) < CHARTLAB_MIN_WIDTH) {
            return [null, 'That line is too short. Draw it across more candles.'];
        }
        if (abs($p2 - $p1) < ($view['max'] - $view['min']) * CHARTLAB_MIN_HEIGHT_PC) {
            return [null, 'That line is almost flat. Follow the slope of the trend.'];
        }
        return [['x1' => $x1, 'x2' => $x2, 'p1' => $p1, 'p2' => $p2], null];
    }

    $x1 = min($vals['x1'], $vals['x2']);
    $x2 = max($vals['x1'], $vals['x2']);
    $p1 = min($vals['p1'], $vals['p2']);
    $p2 = max($vals['p1'], $vals['p2']);

    // Keep everything inside the chart.
    $x1 = max(0.0, min((float) $candleCount, $x1));
    $x2 = max(0.0, min((float) $candleCount, $x2));
    $p1 = max($view['min'], min($view['max'], $p1));
    $p2 = max($view['min'], min($view['max'], $p2));

    $minH = ($view['max'] - $view['min']) * CHARTLAB_MIN_HEIGHT_PC;
    if (($x2 - $x1) < CHARTLAB_MIN_WIDTH || ($p2 - $p1) < $minH) {
        return [null, 'That zone is too small. Draw a larger zone on the chart.'];
    }

    return [['x1' => $x1, 'x2' => $x2, 'p1' => $p1, 'p2' => $p2], null];
}


// =====================================================================
// ADMIN AUTHORING HELPERS
// Used by admin/chart_exercises.php to turn what an admin pastes and
// draws into a safe, gradable exercise.
// =====================================================================

const CHARTLAB_MIN_CANDLES = 20;
const CHARTLAB_MAX_CANDLES = 150;
const CHARTLAB_MAX_ZONES   = 3;

/**
 * Read pasted candles: one candle per line as  open, high, low, close.
 * Commas, semicolons, tabs or spaces may separate the numbers, and a date/time
 * column before them (or a header line) is fine. Decimals must use a dot.
 *
 * @return array [candles|null, decimals, errorMessage|null]
 *         candles = [[o,h,l,c], ...] rounded to the detected decimals
 */
function chartlab_parse_candles_text(string $text): array {
    $lines = preg_split('/\r\n|\r|\n/', trim($text));
    $candles = [];
    $maxDec = 0;
    $seenData = false;

    foreach ($lines as $i => $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $lineNo = $i + 1;
        $tokens = preg_split('/[\s,;]+/', $line, -1, PREG_SPLIT_NO_EMPTY);

        // Numeric tokens only; skip dates, times and header words.
        $nums = [];
        foreach ($tokens as $t) {
            if (is_numeric($t)) {
                $nums[] = $t;
            }
        }

        if (!$nums) {
            if (!$seenData) {
                continue; // header line such as "time,open,high,low,close"
            }
            return [null, 0, "Line $lineNo: expected four numbers (open, high, low, close)."];
        }

        // A compact date or Unix time (8+ digit whole number) before the prices.
        if (count($nums) >= 5 && preg_match('/^\d{8,}$/', $nums[0])) {
            array_shift($nums);
        }
        if (count($nums) < 4) {
            return [null, 0, "Line $lineNo: expected four numbers (open, high, low, close), found " . count($nums) . '.'];
        }

        $seenData = true;
        $nums = array_slice($nums, 0, 4);
        $vals = [];
        foreach ($nums as $n) {
            $v = (float) $n;
            if (!is_finite($v) || $v <= 0) {
                return [null, 0, "Line $lineNo: prices must be positive numbers."];
            }
            $vals[] = $v;
            $dot = strpos($n, '.');
            if ($dot !== false) {
                $maxDec = max($maxDec, strlen(rtrim(substr($n, $dot + 1), '0')));
            }
        }

        [$o, $h, $l, $c] = $vals;
        if ($h + 1e-12 < max($o, $c) || $l - 1e-12 > min($o, $c) || $h + 1e-12 < $l) {
            return [null, 0, "Line $lineNo: the High must be the highest value and the Low the lowest. "
                . 'The order must be open, high, low, close.'];
        }
        $candles[] = $vals;

        if (count($candles) > CHARTLAB_MAX_CANDLES) {
            return [null, 0, 'Too many candles. Use at most ' . CHARTLAB_MAX_CANDLES . '.'];
        }
    }

    if (count($candles) < CHARTLAB_MIN_CANDLES) {
        return [null, 0, 'Add at least ' . CHARTLAB_MIN_CANDLES . ' candles (you have ' . count($candles) . ').'];
    }

    $dec = max(2, min(6, $maxDec));
    foreach ($candles as $k => $c) {
        $candles[$k] = [round($c[0], $dec), round($c[1], $dec), round($c[2], $dec), round($c[3], $dec)];
    }

    $view = chartlab_view_range($candles);
    if (($view['max'] - $view['min']) < 1e-9) {
        return [null, 0, 'These candles are completely flat. Check the numbers.'];
    }

    return [$candles, $dec, null];
}

/** Candles back to editable text, one "open,high,low,close" line each. */
function chartlab_candles_to_text(array $candles, int $decimals): string {
    $out = [];
    foreach ($candles as $c) {
        if (is_array($c) && count($c) === 4) {
            $out[] = number_format((float) $c[0], $decimals, '.', '') . ','
                   . number_format((float) $c[1], $decimals, '.', '') . ','
                   . number_format((float) $c[2], $decimals, '.', '') . ','
                   . number_format((float) $c[3], $decimals, '.', '');
        }
    }
    return implode("\n", $out);
}

/**
 * Validate the answer zones an admin drew.
 * @return array [targets|null, errorMessage|null]
 */
function chartlab_clean_targets($raw, int $candleCount, array $view, string $mode = 'band'): array {
    if (!is_array($raw) || !$raw) {
        return [null, 'Draw the correct answer on the chart before saving.'];
    }
    if (count($raw) > CHARTLAB_MAX_ZONES) {
        return [null, 'Use at most ' . CHARTLAB_MAX_ZONES . ' accepted answers.'];
    }

    if ($mode === 'trendline') {
        $range = $view['max'] - $view['min'];
        $out = [];
        $n = 0;
        foreach ($raw as $z) {
            $n++;
            if (!is_array($z)) {
                return [null, "Line $n could not be read. Draw it again."];
            }
            $v = [];
            foreach (['x1', 'x2', 'p1', 'p2'] as $k) {
                if (!isset($z[$k]) || !is_numeric($z[$k]) || !is_finite((float) $z[$k])) {
                    return [null, "Line $n could not be read. Draw it again."];
                }
                $v[$k] = (float) $z[$k];
            }
            if ($v['x1'] <= $v['x2']) {
                $x1 = $v['x1']; $x2 = $v['x2']; $p1 = $v['p1']; $p2 = $v['p2'];
            } else {
                $x1 = $v['x2']; $x2 = $v['x1']; $p1 = $v['p2']; $p2 = $v['p1'];
            }
            $x1 = max(0.0, min((float) $candleCount, $x1));
            $x2 = max(0.0, min((float) $candleCount, $x2));
            $p1 = max($view['min'], min($view['max'], $p1));
            $p2 = max($view['min'], min($view['max'], $p2));

            if (($x2 - $x1) < 3) {
                return [null, "Line $n is too short. Stretch it across at least 3 candles."];
            }
            if (abs($p2 - $p1) < $range * 0.03) {
                return [null, "Line $n is almost flat. Give it a clear slope."];
            }
            $out[] = ['x1' => round($x1, 2), 'x2' => round($x2, 2), 'p1' => round($p1, 6), 'p2' => round($p2, 6)];
        }
        return [$out, null];
    }

    $range = $view['max'] - $view['min'];
    $out = [];
    $n = 0;
    foreach ($raw as $z) {
        $n++;
        if (!is_array($z)) {
            return [null, "Zone $n could not be read. Draw it again."];
        }
        $v = [];
        foreach (['x1', 'x2', 'p1', 'p2'] as $k) {
            if (!isset($z[$k]) || !is_numeric($z[$k]) || !is_finite((float) $z[$k])) {
                return [null, "Zone $n could not be read. Draw it again."];
            }
            $v[$k] = (float) $z[$k];
        }
        $x1 = max(0.0, min((float) $candleCount, min($v['x1'], $v['x2'])));
        $x2 = max(0.0, min((float) $candleCount, max($v['x1'], $v['x2'])));
        $p1 = max($view['min'], min($view['max'], min($v['p1'], $v['p2'])));
        $p2 = max($view['min'], min($view['max'], max($v['p1'], $v['p2'])));

        if (($x2 - $x1) < 3 || ($p2 - $p1) < $range * 0.03) {
            return [null, "Zone $n is too small. Make it at least 3 candles wide and a little taller."];
        }
        $out[] = ['x1' => round($x1, 2), 'x2' => round($x2, 2), 'p1' => round($p1, 6), 'p2' => round($p2, 6)];
    }
    return [$out, null];
}

/**
 * Prove the finished exercise behaves: every answer zone the admin drew must be
 * graded "correct" by the real grader, and obviously wrong zones must not be.
 * Returns an error message, or null when everything is fine.
 */
function chartlab_self_check(array $targets, string $mode, float $tolP, float $tolX, int $candleCount, array $view): ?string {
    if ($mode === 'trendline') {
        foreach ($targets as $i => $t) {
            $r = chartlab_evaluate_trendline($t, $targets, $tolP, $tolX);
            if ($r['verdict'] !== 'correct') {
                return 'Line ' . ($i + 1) . ' would not be accepted by the grader, so students could never solve it. '
                     . 'Give it a clearer slope or lower the tolerance.';
            }
        }
        foreach ($targets as $t) {
            // A line sloping the opposite way (mirrored around its own
            // midpoint) must NOT also be marked correct.
            $mid = ($t['p1'] + $t['p2']) / 2;
            $flipped = ['x1' => $t['x1'], 'x2' => $t['x2'], 'p1' => 2 * $mid - $t['p1'], 'p2' => 2 * $mid - $t['p2']];
            if (chartlab_evaluate_trendline($flipped, $targets, $tolP, $tolX)['verdict'] === 'correct') {
                return 'The tolerance is too generous: a line sloping the wrong way would be marked correct. '
                     . 'Lower the tolerance values under Advanced.';
            }
        }
        return null;
    }

    foreach ($targets as $i => $t) {
        $r = chartlab_evaluate($t, $targets, $mode, $tolP, $tolX);
        if ($r['verdict'] !== 'correct') {
            return 'Zone ' . ($i + 1) . ' would not be accepted by the grader, so students could never solve it. '
                 . 'Make the zone a little larger or lower the tolerance.';
        }
    }

    $whole = ['x1' => 0.0, 'x2' => (float) $candleCount, 'p1' => $view['min'], 'p2' => $view['max']];
    if (chartlab_evaluate($whole, $targets, $mode, $tolP, $tolX)['verdict'] === 'correct') {
        return 'The answer zone is too large: a student could pass by selecting almost the whole chart. Draw it tighter.';
    }

    if (count($targets) === 1) {
        $t = $targets[0];
        $h = $t['p2'] - $t['p1'];
        $w = $t['x2'] - $t['x1'];
        $shifts = [
            ['p1' => $t['p1'] + 1.5 * $h, 'p2' => $t['p2'] + 1.5 * $h, 'x1' => $t['x1'], 'x2' => $t['x2']],
            ['p1' => $t['p1'] - 1.5 * $h, 'p2' => $t['p2'] - 1.5 * $h, 'x1' => $t['x1'], 'x2' => $t['x2']],
        ];
        if ($mode === 'box') {
            $shifts[] = ['p1' => $t['p1'], 'p2' => $t['p2'], 'x1' => $t['x1'] + 1.5 * $w, 'x2' => $t['x2'] + 1.5 * $w];
            $shifts[] = ['p1' => $t['p1'], 'p2' => $t['p2'], 'x1' => $t['x1'] - 1.5 * $w, 'x2' => $t['x2'] - 1.5 * $w];
        }
        foreach ($shifts as $z) {
            if (chartlab_evaluate($z, $targets, $mode, $tolP, $tolX)['verdict'] === 'correct') {
                return 'The tolerance is too generous: a zone in the wrong place would be marked correct. '
                     . 'Lower the tolerance values under Advanced.';
            }
        }
    }
    return null;
}

