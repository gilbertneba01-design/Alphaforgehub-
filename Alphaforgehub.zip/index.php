<?php
require_once __DIR__ . '/config/functions.php';

$pdo = db();
$courses = $pdo->query("SELECT * FROM courses WHERE status = 'published' ORDER BY sort_order LIMIT 3")->fetchAll();
$testimonials = $pdo->query("SELECT * FROM testimonials WHERE is_approved = 1 ORDER BY created_at DESC LIMIT 3")->fetchAll();

$loggedIn = is_logged_in();

/**
 * Home page carousel. To use your own photos, drop the image files into
 * assets/img/carousel/ and change the 'img' values below (JPG, PNG, WebP or
 * SVG; about 1600 x 640 px looks best).
 */
$slides = [
    [
        'img'     => '/assets/img/carousel/slide-3-chartlab.svg',
        'eyebrow' => 'New: Chart Lab',
        'title'   => 'Mark the zone. See how close you are.',
        'text'    => 'Practise on realistic charts. Draw support, resistance and supply and demand zones, then get instant feedback.',
        'cta'     => $loggedIn ? 'Open Chart Lab' : 'Start Learning Free',
        'href'    => $loggedIn ? '/chart_lab.php' : '/register.php',
    ],
    [
        'img'     => '/assets/img/carousel/slide-1-trend.svg',
        'eyebrow' => 'Learn',
        'title'   => 'Read the market with a clear head.',
        'text'    => 'Structured forex lessons, from your first pip to a complete trading plan.',
        'cta'     => 'Explore Courses',
        'href'    => '/courses.php',
    ],
    [
        'img'     => '/assets/img/carousel/slide-2-levels.svg',
        'eyebrow' => 'Technical Analysis',
        'title'   => 'Spot the levels price respects.',
        'text'    => 'Support, resistance and market structure, explained one step at a time.',
        'cta'     => 'View the Course',
        'href'    => '/course.php?slug=technical-analysis',
    ],
    [
        'img'     => '/assets/img/carousel/slide-4-risk.svg',
        'eyebrow' => 'Risk First',
        'title'   => 'Protect your capital before you chase profit.',
        'text'    => 'Position sizing, stop losses and discipline: the habits that keep traders in the game.',
        'cta'     => 'Learn Risk Management',
        'href'    => '/course.php?slug=risk-management',
    ],
];

$pageTitle = 'Home';
require_once __DIR__ . '/includes/header.php';
?>

<section class="af-section af-home-carousel">
    <div class="af-container">
        <section class="af-carousel" id="afCarousel" aria-roledescription="carousel" aria-label="Featured from Alpha Forge" tabindex="-1">
            <?php foreach ($slides as $i => $sl): ?>
                <article class="af-slide<?= $i === 0 ? ' is-active' : '' ?>" role="group" aria-roledescription="slide" aria-label="<?= $i + 1 ?> of <?= count($slides) ?>">
                    <img src="<?= e(APP_URL . $sl['img']) ?>" alt="" <?= $i === 0 ? 'fetchpriority="high"' : 'loading="lazy"' ?>>
                    <div class="af-slide-shade"></div>
                    <div class="af-slide-copy">
                        <span class="af-eyebrow"><?= e($sl['eyebrow']) ?></span>
                        <h2><?= e($sl['title']) ?></h2>
                        <p><?= e($sl['text']) ?></p>
                        <a href="<?= e(APP_URL . $sl['href']) ?>" class="af-btn af-btn-gold"><?= e($sl['cta']) ?></a>
                    </div>
                </article>
            <?php endforeach; ?>
            <button type="button" class="af-car-btn af-car-prev" aria-label="Previous slide">&lsaquo;</button>
            <button type="button" class="af-car-btn af-car-next" aria-label="Next slide">&rsaquo;</button>
            <div class="af-car-dots"></div>
            <button type="button" class="af-car-toggle" aria-label="Pause slideshow">Pause</button>
        </section>
    </div>
</section>
<script src="<?= APP_URL ?>/assets/js/carousel.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/carousel.js') ?>"></script>

<section class="af-hero">
    <div class="af-container">
        <div class="af-ladder"><span></span><span></span><span></span><span></span><span></span></div>
        <div class="af-hero-eyebrow"><?= te('hero_eyebrow') ?></div>
        <h1>ALPHA FORGE</h1>
        <p class="lead"><?= te('hero_lead') ?></p>
        <div class="af-hero-actions">
            <?php if (!is_logged_in()): ?>
                <a href="<?= APP_URL ?>/register.php" class="af-btn af-btn-gold"><?= te('nav_join') ?></a>
            <?php else: ?>
                <a href="<?= APP_URL ?>/dashboard.php" class="af-btn af-btn-gold"><?= te('nav_dashboard') ?></a>
            <?php endif; ?>
            <button type="button" class="af-btn af-btn-ghost" data-af-install><?= te('nav_install') ?></button>
            <a href="<?= APP_URL ?>/courses.php" class="af-btn af-btn-ghost"><?= te('hero_explore') ?></a>
        </div>
    </div>
</section>

<section class="af-section">
    <div class="af-container">
        <h2 class="af-section-title">Why Alpha Forge</h2>
        <div class="af-grid af-grid-3" style="margin-top:28px;">
            <div class="af-card">
                <span class="af-badge">01</span>
                <h3 style="margin-top:12px;">Structured Learning</h3>
                <p>A clear course → module → lesson path, built so beginners never wonder what to study next.</p>
            </div>
            <div class="af-card">
                <span class="af-badge">02</span>
                <h3 style="margin-top:12px;">Progress Tracking</h3>
                <p>Every completed lesson is recorded against your account, so your dashboard always reflects real progress.</p>
            </div>
            <div class="af-card">
                <span class="af-badge">03</span>
                <h3 style="margin-top:12px;">Risk Management</h3>
                <p>Trading rules are taught alongside the theory — position sizing, stop placement, and account protection.</p>
            </div>
            <div class="af-card">
                <span class="af-badge">04</span>
                <h3 style="margin-top:12px;">Practical Education</h3>
                <p>Lessons are written to be applied on your very next chart session, not just watched once.</p>
            </div>
        </div>
    </div>
</section>

<section class="af-section" style="background:var(--bg-2); border-top:1px solid var(--border); border-bottom:1px solid var(--border);">
    <div class="af-container">
        <h2 class="af-section-title">Courses</h2>
        <div class="af-grid af-grid-3" style="margin-top:28px;">
            <?php foreach ($courses as $c): ?>
                <div class="af-card">
                    <span class="af-badge <?= $c['is_premium'] ? '' : 'af-badge-muted' ?>"><?= $c['is_premium'] ? 'Premium' : 'Free' ?></span>
                    <h3 style="margin-top:12px;"><?= e($c['title']) ?></h3>
                    <p><?= e($c['description']) ?></p>
                    <a href="<?= APP_URL ?>/course.php?slug=<?= urlencode($c['slug']) ?>" class="af-btn af-btn-ghost">View Course</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="af-section">
    <div class="af-container" style="max-width:640px;">
        <h2 class="af-section-title">How It Works</h2>
        <div class="af-steps" style="margin-top:28px;">
            <div class="af-step"><div><h3>Create an account</h3><p>Register for free in under a minute.</p></div></div>
            <div class="af-step"><div><h3>Choose a plan</h3><p>Start free, or unlock premium lessons with a subscription.</p></div></div>
            <div class="af-step"><div><h3>Learn the lessons</h3><p>Work through each module at your own pace.</p></div></div>
            <div class="af-step"><div><h3>Track your progress</h3><p>Your dashboard shows exactly how far you've come.</p></div></div>
        </div>
    </div>
</section>

<?php if ($testimonials): ?>
<section class="af-section" style="background:var(--bg-2); border-top:1px solid var(--border);">
    <div class="af-container">
        <h2 class="af-section-title">What Students Say</h2>
        <div class="af-grid af-grid-3" style="margin-top:28px;">
            <?php foreach ($testimonials as $t): ?>
                <div class="af-card">
                    <p>&ldquo;<?= e($t['message']) ?>&rdquo;</p>
                    <h3 style="margin-top:16px; font-size:16px;"><?= e($t['name']) ?></h3>
                    <?php if ($t['role_title']): ?><p class="af-muted"><?= e($t['role_title']) ?></p><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="af-section">
    <div class="af-container" style="text-align:center;">
        <h2 class="af-section-title">Ready to build your trading foundation?</h2>
        <p style="max-width:520px; margin:0 auto 24px;">Join Alpha Forge today and start learning with structure and discipline.</p>
        <a href="<?= APP_URL ?>/register.php" class="af-btn af-btn-gold">Join Alpha Forge</a>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
