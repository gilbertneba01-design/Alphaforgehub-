<?php
/**
 * ALPHA FORGE HUB - My Trading Journal (STUDENT)
 * List, filter and search the student's own trades. Every query is scoped
 * to the logged-in user - a student can never see another student's journal.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/journal.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

// ---- Delete (POST, CSRF-protected) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    require_csrf();
    $deleted = journal_delete($userId, (int) $_POST['delete_id']);
    flash_set($deleted ? 'success' : 'error', $deleted ? 'Trade deleted.' : 'Trade not found.');
    redirect('/trading_journal.php');
}

// ---- Filters (GET, bookmarkable) ----
$filters = [
    'pair'      => trim((string) ($_GET['pair'] ?? '')),
    'strategy'  => trim((string) ($_GET['strategy'] ?? '')),
    'result'    => (string) ($_GET['result'] ?? ''),
    'session'   => (string) ($_GET['session'] ?? ''),
    'direction' => (string) ($_GET['direction'] ?? ''),
    'date_from' => trim((string) ($_GET['date_from'] ?? '')),
    'date_to'   => trim((string) ($_GET['date_to'] ?? '')),
    'search'    => trim((string) ($_GET['search'] ?? '')),
];

$trades = journal_list($userId, $filters);

$total  = count($trades);
$wins   = count(array_filter($trades, fn($t) => $t['result'] === 'win'));
$losses = count(array_filter($trades, fn($t) => $t['result'] === 'loss'));
$closed = $wins + $losses + count(array_filter($trades, fn($t) => $t['result'] === 'breakeven'));
$winRate = $closed > 0 ? round(($wins / $closed) * 100, 1) : 0;

$pairOptions      = journal_pairs_used($userId);
$strategyOptions  = journal_strategies_used($userId);

$pageTitle = 'My Trading Journal';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <div class="af-lab-hero">
                <div>
                    <h1>My Trading Journal</h1>
                    <p class="af-muted"><?= $total ?> trades shown &middot; <?= $wins ?>W / <?= $losses ?>L &middot; <?= $winRate ?>% win rate (closed trades)</p>
                </div>
                <a href="<?= APP_URL ?>/journal_entry.php" class="af-btn af-btn-gold">+ Add Trade</a>
            </div>

            <form method="get" class="af-card" style="margin-bottom:20px;">
                <div class="af-grid af-grid-3" style="gap:12px;">
                    <div class="af-field">
                        <label>Pair</label>
                        <select name="pair">
                            <option value="">All pairs</option>
                            <?php foreach ($pairOptions as $p): ?>
                                <option value="<?= e($p) ?>" <?= $filters['pair'] === $p ? 'selected' : '' ?>><?= e($p) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field">
                        <label>Strategy</label>
                        <select name="strategy">
                            <option value="">All strategies</option>
                            <?php foreach ($strategyOptions as $s): ?>
                                <option value="<?= e($s) ?>" <?= $filters['strategy'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field">
                        <label>Result</label>
                        <select name="result">
                            <option value="">All results</option>
                            <?php foreach (JOURNAL_RESULTS as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= $filters['result'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field">
                        <label>Session</label>
                        <select name="session">
                            <option value="">All sessions</option>
                            <?php foreach (JOURNAL_SESSIONS as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= $filters['session'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field">
                        <label>Direction</label>
                        <select name="direction">
                            <option value="">Buy &amp; Sell</option>
                            <?php foreach (JOURNAL_DIRECTIONS as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= $filters['direction'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field">
                        <label>Search</label>
                        <input type="text" name="search" value="<?= e($filters['search']) ?>" placeholder="pair, strategy, notes...">
                    </div>
                    <div class="af-field">
                        <label>From</label>
                        <input type="date" name="date_from" value="<?= e($filters['date_from']) ?>">
                    </div>
                    <div class="af-field">
                        <label>To</label>
                        <input type="date" name="date_to" value="<?= e($filters['date_to']) ?>">
                    </div>
                </div>
                <div style="margin-top:10px; display:flex; gap:10px;">
                    <button type="submit" class="af-btn af-btn-gold">Apply Filters</button>
                    <a href="<?= APP_URL ?>/trading_journal.php" class="af-btn af-btn-ghost">Reset</a>
                    <a href="<?= APP_URL ?>/performance.php" class="af-btn af-btn-ghost">View Performance &rarr;</a>
                </div>
            </form>

            <div class="af-table-wrap">
                <table class="af-table">
                    <thead>
                        <tr>
                            <th>Date</th><th>Pair</th><th>Dir</th><th>Entry</th><th>SL</th><th>TP</th>
                            <th>Result</th><th>P/L</th><th>Strategy</th><th>Session</th><th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($trades as $t): ?>
                        <tr>
                            <td><?= e(date('d M Y', strtotime($t['trade_date']))) ?></td>
                            <td><?= e($t['pair']) ?></td>
                            <td style="text-transform:capitalize;"><?= e($t['direction']) ?></td>
                            <td><?= e(rtrim(rtrim((string) $t['entry_price'], '0'), '.')) ?></td>
                            <td><?= $t['stop_loss'] !== null ? e($t['stop_loss']) : '&mdash;' ?></td>
                            <td><?= $t['take_profit'] !== null ? e($t['take_profit']) : '&mdash;' ?></td>
                            <td>
                                <span class="af-badge<?= $t['result'] === 'win' ? '' : ' af-badge-muted' ?>" style="<?= $t['result'] === 'loss' ? 'color:var(--red);border-color:var(--red);' : '' ?>">
                                    <?= e(JOURNAL_RESULTS[$t['result']] ?? $t['result']) ?>
                                </span>
                            </td>
                            <td><?= $t['profit_loss'] !== null ? e(number_format((float) $t['profit_loss'], 2)) : '&mdash;' ?></td>
                            <td><?= e($t['strategy'] ?? '&mdash;') ?></td>
                            <td><?= e(JOURNAL_SESSIONS[$t['session']] ?? '&mdash;') ?></td>
                            <td style="white-space:nowrap;">
                                <a href="<?= APP_URL ?>/journal_entry.php?id=<?= (int) $t['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 10px;">Edit</a>
                                <form method="post" style="display:inline;" data-confirm="Delete this trade?">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="delete_id" value="<?= (int) $t['id'] ?>">
                                    <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$trades): ?>
                        <tr><td colspan="11" class="af-muted">No trades recorded yet. Click "+ Add Trade" to start your journal.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
