<?php
require_once __DIR__ . '/config/functions.php';

if (is_logged_in()) {
    redirect('/dashboard.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!enforce_rate_limit('register', 5, 600, 600)) {
        rate_limit_block_response();
    }

    if (honeypot_tripped()) {
        // Silently pretend success to a bot without creating an account.
        redirect('/login.php');
    }

    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';

    if ($fullName === '') $errors[] = 'Please enter your full name.';
    if (!valid_email($email)) $errors[] = 'Please enter a valid email address.';
    $pwError = password_strength_error($password);
    if ($pwError) $errors[] = $pwError;
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $check = db()->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'An account with this email already exists.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = db()->prepare(
            "INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'student')"
        );
        $stmt->execute([$fullName, $email, $phone ?: null, $hash]);
        login_user((int) db()->lastInsertId());
        redirect('/dashboard.php');
    }
}

$pageTitle = 'Register';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <form method="post" class="af-form-card">
            <h2 style="text-align:center;">Create Your Account</h2>
            <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
            <?= csrf_field() ?>
            <div style="position:absolute; left:-9999px;" aria-hidden="true">
                <label for="website">Leave this field empty</label>
                <input type="text" id="website" name="website" tabindex="-1" autocomplete="off">
            </div>
            <div class="af-field"><label>Full Name</label><input type="text" name="full_name" value="<?= e($_POST['full_name'] ?? '') ?>" required></div>
            <div class="af-field"><label>Email</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
            <div class="af-field"><label>Phone (for Mobile Money payments)</label><input type="text" name="phone" value="<?= e($_POST['phone'] ?? '') ?>" placeholder="e.g. 6XXXXXXXX"></div>
            <div class="af-field"><label>Password</label><input type="password" name="password" required></div>
            <div class="af-field"><label>Confirm Password</label><input type="password" name="password_confirm" required></div>
            <button type="submit" class="af-btn af-btn-gold af-btn-block">Start Learning</button>
            <p class="af-muted" style="text-align:center; margin-top:16px;">Already have an account? <a href="<?= APP_URL ?>/login.php">Login</a></p>
        </form>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
