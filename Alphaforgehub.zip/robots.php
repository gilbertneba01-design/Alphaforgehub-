<?php
require_once __DIR__ . '/config/config.php';
header('Content-Type: text/plain');

echo "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /config/\nDisallow: /payment/\n";
