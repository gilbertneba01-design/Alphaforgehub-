<?php
/**
 * ALPHA FORGE HUB - Simulator price tick (CLI/cron only, never web-accessible).
 * Advances sim_prices by one small random step per pair. Wire this into
 * XAMPP's Task Scheduler / cron to run every 1-5 seconds-to-minutes, e.g.:
 *   php cron/sim_price_tick.php
 * If it is never run, simulator_api.php still works via its own bounded
 * per-minute fallback wander (see sim_current_price()), just less "live".
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); die('CLI only.'); }
require_once __DIR__ . '/../config/functions.php';

$pairs = ['EURUSD' => 1.08500, 'GBPUSD' => 1.26500, 'USDJPY' => 149.500, 'AUDUSD' => 0.65500,
          'USDCAD' => 1.36500, 'USDCHF' => 0.88500, 'NZDUSD' => 0.60500, 'EURJPY' => 162.000];

foreach ($pairs as $pair => $base) {
    $pip = stripos($pair, 'JPY') !== false ? 0.01 : 0.0001;
    $stmt = db()->prepare('SELECT price FROM sim_prices WHERE pair = ?');
    $stmt->execute([$pair]);
    $current = $stmt->fetchColumn();
    $current = $current !== false ? (float) $current : $base;
    $step = (mt_rand(-100, 100) / 100.0) * $pip * 3;
    $next = round(max($current + $step, $pip), 5);
    // stay within +-2% of base so a long-running cron never drifts absurdly
    if (abs($next - $base) / $base > 0.02) $next = $base;
    db()->prepare('INSERT INTO sim_prices (pair, price) VALUES (?, ?) ON DUPLICATE KEY UPDATE price = VALUES(price)')
        ->execute([$pair, $next]);
}
echo "ticked " . count($pairs) . " pairs\n";
