<?php
/** ALPHA FORGE HUB - Currency Correlation (STUDENT) */
require_once __DIR__ . '/config/functions.php';
require_login();

$timeframe = trim((string) ($_GET['timeframe'] ?? '1M'));
$latestDate = db()->prepare('SELECT MAX(snapshot_date) FROM currency_correlations WHERE timeframe = ?');
$latestDate->execute([$timeframe]);
$latestDate = $latestDate->fetchColumn();

$rows = [];
if ($latestDate) {
    $stmt = db()->prepare('SELECT * FROM currency_correlations WHERE timeframe = ? AND snapshot_date = ? ORDER BY ABS(correlation_value) DESC');
    $stmt->execute([$timeframe, $latestDate]);
    $rows = $stmt->fetchAll();
}
$timeframes = array_column(db()->query('SELECT DISTINCT timeframe FROM currency_correlations')->fetchAll(), 'timeframe');

$pageTitle = 'Currency Correlation';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Currency Correlation</h1>
            <p class="af-muted">How pairs tend to move relative to each other. +1.000 = move together, -1.000 = move oppositely, 0 = no relationship. Correlations change over time — this is a snapshot, not a guarantee.</p>

            <?php if ($timeframes): ?>
                <form method="get" style="margin-bottom:16px;">
                    <select name="timeframe" data-autosubmit>
                        <?php foreach ($timeframes as $tf): ?><option value="<?= e($tf) ?>" <?= $tf === $timeframe ? 'selected' : '' ?>><?= e($tf) ?></option><?php endforeach; ?>
                    </select>
                </form>
            <?php endif; ?>

            <?php if (!$latestDate): ?>
                <div class="af-card" style="padding:24px;">
                    <strong>STATUS:</strong> Currency correlation data provider not configured yet.
                </div>
            <?php else: ?>
                <p class="af-muted">Snapshot date: <?= e($latestDate) ?> &middot; Timeframe: <?= e($timeframe) ?></p>
                <div class="af-table-wrap">
                    <table class="af-table">
                        <thead><tr><th>Pair A</th><th>Pair B</th><th>Correlation</th><th>Relationship</th></tr></thead>
                        <tbody>
                        <?php foreach ($rows as $r): $v = (float) $r['correlation_value']; ?>
                            <tr>
                                <td><?= e($r['pair_a']) ?></td>
                                <td><?= e($r['pair_b']) ?></td>
                                <td><?= number_format($v, 3) ?></td>
                                <td><?= $v > 0.5 ? 'Strong positive' : ($v > 0 ? 'Weak positive' : ($v < -0.5 ? 'Strong negative' : ($v < 0 ? 'Weak negative' : 'None'))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
