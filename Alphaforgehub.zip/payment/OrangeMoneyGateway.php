<?php
/**
 * ALPHA FORGE - Orange Money gateway
 *
 * Talks to the Orange Money Web Payment API.
 *
 * REQUIRED CONFIGURATION (from the Orange Developer Portal
 * https://developer.orange.com, "Orange Money Web Payment" product,
 * Cameroon merchant account):
 *   - ORANGE_MONEY_CLIENT_ID
 *   - ORANGE_MONEY_CLIENT_SECRET
 *   - ORANGE_MONEY_MERCHANT_KEY
 *
 * Until these are supplied, initiatePayment() fails closed.
 */

require_once __DIR__ . '/PaymentGatewayInterface.php';

class OrangeMoneyGateway implements PaymentGatewayInterface {

    private string $baseUrl = 'https://api.orange.com';

    private function isConfigured(): bool {
        return ORANGE_MONEY_CLIENT_ID !== '' && ORANGE_MONEY_CLIENT_SECRET !== '' && ORANGE_MONEY_MERCHANT_KEY !== '';
    }

    private function getAccessToken(): ?string {
        if (!$this->isConfigured()) {
            return null;
        }
        $basic = base64_encode(ORANGE_MONEY_CLIENT_ID . ':' . ORANGE_MONEY_CLIENT_SECRET);
        $ch = curl_init($this->baseUrl . '/oauth/v3/token');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query(['grant_type' => 'client_credentials']),
            CURLOPT_HTTPHEADER => [
                'Authorization: Basic ' . $basic,
                'Content-Type: application/x-www-form-urlencoded',
            ],
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($httpCode !== 200) {
            return null;
        }
        $data = json_decode((string) $response, true);
        return $data['access_token'] ?? null;
    }

    public function initiatePayment(array $payment, array $customer, string $phoneNumber): array {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'redirect_url' => null,
                'provider_reference' => null,
                'message' => 'Orange Money is not yet configured. Add ORANGE_MONEY_CLIENT_ID, ORANGE_MONEY_CLIENT_SECRET and ORANGE_MONEY_MERCHANT_KEY to the server configuration.',
            ];
        }

        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return ['success' => false, 'redirect_url' => null, 'provider_reference' => null, 'message' => 'Could not authenticate with Orange Money.'];
        }

        $orderId = 'AF-' . $payment['id'] . '-' . time();

        $body = [
            'merchant_key' => ORANGE_MONEY_MERCHANT_KEY,
            'currency' => $payment['currency'],
            'order_id' => $orderId,
            'amount' => (string) $payment['amount'],
            'return_url' => APP_URL . '/payment_return.php?ref=' . $orderId,
            'cancel_url' => APP_URL . '/pricing.php?payment=cancelled',
            'notif_url' => APP_URL . '/payment_webhook.php?provider=orange_money',
            'lang' => 'fr',
            'reference' => 'Alpha Forge subscription',
        ];

        $ch = curl_init($this->baseUrl . '/orange-money-webpay/cm/v1/webpayment');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_TIMEOUT => 20,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode((string) $response, true);

        if ($httpCode !== 201 || empty($data['payment_url'])) {
            return ['success' => false, 'redirect_url' => null, 'provider_reference' => null, 'message' => 'Orange Money declined the request.'];
        }

        return [
            'success' => true,
            'redirect_url' => $data['payment_url'],
            'provider_reference' => $data['pay_token'] ?? $orderId,
            'message' => 'Redirecting to Orange Money to complete payment.',
        ];
    }

    public function verifyPayment(string $providerReference): string {
        if (!$this->isConfigured()) {
            return 'pending';
        }
        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return 'pending';
        }

        $ch = curl_init($this->baseUrl . '/orange-money-webpay/cm/v1/transactionstatus');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode([
                'order_id' => $providerReference,
                'amount' => null,
                'pay_token' => $providerReference,
            ]),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode((string) $response, true);
        $status = strtoupper($data['status'] ?? 'PENDING');

        return match ($status) {
            'SUCCESS' => 'successful',
            'FAILED' => 'failed',
            default => 'pending',
        };
    }

    public function handleWebhook(array $payload, array $headers): ?array {
        // Production integrations must validate the notif_url payload against
        // Orange's signature/shared-secret scheme for your merchant account
        // before trusting it. Reject anything that can't be verified.
        if (empty($payload['order_id']) || empty($payload['status'])) {
            return null;
        }
        $status = strtoupper($payload['status']) === 'SUCCESS' ? 'successful' : 'failed';
        return [
            'provider_reference' => $payload['order_id'],
            'status' => $status,
            'raw' => $payload,
        ];
    }
}
