<?php
/**
 * ALPHA FORGE - Payment gateway contract
 *
 * Every real gateway (MTN MoMo, Orange Money, card processor, etc.)
 * implements this interface. Nothing in the application talks to a
 * gateway's raw SDK/API directly - it always goes through this contract,
 * so switching or adding providers never touches subscription/business logic.
 */

interface PaymentGatewayInterface {

    /**
     * Starts a payment for a pending local `payments` row.
     * Must return an array shaped like:
     *   [
     *     'success' => bool,
     *     'redirect_url' => string|null,   // where to send the customer, if applicable
     *     'provider_reference' => string|null, // the gateway's own transaction id
     *     'message' => string,
     *   ]
     * MUST NOT mark the local payment/subscription as successful - only
     * initiates the transaction. Activation only happens via verifyPayment()
     * or via handleWebhook(), both of which check the provider directly.
     */
    public function initiatePayment(array $payment, array $customer, string $phoneNumber): array;

    /**
     * Actively asks the provider for the current status of a transaction
     * (used for polling / manual "check status" actions).
     * Must return one of: 'pending', 'successful', 'failed'.
     */
    public function verifyPayment(string $providerReference): string;

    /**
     * Validates and parses an incoming server-to-server webhook/callback
     * from the provider. Must verify authenticity (signature/secret) before
     * trusting any of the payload. Returns:
     *   ['provider_reference' => string, 'status' => 'successful'|'failed', 'raw' => array]
     * or null if the webhook could not be verified.
     */
    public function handleWebhook(array $payload, array $headers): ?array;
}
