<?php
/**
 * ALPHA FORGE - Payment manager
 *
 * The only place business logic (subscriptions/payments tables) touches
 * a payment gateway. Swap or add providers by editing getGateway() only.
 */

require_once __DIR__ . '/PaymentGatewayInterface.php';
require_once __DIR__ . '/MTNMoMoGateway.php';
require_once __DIR__ . '/OrangeMoneyGateway.php';
require_once __DIR__ . '/../config/db.php';

class PaymentManager {

    public static function getGateway(string $provider): PaymentGatewayInterface {
        return match ($provider) {
            'mtn_momo' => new MTNMoMoGateway(),
            'orange_money' => new OrangeMoneyGateway(),
            default => throw new InvalidArgumentException('Unsupported payment provider: ' . $provider),
        };
    }

    /**
     * Creates a pending subscription + payment row, then asks the gateway
     * to initiate the transaction. Subscription/payment stay 'pending'
     * until verifyAndActivate() or the webhook confirms success.
     */
    public static function startSubscriptionPayment(int $userId, int $planId, string $provider, string $phoneNumber): array {
        $pdo = db();

        $planStmt = $pdo->prepare('SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1');
        $planStmt->execute([$planId]);
        $plan = $planStmt->fetch();
        if (!$plan) {
            return ['success' => false, 'message' => 'Invalid subscription plan.'];
        }

        $userStmt = $pdo->prepare('SELECT id, full_name, email FROM users WHERE id = ?');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user) {
            return ['success' => false, 'message' => 'User not found.'];
        }

        $pdo->beginTransaction();
        try {
            $subStmt = $pdo->prepare(
                'INSERT INTO subscriptions (user_id, plan_id, status) VALUES (?, ?, "pending")'
            );
            $subStmt->execute([$userId, $planId]);
            $subscriptionId = (int) $pdo->lastInsertId();

            $payStmt = $pdo->prepare(
                'INSERT INTO payments (user_id, subscription_id, provider, amount, currency, status)
                 VALUES (?, ?, ?, ?, ?, "initiated")'
            );
            $payStmt->execute([$userId, $subscriptionId, $provider, $plan['price'], $plan['currency']]);
            $paymentId = (int) $pdo->lastInsertId();

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Could not start payment. Please try again.'];
        }

        $gateway = self::getGateway($provider);
        $payment = ['id' => $paymentId, 'amount' => $plan['price'], 'currency' => $plan['currency']];
        $result = $gateway->initiatePayment($payment, $user, $phoneNumber);

        $newStatus = $result['success'] ? 'pending' : 'failed';
        $update = $pdo->prepare('UPDATE payments SET status = ?, provider_reference = ?, raw_response = ? WHERE id = ?');
        $update->execute([$newStatus, $result['provider_reference'], json_encode($result), $paymentId]);

        return [
            'success' => $result['success'],
            'message' => $result['message'],
            'redirect_url' => $result['redirect_url'] ?? null,
            'payment_id' => $paymentId,
            'subscription_id' => $subscriptionId,
        ];
    }

    /**
     * Creates a pending store_purchases + payment row for a one-off product
     * (ebook/bundle/premium content) and asks the gateway to initiate it.
     * Mirrors startSubscriptionPayment() but for the Store.
     */
    public static function startProductPayment(int $userId, int $productId, string $provider, string $phoneNumber): array {
        $pdo = db();

        $prodStmt = $pdo->prepare("SELECT * FROM store_products WHERE id = ? AND status = 'published'");
        $prodStmt->execute([$productId]);
        $product = $prodStmt->fetch();
        if (!$product) {
            return ['success' => false, 'message' => 'Product not found.'];
        }

        $userStmt = $pdo->prepare('SELECT id, full_name, email FROM users WHERE id = ?');
        $userStmt->execute([$userId]);
        $user = $userStmt->fetch();
        if (!$user) {
            return ['success' => false, 'message' => 'User not found.'];
        }

        $pdo->beginTransaction();
        try {
            $purchaseStmt = $pdo->prepare('INSERT INTO store_purchases (user_id, product_id, amount, status) VALUES (?, ?, ?, "pending")');
            $purchaseStmt->execute([$userId, $productId, $product['price']]);
            $purchaseId = (int) $pdo->lastInsertId();

            $payStmt = $pdo->prepare(
                'INSERT INTO payments (user_id, product_id, provider, amount, currency, status)
                 VALUES (?, ?, ?, ?, ?, "initiated")'
            );
            $payStmt->execute([$userId, $productId, $provider, $product['price'], $product['currency']]);
            $paymentId = (int) $pdo->lastInsertId();

            $pdo->prepare('UPDATE store_purchases SET payment_id = ? WHERE id = ?')->execute([$paymentId, $purchaseId]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Could not start payment. Please try again.'];
        }

        $gateway = self::getGateway($provider);
        $payment = ['id' => $paymentId, 'amount' => $product['price'], 'currency' => $product['currency']];
        $result = $gateway->initiatePayment($payment, $user, $phoneNumber);

        $newStatus = $result['success'] ? 'pending' : 'failed';
        $update = $pdo->prepare('UPDATE payments SET status = ?, provider_reference = ?, raw_response = ? WHERE id = ?');
        $update->execute([$newStatus, $result['provider_reference'], json_encode($result), $paymentId]);

        return [
            'success' => $result['success'],
            'message' => $result['message'],
            'redirect_url' => $result['redirect_url'] ?? null,
            'payment_id' => $paymentId,
            'purchase_id' => $purchaseId,
        ];
    }

    /**
     * Actively polls the gateway for a payment's real status and, only if the
     * PROVIDER confirms success, activates the subscription or store purchase.
     * Never activates based on the user simply landing on a "return" page.
     */
    public static function verifyAndActivate(int $paymentId): string {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT * FROM payments WHERE id = ?');
        $stmt->execute([$paymentId]);
        $payment = $stmt->fetch();
        if (!$payment) {
            return 'failed';
        }
        if ($payment['status'] === 'successful') {
            return 'successful';
        }
        if (!$payment['provider_reference']) {
            return 'pending';
        }

        $gateway = self::getGateway($payment['provider']);
        $status = $gateway->verifyPayment($payment['provider_reference']);

        if ($status === 'successful') {
            if (!empty($payment['product_id'])) {
                self::activateProductPurchase($payment['id']);
            } else {
                self::activateSubscription($payment['id']);
            }
        } elseif ($status === 'failed') {
            $pdo->prepare('UPDATE payments SET status = "failed" WHERE id = ?')->execute([$paymentId]);
            if (!empty($payment['subscription_id'])) {
                $pdo->prepare('UPDATE subscriptions SET status = "cancelled" WHERE id = ?')->execute([$payment['subscription_id']]);
            } elseif (!empty($payment['product_id'])) {
                $pdo->prepare('UPDATE store_purchases SET status = "failed" WHERE payment_id = ?')->execute([$paymentId]);
            }
        }

        return $status;
    }

    /** Called by a verified webhook or verifyAndActivate() only - never from a GET/return page. */
    public static function activateProductPurchase(int $paymentId): void {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM payments WHERE id = ? FOR UPDATE');
            $stmt->execute([$paymentId]);
            $payment = $stmt->fetch();
            if (!$payment || $payment['status'] === 'successful') {
                $pdo->commit();
                return;
            }

            $pdo->prepare('UPDATE payments SET status = "successful" WHERE id = ?')->execute([$paymentId]);
            $pdo->prepare('UPDATE store_purchases SET status = "paid" WHERE payment_id = ?')->execute([$paymentId]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
        }
    }

    /** Called by a verified webhook or verifyAndActivate() only - never from a GET/return page. */
    public static function activateSubscription(int $paymentId): void {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT p.*, s.plan_id FROM payments p JOIN subscriptions s ON s.id = p.subscription_id WHERE p.id = ? FOR UPDATE');
            $stmt->execute([$paymentId]);
            $payment = $stmt->fetch();
            if (!$payment || $payment['status'] === 'successful') {
                $pdo->commit();
                return;
            }

            $planStmt = $pdo->prepare('SELECT duration_days FROM subscription_plans WHERE id = ?');
            $planStmt->execute([$payment['plan_id']]);
            $plan = $planStmt->fetch();
            $days = (int) ($plan['duration_days'] ?? 30);

            $pdo->prepare('UPDATE payments SET status = "successful" WHERE id = ?')->execute([$paymentId]);
            $pdo->prepare(
                'UPDATE subscriptions SET status = "active", starts_at = NOW(), ends_at = DATE_ADD(NOW(), INTERVAL ? DAY) WHERE id = ?'
            )->execute([$days, $payment['subscription_id']]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
        }
    }
}
