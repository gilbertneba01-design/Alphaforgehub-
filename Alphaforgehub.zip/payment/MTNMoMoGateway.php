<?php
/**
 * ALPHA FORGE - MTN Mobile Money (Collections API) gateway
 *
 * This class talks to the real MTN MoMo "Request to Pay" Collections API.
 *
 * REQUIRED CONFIGURATION (set as environment variables / config/.env.php,
 * obtained from the MTN MoMo Developer Portal https://momodeveloper.mtn.com):
 *   - MTN_MOMO_SUBSCRIPTION_KEY  (Ocp-Apim-Subscription-Key for the Collections product)
 *   - MTN_MOMO_API_USER          (API user UUID, created via the Collections sandbox/prod provisioning call)
 *   - MTN_MOMO_API_KEY           (API key generated for that API user)
 *   - MTN_MOMO_ENV               ('sandbox' or 'production')
 *   - MTN_MOMO_CALLBACK_HOST     (public HTTPS URL MTN will notify - must NOT be localhost in production)
 *
 * Until those are supplied, initiatePayment() will safely fail closed
 * (returns success => false) rather than pretending a payment succeeded.
 */

require_once __DIR__ . '/PaymentGatewayInterface.php';

class MTNMoMoGateway implements PaymentGatewayInterface {

    private string $baseUrl;

    public function __construct() {
        $this->baseUrl = MTN_MOMO_ENV === 'production'
            ? 'https://proxy.momoapi.mtn.com'
            : 'https://sandbox.momodeveloper.mtn.com';
    }

    private function isConfigured(): bool {
        return MTN_MOMO_SUBSCRIPTION_KEY !== '' && MTN_MOMO_API_USER !== '' && MTN_MOMO_API_KEY !== '';
    }

    /** Obtains a short-lived OAuth access token using the API user/key. */
    private function getAccessToken(): ?string {
        if (!$this->isConfigured()) {
            return null;
        }
        $ch = curl_init($this->baseUrl . '/collection/token/');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_USERPWD => MTN_MOMO_API_USER . ':' . MTN_MOMO_API_KEY,
            CURLOPT_HTTPHEADER => [
                'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_SUBSCRIPTION_KEY,
                'Content-Length: 0',
            ],
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            return null;
        }
        $data = json_decode((string) $response, true);
        return $data['access_token'] ?? null;
    }

    public function initiatePayment(array $payment, array $customer, string $phoneNumber): array {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'redirect_url' => null,
                'provider_reference' => null,
                'message' => 'MTN Mobile Money is not yet configured. Add MTN_MOMO_SUBSCRIPTION_KEY, MTN_MOMO_API_USER and MTN_MOMO_API_KEY to the server configuration.',
            ];
        }

        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return ['success' => false, 'redirect_url' => null, 'provider_reference' => null, 'message' => 'Could not authenticate with MTN Mobile Money.'];
        }

        $referenceId = strtolower(bin2hex(random_bytes(16))); // MTN requires a UUID as external Id
        $referenceId = sprintf('%s-%s-%s-%s-%s',
            substr($referenceId, 0, 8), substr($referenceId, 8, 4),
            substr($referenceId, 12, 4), substr($referenceId, 16, 4), substr($referenceId, 20, 12));

        $body = [
            'amount' => (string) $payment['amount'],
            'currency' => $payment['currency'],
            'externalId' => (string) $payment['id'],
            'payer' => ['partyIdType' => 'MSISDN', 'partyId' => preg_replace('/\D/', '', $phoneNumber)],
            'payerMessage' => 'Alpha Forge subscription',
            'payeeNote' => 'Alpha Forge subscription #' . $payment['id'],
        ];

        $ch = curl_init($this->baseUrl . '/collection/v1_0/requesttopay');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'X-Reference-Id: ' . $referenceId,
                'X-Target-Environment: ' . MTN_MOMO_ENV,
                'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_SUBSCRIPTION_KEY,
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 20,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 202) {
            return ['success' => false, 'redirect_url' => null, 'provider_reference' => null, 'message' => 'MTN Mobile Money declined the request: ' . $response];
        }

        return [
            'success' => true,
            'redirect_url' => null, // MoMo push is on-phone approval, no redirect needed
            'provider_reference' => $referenceId,
            'message' => 'A payment prompt has been sent to ' . $phoneNumber . '. Approve it on your phone to activate your subscription.',
        ];
    }

    public function verifyPayment(string $providerReference): string {
        if (!$this->isConfigured()) {
            return 'pending';
        }
        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return 'pending';
        }

        $ch = curl_init($this->baseUrl . '/collection/v1_0/requesttopay/' . urlencode($providerReference));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'X-Target-Environment: ' . MTN_MOMO_ENV,
                'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_SUBSCRIPTION_KEY,
            ],
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode((string) $response, true);
        $status = $data['status'] ?? 'PENDING';

        return match (strtoupper($status)) {
            'SUCCESSFUL' => 'successful',
            'FAILED' => 'failed',
            default => 'pending',
        };
    }

    public function handleWebhook(array $payload, array $headers): ?array {
        // MTN MoMo's sandbox does not sign callbacks; production integrations should
        // verify the request originates from MTN's IP range / an agreed shared secret
        // header before trusting the payload. Reject anything unverified.
        if (empty($payload['referenceId']) || empty($payload['status'])) {
            return null;
        }
        $status = strtoupper($payload['status']) === 'SUCCESSFUL' ? 'successful' : 'failed';
        return [
            'provider_reference' => $payload['referenceId'],
            'status' => $status,
            'raw' => $payload,
        ];
    }
}
