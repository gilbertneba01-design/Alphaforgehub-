<?php
/**
 * ALPHA FORGE HUB - AI Tutor (STUDENT)
 * Alpha Forge AI Tutor & Trading Coach: mode-based Forex education chat,
 * optionally scoped to the lesson the student came from.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/ai_tutor.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

$available = ai_tutor_available();
$quotaLeft = $available ? ai_tutor_quota_remaining($userId) : 0;
$dailyLimit = $available ? ai_tutor_daily_limit($userId) : 0;

$initialLessonId = (int) ($_GET['lesson_id'] ?? 0) ?: null;
$initialCourseId = (int) ($_GET['course_id'] ?? 0) ?: null;
$initialConvId   = (int) ($_GET['conv'] ?? 0) ?: null;

$lessonLabel = null;
if ($initialLessonId) {
    $ctx = ai_tutor_lesson_context($initialLessonId);
    if ($ctx) {
        $lessonLabel = $ctx['lesson_title'];
    }
}

$pageTitle = 'AI Tutor';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section af-lab-page">
    <div class="af-container" style="max-width:1100px;">

        <div class="af-lab-hero">
            <div>
                <span class="af-eyebrow">Alpha Forge HUB</span>
                <h1>&#129302; AI Tutor</h1>
                <p>Your Forex education coach. Ask questions, request examples, switch teaching level, or ask to be quizzed on what you're learning.</p>
            </div>
            <?php if ($available): ?>
                <div class="af-badge af-badge-muted" id="afTutorQuota">
                    <?= (int) $quotaLeft ?> / <?= (int) $dailyLimit ?> messages left today
                </div>
            <?php endif; ?>
        </div>

        <?php if (!$available): ?>
            <div class="af-card">
                <span class="af-badge">Not configured</span>
                <p style="margin-top:10px;">The AI Tutor hasn't been set up yet. An administrator needs to add an AI provider API key in <code>config/.env.php</code>.</p>
            </div>
        <?php else: ?>

        <div class="af-tutor-wrap">
            <aside class="af-tutor-sidebar">
                <button type="button" class="af-btn af-btn-gold af-btn-block" id="afTutorNewBtn">+ New Conversation</button>

                <div class="af-tutor-modes" id="afTutorModes">
                    <?php foreach (AI_TUTOR_MODE_LABELS as $modeKey => $modeLabel): ?>
                        <button type="button" class="af-tutor-mode-btn<?= $modeKey === 'explain' ? ' active' : '' ?>" data-mode="<?= e($modeKey) ?>"><?= e($modeLabel) ?></button>
                    <?php endforeach; ?>
                </div>

                <div class="af-tutor-conv-list" id="afTutorConvList">
                    <p class="af-muted" style="padding:8px;">Loading conversations&hellip;</p>
                </div>
            </aside>

            <main class="af-tutor-main">
                <?php if ($lessonLabel): ?>
                    <div class="af-tutor-context-banner">Context: <?= e($lessonLabel) ?></div>
                <?php endif; ?>

                <div class="af-tutor-messages" id="afTutorMessages">
                    <div class="af-tutor-empty" id="afTutorEmpty">
                        <p>Ask me anything about Forex trading &mdash; market structure, risk management, a Chart Lab concept, or a lesson you just read.</p>
                        <p class="af-muted">Try: &ldquo;I don't understand Break of Structure.&rdquo;</p>
                    </div>
                </div>

                <form id="afTutorForm" class="af-tutor-input-row">
                    <?= csrf_field() ?>
                    <textarea id="afTutorInput" placeholder="Ask the AI Tutor a question..." maxlength="<?= AI_TUTOR_MAX_INPUT_CHARS ?>" rows="2"></textarea>
                    <button type="submit" class="af-btn af-btn-gold" id="afTutorSendBtn">Send</button>
                </form>
                <p class="af-muted af-tutor-disclaimer">Educational only &mdash; the AI Tutor never guarantees profits or predicts the market.</p>
            </main>
        </div>

        <?php endif; ?>
    </div>
</section>
<script nonce="<?= CSP_NONCE ?>">
window.AF_TUTOR_INIT = {
    lessonId: <?= json_encode($initialLessonId) ?>,
    courseId: <?= json_encode($initialCourseId) ?>,
    conversationId: <?= json_encode($initialConvId) ?>,
    apiUrl: <?= json_encode(APP_URL . '/api/ai/chat.php') ?>,
    dailyLimit: <?= json_encode($dailyLimit) ?>
};
</script>
<?php
$extraScripts = ['/assets/js/ai_tutor.js'];
require_once __DIR__ . '/includes/footer.php';

