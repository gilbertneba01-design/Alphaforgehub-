<?php
/** ALPHA FORGE HUB - Risk-On / Risk-Off sentiment dashboard (STUDENT, educational) */
require_once __DIR__ . '/config/functions.php';
require_login();

$latest = db()->query('SELECT * FROM market_sentiment_snapshots ORDER BY snapshot_date DESC LIMIT 5')->fetchAll();
$pageTitle = 'Risk-On / Risk-Off';
require_once __DIR__ . '/includes/header.php';
$labels = ['risk_on' => ['Risk-On', '#2ecc71'], 'risk_off' => ['Risk-Off', '#e74c3c'], 'neutral' => ['Neutral', '#f1c40f']];
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Risk-On / Risk-Off</h1>
            <p class="af-muted">A framework for reading overall market mood. <strong>Risk-on</strong>: investors favor higher-yield/riskier assets (AUD, NZD, equities); money tends to move away from safe havens.
            <strong>Risk-off</strong>: investors favor safety (JPY, CHF, USD, gold); riskier assets are typically sold. This dashboard shows our team's educational read, manually recorded — not a live feed.</p>

            <?php if (empty($latest)): ?>
                <div class="af-card" style="padding:24px;"><strong>STATUS:</strong> Market sentiment not yet recorded by admin.</div>
            <?php else: ?>
                <div class="af-grid" style="gap:14px;">
                    <?php foreach ($latest as $s): [$label, $color] = $labels[$s['sentiment']]; ?>
                        <div class="af-card" style="padding:18px; border-left:4px solid <?= $color ?>;">
                            <div style="display:flex; justify-content:space-between;">
                                <strong style="color:<?= $color ?>;"><?= $label ?></strong>
                                <span class="af-muted"><?= e($s['snapshot_date']) ?></span>
                            </div>
                            <p style="margin:8px 0 0;"><?= e($s['summary']) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <p class="af-lab-legal" style="margin-top:16px;">Educational framework only. Sentiment can shift within a single session — never trade solely off this dashboard.</p>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
