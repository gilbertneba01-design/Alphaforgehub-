<?php
/**
 * ALPHA FORGE - Chart Lab (STUDENT)
 * Practise marking support, resistance, ranges and supply/demand zones on a
 * chart and get an instant, server-checked verdict.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/chartlab.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];
$isAdmin = is_admin();

$available  = chartlab_available();
$exercises  = $available ? chartlab_list_exercises($userId) : [];
$stats      = chartlab_stats($userId);
$hasAccess  = $isAdmin || has_active_subscription($userId);

// ---- Which exercise are we showing? ----
$selected = null;
if ($exercises) {
    $wantId = (int) ($_GET['ex'] ?? 0);
    foreach ($exercises as $row) {
        if ((int) $row['id'] === $wantId) {
            $selected = $row;
            break;
        }
    }
    if ($selected === null) {
        // Default: the first unsolved exercise this student can open.
        foreach ($exercises as $row) {
            $canOpen = !(int) $row['is_premium'] || $hasAccess;
            if ($canOpen && (int) $row['solved_count'] === 0) {
                $selected = $row;
                break;
            }
        }
        if ($selected === null) {
            $selected = $exercises[0];
        }
    }
}

$exercise = null;
$locked   = false;
$payload  = null;

if ($selected !== null) {
    $exercise = chartlab_get_exercise((int) $selected['id']);
    if ($exercise) {
        if (!chartlab_can_access($exercise, $userId)) {
            $locked = true;
        } else {
            $cnt = db()->prepare('SELECT COUNT(*) FROM chartlab_attempts WHERE user_id = ? AND exercise_id = ?');
            $cnt->execute([$userId, (int) $exercise['id']]);
            $payload = chartlab_client_payload($exercise, (int) $cnt->fetchColumn());
        }
    }
}

$pageTitle = 'Chart Lab';
$extraScripts = ['/assets/js/chartlab.js'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section af-lab-page">
    <div class="af-container">

        <div class="af-lab-hero">
            <div>
                <span class="af-eyebrow">Technical Analysis &middot; Practice</span>
                <h1>Chart Lab</h1>
                <p>Read the chart, mark the zone, and get instant feedback. Every verdict comes from the same rules a trader would use: where did price actually react?</p>
            </div>
            <?php if ($stats['total'] > 0): ?>
                <div class="af-lab-score" id="labScore" data-total="<?= (int) $stats['total'] ?>">
                    <span class="af-lab-score-num"><span id="labSolved"><?= (int) $stats['solved'] ?></span><small>/<?= (int) $stats['total'] ?></small></span>
                    <span class="af-lab-score-label">exercises solved</span>
                </div>
            <?php endif; ?>
        </div>

        <div class="af-lab-layout">
            <div class="af-lab-main">
            <?php if (!$available): ?>
                <div class="af-card af-lab-empty">
                    <h3>Chart Lab is almost ready</h3>
                    <?php if ($isAdmin): ?>
                        <p>The Chart Lab tables are missing. In phpMyAdmin, import <code>database/migration_chartlab.sql</code> into the <code>alpha_forge</code> database, then reload this page.</p>
                    <?php else: ?>
                        <p>We are still setting up the exercises. Please check back soon.</p>
                    <?php endif; ?>
                </div>

            <?php elseif (!$exercises): ?>
                <div class="af-card af-lab-empty">
                    <h3>No exercises yet</h3>
                    <p>New chart exercises are on the way. Check back soon.</p>
                </div>

            <?php elseif ($locked): ?>
                <div class="af-card af-lab-locked">
                    <span class="af-badge">Premium</span>
                    <h2><?= e($exercise['title']) ?></h2>
                    <p><?= e($exercise['pair_label']) ?> &middot; <?= e($exercise['timeframe_label']) ?> &middot; <?= e($exercise['difficulty']) ?></p>
                    <p>This exercise is part of Premium. Subscribe to unlock every Chart Lab exercise, plus all Premium lessons and quizzes.</p>
                    <a href="<?= APP_URL ?>/pricing.php?reason=premium" class="af-btn af-btn-gold">Unlock Premium</a>
                </div>

            <?php elseif ($payload): ?>
                <div class="af-card af-lab"
                     id="chartLab"
                     data-api="<?= e(APP_URL . '/chart_lab_api.php') ?>"
                     data-lab-url="<?= e(APP_URL . '/chart_lab.php') ?>"
                     data-csrf="<?= e(csrf_token()) ?>"
                     data-exercise="<?= e(json_encode($payload, JSON_UNESCAPED_SLASHES)) ?>">

                    <div class="af-lab-head">
                        <div class="af-lab-tags">
                            <span class="af-badge"><?= e($exercise['difficulty']) ?></span>
                            <span class="af-badge af-badge-muted"><?= e($exercise['pair_label']) ?> &middot; <?= e($exercise['timeframe_label']) ?></span>
                            <?php if ((int) $exercise['is_premium']): ?><span class="af-badge af-badge-muted">Premium</span><?php endif; ?>
                        </div>
                        <h2><?= e($exercise['title']) ?></h2>
                        <p class="af-lab-instruction"><?= e($exercise['instruction']) ?></p>
                    </div>

                    <div class="af-lab-stage" id="labStage">
                        <canvas id="labCanvas" tabindex="0"
                                aria-label="Price chart. Drag to draw a zone. Press Enter to submit and Escape to clear."></canvas>
                        <noscript><p class="af-alert af-alert-error">Chart Lab needs JavaScript. Please enable it in your browser.</p></noscript>
                    </div>

                    <p class="af-lab-help" id="labHelp">Drag on the chart to draw a zone. Drag inside it to move it, or drag an edge or corner to resize.</p>

                    <div class="af-lab-toolbar">
                        <button type="button" class="af-btn af-btn-gold" id="labSubmit" disabled>Submit Zone</button>
                        <button type="button" class="af-btn af-btn-ghost" id="labClear" disabled>Clear</button>
                        <button type="button" class="af-btn af-btn-ghost" id="labHint">Hint</button>
                        <button type="button" class="af-btn af-btn-ghost" id="labReveal" hidden>Show Answer</button>
                        <a class="af-btn af-btn-gold" id="labNext" href="<?= e(APP_URL . '/chart_lab.php') ?>" hidden>Next Exercise</a>
                    </div>

                    <div class="af-lab-hintbox" id="labHintBox" hidden></div>
                    <div class="af-lab-result" id="labResult" role="status" aria-live="polite" hidden></div>
                    <div class="af-lab-explain" id="labExplain" hidden></div>

                    <p class="af-lab-legal">Practice charts are for education only. They are not predictions, signals or financial advice.</p>
                </div>
            <?php endif; ?>
            </div>

            <?php if ($exercises): ?>
            <aside class="af-lab-list" aria-label="Chart Lab exercises">
                <h3>Exercises</h3>
                <?php foreach ($exercises as $i => $row): ?>
                    <?php
                        $isCurrent = $selected !== null && (int) $row['id'] === (int) $selected['id'];
                        $isSolved  = (int) $row['solved_count'] > 0;
                        $isLocked  = (int) $row['is_premium'] && !$hasAccess;
                        $cls = 'af-lab-item' . ($isCurrent ? ' active' : '') . ($isSolved ? ' solved' : '') . ($isLocked ? ' locked' : '');
                    ?>
                    <a class="<?= $cls ?>" href="<?= APP_URL ?>/chart_lab.php?ex=<?= (int) $row['id'] ?>" data-exercise-id="<?= (int) $row['id'] ?>">
                        <span class="af-lab-item-num"><?= $isSolved ? '&#10003;' : ($i + 1) ?></span>
                        <span class="af-lab-item-body">
                            <strong><?= e($row['title']) ?></strong>
                            <small><?= e($row['pair_label']) ?> &middot; <?= e($row['timeframe_label']) ?> &middot; <?= e($row['difficulty']) ?></small>
                        </span>
                        <?php if ($isLocked): ?><span class="af-badge af-badge-muted">Premium</span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
                <a href="<?= APP_URL ?>/course.php?slug=technical-analysis" class="af-lab-back">&larr; Technical Analysis course</a>
            </aside>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
