<?php
/**
 * ALPHA FORGE HUB - Live Sessions (STUDENT)
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$upcoming = db()->prepare("SELECT * FROM live_sessions WHERE status = 'scheduled' AND session_datetime >= NOW() ORDER BY session_datetime ASC");
$upcoming->execute();
$upcoming = $upcoming->fetchAll();

$past = db()->prepare("SELECT * FROM live_sessions WHERE status = 'completed' OR session_datetime < NOW() ORDER BY session_datetime DESC LIMIT 50");
$past->execute();
$past = $past->fetchAll();

$pageTitle = 'Live Sessions';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Live Sessions</h1>

            <h3>Upcoming</h3>
            <?php foreach ($upcoming as $s): ?>
                <div class="af-card" style="margin-bottom:12px;">
                    <h4 style="margin:0 0 4px;"><?= e($s['title']) ?></h4>
                    <p class="af-muted" style="margin:0 0 8px;"><?= e(date('l, d M Y \a\t H:i', strtotime($s['session_datetime']))) ?></p>
                    <?php if ($s['description']): ?><p><?= nl2br(e($s['description'])) ?></p><?php endif; ?>
                    <?php if ($s['join_url']): ?><a href="<?= e($s['join_url']) ?>" target="_blank" rel="noopener" class="af-btn af-btn-gold">Join Session</a><?php else: ?><span class="af-badge af-badge-muted">Link coming soon</span><?php endif; ?>
                </div>
            <?php endforeach; ?>
            <?php if (!$upcoming): ?><p class="af-muted">No upcoming sessions scheduled yet.</p><?php endif; ?>

            <h3 style="margin-top:26px;">Past Sessions</h3>
            <?php foreach ($past as $s): ?>
                <div class="af-card" style="margin-bottom:12px;">
                    <h4 style="margin:0 0 4px;"><?= e($s['title']) ?></h4>
                    <p class="af-muted" style="margin:0 0 8px;"><?= e(date('d M Y', strtotime($s['session_datetime']))) ?></p>
                    <?php if ($s['recording_url']): ?><a href="<?= e($s['recording_url']) ?>" target="_blank" rel="noopener" class="af-btn af-btn-ghost">Watch Recording</a><?php else: ?><span class="af-muted">Recording not available</span><?php endif; ?>
                </div>
            <?php endforeach; ?>
            <?php if (!$past): ?><p class="af-muted">No past sessions yet.</p><?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
