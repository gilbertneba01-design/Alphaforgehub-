<?php
/**
 * ALPHA FORGE - Build Your First Trade (STUDENT)
 * A guided, self-contained practice exercise linked from the Risk
 * Management lessons ("Risk Per Trade" and "Stop Loss and Take
 * Profit"). No real money and no live prices are involved - this is
 * a structured checklist that scores the STRUCTURE of a trade plan
 * (direction, stop, target, sizing), not a prediction of outcome.
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$pageTitle = 'Build Your First Trade - Practice';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section af-lab-page">
    <div class="af-container" style="max-width:820px;">

        <div class="af-lab-hero">
            <div>
                <span class="af-eyebrow">Risk Management &middot; Practice</span>
                <h1>Build Your First Trade</h1>
                <p>Walk through the same decisions a trader makes before clicking Buy or Sell: direction, entry, stop loss, take profit and position size. Nothing here is a live trade or a prediction - it only checks whether your plan is structured soundly.</p>
            </div>
        </div>

        <div class="af-card" style="padding:24px;">
            <div id="ftScenario" style="margin-bottom:18px; padding:14px; border-radius:10px; background:rgba(157,176,196,0.08);">
                <strong id="ftPairLine"></strong>
                <p id="ftContext" style="margin:6px 0 0; color:var(--af-muted,#9DB0C4); font-size:14px;"></p>
            </div>

            <div style="display:grid; gap:16px;">
                <div>
                    <span style="display:block; margin-bottom:8px; font-size:13px;">1. Direction - based on the context above, will you buy or sell?</span>
                    <div style="display:flex; gap:10px;">
                        <button type="button" class="af-btn af-btn-ghost" id="ftBuy">Buy</button>
                        <button type="button" class="af-btn af-btn-ghost" id="ftSell">Sell</button>
                    </div>
                </div>

                <div class="af-field"><label>2. Entry price</label>
                    <input type="number" step="0.00001" id="ftEntry"></div>

                <div class="af-field"><label>3. Stop loss price</label>
                    <input type="number" step="0.00001" id="ftStop"></div>

                <div class="af-field"><label>4. Take profit price</label>
                    <input type="number" step="0.00001" id="ftTarget"></div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                    <div class="af-field"><label>5. Account balance ($)</label>
                        <input type="number" step="1" id="ftBalance" value="1000"></div>
                    <div class="af-field"><label>6. Risk on this trade (%)</label>
                        <input type="number" step="0.1" id="ftRiskPct" value="1"></div>
                </div>
            </div>

            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:18px;">
                <button type="button" class="af-btn af-btn-gold" id="ftCheck">Check My Trade</button>
                <button type="button" class="af-btn af-btn-ghost" id="ftNew">New Scenario</button>
            </div>

            <div id="ftResult" class="af-lab-result" role="status" aria-live="polite" hidden style="margin-top:18px;"></div>

            <p class="af-lab-legal" style="margin-top:20px;">Educational exercise only. No real prices, no real money and no guarantee of profit - this checks the STRUCTURE of a trade plan, not whether the market would actually move this way.</p>
        </div>
    </div>
</section>

<script nonce="<?= CSP_NONCE ?>">
(function () {
    var scenarios = [
        { pair: 'EUR/USD', price: 1.08500, decimals: 5, pip: 0.0001, pipValuePerLot: 10,
          context: 'Price has made two rising swing lows over the last few hours and just broke above the recent high. The higher-low structure suggests an uptrend continuing.' },
        { pair: 'GBP/USD', price: 1.26400, decimals: 5, pip: 0.0001, pipValuePerLot: 10,
          context: 'Price has made two falling swing highs and just broke below the recent low. The lower-high structure suggests the downtrend is continuing.' },
        { pair: 'USD/JPY', price: 151.800, decimals: 3, pip: 0.01, pipValuePerLot: 9.1,
          context: 'Price bounced strongly off the same support level three times this week and is now rallying away from it.' }
    ];

    var direction = null;
    var scenario = null;

    function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
    function fmt(v) { return v.toFixed(scenario.decimals); }

    function newScenario() {
        scenario = rand(scenarios);
        direction = null;
        document.getElementById('ftPairLine').textContent = scenario.pair + ' is currently trading around ' + fmt(scenario.price) + '.';
        document.getElementById('ftContext').textContent = scenario.context;
        document.getElementById('ftEntry').value = '';
        document.getElementById('ftStop').value = '';
        document.getElementById('ftTarget').value = '';
        document.getElementById('ftResult').hidden = true;
        setDirButtons();
    }

    function setDirButtons() {
        document.getElementById('ftBuy').className = 'af-btn ' + (direction === 'buy' ? 'af-btn-gold' : 'af-btn-ghost');
        document.getElementById('ftSell').className = 'af-btn ' + (direction === 'sell' ? 'af-btn-gold' : 'af-btn-ghost');
    }

    document.getElementById('ftBuy').addEventListener('click', function () { direction = 'buy'; setDirButtons(); });
    document.getElementById('ftSell').addEventListener('click', function () { direction = 'sell'; setDirButtons(); });
    document.getElementById('ftNew').addEventListener('click', newScenario);

    function showResult(kind, lines) {
        var r = document.getElementById('ftResult');
        r.hidden = false;
        r.className = 'af-lab-result is-' + kind;
        r.innerHTML = lines.map(function (l) { return '<p style="margin:2px 0;">' + l + '</p>'; }).join('');
    }

    document.getElementById('ftCheck').addEventListener('click', function () {
        var entry = parseFloat(document.getElementById('ftEntry').value);
        var stop = parseFloat(document.getElementById('ftStop').value);
        var target = parseFloat(document.getElementById('ftTarget').value);
        var balance = parseFloat(document.getElementById('ftBalance').value);
        var riskPct = parseFloat(document.getElementById('ftRiskPct').value);

        var problems = [];
        if (!direction) { problems.push('Choose Buy or Sell first.'); }
        [entry, stop, target, balance, riskPct].forEach(function (v, i) {
            if (!isFinite(v)) { problems.push('Fill in every field before checking.'); }
        });
        if (problems.length) { showResult('wrong', problems); return; }

        if (direction === 'buy') {
            if (stop >= entry) { problems.push('For a BUY, your stop loss must be placed BELOW your entry price.'); }
            if (target <= entry) { problems.push('For a BUY, your take profit must be placed ABOVE your entry price.'); }
        } else {
            if (stop <= entry) { problems.push('For a SELL, your stop loss must be placed ABOVE your entry price.'); }
            if (target >= entry) { problems.push('For a SELL, your take profit must be placed BELOW your entry price.'); }
        }

        if (problems.length) { showResult('wrong', problems); return; }

        var riskDistance = Math.abs(entry - stop);
        var rewardDistance = Math.abs(target - entry);
        var rr = riskDistance > 0 ? rewardDistance / riskDistance : 0;
        var riskPips = riskDistance / scenario.pip;
        var riskAmount = balance * (riskPct / 100);
        var lotSize = riskPips > 0 ? riskAmount / (riskPips * scenario.pipValuePerLot) : 0;

        var notes = [];
        var kind = 'correct';

        notes.push('Direction: <strong>' + direction.toUpperCase() + '</strong> at ' + fmt(entry) + ', stop ' + fmt(stop) + ', target ' + fmt(target) + '.');
        notes.push('Risk-to-reward ratio: <strong>1 : ' + rr.toFixed(2) + '</strong>' + (rr < 1 ? ' - this trade risks more than it aims to gain.' : (rr < 1.5 ? ' - workable, but many traders look for at least 1:1.5.' : ' - a healthy ratio.')));
        notes.push('Position size for ' + riskPct + '% risk: approximately <strong>' + lotSize.toFixed(2) + ' lots</strong> (risking about $' + riskAmount.toFixed(2) + ').');

        if (rr < 1) { kind = 'wrong'; }
        else if (rr < 1.5 || riskPct > 2) { kind = 'close'; }

        if (riskPct > 2) { notes.push('Risking ' + riskPct + '% on one trade is high. Most risk-management rules cap this at around 1-2% per trade.'); }

        showResult(kind, notes);
    });

    newScenario();
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
