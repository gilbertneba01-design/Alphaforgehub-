<?php
/** ALPHA FORGE HUB - Global Search (PUBLIC + STUDENT, results vary by login) */
require_once __DIR__ . '/config/functions.php';

$q = trim((string) ($_GET['q'] ?? ''));
$results = ['courses' => [], 'lessons' => [], 'forexpedia' => [], 'chartlab' => [], 'tools' => []];

$toolsIndex = [
    ['forex_tools.php', 'Pip Calculator'], ['forex_tools.php', 'Lot Size Calculator'],
    ['forex_tools.php', 'Risk Calculator'], ['forex_tools.php', 'Risk/Reward Calculator'],
    ['forex_tools.php', 'Profit/Loss Calculator'], ['forex_tools.php', 'Margin Calculator'],
    ['forex_tools.php', 'Currency Converter'], ['forex_tools.php', 'Swap Calculator'],
    ['forex_tools.php', 'Pivot Point Calculator'], ['forex_tools.php', 'Gain/Loss Calculator'],
];

if (mb_strlen($q) >= 2) {
    $like = '%' . $q . '%';

    $stmt = db()->prepare("SELECT id, title, slug FROM courses WHERE status='published' AND title LIKE ? LIMIT 10");
    $stmt->execute([$like]);
    $results['courses'] = $stmt->fetchAll();

    $stmt = db()->prepare("SELECT id, title, slug FROM lessons WHERE title LIKE ? LIMIT 10");
    $stmt->execute([$like]);
    $results['lessons'] = $stmt->fetchAll();

    $stmt = db()->prepare("SELECT id, term, slug, short_definition FROM forexpedia_terms WHERE status='published' AND (term LIKE ? OR short_definition LIKE ?) LIMIT 10");
    $stmt->execute([$like, $like]);
    $results['forexpedia'] = $stmt->fetchAll();

    $stmt = db()->prepare("SELECT id, title, slug FROM chartlab_exercises WHERE title LIKE ? LIMIT 10");
    $stmt->execute([$like]);
    $results['chartlab'] = $stmt->fetchAll();

    foreach ($toolsIndex as [$href, $name]) {
        if (stripos($name, $q) !== false) $results['tools'][] = [$href, $name];
    }
}

$totalCount = array_sum(array_map('count', $results));
$pageTitle = 'Search' . ($q !== '' ? ': ' . $q : '');
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:820px;">
        <h1>Search Alpha Forge</h1>
        <form method="get" style="display:flex; gap:10px; margin:16px 0;">
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search courses, lessons, glossary, Chart Lab, tools..." style="flex:1;" autofocus>
            <button type="submit" class="af-btn af-btn-gold">Search</button>
        </form>

        <?php if ($q !== '' && mb_strlen($q) < 2): ?>
            <p class="af-muted">Enter at least 2 characters.</p>
        <?php elseif ($q !== '' && $totalCount === 0): ?>
            <p class="af-muted">No results for "<?= e($q) ?>".</p>
        <?php elseif ($q !== ''): ?>

            <?php if ($results['courses']): ?>
                <h2>Courses</h2>
                <ul>
                <?php foreach ($results['courses'] as $r): ?>
                    <li><a href="<?= APP_URL ?>/course.php?slug=<?= urlencode($r['slug']) ?>"><?= e($r['title']) ?></a></li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <?php if ($results['lessons']): ?>
                <h2>Lessons</h2>
                <ul>
                <?php foreach ($results['lessons'] as $r): ?>
                    <li><a href="<?= APP_URL ?>/lesson.php?id=<?= (int) $r['id'] ?>"><?= e($r['title']) ?></a></li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <?php if ($results['forexpedia']): ?>
                <h2>Forexpedia</h2>
                <ul>
                <?php foreach ($results['forexpedia'] as $r): ?>
                    <li><a href="<?= APP_URL ?>/forexpedia.php?term=<?= urlencode($r['slug']) ?>"><?= e($r['term']) ?></a> — <span class="af-muted"><?= e($r['short_definition']) ?></span></li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <?php if ($results['chartlab']): ?>
                <h2>Chart Lab Exercises</h2>
                <ul>
                <?php foreach ($results['chartlab'] as $r): ?>
                    <li><a href="<?= APP_URL ?>/chart_lab.php?ex=<?= (int) $r['id'] ?>"><?= e($r['title']) ?></a></li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <?php if ($results['tools']): ?>
                <h2>Forex Tools</h2>
                <ul>
                <?php foreach ($results['tools'] as [$href, $name]): ?>
                    <li><a href="<?= APP_URL ?>/<?= $href ?>"><?= e($name) ?></a></li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>

        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
