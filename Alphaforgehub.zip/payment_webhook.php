<?php
/**
 * ALPHA FORGE - Payment provider webhook endpoint
 *
 * MTN MoMo / Orange Money call this URL server-to-server when a payment's
 * status changes. This is the only route (besides verifyAndActivate polling)
 * that can flip a subscription to 'active', and only after the gateway class
 * has verified the payload's authenticity in handleWebhook().
 */

require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/payment/PaymentManager.php';

header('Content-Type: application/json');

$provider = $_GET['provider'] ?? '';
if (!in_array($provider, ['mtn_momo', 'orange_money'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'unknown provider']);
    exit;
}

$rawBody = file_get_contents('php://input');
$payload = json_decode($rawBody, true) ?: $_POST;
$headers = function_exists('getallheaders') ? getallheaders() : [];

$gateway = PaymentManager::getGateway($provider);
$verified = $gateway->handleWebhook($payload, $headers);

if (!$verified) {
    http_response_code(400);
    echo json_encode(['error' => 'could not verify webhook payload']);
    exit;
}

$stmt = db()->prepare('SELECT id, status FROM payments WHERE provider_reference = ? AND provider = ? LIMIT 1');
$stmt->execute([$verified['provider_reference'], $provider]);
$payment = $stmt->fetch();

if (!$payment) {
    http_response_code(404);
    echo json_encode(['error' => 'payment not found']);
    exit;
}

if ($verified['status'] === 'successful') {
    $fullPayment = db()->prepare('SELECT product_id FROM payments WHERE id = ?');
    $fullPayment->execute([$payment['id']]);
    $productId = $fullPayment->fetchColumn();
    if ($productId) {
        PaymentManager::activateProductPurchase((int) $payment['id']);
    } else {
        PaymentManager::activateSubscription((int) $payment['id']);
    }
} else {
    db()->prepare('UPDATE payments SET status = "failed" WHERE id = ?')->execute([$payment['id']]);
}

echo json_encode(['received' => true]);
