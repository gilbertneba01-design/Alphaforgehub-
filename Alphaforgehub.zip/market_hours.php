<?php
/** ALPHA FORGE HUB - Market Hours (STUDENT) - session clock, computed client-side from real UTC time. */
require_once __DIR__ . '/config/functions.php';
require_login();
$pageTitle = 'Market Hours';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Market Hours</h1>
            <p class="af-muted">Standard Forex session windows (UTC). Your local time and each session's live/closed status update automatically. Daylight-saving shifts in New York/London are approximate — always confirm with your broker's server time.</p>

            <div id="mhLocal" class="af-card" style="padding:16px; margin:16px 0; font-weight:700;"></div>

            <div class="af-grid af-grid-2" style="gap:14px;" id="mhSessions"></div>

            <p class="af-lab-legal" style="margin-top:20px;">Overlap windows (e.g. London/New York) typically see the highest liquidity and volatility of the trading day.</p>
        </div>
    </div>
</section>
<script nonce="<?= CSP_NONCE ?>">
(function () {
    // [start, end] in UTC hours, standard (non-DST-adjusted) approximation.
    var sessions = [
        { name: 'Sydney', start: 21, end: 6 },
        { name: 'Tokyo', start: 0, end: 9 },
        { name: 'London', start: 7, end: 16 },
        { name: 'New York', start: 12, end: 21 }
    ];

    function isOpen(s, utcHour) {
        if (s.start < s.end) return utcHour >= s.start && utcHour < s.end;
        return utcHour >= s.start || utcHour < s.end; // wraps past midnight
    }

    function render() {
        var now = new Date();
        var utcHour = now.getUTCHours() + now.getUTCMinutes() / 60;
        document.getElementById('mhLocal').textContent =
            'Your local time: ' + now.toLocaleTimeString() + ' | UTC: ' + now.toUTCString().slice(17, 25);

        var html = '';
        sessions.forEach(function (s) {
            var open = isOpen(s, utcHour);
            html += '<div class="af-card" style="padding:18px;">' +
                '<h3 style="margin:0 0 6px;">' + s.name + '</h3>' +
                '<span class="af-badge" style="background:' + (open ? 'rgba(46,204,113,0.15)' : 'rgba(255,255,255,0.08)') + '; color:' + (open ? '#2ecc71' : 'inherit') + ';">' + (open ? 'OPEN NOW' : 'Closed') + '</span>' +
                '<p class="af-muted" style="margin-top:8px;">' + s.start.toString().padStart(2,'0') + ':00 &ndash; ' + s.end.toString().padStart(2,'0') + ':00 UTC</p>' +
                '</div>';
        });
        document.getElementById('mhSessions').innerHTML = html;
    }

    render();
    setInterval(render, 30000);
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
