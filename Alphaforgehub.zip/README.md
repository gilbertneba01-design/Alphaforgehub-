# ALPHA FORGE — Installation & Deployment Guide

## 1. Install XAMPP

1. Download XAMPP for your OS from https://www.apachefriends.org
2. Install it and start the **Apache** and **MySQL** modules from the XAMPP Control Panel.
3. Copy the entire `alpha_forge/` project folder into your XAMPP `htdocs` directory, e.g.
   `C:\xampp\htdocs\alpha_forge` (Windows) or `/Applications/XAMPP/htdocsalpha_forge` (Mac).

## 2. Create the database

1. Open http://localhost/phpmyadmin
2. Click **New**, or just proceed — `schema.sql` creates the database itself.

## 3. Import schema.sql

1. In phpMyAdmin, click **Import**.
2. Choose the file `database/schema.sql` from this project.
3. Click **Go**. This creates the `alpha_forge` database, all tables, seed courses/lessons, and default subscription plans.

## 3b. Import the Chart Lab migration (new)

The Chart Lab needs two extra tables and its starter exercises.

1. In phpMyAdmin, click **Import** again.
2. Choose `database/migration_chartlab.sql` and click **Go**.
3. It is safe to run more than once: nothing is duplicated.

Until this is imported the rest of the site keeps working, and the Chart Lab page
will tell you it is not set up yet.

## Adding Chart Lab exercises (admin)

1. Log in to the admin area and open **Chart Lab** in the left menu.
2. Click **Add exercise**. Choose the course (Technical Analysis is pre-selected), write the title and instruction, and choose how it is judged:
   - *Price level only* for support and resistance.
   - *Price and time* for ranges and supply/demand zones.
3. Add the chart. Either paste candles (one per line: `open, high, low, close`, from a spreadsheet, TradingView or MetaTrader) or pick a pattern and press **Generate chart**, which also suggests the answer zone.
4. **Draw the correct answer zone** on the chart. Drag to draw, drag inside to move, drag the edges or corners to resize. If two different zones would both be correct, add a second one (up to 3).
5. Press **Create exercise**. Set the status to *Draft* to hide it until you are ready, or *Published* to show it to students right away.

The site checks every exercise before saving: an answer zone the grader would not accept, or one so large that a student could pass by selecting the whole chart, is refused with an explanation. Use the arrows in the exercise list to change the order.

## 4. Configure the app

1. Copy `config/.env.php.example` to `config/.env.php`.
2. Edit `config/.env.php` and set `DB_USER` / `DB_PASS` to match your local MySQL
   (XAMPP default is user `root` with an empty password — the example file already matches this).
3. Leave the MTN/Orange Money keys blank for now — payments will safely report
   "not configured" until you add real credentials (see step 10).

## 5. Create the Admin account

1. Visit **http://localhost/alpha_forge/admin/install.php**
2. Fill in your name, email, and a password — this creates the one and only way to make the first Admin.
3. The script automatically refuses to run again once an Admin exists. You can delete
   `admin/install.php` afterward for extra safety, but it's safe either way.

## 6. Test registration

1. Visit **http://localhost/alpha_forge/register.php**
2. Create a student account. You should land on `/dashboard.php` showing 0% progress.

## 7. Test login

1. Log out, then log back in at `/login.php` with the same credentials.
2. Try 5 wrong passwords in a row — the account should temporarily lock (matches `MAX_LOGIN_ATTEMPTS`).

## 8. Test courses

1. Visit `/courses.php` — you should see the three seeded courses (Forex Fundamentals,
   Technical Analysis, Risk Management).
2. Open **Forex Fundamentals** — you should see its module and 6 lessons, some marked Premium.

## 9. Test lesson progress

1. Open a free (non-Premium) lesson and click **Mark Lesson Complete**.
2. Return to `/dashboard.php` — "Lessons Completed" and the progress percentage should update immediately
   (this is calculated live from the database, never hard-coded).

## 10. Test Premium protection

1. While logged in as a student with **no active subscription**, try to open a Premium lesson
   directly by its URL (`/lesson.php?id=3`, for example).
2. You should be redirected to `/pricing.php?reason=premium` — the check happens in PHP
   (`require_active_subscription()` / the inline check in `lesson.php`), not in JavaScript,
   so it can't be bypassed by disabling JS or editing the page.

## 11. Connecting the real payment provider

Alpha Forge ships with a working `PaymentGatewayInterface` and real API integrations for:

**MTN Mobile Money** (Collections API — https://momodeveloper.mtn.com)
Add to `config/.env.php` (or your host's environment variables):
```
MTN_MOMO_SUBSCRIPTION_KEY=your-ocp-apim-subscription-key
MTN_MOMO_API_USER=your-api-user-uuid
MTN_MOMO_API_KEY=your-api-key
MTN_MOMO_ENV=production   (or "sandbox" while testing)
```

**Orange Money** (Web Payment API — https://developer.orange.com)
```
ORANGE_MONEY_CLIENT_ID=your-client-id
ORANGE_MONEY_CLIENT_SECRET=your-client-secret
ORANGE_MONEY_MERCHANT_KEY=your-merchant-key
```

Until these are supplied, `subscribe.php` will show "not yet configured" rather than
faking a successful payment — no subscription is ever activated without a real,
provider-verified confirmation (either the student polling `payment_return.php`, which asks
the provider directly, or the provider calling `payment_webhook.php` server-to-server).

Register your webhook URL with each provider as:
`https://yourdomain.com/payment_webhook.php?provider=mtn_momo`
`https://yourdomain.com/payment_webhook.php?provider=orange_money`

## 12. Deploying to paid hosting

1. Choose a host that supports PHP 8+ and MySQL/MariaDB (most standard cPanel hosting works).
2. Upload the entire project via FTP/SFTP or your host's file manager.
3. Create a MySQL database and user through your host's control panel, then import
   `database/schema.sql` via phpMyAdmin (most hosts provide this).
4. Set `config/.env.php` (or your host's environment-variable panel) with the production
   database credentials and `APP_ENV=production` (this disables verbose PHP error output).
5. Set `APP_URL` to your real domain, e.g. `https://alphaforge.com`.
6. Re-run step 5 above (`/admin/install.php`) once on the live site to create your
   production Admin account, then delete that file.

## 13. Connecting the domain

1. Point your domain's DNS (A record) to your hosting provider's IP address, or follow
   your host's "connect a domain" instructions if using their nameservers.
2. Wait for DNS propagation (can take a few hours).

## 14. Enabling HTTPS

1. Most hosts offer a free Let's Encrypt SSL certificate from the control panel — enable it
   for your domain.
2. Once HTTPS is active, update `APP_URL` to use `https://`.
3. `config/auth.php` automatically marks session cookies as `secure` once `APP_ENV=production`,
   so cookies will only be sent over HTTPS from that point on.

---

---

## V2 EXPANSION — What's New

This upgrade adds the systems below on top of everything documented above. **Nothing existing was removed or rebuilt** — Chart Lab, Journal, AI Tutor, Certificates, Community, Challenges, Live Sessions and the payment architecture are untouched except where noted.

### New: run the V2 migration

1. In phpMyAdmin, click **Import**.
2. Choose `database/migration_v2_expansion.sql` and click **Go**.
3. Run this **once** — it includes a couple of non-repeatable `ALTER TABLE` statements (making `payments.subscription_id` nullable and adding `payments.product_id` so the Store can reuse the existing MTN/Orange payment flow). Everything else in the file is safe to re-run.

### New features included

| Feature | Files | Notes |
|---|---|---|
| Forexpedia (glossary) | `forexpedia.php`, `admin/forexpedia.php` | Public + student, A-Z index, search, 14 starter terms seeded |
| Market Center | `market_center.php`, `market_hours.php`, `currency_strength.php`, `currency_correlation.php`, `market_sentiment.php`, `admin/market_data.php` | Market Hours is computed live (real UTC time); strength/correlation/sentiment are admin-entered snapshots and honestly show "not configured" until you add data — never fabricated |
| Trading Simulator | `simulator.php`, `simulator_api.php`, `assets/js/simulator.js` | $10,000 DEMO account, synthetic practice price feed (clearly labeled, not live market data), server-verified P/L |
| Backtesting Lab | `backtest.php`, `backtest_api.php`, `assets/js/backtest.js` | Candle-by-candle reveal practice on generated data, R-multiple stats |
| Mentorship | `mentorship.php`, `admin/mentorship.php` | Student requests a session, admin schedules manually (no auto-booking yet) |
| Prop Firm Academy | `prop_firm_academy.php` | Educational content + a personal readiness checklist — makes no pass/fail promises |
| Global Search | `search.php` | Searches courses, lessons, Forexpedia, Chart Lab exercises, Forex Tools |
| Store + Library | `store.php`, `store_checkout.php`, `my_library.php`, `download.php`, `admin/store_products.php` | Ebooks/bundles sold via the **same** MTN/Orange gateway as subscriptions; files are served only to verified buyers through `download.php`, never a direct link |
| 2 new Forex Tools | `forex_tools.php` additions | Pivot Point Calculator, Gain/Loss Calculator (completes the spec's list of 10) |
| PWA / installable app | `manifest.json`, `service-worker.js`, `offline.html`, `assets/js/pwa.js`, `assets/icons/` | Installable on mobile/desktop; only static assets (CSS/JS/icons) are cached — every PHP page stays network-first so private data (balances, journal, payments) is never cached offline |
| English / French | `language/en.php`, `language/fr.php`, `t()` helper in `config/functions.php`, language switcher in the header | Framework is live and applied to the header/footer nav. **Not yet applied to every page** — add a `t('your_key')` call and matching entries in both language files as you translate each page's remaining text |

### Store setup

1. Log in to the admin area → **Store Products** → add an ebook, set its price, and upload the PDF/EPUB.
2. Uploaded files are stored in `/uploads/store/`, which has a `.htaccess` denying direct web access — students can only get the file through `download.php` after their payment shows `status = paid`.
3. Buyers see their purchases at `/my_library.php`.

### Known limits / what's intentionally not built yet

- **Trading Accounts / real broker integration** — deliberately deferred, per the master spec's own rule that this needs a secure, documented broker API relationship before any credential handling is designed.
- **i18n coverage** — the framework and navigation are translated; the bulk of course/lesson content and page body text is still English-only. Retrofit page-by-page using the `t()` helper.
- **Market Center data** — strength/correlation/sentiment require an admin to enter snapshots (or a real data provider to be wired in later); until then those pages honestly say so instead of showing fake numbers.

## Notes on structure


- All secrets (DB password, payment API keys) live in `config/.env.php` (git-ignored) or your
  host's environment variables — never in HTML, JS, or a public URL.
- Every Premium-content check happens in PHP on the server (`config/auth.php`'s
  `has_active_subscription()` / `require_active_subscription()`), never in JavaScript.
- Subscriptions only ever become `active` through `PaymentManager::activateSubscription()`,
  which is only called after a provider directly confirms payment — never just because a
  user was redirected back to the site.
