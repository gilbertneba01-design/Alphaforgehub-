<?php
/** ALPHA FORGE HUB - Mentor Dashboard (MENTOR ROLE ONLY; never grants Admin) */
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/mentorship.php';
require_mentor();
$user = current_user();
$mentorIds = mentor_profile_ids((int) $user['id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($mentorIds)) {
    require_csrf();
    $reqId = (int) ($_POST['request_id'] ?? 0);
    $r = mentorship_request_for($reqId, $user);
    if ($r && (int) $r['mentor_user_id'] === (int) $user['id']) {
        $action = $_POST['action'] ?? '';
        if ($action === 'accept') {
            db()->prepare("UPDATE mentorship_requests SET status='scheduled' WHERE id=?")->execute([$reqId]);
            notify((int) $r['user_id'], 'mentor_accepted', t('notif_mentor_accepted'), $r['mentor_name'], '/mentorship.php');
        } elseif ($action === 'decline') {
            db()->prepare("UPDATE mentorship_requests SET status='declined' WHERE id=?")->execute([$reqId]);
            notify((int) $r['user_id'], 'mentor_declined', t('notif_mentor_declined'), $r['mentor_name'], '/mentorship.php');
        } elseif ($action === 'complete') {
            db()->prepare("UPDATE mentorship_requests SET status='completed' WHERE id=?")->execute([$reqId]);
        } elseif ($action === 'feedback') {
            $body = post_text('body', 2000);
            $pct  = max(0, min(100, (int) ($_POST['progress_pct'] ?? 0)));
            if ($body !== '') {
                db()->prepare('INSERT INTO mentorship_feedback (request_id, mentor_user_id, body, progress_pct) VALUES (?,?,?,?)')
                    ->execute([$reqId, $user['id'], $body, $pct]);
                notify((int) $r['user_id'], 'mentor_feedback', t('notif_mentor_feedback'), mb_substr($body, 0, 150), '/mentorship.php');
            }
        }
    }
    redirect('/mentor/index.php');
}

if (empty($mentorIds)) {
    $pending = []; $active = [];
} else {
    $in = implode(',', array_fill(0, count($mentorIds), '?'));
    $pending = db()->prepare("SELECT mr.*, s.full_name AS student_name FROM mentorship_requests mr
        JOIN users s ON s.id = mr.user_id WHERE mr.mentor_id IN ($in) AND mr.status='pending' ORDER BY mr.created_at ASC");
    $pending->execute($mentorIds); $pending = $pending->fetchAll();

    $active = db()->prepare("SELECT mr.*, s.full_name AS student_name FROM mentorship_requests mr
        JOIN users s ON s.id = mr.user_id WHERE mr.mentor_id IN ($in) AND mr.status IN ('scheduled','completed') ORDER BY mr.updated_at DESC");
    $active->execute($mentorIds); $active = $active->fetchAll();
}

$pageTitle = t('mtr_title');
require_once __DIR__ . '/../includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <h1><?= te('mtr_title') ?></h1>
        <?php if (empty($mentorIds)): ?>
            <div class="af-card"><?= te('mtr_no_profile') ?></div>
        <?php else: ?>
            <h2><?= te('mtr_pending') ?> (<?= count($pending) ?>)</h2>
            <?php if (!$pending): ?><p class="af-muted"><?= te('mtr_no_pending') ?></p><?php endif; ?>
            <?php foreach ($pending as $r): ?>
                <div class="af-card" style="margin-bottom:10px;">
                    <strong><?= e($r['student_name']) ?></strong>
                    <p style="white-space:pre-wrap;margin:6px 0;"><?= e($r['message']) ?></p>
                    <?php if ($r['preferred_time']): ?><p class="af-muted">Preferred: <?= e($r['preferred_time']) ?></p><?php endif; ?>
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="request_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="accept">
                        <button class="af-btn af-btn-gold af-btn-sm" type="submit"><?= te('btn_accept') ?></button></form>
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="request_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="decline">
                        <button class="af-btn af-btn-ghost af-btn-sm" type="submit"><?= te('btn_decline') ?></button></form>
                </div>
            <?php endforeach; ?>

            <h2 style="margin-top:24px;"><?= te('mtr_students') ?> (<?= count($active) ?>)</h2>
            <?php if (!$active): ?><p class="af-muted"><?= te('mtr_no_students') ?></p><?php endif; ?>
            <?php foreach ($active as $r): ?>
                <div class="af-card" style="margin-bottom:10px;">
                    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                        <strong><?= e($r['student_name']) ?></strong>
                        <span class="af-badge af-badge-muted"><?= te('mt_status_' . $r['status']) ?></span>
                    </div>
                    <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">
                        <a class="af-btn af-btn-gold af-btn-sm" href="<?= APP_URL ?>/mentor/chat.php?id=<?= (int) $r['id'] ?>"><?= te('mt_open_chat') ?></a>
                        <?php if ($r['status'] === 'scheduled'): ?>
                        <form method="post"><?= csrf_field() ?><input type="hidden" name="request_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="complete">
                            <button class="af-btn af-btn-ghost af-btn-sm" type="submit"><?= te('mtr_mark_completed') ?></button></form>
                        <?php endif; ?>
                    </div>
                    <details style="margin-top:8px;">
                        <summary class="af-muted" style="cursor:pointer;"><?= te('mtr_give_feedback') ?></summary>
                        <form method="post" style="margin-top:8px;">
                            <?= csrf_field() ?><input type="hidden" name="request_id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="feedback">
                            <div class="af-field"><label><?= te('mt_feedback') ?></label><textarea name="body" rows="3" maxlength="2000"></textarea></div>
                            <div class="af-field"><label><?= te('mtr_progress_pct') ?></label><input type="number" name="progress_pct" min="0" max="100" value="0"></div>
                            <button class="af-btn af-btn-gold af-btn-sm" type="submit"><?= te('btn_save') ?></button>
                        </form>
                    </details>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
