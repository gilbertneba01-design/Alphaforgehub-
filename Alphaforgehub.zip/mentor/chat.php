<?php
/**
 * ALPHA FORGE HUB - Private mentor <-> student chat.
 * Access is decided ONLY by mentorship_request_for(): the request's own
 * student, the request's own mentor, nobody else. No admin bypass here.
 */
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/mentorship.php';
require_login();
$user = current_user();
if (!in_array($user['role'], ['student', 'mentor'], true)) { http_response_code(403); die('Access denied.'); }

$reqId = (int) ($_GET['id'] ?? 0);
$r = mentorship_request_for($reqId, $user);
if (!$r) { flash_set('error', t('err_permission')); redirect($user['role'] === 'mentor' ? '/mentor/index.php' : '/mentorship.php'); }
$open = mentorship_chat_open($r);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if ($open) {
        $body = post_text('body', 3000);
        if ($body !== '') {
            db()->prepare('INSERT INTO mentorship_messages (request_id, sender_id, body) VALUES (?,?,?)')->execute([$reqId, $user['id'], $body]);
            $otherId = ((int) $r['user_id'] === (int) $user['id']) ? (int) $r['mentor_user_id'] : (int) $r['user_id'];
            if ($otherId) notify($otherId, 'mentor_message', t('notif_mentor_message'), mb_substr($body, 0, 150), $user['role'] === 'mentor' ? '/mentorship.php' : ('/mentor/chat.php?id=' . $reqId));
        }
    }
    redirect('/mentor/chat.php?id=' . $reqId);
}

$msgs = db()->prepare('SELECT m.*, u.full_name FROM mentorship_messages m JOIN users u ON u.id = m.sender_id WHERE m.request_id = ? ORDER BY m.created_at ASC');
$msgs->execute([$reqId]);
$msgs = $msgs->fetchAll();

$otherName = ((int) $r['user_id'] === (int) $user['id']) ? $r['mentor_name'] : $r['student_name'];
$pageTitle = t('mt_chat');
require_once __DIR__ . '/../includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:680px;">
        <a href="<?= APP_URL ?>/<?= $user['role'] === 'mentor' ? 'mentor/index.php' : 'mentorship.php' ?>" class="af-muted">&larr; <?= te('mtr_title') ?></a>
        <h1 style="margin-top:6px;"><?= te('mt_chat') ?> &middot; <?= e($otherName) ?></h1>
        <?php if (!$open): ?><div class="af-alert"><?= te('mt_chat_locked') ?></div><?php endif; ?>
        <div class="af-card" style="max-height:420px;overflow-y:auto;">
            <?php if (!$msgs): ?><p class="af-muted"><?= te('mt_no_messages') ?></p><?php endif; ?>
            <?php foreach ($msgs as $m): ?>
                <div class="af-msg<?= (int) $m['sender_id'] === (int) $user['id'] ? ' mine' : '' ?>">
                    <small><?= e($m['full_name']) ?> &middot; <?= e(date('d M H:i', strtotime($m['created_at']))) ?></small>
                    <?= nl2br(e($m['body'])) ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if ($open): ?>
        <form method="post" class="af-card" style="margin-top:10px;">
            <?= csrf_field() ?>
            <textarea name="body" rows="2" maxlength="3000" required placeholder="<?= te('mt_write') ?>"></textarea>
            <button class="af-btn af-btn-gold" style="margin-top:8px;" type="submit"><?= te('btn_send') ?></button>
        </form>
        <?php endif; ?>
        <?php if ($user['role'] === 'mentor'): ?>
            <h3 style="margin-top:20px;"><?= te('mt_feedback') ?></h3>
            <?php
            $fb = db()->prepare('SELECT * FROM mentorship_feedback WHERE request_id = ? ORDER BY created_at DESC');
            $fb->execute([$reqId]); $fb = $fb->fetchAll();
            ?>
            <?php if (!$fb): ?><p class="af-muted"><?= te('mt_no_feedback') ?></p><?php endif; ?>
            <?php foreach ($fb as $f): ?><div class="af-card" style="margin-bottom:8px;"><small class="af-muted"><?= e(date('d M Y', strtotime($f['created_at']))) ?> &middot; <?= (int) $f['progress_pct'] ?>%</small><p style="margin:4px 0 0;"><?= nl2br(e($f['body'])) ?></p></div><?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
