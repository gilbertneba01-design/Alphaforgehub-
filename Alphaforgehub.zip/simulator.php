<?php
/** ALPHA FORGE HUB - Trading Simulator (STUDENT) - DEMO / SIMULATED TRADING ONLY */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$hasAccess = is_admin() || has_active_subscription((int) $user['id']);
$pageTitle = 'Trading Simulator';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section af-lab-page">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <div class="af-lab-hero">
                <span class="af-badge" style="background:rgba(231,76,60,0.15); color:#e74c3c;">DEMO &middot; SIMULATED TRADING</span>
                <h1>Trading Simulator</h1>
                <p>Practice with $10,000 in virtual funds against a simulated price feed. No real money, no real broker — this is for building discipline, not a live market data source.</p>
            </div>

            <?php if (!$hasAccess): ?>
                <div class="af-card af-lab-locked">
                    <span class="af-badge">Premium</span>
                    <h2>Trading Simulator</h2>
                    <p>The Trading Simulator is part of Premium.</p>
                    <a href="<?= APP_URL ?>/pricing.php?reason=premium" class="af-btn af-btn-gold">Unlock Premium</a>
                </div>
            <?php else: ?>

            <div class="af-grid af-grid-3" style="gap:14px; margin-bottom:16px;">
                <div class="af-card" style="padding:16px;"><small class="af-muted">Balance</small><div id="simBalance" style="font-size:22px; font-weight:700;">&mdash;</div></div>
                <div class="af-card" style="padding:16px;"><small class="af-muted">Equity</small><div id="simEquity" style="font-size:22px; font-weight:700;">&mdash;</div></div>
                <div class="af-card" style="padding:16px;"><small class="af-muted">Floating P/L</small><div id="simFloating" style="font-size:22px; font-weight:700;">$0.00</div></div>
            </div>

            <div class="af-card" style="padding:20px; margin-bottom:16px;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div>
                        <label class="af-muted" style="font-size:13px;">Instrument</label><br>
                        <select id="simPair" style="font-size:16px;">
                            <option value="EURUSD">EUR/USD</option>
                            <option value="GBPUSD">GBP/USD</option>
                            <option value="USDJPY">USD/JPY</option>
                            <option value="AUDUSD">AUD/USD</option>
                        </select>
                    </div>
                    <div style="text-align:right;">
                        <small class="af-muted">Simulated price (synthetic, for practice only)</small>
                        <div id="simPrice" style="font-size:28px; font-weight:700; color:var(--af-gold,#D4AF37);">&mdash;</div>
                    </div>
                </div>
            </div>

            <div class="af-card" style="padding:20px; margin-bottom:16px;">
                <div class="af-grid af-grid-3" style="gap:12px;">
                    <div class="af-field"><label>Lot Size</label><input type="number" id="simLots" value="0.10" step="0.01" min="0.01" max="50"></div>
                    <div class="af-field"><label>Stop Loss (price, optional)</label><input type="number" id="simSL" step="0.00001"></div>
                    <div class="af-field"><label>Take Profit (price, optional)</label><input type="number" id="simTP" step="0.00001"></div>
                </div>
                <div style="display:flex; gap:10px; margin-top:10px; flex-wrap:wrap;">
                    <button class="af-btn af-btn-gold" id="simBuy" style="background:#2ecc71; border-color:#2ecc71;">BUY</button>
                    <button class="af-btn af-btn-gold" id="simSell" style="background:#e74c3c; border-color:#e74c3c;">SELL</button>
                    <button class="af-btn af-btn-ghost" id="simReset">Reset Account</button>
                </div>
                <div id="simMsg" class="af-lab-result" hidden style="margin-top:12px;"></div>
            </div>

            <h2>Open Positions</h2>
            <div class="af-table-wrap"><table class="af-table" id="simOpenTable">
                <thead><tr><th>Pair</th><th>Dir</th><th>Lots</th><th>Entry</th><th>SL/TP</th><th>Floating P/L</th><th></th></tr></thead>
                <tbody></tbody>
            </table></div>

            <h2 style="margin-top:24px;">Closed Positions</h2>
            <div class="af-table-wrap"><table class="af-table" id="simClosedTable">
                <thead><tr><th>Pair</th><th>Dir</th><th>Lots</th><th>Entry</th><th>Exit</th><th>P/L</th><th>Closed</th></tr></thead>
                <tbody></tbody>
            </table></div>

            <p class="af-lab-legal" style="margin-top:20px;">Simulated results do not guarantee, predict or resemble real trading performance. Real spreads, slippage and execution differ from this practice environment.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php if ($hasAccess): ?>
<script nonce="<?= CSP_NONCE ?>">window.AF_SIM = { apiUrl: <?= json_encode(APP_URL . '/simulator_api.php') ?>, csrf: <?= json_encode(csrf_token()) ?> };</script>
<script src="<?= APP_URL ?>/assets/js/simulator.js"></script>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
