<?php
require_once __DIR__ . '/config/functions.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!enforce_rate_limit('contact', 5, 600, 600)) {
        rate_limit_block_response();
    }

    if (honeypot_tripped()) {
        redirect('/contact.php');
    }

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '') $errors[] = 'Please enter your name.';
    if (!valid_email($email)) $errors[] = 'Please enter a valid email address.';
    if ($message === '') $errors[] = 'Please enter a message.';

    if (!$errors) {
        $stmt = db()->prepare('INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)');
        $stmt->execute([$name, $email, $message]);
        flash_set('success', 'Thanks — your message has been sent. We will get back to you soon.');
        redirect('/contact.php');
    }
}

$pageTitle = 'Contact';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:560px;">
        <div class="af-ladder"><span></span><span></span><span></span><span></span><span></span></div>
        <h1>Contact Us</h1>
        <p>Questions about a course or your subscription? Send us a message.</p>

        <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

        <form method="post" class="af-form-card" style="margin:20px 0 0;">
            <?= csrf_field() ?>
            <div style="position:absolute; left:-9999px;" aria-hidden="true">
                <label for="website">Leave this field empty</label>
                <input type="text" id="website" name="website" tabindex="-1" autocomplete="off">
            </div>
            <div class="af-field"><label>Name</label><input type="text" name="name" value="<?= e($_POST['name'] ?? '') ?>" required></div>
            <div class="af-field"><label>Email</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
            <div class="af-field"><label>Message</label><textarea name="message" rows="5" required><?= e($_POST['message'] ?? '') ?></textarea></div>
            <button type="submit" class="af-btn af-btn-gold af-btn-block">Send Message</button>
        </form>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
