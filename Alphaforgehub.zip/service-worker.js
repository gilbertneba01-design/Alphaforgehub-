/**
 * ALPHA FORGE HUB - Service Worker
 * Caches only static assets (CSS/JS/icons/fonts). All PHP pages are
 * network-first and NEVER cached, since they can contain private
 * account data, balances, journal entries, etc. On a failed navigation
 * while offline, shows a minimal offline fallback page instead of the
 * browser's default error.
 */
const CACHE_NAME = 'alpha-forge-static-v1';
const STATIC_ASSET_PATTERN = /\.(css|js|png|jpg|jpeg|svg|webp|woff2?|ico)$/i;

self.addEventListener('install', function (event) {
    event.waitUntil(
        caches.open(CACHE_NAME).then(function (cache) {
            return cache.addAll(['offline.html', 'assets/icons/icon-192.png']);
        })
    );
    self.skipWaiting();
});

self.addEventListener('activate', function (event) {
    event.waitUntil(
        caches.keys().then(function (keys) {
            return Promise.all(keys.filter(function (k) { return k !== CACHE_NAME; }).map(function (k) { return caches.delete(k); }));
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', function (event) {
    const req = event.request;
    if (req.method !== 'GET') return; // never intercept POST (payments, forms, API calls)

    const url = new URL(req.url);
    if (url.origin !== self.location.origin) return;

    if (STATIC_ASSET_PATTERN.test(url.pathname)) {
        // Static assets: cache-first, refresh in background.
        event.respondWith(
            caches.open(CACHE_NAME).then(function (cache) {
                return cache.match(req).then(function (cached) {
                    const fetchPromise = fetch(req).then(function (res) {
                        if (res.ok) cache.put(req, res.clone());
                        return res;
                    }).catch(function () { return cached; });
                    return cached || fetchPromise;
                });
            })
        );
        return;
    }

    if (req.mode === 'navigate') {
        // Pages: always go to the network for fresh, private data. Only fall
        // back to a minimal offline notice if the network is unreachable.
        event.respondWith(
            fetch(req).catch(function () {
                return caches.match('offline.html').then(function (res) {
                    return res || new Response('You are offline.', { headers: { 'Content-Type': 'text/plain' } });
                });
            })
        );
    }
});
