<?php
/** ALPHA FORGE HUB - Market Center hub (STUDENT) */
require_once __DIR__ . '/config/functions.php';
require_login();
$pageTitle = 'Market Center';
require_once __DIR__ . '/includes/header.php';
$links = [
    ['economic_calendar.php', 'Economic Calendar', 'Upcoming high/medium/low impact events.'],
    ['market_news.php', 'Market News', 'Admin-curated Forex news and commentary.'],
    ['market_hours.php', 'Market Hours', 'Sydney, Tokyo, London & New York sessions in your local time.'],
    ['currency_strength.php', 'Currency Strength', 'Relative strength snapshot across the majors.'],
    ['currency_correlation.php', 'Currency Correlation', 'How pairs move in relation to each other.'],
    ['market_sentiment.php', 'Risk-On / Risk-Off', 'Educational market sentiment dashboard.'],
];
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Market Center</h1>
            <p class="af-muted">Everything about current market context in one place. Data here is admin-curated or clearly marked when unavailable — never fabricated.</p>
            <div class="af-grid af-grid-2" style="gap:14px; margin-top:18px;">
                <?php foreach ($links as [$href, $title, $desc]): ?>
                    <a href="<?= APP_URL ?>/<?= $href ?>" class="af-card" style="padding:20px; text-decoration:none; color:inherit;">
                        <h3 style="margin:0 0 6px;"><?= e($title) ?></h3>
                        <p class="af-muted" style="margin:0;"><?= e($desc) ?></p>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
