<?php
/** ALPHA FORGE HUB - Study Group discussion (members only; admin can moderate) */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$gid = (int) ($_GET['id'] ?? 0);

$s = db()->prepare('SELECT * FROM study_groups WHERE id = ?'); $s->execute([$gid]); $group = $s->fetch();
if (!$group) { flash_set('error', t('err_not_found')); redirect('/study_groups.php'); }

$m = db()->prepare("SELECT status FROM study_group_members WHERE group_id=? AND user_id=?");
$m->execute([$gid, $user['id']]);
$member = $m->fetch();
$isMember = $member && $member['status'] === 'active';
$canPost = $isMember && $group['status'] === 'open';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if ($_POST['action'] === 'post') {
        if (!$isMember) { flash_set('error', t('sg_must_join')); redirect('/study_group.php?id=' . $gid); }
        if ($group['status'] !== 'open') { flash_set('error', t('sg_locked')); redirect('/study_group.php?id=' . $gid); }
        if (!empty($user['community_muted'])) { flash_set('error', t('err_muted')); redirect('/study_group.php?id=' . $gid); }
        $body = post_text('body', 3000);
        $parent = !empty($_POST['parent_id']) ? (int) $_POST['parent_id'] : null;
        if ($body !== '') {
            db()->prepare('INSERT INTO study_group_posts (group_id, user_id, parent_id, body) VALUES (?,?,?,?)')
                ->execute([$gid, $user['id'], $parent, $body]);
        }
    }
    redirect('/study_group.php?id=' . $gid);
}

$posts = db()->prepare(
    "SELECT p.*, u.full_name FROM study_group_posts p JOIN users u ON u.id = p.user_id
     WHERE p.group_id = ? ORDER BY p.created_at ASC");
$posts->execute([$gid]);
$posts = $posts->fetchAll();
$byParent = [];
foreach ($posts as $p) { $byParent[$p['parent_id'] ?: 0][] = $p; }
function sg_render_thread(array $byParent, ?int $parentId, int $userId): void {
    foreach ($byParent[$parentId ?: 0] as $p) {
        if ($p['is_hidden']) { echo '<div class="af-msg"><em>' . e(t('com_hidden')) . '</em></div>'; continue; }
        echo '<div class="af-msg' . ((int) $p['user_id'] === $userId ? ' mine' : '') . '">'
           . '<small>' . e($p['full_name']) . ' &middot; ' . e(date('d M H:i', strtotime($p['created_at']))) . '</small>'
           . nl2br(e($p['body'])) . '</div>';
        if (!empty($byParent[$p['id']])) {
            echo '<div class="af-thread">'; sg_render_thread($byParent, $p['id'], $userId); echo '</div>';
        }
    }
}

$pageTitle = $group['name'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div style="min-width:0;max-width:720px;">
            <a href="<?= APP_URL ?>/study_groups.php" class="af-muted">&larr; <?= te('sg_title') ?></a>
            <h1 style="margin-top:6px;"><?= e($group['name']) ?></h1>
            <?php if (!$isMember): ?>
                <div class="af-card"><?= te('sg_must_join') ?></div>
            <?php else: ?>
                <?php if ($group['status'] === 'locked'): ?><div class="af-alert"><?= te('sg_locked') ?></div><?php endif; ?>
                <?php if ($group['status'] === 'closed'): ?><div class="af-alert"><?= te('sg_closed') ?></div><?php endif; ?>
                <div class="af-card" style="max-height:420px;overflow-y:auto;">
                    <?php if (!$posts): ?><p class="af-muted"><?= te('sg_no_messages') ?></p><?php else: ?><?php sg_render_thread($byParent, null, (int) $user['id']); ?><?php endif; ?>
                </div>
                <?php if ($canPost): ?>
                <form method="post" class="af-card" style="margin-top:10px;">
                    <?= csrf_field() ?><input type="hidden" name="action" value="post">
                    <textarea name="body" rows="2" maxlength="3000" required placeholder="<?= te('sg_write') ?>"></textarea>
                    <button class="af-btn af-btn-gold" style="margin-top:8px;" type="submit"><?= te('btn_send') ?></button>
                </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
