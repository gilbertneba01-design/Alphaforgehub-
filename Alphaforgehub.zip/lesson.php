<?php
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];

$lessonId = (int) ($_GET['id'] ?? 0);

$stmt = db()->prepare(
    "SELECT l.*, m.title AS module_title, m.id AS module_id, m.sort_order AS module_sort,
            c.title AS course_title, c.slug AS course_slug, c.id AS course_id,
            c.is_premium AS course_is_premium
     FROM lessons l
     JOIN modules m ON m.id = l.module_id
     JOIN courses c ON c.id = m.course_id
     WHERE l.id = ? AND l.status = 'published' AND c.status = 'published'
     LIMIT 1"
);
$stmt->execute([$lessonId]);
$lesson = $stmt->fetch();

if (!$lesson) {
    http_response_code(404);
    $pageTitle = 'Lesson Not Found';
    require_once __DIR__ . '/includes/header.php';
    echo '<section class="af-section"><div class="af-container"><h1>Lesson not found</h1></div></section>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// ---- SERVER-SIDE premium gate. Never trust client state for this. ----
// A lesson is premium if it is marked premium OR its whole course is premium.
if (($lesson['is_premium'] || $lesson['course_is_premium']) && !can_view_premium($userId)) {
    redirect('/pricing.php?reason=premium');
}

// Mark complete (POST only, CSRF-protected, no duplicate rows thanks to unique key)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_complete'])) {
    require_csrf();
    $ins = db()->prepare('INSERT IGNORE INTO lesson_progress (user_id, lesson_id) VALUES (?, ?)');
    $ins->execute([$userId, $lessonId]);
    flash_set('success', 'Lesson marked as complete.');
    redirect('/lesson.php?id=' . $lessonId);
}

$completed = lesson_is_completed($userId, $lessonId);

// Previous / next lesson within the same course (across modules, ordered)
$orderStmt = db()->prepare(
    "SELECT l.id FROM lessons l
     JOIN modules m ON m.id = l.module_id
     WHERE m.course_id = ? AND l.status = 'published'
     ORDER BY m.sort_order, l.sort_order"
);
$orderStmt->execute([$lesson['course_id']]);
$order = array_column($orderStmt->fetchAll(), 'id');
$pos = array_search($lessonId, $order, true);
$prevId = $pos !== false && $pos > 0 ? $order[$pos - 1] : null;
$nextId = $pos !== false && $pos < count($order) - 1 ? $order[$pos + 1] : null;

$quizCountStmt = db()->prepare('SELECT COUNT(*) FROM quizzes WHERE lesson_id = ?');
$quizCountStmt->execute([$lessonId]);
$hasQuiz = (int) $quizCountStmt->fetchColumn() > 0;

$pageTitle = $lesson['title'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:760px;">
        <p class="af-muted">
            <a href="<?= APP_URL ?>/course.php?slug=<?= urlencode($lesson['course_slug']) ?>"><?= e($lesson['course_title']) ?></a>
            &rsaquo; <?= e($lesson['module_title']) ?>
        </p>
        <h1><?= e($lesson['title']) ?></h1>
        <p class="af-muted"><?= (int) $lesson['duration_minutes'] ?> min <?php if ($completed): ?>&middot; <span style="color:var(--green);">Completed</span><?php endif; ?></p>

        <div class="af-card" style="margin-top:20px; line-height:1.8;">
            <?= nl2br(e($lesson['content'])) ?>
        </div>

        <div style="display:flex; gap:14px; flex-wrap:wrap; margin-top:22px;">
            <?php if (!$completed): ?>
                <form method="post">
                    <?= csrf_field() ?>
                    <button type="submit" name="mark_complete" value="1" class="af-btn af-btn-gold">Mark Lesson Complete</button>
                </form>
            <?php endif; ?>
            <?php if ($hasQuiz): ?>
                <a href="<?= APP_URL ?>/quiz.php?lesson_id=<?= $lessonId ?>" class="af-btn af-btn-ghost">Take Quiz</a>
            <?php endif; ?>
            <?php if ($lesson['slug'] === 'pips-lots-and-leverage'): ?>
                <a href="<?= APP_URL ?>/pips_lots_calculator.php" class="af-btn af-btn-ghost">Practice: Pips &amp; Lots Calculator</a>
            <?php endif; ?>
            <?php if (in_array($lesson['slug'], ['risk-per-trade', 'stop-loss-and-take-profit'], true)): ?>
                <a href="<?= APP_URL ?>/first_trade.php" class="af-btn af-btn-ghost">Practice: Build Your First Trade</a>
            <?php endif; ?>
            <a href="<?= APP_URL ?>/ai_tutor.php?lesson_id=<?= $lessonId ?>&course_id=<?= (int) $lesson['course_id'] ?>" class="af-btn af-btn-ghost">&#129302; Ask Alpha Forge Tutor</a>
        </div>

        <div style="display:flex; justify-content:space-between; margin-top:36px; border-top:1px solid var(--border); padding-top:18px;">
            <?php if ($prevId): ?><a href="<?= APP_URL ?>/lesson.php?id=<?= $prevId ?>" class="af-btn af-btn-ghost">&larr; Previous</a><?php else: ?><span></span><?php endif; ?>
            <?php if ($nextId): ?><a href="<?= APP_URL ?>/lesson.php?id=<?= $nextId ?>" class="af-btn af-btn-ghost">Next &rarr;</a><?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
