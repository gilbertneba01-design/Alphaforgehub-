<?php
/**
 * ALPHA FORGE HUB - Backtesting Lab API (STUDENT, JSON)
 * Uses a synthetic (randomly generated) candle sequence for practice —
 * clearly labeled as practice data, never presented as real historical
 * market data, per the "never fabricate live/historical data" rule.
 * Candle sequence lives in the PHP session; only trade decisions and
 * final results are persisted to the database.
 */
require_once __DIR__ . '/config/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function bt_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') bt_json(['ok' => false, 'error' => 'Method not allowed.'], 405);
if (!is_logged_in()) bt_json(['ok' => false, 'login' => true], 401);
if (!csrf_verify()) bt_json(['ok' => false, 'error' => 'Session expired. Reload the page.'], 403);
if (!enforce_rate_limit('backtest', 90, 60, 60)) bt_json(['ok' => false, 'error' => 'Slow down a little.'], 429);

$userId = (int) current_user()['id'];
$action = (string) ($_POST['action'] ?? '');

function bt_generate_candles(float $start, int $count): array {
    $candles = [];
    $price = $start;
    for ($i = 0; $i < $count; $i++) {
        $open = $price;
        $change = (mt_rand(-100, 100) / 100000) * mt_rand(3, 12);
        $close = $open + $change;
        $high = max($open, $close) + (mt_rand(0, 40) / 100000);
        $low  = min($open, $close) - (mt_rand(0, 40) / 100000);
        $candles[] = ['o' => round($open, 5), 'h' => round($high, 5), 'l' => round($low, 5), 'c' => round($close, 5)];
        $price = $close;
    }
    return $candles;
}

if ($action === 'start') {
    $pair = strtoupper(trim((string) ($_POST['pair'] ?? 'EURUSD')));
    $tf   = trim((string) ($_POST['timeframe'] ?? 'H1'));
    $notes = trim((string) ($_POST['strategy_notes'] ?? ''));
    if (!preg_match('/^[A-Z]{6}$/', $pair)) $pair = 'EURUSD';

    $candles = bt_generate_candles(1.08000, 120);
    $_SESSION['bt_candles'] = $candles;
    $_SESSION['bt_reveal_index'] = 10; // start with 10 candles already visible
    $_SESSION['bt_pair'] = $pair;

    $stmt = db()->prepare('INSERT INTO backtest_sessions (user_id, pair, timeframe, strategy_notes) VALUES (?,?,?,?)');
    $stmt->execute([$userId, $pair, $tf, $notes ?: null]);
    $_SESSION['bt_session_id'] = (int) db()->lastInsertId();

    bt_json(['ok' => true, 'session_id' => $_SESSION['bt_session_id'], 'visible' => array_slice($candles, 0, 10), 'pair' => $pair]);
}

if (!isset($_SESSION['bt_candles'], $_SESSION['bt_session_id'])) {
    bt_json(['ok' => false, 'error' => 'No active backtest session. Start a new one.'], 400);
}

if ($action === 'next_candle') {
    $idx = (int) $_SESSION['bt_reveal_index'];
    if ($idx >= count($_SESSION['bt_candles'])) bt_json(['ok' => false, 'error' => 'End of historical data. Finish the session to see your results.']);
    $candle = $_SESSION['bt_candles'][$idx];
    $_SESSION['bt_reveal_index'] = $idx + 1;
    bt_json(['ok' => true, 'candle' => $candle, 'index' => $idx, 'done' => ($idx + 1) >= count($_SESSION['bt_candles'])]);
}

if ($action === 'open_trade') {
    $direction = ($_POST['direction'] ?? '') === 'sell' ? 'sell' : 'buy';
    $entry = (float) ($_POST['entry_price'] ?? 0);
    if ($entry <= 0) bt_json(['ok' => false, 'error' => 'Invalid entry price.'], 400);
    $stmt = db()->prepare('INSERT INTO backtest_trades (session_id, candle_index, direction, entry_price) VALUES (?,?,?,?)');
    $stmt->execute([$_SESSION['bt_session_id'], (int) $_SESSION['bt_reveal_index'], $direction, $entry]);
    bt_json(['ok' => true, 'trade_id' => (int) db()->lastInsertId()]);
}

if ($action === 'close_trade') {
    $tradeId = (int) ($_POST['trade_id'] ?? 0);
    $exit = (float) ($_POST['exit_price'] ?? 0);
    $stmt = db()->prepare('SELECT * FROM backtest_trades WHERE id = ? AND session_id = ?');
    $stmt->execute([$tradeId, $_SESSION['bt_session_id']]);
    $trade = $stmt->fetch();
    if (!$trade || $exit <= 0) bt_json(['ok' => false, 'error' => 'Trade not found.'], 404);

    $diff = $trade['direction'] === 'buy' ? ($exit - $trade['entry_price']) : ($trade['entry_price'] - $exit);
    $riskUnit = 0.0020; // fixed 20-pip "1R" assumption for this practice tool
    $r = round($diff / $riskUnit, 2);
    $result = $r > 0.05 ? 'win' : ($r < -0.05 ? 'loss' : 'breakeven');

    db()->prepare("UPDATE backtest_trades SET exit_price=?, result=?, pnl_r=? WHERE id=?")
        ->execute([$exit, $result, $r, $tradeId]);
    bt_json(['ok' => true, 'result' => $result, 'r' => $r]);
}

if ($action === 'finish') {
    $stmt = db()->prepare("UPDATE backtest_sessions SET status='completed', completed_at=NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['bt_session_id']]);

    $stats = db()->prepare("SELECT
            COUNT(*) AS total,
            SUM(result='win') AS wins,
            SUM(result='loss') AS losses,
            SUM(pnl_r) AS total_r
        FROM backtest_trades WHERE session_id = ? AND result != 'open'");
    $stats->execute([$_SESSION['bt_session_id']]);
    $row = $stats->fetch();
    $total = (int) ($row['total'] ?? 0);
    $winRate = $total > 0 ? round(($row['wins'] / $total) * 100, 1) : 0;

    unset($_SESSION['bt_candles'], $_SESSION['bt_reveal_index'], $_SESSION['bt_session_id'], $_SESSION['bt_pair']);

    bt_json(['ok' => true, 'total_trades' => $total, 'wins' => (int) $row['wins'], 'losses' => (int) $row['losses'], 'win_rate' => $winRate, 'total_r' => (float) $row['total_r']]);
}

bt_json(['ok' => false, 'error' => 'Unknown action.'], 400);
