<?php
/**
 * ALPHA FORGE HUB - Forex Tools: live exchange rate proxy
 *
 * The browser never calls a third-party FX API directly (avoids CORS
 * issues and keeps a single, rate-limited, server-side choke point).
 * Source: Frankfurter.app (European Central Bank reference rates, free,
 * no API key required). Cached to disk for 1 hour to be a good citizen.
 *
 * GET /api/tools/fx_rate.php?from=EUR&to=USD
 */
require_once __DIR__ . '/../../config/functions.php';

header('Content-Type: application/json; charset=utf-8');

function fx_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

if (!is_logged_in()) {
    fx_json(['ok' => false, 'error' => 'Please log in.'], 401);
}
if (!enforce_rate_limit('fx_rate', 30, 60, 60)) {
    fx_json(['ok' => false, 'error' => 'Too many requests. Please wait a moment.'], 429);
}

$from = strtoupper(trim((string) ($_GET['from'] ?? '')));
$to   = strtoupper(trim((string) ($_GET['to'] ?? '')));

if (!preg_match('/^[A-Z]{3}$/', $from) || !preg_match('/^[A-Z]{3}$/', $to)) {
    fx_json(['ok' => false, 'error' => 'Invalid currency code.'], 422);
}
if ($from === $to) {
    fx_json(['ok' => true, 'rate' => 1.0, 'from' => $from, 'to' => $to, 'cached' => false]);
}

$cacheDir = sys_get_temp_dir() . '/af_fx_cache';
if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0755, true);
}
$cacheFile = $cacheDir . '/' . $from . '_' . $to . '.json';

if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 3600) {
    $cached = json_decode((string) file_get_contents($cacheFile), true);
    if (is_array($cached) && isset($cached['rate'])) {
        fx_json(['ok' => true, 'rate' => $cached['rate'], 'from' => $from, 'to' => $to, 'cached' => true]);
    }
}

$url = 'https://api.frankfurter.app/latest?from=' . urlencode($from) . '&to=' . urlencode($to);
$ch  = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_CONNECTTIMEOUT => 5,
]);
$raw  = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($raw === false || $code >= 400) {
    fx_json(['ok' => false, 'error' => 'Could not fetch a live rate right now (' . ($err ?: ('HTTP ' . $code)) . '). Enter the rate manually below.'], 502);
}

$data = json_decode((string) $raw, true);
$rate = $data['rates'][$to] ?? null;
if (!$rate) {
    fx_json(['ok' => false, 'error' => 'That currency pair is not available from the rate provider. Enter the rate manually below.'], 502);
}

file_put_contents($cacheFile, json_encode(['rate' => $rate]));
fx_json(['ok' => true, 'rate' => $rate, 'from' => $from, 'to' => $to, 'cached' => false]);
