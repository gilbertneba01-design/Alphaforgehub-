<?php
/**
 * ALPHA FORGE HUB - AI Tutor API (STUDENT, JSON)
 *
 * POST only. Actions:
 *   new   - start a new conversation (optionally scoped to a lesson/course)
 *   send  - send a student message inside a conversation, get the AI reply
 *   list  - list this student's recent conversations
 *   load  - load a single conversation's messages (ownership-checked)
 *
 * The AI API key is never sent to the browser: this endpoint is the only
 * place that talks to the configured AI provider.
 */
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/../../config/ai_tutor.php';
require_once __DIR__ . '/../../includes/ai/AiProviderManager.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function ai_json(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    ai_json(['ok' => false, 'error' => 'Method not allowed.'], 405);
}
if (!is_logged_in()) {
    ai_json(['ok' => false, 'login' => true, 'error' => 'Your session has expired. Please log in again.'], 401);
}
if (!csrf_verify()) {
    ai_json(['ok' => false, 'error' => 'Your page session expired. Reload the page and try again.'], 403);
}

$user   = current_user();
$userId = (int) $user['id'];

$action = (string) ($_POST['action'] ?? '');
if (!in_array($action, ['new', 'send', 'list', 'load'], true)) {
    ai_json(['ok' => false, 'error' => 'Unknown action.'], 400);
}

// Abuse throttle (per IP): generous, just stops scripted hammering, not real students.
if (!enforce_rate_limit('ai_tutor_' . $action, 60, 60, 120)) {
    ai_json(['ok' => false, 'error' => 'You are going a little fast. Wait a moment and try again.'], 429);
}

// list/load only need the DB, but new/send need a working AI provider.
if (in_array($action, ['new', 'send'], true) && !ai_tutor_available()) {
    ai_json(['ok' => false, 'error' => 'The AI Tutor is not set up yet. Please contact the administrator.'], 503);
}

// ---------------------------------------------------------------
// LIST
// ---------------------------------------------------------------
if ($action === 'list') {
    ai_json(['ok' => true, 'conversations' => ai_tutor_list_conversations($userId)]);
}

// ---------------------------------------------------------------
// LOAD
// ---------------------------------------------------------------
if ($action === 'load') {
    $conversationId = (int) ($_POST['conversation_id'] ?? 0);
    $conv = ai_tutor_get_conversation($userId, $conversationId);
    if (!$conv) {
        ai_json(['ok' => false, 'error' => 'Conversation not found.'], 404);
    }
    ai_json([
        'ok'           => true,
        'conversation' => $conv,
        'messages'     => ai_tutor_get_messages($conversationId),
        'quota_remaining' => ai_tutor_quota_remaining($userId),
    ]);
}

// ---------------------------------------------------------------
// NEW
// ---------------------------------------------------------------
if ($action === 'new') {
    $mode = (string) ($_POST['mode'] ?? 'explain');
    if (!in_array($mode, AI_TUTOR_MODES, true)) {
        $mode = 'explain';
    }
    $lessonId = (int) ($_POST['lesson_id'] ?? 0) ?: null;
    $courseId = (int) ($_POST['course_id'] ?? 0) ?: null;

    // If a lesson id was given, confirm the student can actually access it -
    // otherwise silently drop the context rather than leak premium content
    // into the AI prompt for a non-subscriber.
    if ($lessonId) {
        $stmt = db()->prepare(
            "SELECT l.is_premium, c.is_premium AS course_is_premium
             FROM lessons l JOIN modules m ON m.id = l.module_id JOIN courses c ON c.id = m.course_id
             WHERE l.id = ? LIMIT 1"
        );
        $stmt->execute([$lessonId]);
        $row = $stmt->fetch();
        if (!$row) {
            $lessonId = null;
        } elseif (($row['is_premium'] || $row['course_is_premium']) && !can_view_premium($userId)) {
            $lessonId = null;
        }
    }

    $conversationId = ai_tutor_create_conversation($userId, $courseId, $lessonId, $mode);
    ai_json([
        'ok'              => true,
        'conversation_id' => $conversationId,
        'quota_remaining' => ai_tutor_quota_remaining($userId),
    ]);
}

// ---------------------------------------------------------------
// SEND
// ---------------------------------------------------------------
if ($action === 'send') {
    $conversationId = (int) ($_POST['conversation_id'] ?? 0);
    $conv = ai_tutor_get_conversation($userId, $conversationId);
    if (!$conv) {
        ai_json(['ok' => false, 'error' => 'Conversation not found.'], 404);
    }

    $mode = (string) ($_POST['mode'] ?? $conv['mode']);
    if (!in_array($mode, AI_TUTOR_MODES, true)) {
        $mode = 'explain';
    }

    $text = trim((string) ($_POST['message'] ?? ''));
    if ($text === '') {
        ai_json(['ok' => false, 'error' => 'Type a question first.'], 422);
    }
    if (mb_strlen($text) > AI_TUTOR_MAX_INPUT_CHARS) {
        ai_json(['ok' => false, 'error' => 'That message is too long. Please shorten it.'], 422);
    }

    $remaining = ai_tutor_quota_remaining($userId);
    if ($remaining <= 0) {
        $limit = ai_tutor_daily_limit($userId);
        ai_json([
            'ok'             => false,
            'quota_exceeded' => true,
            'error'          => "You've reached today's AI Tutor limit ({$limit} messages). "
                . (has_active_subscription($userId)
                    ? 'Please try again tomorrow.'
                    : 'Upgrade to Premium for a higher daily limit, or try again tomorrow.'),
        ], 429);
    }

    // Store the student's message first so it's part of the history sent to the model.
    ai_tutor_add_message($conversationId, $userId, 'user', $text, $mode);

    $lessonCtx    = ai_tutor_lesson_context($conv['lesson_id'] ? (int) $conv['lesson_id'] : null);
    $systemPrompt = ai_tutor_system_prompt($mode, $lessonCtx);

    $historyRows = ai_tutor_get_messages($conversationId, AI_TUTOR_MAX_HISTORY_TURNS * 2 + 2);
    $historyRows = array_slice($historyRows, -1 * (AI_TUTOR_MAX_HISTORY_TURNS * 2 + 1));

    $provider = AiProviderManager::getProvider();
    $result   = $provider->chat($systemPrompt, $historyRows);

    if (!$result['success']) {
        ai_json(['ok' => false, 'error' => $result['error'] ?: 'The AI Tutor could not respond right now. Please try again.'], 502);
    }

    ai_tutor_add_message($conversationId, $userId, 'assistant', (string) $result['reply']);
    ai_tutor_touch_conversation($conversationId);
    ai_tutor_rename_conversation_if_default($conversationId, $text);

    ai_json([
        'ok'              => true,
        'reply'           => $result['reply'],
        'quota_remaining' => ai_tutor_quota_remaining($userId),
    ]);
}
