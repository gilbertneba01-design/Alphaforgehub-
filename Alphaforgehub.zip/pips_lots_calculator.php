<?php
/**
 * ALPHA FORGE - Pips & Lots Calculator Practice (STUDENT)
 * A self-contained practice tool linked from the "Pips, Lots and
 * Leverage" lesson. Generates a random risk-sizing scenario and checks
 * the student's own calculation - it never calculates the answer for
 * them up front.
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$user      = current_user();
$userId    = (int) $user['id'];
$isAdmin   = is_admin();
$hasAccess = $isAdmin || has_active_subscription($userId);

$lessonRow = null;
$stmt = db()->prepare("SELECT l.*, m.course_id FROM lessons l JOIN modules m ON m.id = l.module_id WHERE l.slug = 'pips-lots-and-leverage' LIMIT 1");
$stmt->execute();
$lessonRow = $stmt->fetch();

$locked = $lessonRow && (int) $lessonRow['is_premium'] && !$hasAccess;

$pageTitle = 'Pips & Lots Calculator - Practice';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section af-lab-page">
    <div class="af-container" style="max-width:760px;">

        <div class="af-lab-hero">
            <div>
                <span class="af-eyebrow">Forex Fundamentals &middot; Practice</span>
                <h1>Pips &amp; Lots Calculator</h1>
                <p>You're given an account balance, a risk percentage and a stop-loss distance. Work out the dollar risk and the correct lot size yourself, then check your answer.</p>
            </div>
        </div>

        <?php if ($locked): ?>
            <div class="af-card af-lab-locked">
                <span class="af-badge">Premium</span>
                <h2>Pips &amp; Lots Calculator</h2>
                <p>This practice tool is part of Premium. Subscribe to unlock it, plus all Premium lessons and Chart Lab exercises.</p>
                <a href="<?= APP_URL ?>/pricing.php?reason=premium" class="af-btn af-btn-gold">Unlock Premium</a>
            </div>
        <?php else: ?>

            <div class="af-card" id="plCalc" style="padding:24px;">
                <p style="color:var(--af-muted,#9DB0C4); font-size:14px; margin-top:0;">
                    Assumption for this tool: a pip value of <strong>$10 per standard lot (1.00 lot)</strong>,
                    as commonly used for USD-quoted major pairs such as EUR/USD, GBP/USD and AUD/USD.
                </p>

                <div id="plScenario" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:14px; margin:18px 0;">
                    <div><small style="color:var(--af-muted,#9DB0C4);">Account balance</small><div id="plBalance" style="font-size:20px; font-weight:700;"></div></div>
                    <div><small style="color:var(--af-muted,#9DB0C4);">Risk per trade</small><div id="plRisk" style="font-size:20px; font-weight:700;"></div></div>
                    <div><small style="color:var(--af-muted,#9DB0C4);">Stop loss distance</small><div id="plPips" style="font-size:20px; font-weight:700;"></div></div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:14px;">
                    <div class="af-field"><label>Dollar risk amount ($)</label>
                        <input type="number" step="0.01" id="plRiskInput" placeholder="e.g. 20.00"></div>
                    <div class="af-field"><label>Correct lot size</label>
                        <input type="number" step="0.01" id="plLotInput" placeholder="e.g. 0.40"></div>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="button" class="af-btn af-btn-gold" id="plCheck">Check Answer</button>
                    <button type="button" class="af-btn af-btn-ghost" id="plNew">New Problem</button>
                    <button type="button" class="af-btn af-btn-ghost" id="plShow">Show Solution</button>
                </div>

                <div id="plResult" class="af-lab-result" role="status" aria-live="polite" hidden style="margin-top:16px;"></div>
                <div id="plSolution" hidden style="margin-top:14px; padding:14px; border:1px solid rgba(216,174,69,0.35); border-radius:10px; font-size:14px; line-height:1.6;"></div>

                <p class="af-lab-legal" style="margin-top:20px;">Practice figures only. Real pip values vary slightly by pair, broker and account currency - always confirm the exact pip value your broker quotes before sizing a live trade.</p>
            </div>

        <?php endif; ?>
    </div>
</section>

<script nonce="<?= CSP_NONCE ?>">
(function () {
    var box = document.getElementById('plCalc');
    if (!box) { return; }

    var balances = [500, 1000, 2000, 5000, 10000];
    var risks = [0.5, 1, 1.5, 2];
    var pipValuePerLot = 10; // $ per pip, per 1.00 standard lot (this tool's stated assumption)

    var scenario = {};

    function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
    function money(n) { return '$' + n.toFixed(2); }

    function newProblem() {
        scenario.balance = rand(balances);
        scenario.riskPct = rand(risks);
        scenario.pips = 10 + Math.floor(Math.random() * 51); // 10-60 pips

        document.getElementById('plBalance').textContent = money(scenario.balance);
        document.getElementById('plRisk').textContent = scenario.riskPct + '%';
        document.getElementById('plPips').textContent = scenario.pips + ' pips';

        document.getElementById('plRiskInput').value = '';
        document.getElementById('plLotInput').value = '';
        document.getElementById('plResult').hidden = true;
        document.getElementById('plSolution').hidden = true;
    }

    function correctAnswer() {
        var riskAmount = scenario.balance * (scenario.riskPct / 100);
        var lotSize = riskAmount / (scenario.pips * pipValuePerLot);
        return { riskAmount: riskAmount, lotSize: lotSize };
    }

    function showResult(ok, text) {
        var r = document.getElementById('plResult');
        r.hidden = false;
        r.className = 'af-lab-result ' + (ok ? 'is-correct' : 'is-wrong');
        r.textContent = text;
    }

    document.getElementById('plCheck').addEventListener('click', function () {
        var riskGiven = parseFloat(document.getElementById('plRiskInput').value);
        var lotGiven = parseFloat(document.getElementById('plLotInput').value);
        if (!isFinite(riskGiven) || !isFinite(lotGiven)) {
            showResult(false, 'Enter both the dollar risk amount and the lot size before checking.');
            return;
        }
        var correct = correctAnswer();
        var riskOk = Math.abs(riskGiven - correct.riskAmount) <= 0.5;
        var lotOk = Math.abs(lotGiven - correct.lotSize) <= 0.02;

        if (riskOk && lotOk) {
            showResult(true, 'Correct! Risk amount ' + money(correct.riskAmount) + ', lot size ' + correct.lotSize.toFixed(2) + '.');
        } else if (riskOk && !lotOk) {
            showResult(false, 'Your dollar risk is right, but the lot size is off. Lot size = risk amount \u00f7 (pips \u00d7 $10).');
        } else if (!riskOk && lotOk) {
            showResult(false, 'Your lot size is right, but double check the dollar risk amount = balance \u00d7 risk %.');
        } else {
            showResult(false, 'Not quite. Work through it step by step: risk amount first, then divide by (pips \u00d7 $10).');
        }
    });

    document.getElementById('plShow').addEventListener('click', function () {
        var correct = correctAnswer();
        var sol = document.getElementById('plSolution');
        sol.hidden = false;
        sol.innerHTML =
            '<strong>Step 1 - Dollar risk:</strong> ' + money(scenario.balance) + ' \u00d7 ' + scenario.riskPct + '% = ' + money(correct.riskAmount) + '<br>' +
            '<strong>Step 2 - Lot size:</strong> ' + money(correct.riskAmount) + ' \u00f7 (' + scenario.pips + ' pips \u00d7 $10/pip/lot) = ' + correct.lotSize.toFixed(2) + ' lots';
    });

    document.getElementById('plNew').addEventListener('click', newProblem);

    newProblem();
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
