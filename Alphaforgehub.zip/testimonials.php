<?php
require_once __DIR__ . '/config/functions.php';
$testimonials = db()->query("SELECT * FROM testimonials WHERE is_approved = 1 ORDER BY created_at DESC")->fetchAll();
$pageTitle = 'Testimonials';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <div class="af-ladder"><span></span><span></span><span></span><span></span><span></span></div>
        <h1>Testimonials</h1>
        <div class="af-grid af-grid-3" style="margin-top:30px;">
            <?php foreach ($testimonials as $t): ?>
                <div class="af-card">
                    <p>&ldquo;<?= e($t['message']) ?>&rdquo;</p>
                    <h3 style="margin-top:16px; font-size:16px;"><?= e($t['name']) ?></h3>
                    <?php if ($t['role_title']): ?><p class="af-muted"><?= e($t['role_title']) ?></p><?php endif; ?>
                </div>
            <?php endforeach; ?>
            <?php if (!$testimonials): ?><p class="af-muted">No testimonials yet.</p><?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
