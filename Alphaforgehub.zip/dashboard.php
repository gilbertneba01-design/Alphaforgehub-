<?php
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/chartlab.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];

$progress = get_student_progress($userId);
$subscription = get_effective_subscription($userId);
$labStats = chartlab_stats($userId);
$courses = db()->query("SELECT * FROM courses WHERE status = 'published' ORDER BY sort_order")->fetchAll();

$recentStmt = db()->prepare(
    "SELECT lp.completed_at, l.title AS lesson_title, c.title AS course_title
     FROM lesson_progress lp
     JOIN lessons l ON l.id = lp.lesson_id
     JOIN modules m ON m.id = l.module_id
     JOIN courses c ON c.id = m.course_id
     WHERE lp.user_id = ?
     ORDER BY lp.completed_at DESC LIMIT 5"
);
$recentStmt->execute([$userId]);
$recent = $recentStmt->fetchAll();

// Find the next incomplete lesson to power "Continue Learning"
$nextStmt = db()->prepare(
    "SELECT l.id FROM lessons l
     JOIN modules m ON m.id = l.module_id
     JOIN courses c ON c.id = m.course_id
     LEFT JOIN lesson_progress lp ON lp.lesson_id = l.id AND lp.user_id = ?
     WHERE l.status = 'published' AND c.status = 'published' AND lp.id IS NULL
     ORDER BY c.sort_order, m.sort_order, l.sort_order LIMIT 1"
);
$nextStmt->execute([$userId]);
$next = $nextStmt->fetch();

/**
 * Carousel slides. To use your own photos, drop the image files into
 * assets/img/carousel/ and change the 'img' value below (any JPG, PNG,
 * WebP or SVG works; about 1600 x 640 px looks best).
 */
$slides = [
    [
        'img'     => '/assets/img/carousel/slide-3-chartlab.svg',
        'eyebrow' => 'New: Chart Lab',
        'title'   => 'Mark the zone. See how close you are.',
        'text'    => 'Practise on realistic charts. Draw support, resistance and supply and demand zones, then get instant feedback.',
        'cta'     => 'Open Chart Lab',
        'href'    => '/chart_lab.php',
    ],
    [
        'img'     => '/assets/img/carousel/slide-1-trend.svg',
        'eyebrow' => 'Learn',
        'title'   => 'Read the market with a clear head.',
        'text'    => 'Structured forex lessons, from your first pip to a complete trading plan.',
        'cta'     => $next ? 'Continue Learning' : 'Browse Courses',
        'href'    => $next ? '/lesson.php?id=' . (int) $next['id'] : '/courses.php',
    ],
    [
        'img'     => '/assets/img/carousel/slide-2-levels.svg',
        'eyebrow' => 'Technical Analysis',
        'title'   => 'Spot the levels price respects.',
        'text'    => 'Support, resistance and market structure, explained one step at a time.',
        'cta'     => 'Open the Course',
        'href'    => '/course.php?slug=technical-analysis',
    ],
    [
        'img'     => '/assets/img/carousel/slide-4-risk.svg',
        'eyebrow' => 'Risk First',
        'title'   => 'Protect your capital before you chase profit.',
        'text'    => 'Position sizing, stop losses and discipline: the habits that keep traders in the game.',
        'cta'     => 'Learn Risk Management',
        'href'    => '/course.php?slug=risk-management',
    ],
];

$pageTitle = 'Dashboard';
$extraScripts = ['/assets/js/carousel.js'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>

        <div class="af-dash-main">

            <div class="af-dash-head">
                <div>
                    <span class="af-eyebrow">Student Dashboard</span>
                    <h1>Welcome back, <?= e(explode(' ', $user['full_name'])[0]) ?>.</h1>
                    <p>Pick up where you left off, or sharpen your eye in the Chart Lab.</p>
                </div>
                <?php if ($next): ?>
                    <a href="<?= APP_URL ?>/lesson.php?id=<?= (int) $next['id'] ?>" class="af-btn af-btn-gold">Continue Learning</a>
                <?php endif; ?>
            </div>

            <!-- Featured carousel -->
            <section class="af-carousel" id="afCarousel" aria-roledescription="carousel" aria-label="Featured from Alpha Forge" tabindex="-1">
                <?php foreach ($slides as $i => $s): ?>
                    <article class="af-slide<?= $i === 0 ? ' is-active' : '' ?>" role="group" aria-roledescription="slide" aria-label="<?= $i + 1 ?> of <?= count($slides) ?>">
                        <img src="<?= e(APP_URL . $s['img']) ?>" alt="" <?= $i === 0 ? 'fetchpriority="high"' : 'loading="lazy"' ?>>
                        <div class="af-slide-shade"></div>
                        <div class="af-slide-copy">
                            <span class="af-eyebrow"><?= e($s['eyebrow']) ?></span>
                            <h2><?= e($s['title']) ?></h2>
                            <p><?= e($s['text']) ?></p>
                            <a href="<?= e(APP_URL . $s['href']) ?>" class="af-btn af-btn-gold"><?= e($s['cta']) ?></a>
                        </div>
                    </article>
                <?php endforeach; ?>
                <button type="button" class="af-car-btn af-car-prev" aria-label="Previous slide">&lsaquo;</button>
                <button type="button" class="af-car-btn af-car-next" aria-label="Next slide">&rsaquo;</button>
                <div class="af-car-dots"></div>
                <button type="button" class="af-car-toggle" aria-label="Pause slideshow">Pause</button>
            </section>

            <!-- Stats -->
            <div class="af-stats">
                <div class="af-stat">
                    <span class="af-stat-ico" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 5.5v16"/><path d="M9 8h7"/></svg>
                    </span>
                    <div class="af-stat-body">
                        <small>Lessons Completed</small>
                        <strong><?= (int) $progress['completed'] ?> / <?= (int) $progress['total'] ?></strong>
                    </div>
                </div>
                <div class="af-stat">
                    <span class="af-stat-ico" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/></svg>
                    </span>
                    <div class="af-stat-body">
                        <small>Overall Progress</small>
                        <strong><?= (int) $progress['percent'] ?>%</strong>
                        <div class="af-progress-bar"><span style="width:<?= (int) $progress['percent'] ?>%;"></span></div>
                    </div>
                </div>
                <div class="af-stat">
                    <span class="af-stat-ico" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="0.8" fill="currentColor"/></svg>
                    </span>
                    <div class="af-stat-body">
                        <small>Chart Lab</small>
                        <strong><?= (int) $labStats['solved'] ?> / <?= (int) $labStats['total'] ?></strong>
                    </div>
                </div>
                <div class="af-stat">
                    <span class="af-stat-ico" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/></svg>
                    </span>
                    <div class="af-stat-body">
                        <small>Subscription</small>
                        <strong style="font-size:20px; text-transform:capitalize;"><?= $subscription ? e($subscription['status']) : 'None' ?></strong>
                        <?php if ($subscription && $subscription['status'] === 'active'): ?>
                            <span class="af-muted">Until <?= e(date('d M Y', strtotime($subscription['ends_at']))) ?></span>
                        <?php else: ?>
                            <a href="<?= APP_URL ?>/pricing.php" class="af-muted"><strong style="display:inline; font-size:13px; color:var(--gold);">Upgrade &rarr;</strong></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Chart Lab banner -->
            <div class="af-feature">
                <div>
                    <span class="af-eyebrow">Practice</span>
                    <h3>Train your eye in the Chart Lab</h3>
                    <p>Lessons teach the idea. The Chart Lab makes it stick: mark real zones on charts and learn from every attempt.<?php if ($labStats['total'] > 0): ?> You have solved <?= (int) $labStats['solved'] ?> of <?= (int) $labStats['total'] ?> exercises.<?php endif; ?></p>
                </div>
                <div class="af-feature-actions">
                    <a href="<?= APP_URL ?>/chart_lab.php" class="af-btn af-btn-gold">Open Chart Lab</a>
                    <a href="<?= APP_URL ?>/course.php?slug=technical-analysis" class="af-btn af-btn-ghost">Technical Analysis</a>
                </div>
            </div>

            <!-- AI Tutor banner -->
            <div class="af-feature">
                <div>
                    <span class="af-eyebrow">New</span>
                    <h3>&#129302; Ask the Alpha Forge AI Tutor</h3>
                    <p>Stuck on a concept? Ask for an explanation, a simpler version, a quiz question, or help understanding a mistake.</p>
                </div>
                <div class="af-feature-actions">
                    <a href="<?= APP_URL ?>/ai_tutor.php" class="af-btn af-btn-gold">Open AI Tutor</a>
                </div>
            </div>

            <!-- Quick links to newer tools -->
            <div class="af-quicklinks">
                <a href="<?= APP_URL ?>/trading_journal.php">&#128203; Trading Journal</a>
                <a href="<?= APP_URL ?>/performance.php">&#128202; Performance</a>
                <a href="<?= APP_URL ?>/forex_tools.php">&#129518; Forex Tools</a>
                <a href="<?= APP_URL ?>/certificates.php">&#127942; Certificates</a>
                <a href="<?= APP_URL ?>/economic_calendar.php">&#128197; Calendar</a>
                <a href="<?= APP_URL ?>/market_news.php">&#128240; News</a>
                <a href="<?= APP_URL ?>/community.php">&#128101; Community</a>
                <a href="<?= APP_URL ?>/challenges.php">&#127919; Challenges</a>
                <a href="<?= APP_URL ?>/live_sessions.php">&#127909; Live Sessions</a>
            </div>

            <!-- Courses -->
            <div>
                <div class="af-section-head"><h2>Courses</h2><a href="<?= APP_URL ?>/courses.php">View all &rarr;</a></div>
                <div class="af-grid af-grid-3">
                    <?php foreach ($courses as $c): ?>
                        <div class="af-card af-course-card">
                            <div class="af-card-tags">
                                <span class="af-badge af-badge-muted"><?= e($c['level']) ?></span>
                                <span class="af-badge <?= $c['is_premium'] ? '' : 'af-badge-muted' ?>"><?= $c['is_premium'] ? 'Premium' : 'Free' ?></span>
                            </div>
                            <h3><?= e($c['title']) ?></h3>
                            <p><?= e($c['description']) ?></p>
                            <?php if ($c['slug'] === 'technical-analysis'): ?>
                                <span class="af-chip">Includes Chart Lab</span>
                            <?php endif; ?>
                            <a href="<?= APP_URL ?>/course.php?slug=<?= urlencode($c['slug']) ?>" class="af-btn af-btn-ghost">Open</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Recent activity -->
            <div>
                <div class="af-section-head"><h2>Recent Activity</h2></div>
                <?php if ($recent): ?>
                    <div class="af-table-wrap">
                        <table class="af-table">
                            <thead><tr><th>Lesson</th><th>Course</th><th>Completed</th></tr></thead>
                            <tbody>
                            <?php foreach ($recent as $r): ?>
                                <tr>
                                    <td><?= e($r['lesson_title']) ?></td>
                                    <td><?= e($r['course_title']) ?></td>
                                    <td><?= e(date('d M Y, H:i', strtotime($r['completed_at']))) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="af-muted">No lessons completed yet. Start with your first lesson above.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
