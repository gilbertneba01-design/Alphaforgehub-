<?php
require_once __DIR__ . '/config/functions.php';

$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM courses WHERE slug = ? AND status = 'published' LIMIT 1");
$stmt->execute([$slug]);
$course = $stmt->fetch();

if (!$course) {
    http_response_code(404);
    $pageTitle = 'Course Not Found';
    require_once __DIR__ . '/includes/header.php';
    echo '<section class="af-section"><div class="af-container"><h1>Course not found</h1><p><a href="' . APP_URL . '/courses.php">Back to courses</a></p></div></section>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$modStmt = db()->prepare('SELECT * FROM modules WHERE course_id = ? ORDER BY sort_order');
$modStmt->execute([$course['id']]);
$modules = $modStmt->fetchAll();

foreach ($modules as &$mod) {
    $lesStmt = db()->prepare("SELECT * FROM lessons WHERE module_id = ? AND status = 'published' ORDER BY sort_order");
    $lesStmt->execute([$mod['id']]);
    $mod['lessons'] = $lesStmt->fetchAll();
}
unset($mod);

$user = current_user();
$subscribed = $user ? can_view_premium((int) $user['id']) : false;

// Chart Lab promo: always on the Technical Analysis course, and on any course
// that has Chart Lab exercises attached to it.
require_once __DIR__ . '/config/chartlab.php';
$labCount = 0;
if (chartlab_available()) {
    $labStmt = db()->prepare("SELECT COUNT(*) FROM chartlab_exercises WHERE status = 'published' AND course_id = ?");
    $labStmt->execute([$course['id']]);
    $labCount = (int) $labStmt->fetchColumn();
}
$showLab = ($course['slug'] === 'technical-analysis') || $labCount > 0;

$pageTitle = $course['title'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:760px;">
        <span class="af-badge af-badge-muted"><?= e($course['level']) ?></span>
        <span class="af-badge <?= $course['is_premium'] ? '' : 'af-badge-muted' ?>"><?= $course['is_premium'] ? 'Premium' : 'Free' ?></span>
        <h1 style="margin-top:14px;"><?= e($course['title']) ?></h1>
        <p><?= e($course['description']) ?></p>

        <?php if ($showLab): ?>
            <div class="af-lab-promo">
                <div>
                    <span class="af-eyebrow">Practice</span>
                    <h3>Chart Lab</h3>
                    <p>Put this course into practice. Mark support, resistance and supply and demand zones on real-looking charts and get instant feedback.</p>
                </div>
                <a href="<?= APP_URL ?>/chart_lab.php" class="af-btn af-btn-gold">Open Chart Lab</a>
            </div>
        <?php endif; ?>

        <?php foreach ($modules as $mod): ?>
            <div class="af-card" style="margin-top:22px;">
                <h3><?= e($mod['title']) ?></h3>
                <?php if ($mod['description']): ?><p><?= e($mod['description']) ?></p><?php endif; ?>
                <div style="margin-top:10px;">
                    <?php foreach ($mod['lessons'] as $lesson): ?>
                        <?php
                            $isPremiumLesson = $lesson['is_premium'] || $course['is_premium'];
                            $locked = $isPremiumLesson && !$subscribed;
                            $completed = $user && lesson_is_completed((int) $user['id'], (int) $lesson['id']);
                        ?>
                        <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-top:1px solid var(--border);">
                            <span>
                                <?= e($lesson['title']) ?>
                                <span class="af-muted"> · <?= (int) $lesson['duration_minutes'] ?> min</span>
                                <?php if ($isPremiumLesson): ?><span class="af-badge" style="margin-left:8px;">Premium</span><?php endif; ?>
                                <?php if ($completed): ?><span class="af-badge" style="margin-left:8px; background:rgba(60,191,131,0.14); color:var(--green);">Completed</span><?php endif; ?>
                            </span>
                            <?php if ($locked): ?>
                                <a href="<?= APP_URL ?>/pricing.php" class="af-btn af-btn-ghost">Unlock</a>
                            <?php else: ?>
                                <a href="<?= APP_URL ?>/lesson.php?id=<?= (int) $lesson['id'] ?>" class="af-btn af-btn-ghost">Open</a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!$modules): ?>
            <p class="af-muted" style="margin-top:20px;">Modules for this course are coming soon.</p>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
