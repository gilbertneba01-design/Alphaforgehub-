// ALPHA FORGE - Admin Chart Lab exercise editor
// Lets an admin paste (or generate) candles and DRAW the correct answer
// zone(s) on the chart. The server re-validates everything on save, so
// nothing here is trusted for correctness. Loaded as an external file so it
// works under the site's Content-Security-Policy (no inline scripts).
(function () {
    'use strict';

    var form = document.getElementById('exForm');
    var canvas = document.getElementById('edCanvas');
    var stage = document.getElementById('edStage');
    var ta = document.getElementById('edCandles');
    var hidden = document.getElementById('edTargets');
    var zonesEl = document.getElementById('edZones');
    var infoEl = document.getElementById('edInfo');
    var countEl = document.getElementById('edCount');
    if (!form || !canvas || !stage || !ta || !hidden || !zonesEl) { return; }
    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }

    var MAX_ZONES = 3;
    var MIN_CANDLES = 20, MAX_CANDLES = 150;
    var COLORS = {
        up: '#3CBF83', down: '#E2604F', gold: '#D8AE45', axis: '#9DB0C4',
        grid: 'rgba(157,176,196,0.13)', text: '#EEF4FB'
    };

    // ---------------------------------------------------------------
    // State
    // ---------------------------------------------------------------
    var candles = [];          // [[o,h,l,c], ...]
    var decimals = 5;
    var parseError = '';
    var pmin = 0, pmax = 1, N = 0;
    var zones = [null];        // each: {x1,x2,p1,p2} or null (not drawn yet)
    var active = 0;
    var drag = null;
    var hoverCursor = 'crosshair';
    var lastPointer = null;
    var cssW = 0, cssH = 0, PL = 10, PR = 66, PT = 12, PB = 14, pw = 0, ph = 0;

    // ---------------------------------------------------------------
    // Candle parsing (same rules as the PHP that validates on save)
    // ---------------------------------------------------------------
    function isNum(t) { return t !== '' && isFinite(Number(t)); }

    function parseCandles(text) {
        var lines = text.split(/\r\n|\r|\n/);
        var out = [], maxDec = 0, seen = false, i, j;
        for (i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (line === '') { continue; }
            var tokens = line.split(/[\s,;]+/).filter(function (t) { return t !== ''; });
            var nums = tokens.filter(isNum);
            if (!nums.length) {
                if (!seen) { continue; }
                return { error: 'Line ' + (i + 1) + ': expected four numbers (open, high, low, close).' };
            }
            if (nums.length >= 5 && /^\d{8,}$/.test(nums[0])) { nums.shift(); }
            if (nums.length < 4) {
                return { error: 'Line ' + (i + 1) + ': expected four numbers (open, high, low, close), found ' + nums.length + '.' };
            }
            seen = true;
            nums = nums.slice(0, 4);
            var v = [];
            for (j = 0; j < 4; j++) {
                var n = Number(nums[j]);
                if (!isFinite(n) || n <= 0) { return { error: 'Line ' + (i + 1) + ': prices must be positive numbers.' }; }
                v.push(n);
                var dot = nums[j].indexOf('.');
                if (dot !== -1) { maxDec = Math.max(maxDec, nums[j].slice(dot + 1).replace(/0+$/, '').length); }
            }
            if (v[1] + 1e-12 < Math.max(v[0], v[3]) || v[2] - 1e-12 > Math.min(v[0], v[3]) || v[1] + 1e-12 < v[2]) {
                return { error: 'Line ' + (i + 1) + ': the High must be the highest value and the Low the lowest (order: open, high, low, close).' };
            }
            out.push(v);
            if (out.length > MAX_CANDLES) { return { error: 'Too many candles. Use at most ' + MAX_CANDLES + '.' }; }
        }
        if (out.length < MIN_CANDLES) {
            return { error: 'Add at least ' + MIN_CANDLES + ' candles (you have ' + out.length + ').' };
        }
        return { candles: out, decimals: Math.max(2, Math.min(6, maxDec)) };
    }

    function viewOf(list) {
        var lo = Infinity, hi = -Infinity;
        list.forEach(function (c) { lo = Math.min(lo, c[2]); hi = Math.max(hi, c[1]); });
        var pad = (hi - lo) * 0.08;
        return { min: lo - pad, max: hi + pad };
    }

    function loadFromText() {
        var res = parseCandles(ta.value);
        if (res.error) {
            candles = []; N = 0; parseError = ta.value.trim() === '' ? '' : res.error;
            countEl.textContent = parseError ? '' : '';
            countEl.style.color = '';
            if (parseError) { countEl.textContent = ' - ' + parseError; countEl.style.color = 'var(--red)'; }
        } else {
            candles = res.candles; decimals = res.decimals; N = candles.length; parseError = '';
            var v = viewOf(candles); pmin = v.min; pmax = v.max;
            countEl.textContent = ' - ' + N + ' candles';
            countEl.style.color = 'var(--green)';
            zones = zones.map(function (z) { return z ? clampZone(z) : z; });
        }
        layout(); draw(); syncHidden(); renderChips(); renderInfo();
    }

    // ---------------------------------------------------------------
    // Coordinates (identical mapping to the student chart)
    // ---------------------------------------------------------------
    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
    function xToPx(u) { return PL + (u / N) * pw; }
    function pxToX(px) { return ((px - PL) / pw) * N; }
    function pToPy(p) { return PT + ((pmax - p) / (pmax - pmin)) * ph; }
    function pyToP(py) { return pmax - ((py - PT) / ph) * (pmax - pmin); }
    function fmt(p) { return p.toFixed(decimals); }
    function copyZone(z) { return { x1: z.x1, x2: z.x2, p1: z.p1, p2: z.p2 }; }
    function norm(z) {
        return { x1: Math.min(z.x1, z.x2), x2: Math.max(z.x1, z.x2), p1: Math.min(z.p1, z.p2), p2: Math.max(z.p1, z.p2) };
    }
    function clampZone(z) {
        z = norm(z);
        return { x1: clamp(z.x1, 0, N), x2: clamp(z.x2, 0, N), p1: clamp(z.p1, pmin, pmax), p2: clamp(z.p2, pmin, pmax) };
    }
    function rectOf(z) { return { x1: xToPx(z.x1), x2: xToPx(z.x2), y1: pToPy(z.p2), y2: pToPy(z.p1) }; }
    function zoneOk(z) {
        return !!z && (z.x2 - z.x1) >= 3 && (z.p2 - z.p1) >= (pmax - pmin) * 0.03;
    }

    // ---------------------------------------------------------------
    // Trendline mode: the admin still drags out a box exactly as before;
    // the DIAGONAL of that box (bottom-left-to-top-right for an uptrend,
    // top-left-to-bottom-right for a downtrend) becomes the answer line.
    // Nothing about the existing drag/resize code below is changed.
    // ---------------------------------------------------------------
    function currentMode() {
        var sel = document.getElementById('exMode');
        return sel ? sel.value : 'band';
    }
    function currentDirection() {
        var sel = document.getElementById('exDirection');
        return sel ? sel.value : 'up';
    }
    function updateDirectionVisibility() {
        var wrap = document.getElementById('exDirectionWrap');
        if (wrap) { wrap.hidden = currentMode() !== 'trendline'; }
    }
    var exModeEl = document.getElementById('exMode');
    if (exModeEl) {
        exModeEl.addEventListener('change', function () { updateDirectionVisibility(); changed(); });
    }
    var exDirectionEl = document.getElementById('exDirection');
    if (exDirectionEl) {
        exDirectionEl.addEventListener('change', function () { changed(); });
    }

    function layout() {
        var w = Math.max(280, Math.floor(stage.clientWidth));
        var h = w < 520 ? Math.round(w * 0.95) : Math.round(clamp(w * 0.52, 340, 500));
        var dpr = window.devicePixelRatio || 1;
        cssW = w; cssH = h;
        PR = w < 520 ? 54 : 66;
        pw = w - PL - PR; ph = h - PT - PB;
        canvas.style.height = h + 'px';
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    // ---------------------------------------------------------------
    // Drawing
    // ---------------------------------------------------------------
    function niceStep(range, target) {
        var raw = range / target, mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), n = raw / mag;
        return (n < 1.5 ? 1 : (n < 3 ? 2 : (n < 7 ? 5 : 10))) * mag;
    }

    function handlesOf(z) {
        var r = rectOf(z);
        var x1 = Math.min(r.x1, r.x2), x2 = Math.max(r.x1, r.x2), y1 = Math.min(r.y1, r.y2), y2 = Math.max(r.y1, r.y2);
        var mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
        return [
            { k: 'nw', x: x1, y: y1 }, { k: 'n', x: mx, y: y1 }, { k: 'ne', x: x2, y: y1 },
            { k: 'e', x: x2, y: my }, { k: 'se', x: x2, y: y2 }, { k: 's', x: mx, y: y2 },
            { k: 'sw', x: x1, y: y2 }, { k: 'w', x: x1, y: my }
        ];
    }

    function draw() {
        if (!cssW) { return; }
        ctx.clearRect(0, 0, cssW, cssH);
        ctx.fillStyle = '#0B1E36';
        ctx.fillRect(0, 0, cssW, cssH);

        if (!N) {
            ctx.fillStyle = COLORS.axis;
            ctx.font = '600 14px Inter, system-ui, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(parseError ? 'Fix the candles above to see the chart' : 'Paste candles or generate a chart to begin', cssW / 2, cssH / 2);
            return;
        }

        var i, x, y;
        // Horizontal grid + price labels
        var step = niceStep(pmax - pmin, 6);
        ctx.font = '11px Inter, system-ui, sans-serif';
        ctx.textAlign = 'left';
        for (var p = Math.ceil(pmin / step) * step; p <= pmax; p += step) {
            y = Math.round(pToPy(p)) + 0.5;
            ctx.strokeStyle = COLORS.grid; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(PL, y); ctx.lineTo(PL + pw, y); ctx.stroke();
            ctx.fillStyle = COLORS.axis;
            ctx.fillText(p.toFixed(decimals), PL + pw + 6, y + 4);
        }
        var slot = pw / N;
        for (i = 6; i < N; i += 6) {
            x = Math.round(PL + i * slot) + 0.5;
            ctx.strokeStyle = 'rgba(157,176,196,0.07)';
            ctx.beginPath(); ctx.moveTo(x, PT); ctx.lineTo(x, PT + ph); ctx.stroke();
        }

        ctx.save();
        ctx.beginPath(); ctx.rect(PL, PT, pw, ph); ctx.clip();

        var bodyW = Math.max(2, slot * 0.62);
        for (i = 0; i < N; i++) {
            var c = candles[i], xc = PL + (i + 0.5) * slot, up = c[3] >= c[0];
            ctx.strokeStyle = up ? COLORS.up : COLORS.down;
            ctx.fillStyle = up ? COLORS.up : COLORS.down;
            ctx.lineWidth = 1.4;
            ctx.beginPath(); ctx.moveTo(xc, pToPy(c[1])); ctx.lineTo(xc, pToPy(c[2])); ctx.stroke();
            var yo = pToPy(c[0]), yc = pToPy(c[3]);
            ctx.fillRect(xc - bodyW / 2, Math.min(yo, yc), bodyW, Math.max(1.5, Math.abs(yo - yc)));
        }

        // Inactive zones first, active zone on top
        zones.forEach(function (z, idx) {
            if (!z || idx === active) { return; }
            var r = rectOf(z);
            ctx.fillStyle = 'rgba(216,174,69,0.07)';
            ctx.fillRect(Math.min(r.x1, r.x2), Math.min(r.y1, r.y2), Math.abs(r.x2 - r.x1), Math.abs(r.y2 - r.y1));
            ctx.strokeStyle = 'rgba(216,174,69,0.6)'; ctx.lineWidth = 1.5; ctx.setLineDash([6, 4]);
            ctx.strokeRect(Math.min(r.x1, r.x2) + 0.5, Math.min(r.y1, r.y2) + 0.5, Math.abs(r.x2 - r.x1), Math.abs(r.y2 - r.y1));
            ctx.setLineDash([]);
        });
        var az = zones[active];
        if (az) {
            var ar = rectOf(az);
            var ok = zoneOk(az);
            ctx.fillStyle = ok ? 'rgba(216,174,69,0.20)' : 'rgba(226,96,79,0.16)';
            ctx.fillRect(Math.min(ar.x1, ar.x2), Math.min(ar.y1, ar.y2), Math.abs(ar.x2 - ar.x1), Math.abs(ar.y2 - ar.y1));
            ctx.strokeStyle = ok ? COLORS.gold : COLORS.down; ctx.lineWidth = 2;
            ctx.strokeRect(Math.min(ar.x1, ar.x2) + 0.5, Math.min(ar.y1, ar.y2) + 0.5, Math.abs(ar.x2 - ar.x1), Math.abs(ar.y2 - ar.y1));

            if (currentMode() === 'trendline') {
                var lx1 = Math.min(ar.x1, ar.x2), lx2 = Math.max(ar.x1, ar.x2);
                var top = Math.min(ar.y1, ar.y2), bottom = Math.max(ar.y1, ar.y2);
                var ly1, ly2;
                if (currentDirection() === 'down') { ly1 = top; ly2 = bottom; } else { ly1 = bottom; ly2 = top; }
                ctx.strokeStyle = COLORS.gold; ctx.lineWidth = 3; ctx.setLineDash([]);
                ctx.beginPath(); ctx.moveTo(lx1, ly1); ctx.lineTo(lx2, ly2); ctx.stroke();
            }
        }
        ctx.restore();

        // Zone labels
        ctx.font = '600 11px Inter, system-ui, sans-serif';
        zones.forEach(function (z, idx) {
            if (!z) { return; }
            var r = rectOf(z);
            var lx = Math.max(PL + 4, Math.min(r.x1, r.x2) + 4), ly = Math.max(PT + 12, Math.min(r.y1, r.y2) - 5);
            ctx.fillStyle = idx === active ? COLORS.gold : 'rgba(216,174,69,0.75)';
            ctx.fillText('Zone ' + (idx + 1), lx, ly);
        });

        if (az) {
            handlesOf(az).forEach(function (h) {
                ctx.fillStyle = COLORS.gold; ctx.strokeStyle = '#071426'; ctx.lineWidth = 1.5;
                ctx.fillRect(h.x - 4.5, h.y - 4.5, 9, 9); ctx.strokeRect(h.x - 4.5, h.y - 4.5, 9, 9);
            });
        }

        // Cursor price tag
        if (lastPointer && !drag) {
            var py = clamp(lastPointer.y, PT, PT + ph);
            var pr = pyToP(py);
            ctx.fillStyle = 'rgba(11,30,54,0.9)';
            ctx.fillRect(PL + pw + 2, py - 9, PR - 4, 18);
            ctx.fillStyle = COLORS.text; ctx.font = '600 11px Inter, system-ui, sans-serif';
            ctx.fillText(pr.toFixed(decimals), PL + pw + 6, py + 4);
        }
    }

    // ---------------------------------------------------------------
    // Zone chips and info text
    // ---------------------------------------------------------------
    function renderChips() {
        var html = '';
        zones.forEach(function (z, i) {
            var label = 'Zone ' + (i + 1) + (z ? '' : ' (not drawn)');
            html += '<span class="af-ed-chip' + (i === active ? ' is-active' : '') + '">' +
                '<button type="button" data-zone-select="' + i + '">' + label + '</button>' +
                (zones.length > 1 || z ? '<button type="button" class="af-ed-chip-x" data-zone-remove="' + i + '" aria-label="Remove zone ' + (i + 1) + '">&times;</button>' : '') +
                '</span>';
        });
        if (zones.length < MAX_ZONES) {
            html += '<button type="button" class="af-btn af-btn-ghost af-ed-add" data-zone-add="1">+ Add another accepted zone</button>';
        }
        zonesEl.innerHTML = html;
    }

    function renderInfo(msg, isError) {
        var z = zones[active];
        var text;
        if (msg) {
            text = msg;
        } else if (!N) {
            text = 'The chart appears here once you paste or generate candles.';
        } else if (!z) {
            text = 'Drag on the chart to draw Zone ' + (active + 1) + '.';
        } else {
            text = 'Zone ' + (active + 1) + ': price ' + fmt(z.p1) + ' to ' + fmt(z.p2) + ', candles ' + Math.round(z.x1) + ' to ' + Math.round(z.x2) + '.';
            if (!zoneOk(z)) {
                text += ' This zone is too small to save. Make it at least 3 candles wide and a bit taller.';
                isError = true;
            } else if ((z.p2 - z.p1) > (pmax - pmin) * 0.5) {
                text += ' This is a very large zone. Tighten it so students must be precise.';
            }
        }
        infoEl.textContent = text;
        infoEl.style.color = isError ? 'var(--red)' : '';
    }

    function syncHidden() {
        var isLine = currentMode() === 'trendline';
        var down = currentDirection() === 'down';
        var out = [];
        zones.forEach(function (z) {
            if (!z) { return; }
            if (isLine) {
                // zones[] is always kept low-price-first by norm(); the
                // chosen direction decides which corner is the start.
                var p1 = down ? z.p2 : z.p1;
                var p2 = down ? z.p1 : z.p2;
                out.push({
                    x1: +z.x1.toFixed(2), x2: +z.x2.toFixed(2),
                    p1: +p1.toFixed(6), p2: +p2.toFixed(6)
                });
            } else {
                out.push({
                    x1: +z.x1.toFixed(2), x2: +z.x2.toFixed(2),
                    p1: +z.p1.toFixed(6), p2: +z.p2.toFixed(6)
                });
            }
        });
        hidden.value = out.length ? JSON.stringify(out) : '';
    }

    function changed() { syncHidden(); renderChips(); renderInfo(); draw(); }

    zonesEl.addEventListener('click', function (ev) {
        var t = ev.target;
        if (!(t instanceof Element)) { return; }
        var sel = t.getAttribute('data-zone-select');
        var rem = t.getAttribute('data-zone-remove');
        if (sel !== null) { active = +sel; changed(); return; }
        if (rem !== null) {
            var idx = +rem;
            if (zones.length === 1) { zones = [null]; } else { zones.splice(idx, 1); }
            active = Math.min(active, zones.length - 1);
            if (idx < active) { active = Math.max(0, active - 1); }
            changed(); return;
        }
        if (t.getAttribute('data-zone-add') !== null && zones.length < MAX_ZONES) {
            zones.push(null); active = zones.length - 1; changed();
        }
    });

    // ---------------------------------------------------------------
    // Pointer interaction (draw, move, resize)
    // ---------------------------------------------------------------
    function posOf(ev) {
        var r = canvas.getBoundingClientRect();
        return { x: ev.clientX - r.left, y: ev.clientY - r.top };
    }
    function hitHandle(z, pt, touch) {
        var rad = touch ? 18 : 11, list = handlesOf(z), best = null, bd = 1e9;
        list.forEach(function (h) {
            var d = Math.hypot(h.x - pt.x, h.y - pt.y);
            if (d <= rad && d < bd) { best = h.k; bd = d; }
        });
        return best;
    }
    function inside(z, pt) {
        var r = rectOf(z);
        return pt.x >= Math.min(r.x1, r.x2) && pt.x <= Math.max(r.x1, r.x2) && pt.y >= Math.min(r.y1, r.y2) && pt.y <= Math.max(r.y1, r.y2);
    }
    var CURSORS = { nw: 'nwse-resize', se: 'nwse-resize', ne: 'nesw-resize', sw: 'nesw-resize', n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize' };

    canvas.addEventListener('pointerdown', function (ev) {
        if (!N || (ev.pointerType === 'mouse' && ev.button !== 0)) { return; }
        ev.preventDefault();
        var pt = posOf(ev), touch = ev.pointerType !== 'mouse';
        var az = zones[active];
        drag = null;

        if (az) {
            var hk = hitHandle(az, pt, touch);
            if (hk) { drag = { type: 'resize', k: hk, start: copyZone(az) }; }
            else if (inside(az, pt)) {
                drag = { type: 'move', start: copyZone(az), px: pxToX(pt.x), pp: pyToP(pt.y) };
            }
        }
        if (!drag) {
            // clicking inside another zone selects it
            for (var i = 0; i < zones.length; i++) {
                if (i !== active && zones[i] && inside(zones[i], pt)) { active = i; changed(); return; }
            }
            var ax = clamp(pxToX(pt.x), 0, N), ap = clamp(pyToP(pt.y), pmin, pmax);
            drag = { type: 'draw', ax: ax, ap: ap, prev: az ? copyZone(az) : null };
            zones[active] = { x1: ax, x2: ax, p1: ap, p2: ap };
        }
        try { canvas.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
        draw();
    });

    canvas.addEventListener('pointermove', function (ev) {
        var pt = posOf(ev);
        lastPointer = ev.pointerType === 'mouse' ? pt : null;
        if (!drag) {
            var az = zones[active], cur = 'crosshair';
            if (N && az) {
                var hk = hitHandle(az, pt, false);
                cur = hk ? CURSORS[hk] : (inside(az, pt) ? 'move' : 'crosshair');
            }
            if (cur !== hoverCursor) { hoverCursor = cur; canvas.style.cursor = cur; }
            draw();
            return;
        }
        var x = clamp(pxToX(pt.x), 0, N), p = clamp(pyToP(pt.y), pmin, pmax);
        if (drag.type === 'draw') {
            zones[active] = norm({ x1: drag.ax, x2: x, p1: drag.ap, p2: p });
        } else if (drag.type === 'move') {
            var s = drag.start, w = s.x2 - s.x1, h = s.p2 - s.p1;
            var nx1 = clamp(s.x1 + (x - drag.px), 0, N - w), np1 = clamp(s.p1 + (p - drag.pp), pmin, pmax - h);
            zones[active] = { x1: nx1, x2: nx1 + w, p1: np1, p2: np1 + h };
        } else {
            var z = copyZone(drag.start);
            if (drag.k.indexOf('w') !== -1) { z.x1 = x; }
            if (drag.k.indexOf('e') !== -1) { z.x2 = x; }
            if (drag.k.indexOf('n') !== -1) { z.p2 = p; }
            if (drag.k.indexOf('s') !== -1) { z.p1 = p; }
            zones[active] = norm(z);
        }
        renderInfo();
        draw();
    });

    function endDrag(ev) {
        if (!drag) { return; }
        try { canvas.releasePointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
        var z = zones[active];
        if (drag.type === 'draw') {
            // A plain click (no real drag) must not create a zone.
            if (!z || (z.x2 - z.x1) < 0.8 || (z.p2 - z.p1) < (pmax - pmin) * 0.01) {
                zones[active] = drag.prev;
            }
        }
        drag = null;
        changed();
    }
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', endDrag);
    canvas.addEventListener('pointerleave', function () { lastPointer = null; if (!drag) { draw(); } });

    // ---------------------------------------------------------------
    // Practice-chart generator
    // ---------------------------------------------------------------
    function rng(seed) {
        var a = seed >>> 0;
        return function () {
            a |= 0; a = (a + 0x6D2B79F5) | 0;
            var t = Math.imul(a ^ (a >>> 15), 1 | a);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }

    function interp(way, i) {
        for (var k = 0; k < way.length - 1; k++) {
            if (i >= way[k][0] && i <= way[k + 1][0]) {
                var span = way[k + 1][0] - way[k][0];
                var f = span === 0 ? 0 : (i - way[k][0]) / span;
                return way[k][1] + (way[k + 1][1] - way[k][1]) * f;
            }
        }
        return way[way.length - 1][1];
    }

    // Builds candles from waypoints (levels in "u" units above the base price).
    function build(base, way, noiseAt, rnd, pins) {
        var u = base * 0.0012, N2 = way[way.length - 1][0] + 1;
        var closes = [], i;
        for (i = 0; i < N2; i++) {
            var nz = noiseAt(i) * u;
            closes.push(base + interp(way, i) * u + (rnd() - 0.5) * nz * 1.1);
        }
        (pins.close || []).forEach(function (pn) { closes[pn.i] = base + pn.level * u; });
        var out = [];
        for (i = 0; i < N2; i++) {
            var n2 = noiseAt(i) * u;
            var o = i === 0 ? closes[0] + (rnd() - 0.5) * n2 : closes[i - 1];
            var c = closes[i];
            var h = Math.max(o, c) + rnd() * n2 * 0.7;
            var l = Math.min(o, c) - rnd() * n2 * 0.7;
            out.push([o, h, l, c]);
        }
        (pins.low || []).forEach(function (pn) {
            var cd = out[pn.i]; cd[2] = base + pn.level * u; cd[1] = Math.max(cd[1], cd[0], cd[3]);
            cd[2] = Math.min(cd[2], cd[0], cd[3]);
        });
        (pins.high || []).forEach(function (pn) {
            var cd = out[pn.i]; cd[1] = base + pn.level * u; cd[2] = Math.min(cd[2], cd[0], cd[3]);
            cd[1] = Math.max(cd[1], cd[0], cd[3]);
        });
        return { candles: out, u: u };
    }

    function extremes(cs, a, b) {
        var lo = Infinity, hi = -Infinity;
        for (var i = a; i <= b && i < cs.length; i++) { lo = Math.min(lo, cs[i][2]); hi = Math.max(hi, cs[i][1]); }
        return { lo: lo, hi: hi };
    }

    var PATTERNS = {
        support: {
            mode: 'band',
            gen: function (base, rnd) {
                var w = [[0, 6], [9, 0.25], [17, 4.6], [24, 0.25], [32, 5.6], [38, 0.25], [47, 8]];
                var touches = [9, 24, 38];
                var b = build(base, w, function () { return 0.5; }, rnd, {
                    close: touches.map(function (i) { return { i: i, level: 0.25 + rnd() * 0.3 }; }),
                    low: touches.map(function (i) { return { i: i, level: -0.05 - rnd() * 0.25 }; })
                });
                var lo = extremes(b.candles, 9, 38).lo;
                return { candles: b.candles, zones: [{ x1: 8, x2: 40, p1: Math.min(lo, base - 0.05 * b.u), p2: base + 0.85 * b.u }] };
            },
            text: {
                title: 'Mark the Support Zone',
                instruction: 'Price keeps falling to the same floor and bouncing. Drag a box over the support zone: the price area where buyers stepped in each time. Stretch it across the candles that touched the floor.',
                hint: 'Look for the price level where the lows line up.',
                explanation: 'Support is a price area where buyers repeatedly stepped in and pushed price back up. The lows here clustered at the same level, so that band is the support zone.'
            }
        },
        resistance: {
            mode: 'band',
            gen: function (base, rnd) {
                var w = [[0, -6], [10, -0.25], [18, -4.6], [25, -0.25], [33, -5.6], [39, -0.25], [47, -8]];
                var touches = [10, 25, 39];
                var b = build(base, w, function () { return 0.5; }, rnd, {
                    close: touches.map(function (i) { return { i: i, level: -0.25 - rnd() * 0.3 }; }),
                    high: touches.map(function (i) { return { i: i, level: 0.05 + rnd() * 0.25 }; })
                });
                var hi = extremes(b.candles, 10, 39).hi;
                return { candles: b.candles, zones: [{ x1: 9, x2: 41, p1: base - 0.85 * b.u, p2: Math.max(hi, base + 0.05 * b.u) }] };
            },
            text: {
                title: 'Mark the Resistance Zone',
                instruction: 'Price keeps rising to the same ceiling and getting pushed back down. Drag a box over the resistance zone: the price area where sellers stepped in each time.',
                hint: 'Look for the price level where the highs line up.',
                explanation: 'Resistance is a price area where sellers repeatedly stepped in and pushed price back down. The highs here clustered at the same level, so that band is the resistance zone.'
            }
        },
        range: {
            mode: 'box',
            gen: function (base, rnd) {
                var W = 5;
                var w = [[0, -3], [11, W], [15, 0.4], [19, W - 0.3], [23, 0.5], [27, W - 0.4], [31, 0.6], [34, W * 0.6], [38, W + 2.5], [47, W + 7]];
                var b = build(base, w, function () { return 0.5; }, rnd, {
                    close: [{ i: 11, level: W - 0.5 }, { i: 15, level: 0.7 }, { i: 19, level: W - 0.7 }, { i: 23, level: 0.8 }, { i: 27, level: W - 0.7 }, { i: 31, level: 0.9 }],
                    high: [{ i: 11, level: W + 0.15 }, { i: 19, level: W + 0.1 }, { i: 27, level: W + 0.2 }],
                    low: [{ i: 15, level: 0.05 }, { i: 23, level: 0.0 }, { i: 31, level: 0.1 }]
                });
                var e = extremes(b.candles, 11, 33);
                return { candles: b.candles, zones: [{ x1: 11, x2: 34, p1: e.lo, p2: e.hi }] };
            },
            text: {
                title: 'Mark the Consolidation Range',
                instruction: 'After a push up, price paused in a tight sideways range before breaking out. Drag a box around the consolidation: its start, its end, its top and its bottom.',
                hint: 'The range is where price bounced between the same high and low several times.',
                explanation: 'A consolidation is a pause where buyers and sellers are balanced. Price moved between a clear top and bottom before the breakout, so the box covers that whole stretch.'
            }
        },
        demand: {
            mode: 'box',
            gen: function (base, rnd) {
                var w = [[0, 9], [12, 1.6], [13, 0.6], [15, 0.9], [17, 0.5], [19, 1.0], [20, 1.4], [23, 4.2], [30, 8], [38, 11], [47, 14.5]];
                var b = build(base, w, function (i) { return (i >= 13 && i <= 19) ? 0.22 : 0.5; }, rnd, { close: [], low: [], high: [] });
                var e = extremes(b.candles, 13, 19);
                return { candles: b.candles, zones: [{ x1: 13, x2: 20, p1: e.lo, p2: e.hi }] };
            },
            text: {
                title: 'Mark the Demand Zone',
                instruction: 'Price stalled in a tight base and then rallied hard away from it. Drag a box around the base where buyers were waiting: the demand zone.',
                hint: 'Find the small, tight candles just before the strong move up.',
                explanation: 'A demand zone is a small base where buyers took control, followed by a sharp rally. Price often reacts to that area again when it returns.'
            }
        },
        supply: {
            mode: 'box',
            gen: function (base, rnd) {
                var w = [[0, -9], [12, -1.6], [13, -0.6], [15, -0.9], [17, -0.5], [19, -1.0], [20, -1.4], [23, -4.2], [30, -8], [38, -11], [47, -14.5]];
                var b = build(base, w, function (i) { return (i >= 13 && i <= 19) ? 0.22 : 0.5; }, rnd, { close: [], low: [], high: [] });
                var e = extremes(b.candles, 13, 19);
                return { candles: b.candles, zones: [{ x1: 13, x2: 20, p1: e.lo, p2: e.hi }] };
            },
            text: {
                title: 'Mark the Supply Zone',
                instruction: 'Price stalled in a tight base and then dropped hard away from it. Drag a box around the base where sellers were waiting: the supply zone.',
                hint: 'Find the small, tight candles just before the strong move down.',
                explanation: 'A supply zone is a small base where sellers took control, followed by a sharp drop. Price often reacts to that area again when it returns.'
            }
        },
        uptrend: {
            mode: 'trendline',
            direction: 'up',
            gen: function (base, rnd) {
                var w = [[0, 0], [9, 0.9], [17, 3.6], [24, 3.0], [32, 6.2], [39, 5.6], [47, 9.5]];
                var b = build(base, w, function () { return 0.45; }, rnd, {
                    low: [
                        { i: 9, level: 0.55 + rnd() * 0.15 },
                        { i: 24, level: 3.15 + rnd() * 0.15 }
                    ]
                });
                var lo1 = b.candles[9][2], lo2 = b.candles[24][2];
                return { candles: b.candles, zones: [{ x1: 8, x2: 25, p1: Math.min(lo1, lo2), p2: Math.max(lo1, lo2) }] };
            },
            text: {
                title: 'Draw the Upward Trend',
                instruction: 'Price is making higher highs and higher lows. Draw a line connecting the swing lows: drag from an early pullback low to a later, higher pullback low.',
                hint: 'Find two points where price pulled back and bounced, each one higher than the one before it, then connect them.',
                explanation: 'An uptrend line connects a series of rising swing lows. As long as price stays above this line, the higher-low structure - and the uptrend - is still intact.'
            }
        },
        downtrend: {
            mode: 'trendline',
            direction: 'down',
            gen: function (base, rnd) {
                var w = [[0, 0], [9, -0.9], [17, -3.6], [24, -3.0], [32, -6.2], [39, -5.6], [47, -9.5]];
                var b = build(base, w, function () { return 0.45; }, rnd, {
                    high: [
                        { i: 9, level: -(0.55 + rnd() * 0.15) },
                        { i: 24, level: -(3.15 + rnd() * 0.15) }
                    ]
                });
                var hi1 = b.candles[9][1], hi2 = b.candles[24][1];
                return { candles: b.candles, zones: [{ x1: 8, x2: 25, p1: Math.min(hi1, hi2), p2: Math.max(hi1, hi2) }] };
            },
            text: {
                title: 'Draw the Downward Trend',
                instruction: 'Price is making lower highs and lower lows. Draw a line connecting the swing highs: drag from an early pullback high to a later, lower pullback high.',
                hint: 'Find two points where price rallied and got rejected, each one lower than the one before it, then connect them.',
                explanation: 'A downtrend line connects a series of falling swing highs. As long as price stays below this line, the lower-high structure - and the downtrend - is still intact.'
            }
        }
    };

    function fillIfEmpty(id, value) {
        var el = document.getElementById(id);
        if (el && el.value.trim() === '') { el.value = value; }
    }

    function generate() {
        var pat = PATTERNS[document.getElementById('genPattern').value];
        var base = parseFloat(document.getElementById('genBase').value);
        var dec = parseInt(document.getElementById('genDecimals').value, 10);
        var seed = parseInt(document.getElementById('genSeed').value, 10) || 1;
        if (!pat) { return; }
        if (!isFinite(base) || base <= 0) { renderInfo('Enter a start price above zero, for example 1.0850.', true); return; }
        if (!isFinite(dec)) { dec = 5; }
        dec = clamp(dec, 2, 6);

        var res = pat.gen(base, rng(seed));
        var f = Math.pow(10, dec);
        function r(v) { return Math.round(v * f) / f; }
        var rounded = res.candles.map(function (c) {
            var o = r(c[0]), cl = r(c[3]);
            return [o, Math.max(r(c[1]), o, cl), Math.min(r(c[2]), o, cl), cl];
        });
        ta.value = rounded.map(function (c) { return c.map(function (v) { return v.toFixed(dec); }).join(','); }).join('\n');

        // Suggested answer zone(s); the admin can still move or resize them.
        zones = res.zones.map(function (z) { return { x1: z.x1, x2: z.x2, p1: r(z.p1), p2: r(z.p2) }; });
        active = 0;

        var modeSel = document.getElementById('exMode');
        if (modeSel) { modeSel.value = pat.mode; }
        if (exDirectionEl && pat.direction) { exDirectionEl.value = pat.direction; }
        updateDirectionVisibility();
        fillIfEmpty('exTitle', pat.text.title);
        fillIfEmpty('exInstruction', pat.text.instruction);
        fillIfEmpty('exHint', pat.text.hint);
        fillIfEmpty('exExplanation', pat.text.explanation);

        loadFromText();
        renderInfo('Chart generated with a suggested answer zone. Adjust the zone if you like, then save. Change the Variation number for a different chart.');
    }

    var genBtn = document.getElementById('genBtn');
    if (genBtn) { genBtn.addEventListener('click', generate); }

    // ---------------------------------------------------------------
    // Start-up and events
    // ---------------------------------------------------------------
    var typingTimer = null;
    ta.addEventListener('input', function () {
        clearTimeout(typingTimer);
        typingTimer = setTimeout(loadFromText, 220);
    });

    form.addEventListener('submit', function (ev) {
        var msg = '';
        if (!N) { msg = parseError || 'Paste or generate the candles first.'; }
        else if (!zones.some(zoneOk)) { msg = 'Draw the correct answer zone on the chart before saving.'; }
        else if (zones.some(function (z) { return z && !zoneOk(z); })) { msg = 'One of the zones is too small. Enlarge it or remove it.'; }
        if (msg) {
            ev.preventDefault();
            renderInfo(msg, true);
            stage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    });

    if (window.ResizeObserver) {
        new ResizeObserver(function () { layout(); draw(); }).observe(stage);
    } else {
        window.addEventListener('resize', function () { layout(); draw(); });
    }

    // Load zones saved earlier (edit mode)
    try {
        var saved = JSON.parse(hidden.value || '[]');
        if (Array.isArray(saved) && saved.length) {
            if (currentMode() === 'trendline' && exDirectionEl) {
                // Recover which way the saved line sloped before we sort
                // the points low-price-first for the generic box editor.
                exDirectionEl.value = (+saved[0].p2 >= +saved[0].p1) ? 'up' : 'down';
            }
            zones = saved.slice(0, MAX_ZONES).map(function (z) {
                return { x1: +z.x1, x2: +z.x2, p1: Math.min(+z.p1, +z.p2), p2: Math.max(+z.p1, +z.p2) };
            });
        }
    } catch (e) { zones = [null]; }

    updateDirectionVisibility();
    canvas.style.touchAction = 'none';
    canvas.style.cursor = 'crosshair';
    loadFromText();
})();
