// ALPHA FORGE - dashboard carousel
// Accessible, dependency-free. Autoplay pauses on hover / focus / touch and
// is switched off entirely for people who prefer reduced motion.
(function () {
    'use strict';

    var root = document.getElementById('afCarousel');
    if (!root) { return; }

    var slides = Array.prototype.slice.call(root.querySelectorAll('.af-slide'));
    if (slides.length < 2) { return; }

    var dotsWrap = root.querySelector('.af-car-dots');
    var btnPrev = root.querySelector('.af-car-prev');
    var btnNext = root.querySelector('.af-car-next');
    var btnToggle = root.querySelector('.af-car-toggle');
    var INTERVAL = 6000;

    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var index = 0;
    var timer = null;
    var userPaused = !!reduce;   // start paused for reduced-motion users
    var hoverPaused = false;

    var dots = [];
    if (dotsWrap) {
        slides.forEach(function (_, i) {
            var d = document.createElement('button');
            d.type = 'button';
            d.className = 'af-car-dot';
            d.setAttribute('aria-label', 'Go to slide ' + (i + 1));
            d.addEventListener('click', function () { go(i, true); });
            dotsWrap.appendChild(d);
            dots.push(d);
        });
    }

    function show(i) {
        index = (i + slides.length) % slides.length;
        slides.forEach(function (s, n) {
            var active = n === index;
            s.classList.toggle('is-active', active);
            s.setAttribute('aria-hidden', active ? 'false' : 'true');
        });
        dots.forEach(function (d, n) {
            d.classList.toggle('is-active', n === index);
            if (n === index) { d.setAttribute('aria-current', 'true'); } else { d.removeAttribute('aria-current'); }
        });
    }

    function stop() {
        if (timer) { window.clearInterval(timer); timer = null; }
    }
    function start() {
        stop();
        if (userPaused || hoverPaused) { return; }
        timer = window.setInterval(function () { show(index + 1); }, INTERVAL);
    }
    function go(i, fromUser) {
        show(i);
        if (fromUser) { start(); }   // restart the countdown after a manual change
    }

    function syncToggle() {
        if (!btnToggle) { return; }
        btnToggle.textContent = userPaused ? 'Play' : 'Pause';
        btnToggle.setAttribute('aria-label', userPaused ? 'Start slideshow' : 'Pause slideshow');
    }

    if (btnPrev) { btnPrev.addEventListener('click', function () { go(index - 1, true); }); }
    if (btnNext) { btnNext.addEventListener('click', function () { go(index + 1, true); }); }
    if (btnToggle) {
        btnToggle.addEventListener('click', function () {
            userPaused = !userPaused;
            syncToggle();
            start();
        });
    }

    root.addEventListener('mouseenter', function () { hoverPaused = true; stop(); });
    root.addEventListener('mouseleave', function () { hoverPaused = false; start(); });
    root.addEventListener('focusin', function () { hoverPaused = true; stop(); });
    root.addEventListener('focusout', function () { hoverPaused = false; start(); });

    root.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowLeft') { go(index - 1, true); }
        else if (e.key === 'ArrowRight') { go(index + 1, true); }
    });

    // Swipe on touch screens
    var startX = null, startY = null;
    root.addEventListener('touchstart', function (e) {
        if (!e.touches.length) { return; }
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
        hoverPaused = true; stop();
    }, { passive: true });
    root.addEventListener('touchend', function (e) {
        if (startX !== null && e.changedTouches.length) {
            var dx = e.changedTouches[0].clientX - startX;
            var dy = e.changedTouches[0].clientY - startY;
            if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                show(dx < 0 ? index + 1 : index - 1);
            }
        }
        startX = startY = null;
        hoverPaused = false;
        start();
    }, { passive: true });

    // Don't burn CPU in a background tab
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) { stop(); } else { start(); }
    });

    show(0);
    syncToggle();
    start();
})();
