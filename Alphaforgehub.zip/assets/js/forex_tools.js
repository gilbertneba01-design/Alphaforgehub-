/**
 * ALPHA FORGE HUB - Forex Tools calculators
 * All math runs in the browser except the live FX rate, which comes from
 * our own server-side proxy (api/tools/fx_rate.php) - never a third-party
 * API called directly with a key from client code (there is no key here).
 */
window.AF_TOOLS = (function () {
    const CONTRACT_SIZE = 100000; // standard lot, units of base currency

    function pipSizeFor(pair) {
        pair = (pair || '').toUpperCase();
        return pair.includes('JPY') ? 0.01 : 0.0001;
    }
    function num(id) {
        var el = document.getElementById(id);
        var v = parseFloat(el ? el.value : '');
        return isNaN(v) ? null : v;
    }
    function setText(id, text) {
        var el = document.getElementById(id);
        if (el) el.textContent = text;
    }
    function fmt(n, decimals) {
        if (n === null || n === undefined || isNaN(n)) return '—';
        return Number(n).toLocaleString(undefined, { minimumFractionDigits: decimals || 2, maximumFractionDigits: decimals || 2 });
    }

    function pip() {
        var pair = document.getElementById('pipPair').value;
        var lots = num('pipLots');
        var conv = num('pipConv') || 1;
        if (lots === null) { setText('pipResult', 'Enter a lot size.'); return; }
        var pipSize = pipSizeFor(pair);
        var valueQuote = pipSize * CONTRACT_SIZE * lots;
        var valueAccount = valueQuote * conv;
        setText('pipResult', 'Pip value: ' + fmt(valueQuote) + ' (quote currency) \u2192 ' + fmt(valueAccount) + ' (account currency)');
    }

    function lotSize() {
        var pair = document.getElementById('lotPair').value;
        var balance = num('lotBalance');
        var riskPct = num('lotRiskPct');
        var slPips = num('lotSlPips');
        var conv = num('lotConv') || 1;
        if (balance === null || riskPct === null || slPips === null || slPips <= 0) {
            setText('lotResult', 'Fill in balance, risk % and stop loss (pips).');
            return;
        }
        var riskAmount = balance * (riskPct / 100);
        var pipSize = pipSizeFor(pair);
        var pipValuePerLotQuote = pipSize * CONTRACT_SIZE;
        var pipValuePerLotAccount = pipValuePerLotQuote * conv;
        if (pipValuePerLotAccount <= 0) { setText('lotResult', 'Check the conversion rate.'); return; }
        var lots = riskAmount / (slPips * pipValuePerLotAccount);
        setText('lotResult', 'Risking ' + fmt(riskAmount) + ' \u2192 suggested lot size: ' + fmt(lots, 2) + ' lots');
    }

    function riskFromPct() {
        var balance = num('riskBalance');
        var pct = num('riskPct');
        if (balance === null || pct === null) { setText('riskResult', 'Enter balance and risk %.'); return; }
        var amount = balance * (pct / 100);
        document.getElementById('riskAmount').value = amount.toFixed(2);
        setText('riskResult', pct + '% of ' + fmt(balance) + ' = ' + fmt(amount) + ' at risk');
    }
    function riskFromAmount() {
        var balance = num('riskBalance');
        var amount = num('riskAmount');
        if (balance === null || amount === null || balance <= 0) { setText('riskResult', 'Enter balance and risk amount.'); return; }
        var pct = (amount / balance) * 100;
        document.getElementById('riskPct').value = pct.toFixed(2);
        setText('riskResult', fmt(amount) + ' of ' + fmt(balance) + ' = ' + pct.toFixed(2) + '% at risk');
    }

    function riskReward() {
        var dir = document.getElementById('rrDirection').value;
        var entry = num('rrEntry'), stop = num('rrStop'), target = num('rrTarget');
        if (entry === null || stop === null || target === null) { setText('rrResult', 'Fill in entry, stop and target.'); return; }
        var riskDist = dir === 'buy' ? (entry - stop) : (stop - entry);
        var rewardDist = dir === 'buy' ? (target - entry) : (entry - target);
        if (riskDist <= 0) { setText('rrResult', 'Stop loss is on the wrong side of entry for this direction.'); return; }
        var ratio = rewardDist / riskDist;
        setText('rrResult', 'Risk: ' + fmt(Math.abs(riskDist), 5) + '  |  Reward: ' + fmt(Math.abs(rewardDist), 5) + '  |  Ratio: 1:' + fmt(ratio, 2));
    }

    function profitLoss() {
        var pair = document.getElementById('plPair').value;
        var dir = document.getElementById('plDirection').value;
        var entry = num('plEntry'), exit = num('plExit'), lots = num('plLots'), conv = num('plConv') || 1;
        if (entry === null || exit === null || lots === null) { setText('plResult', 'Fill in entry, exit and lot size.'); return; }
        var pipSize = pipSizeFor(pair);
        var priceDiff = dir === 'buy' ? (exit - entry) : (entry - exit);
        var pips = priceDiff / pipSize;
        var pipValuePerLotQuote = pipSize * CONTRACT_SIZE;
        var result = pips * pipValuePerLotQuote * lots * conv;
        var word = result >= 0 ? 'Profit' : 'Loss';
        setText('plResult', word + ': ' + fmt(Math.abs(result)) + '  (' + fmt(pips, 1) + ' pips)');
    }

    function margin() {
        var lots = num('marLots'), price = num('marPrice'), leverage = num('marLeverage'), conv = num('marConv') || 1;
        if (lots === null || price === null || !leverage) { setText('marResult', 'Fill in lot size, price and leverage.'); return; }
        var marginBase = (lots * CONTRACT_SIZE * price) / leverage;
        var marginAccount = marginBase * conv;
        setText('marResult', 'Estimated required margin: ' + fmt(marginAccount));
    }

    function convert() {
        var amount = num('fxAmount'), rate = num('fxRate');
        if (amount === null || rate === null) { setText('fxResult', 'Enter an amount and a rate (or fetch a live rate).'); return; }
        setText('fxResult', 'Converted amount: ' + fmt(amount * rate));
    }
    function fetchRate() {
        var from = (document.getElementById('fxFrom').value || '').toUpperCase();
        var to = (document.getElementById('fxTo').value || '').toUpperCase();
        setText('fxResult', 'Fetching live rate\u2026');
        fetch(window.AF_TOOLS_API + '?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to))
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (!res.ok) { setText('fxResult', res.error || 'Could not fetch a live rate. Enter one manually.'); return; }
                document.getElementById('fxRate').value = res.rate;
                setText('fxResult', 'Live rate loaded: 1 ' + from + ' = ' + res.rate + ' ' + to);
            })
            .catch(function () { setText('fxResult', 'Network error fetching the rate. Enter one manually.'); });
    }

    function swap() {
        var rate = num('swapRate'), lots = num('swapLots'), nights = num('swapNights');
        if (rate === null || lots === null || nights === null) { setText('swapResult', 'Fill in the swap rate, lot size and nights.'); return; }
        var total = rate * lots * nights;
        var word = total >= 0 ? 'Credit' : 'Cost';
        setText('swapResult', 'Total swap ' + word + ': ' + fmt(Math.abs(total)));
    }

    function pivot() {
        var high = num('pivHigh'), low = num('pivLow'), close = num('pivClose');
        if (high === null || low === null || close === null) { setText('pivResult', 'Enter the prior period High, Low and Close.'); return; }
        var pp = (high + low + close) / 3;
        var r1 = (2 * pp) - low, s1 = (2 * pp) - high;
        var r2 = pp + (high - low), s2 = pp - (high - low);
        var r3 = high + 2 * (pp - low), s3 = low - 2 * (high - pp);
        setText('pivResult',
            'Pivot: ' + fmt(pp, 5) +
            ' | R1: ' + fmt(r1, 5) + '  R2: ' + fmt(r2, 5) + '  R3: ' + fmt(r3, 5) +
            ' | S1: ' + fmt(s1, 5) + '  S2: ' + fmt(s2, 5) + '  S3: ' + fmt(s3, 5));
    }

    function gainLoss() {
        var startBal = num('glStart'), endBal = num('glEnd');
        if (startBal === null || endBal === null || startBal <= 0) { setText('glResult', 'Enter a starting balance greater than 0 and an ending balance.'); return; }
        var changeAmount = endBal - startBal;
        var changePct = (changeAmount / startBal) * 100;
        var recoveryPct = changeAmount < 0 ? (Math.abs(changeAmount) / endBal) * 100 : null;
        var text = (changeAmount >= 0 ? 'Gain' : 'Loss') + ': ' + fmt(Math.abs(changeAmount)) + ' (' + fmt(changePct, 2) + '%)';
        if (recoveryPct !== null && isFinite(recoveryPct)) {
            text += ' — needs a ' + fmt(recoveryPct, 2) + '% gain from here to recover.';
        }
        setText('glResult', text);
    }

    function resetCard(prefix) {
        document.querySelectorAll('[id^="' + prefix + '"]').forEach(function (el) {
            if (el.tagName === 'INPUT') el.value = el.defaultValue;
            if (el.tagName === 'SELECT') el.selectedIndex = 0;
        });
        var resultEl = document.getElementById(prefix + 'Result');
        if (resultEl) resultEl.textContent = 'Result: —';
    }

    return {
        pip: pip, lotSize: lotSize, riskFromPct: riskFromPct, riskFromAmount: riskFromAmount,
        riskReward: riskReward, profitLoss: profitLoss, margin: margin,
        convert: convert, fetchRate: fetchRate, swap: swap,
        pivot: pivot, gainLoss: gainLoss, resetCard: resetCard
    };
})();
