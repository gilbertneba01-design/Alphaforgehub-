/**
 * ALPHA FORGE HUB - PWA registration + optional install banner.
 * Never forces installation; the visitor can dismiss it.
 */
(function () {
    if ('serviceWorker' in navigator) {
        var base = (window.AF_APP_URL || '') + '/';
        window.addEventListener('load', function () {
            navigator.serviceWorker.register(base + 'service-worker.js', { scope: base }).catch(function () { /* silent: non-critical */ });
        });
    }

    var deferredPrompt = null;
    window.addEventListener('beforeinstallprompt', function (e) {
        e.preventDefault();
        deferredPrompt = e;
        if (localStorage.getItem('af_install_dismissed') === '1') return;
        showBanner();
    });

    function showBanner() {
        if (document.getElementById('afInstallBanner')) return;
        var bar = document.createElement('div');
        bar.id = 'afInstallBanner';
        bar.style.cssText = 'position:fixed; bottom:0; left:0; right:0; background:#0D2037; color:#EEF4FB; padding:14px 16px; display:flex; justify-content:space-between; align-items:center; gap:12px; z-index:9999; border-top:1px solid #193653; font-family:Inter,sans-serif;';
        bar.innerHTML = '<span>Install Alpha Forge for quick, full-screen access.</span>' +
            '<span style="display:flex; gap:8px;">' +
            '<button id="afInstallBtn" style="background:#D8AE45; color:#071426; border:none; padding:8px 14px; border-radius:6px; font-weight:700; cursor:pointer;">Install</button>' +
            '<button id="afInstallDismiss" style="background:transparent; color:#9DB0C4; border:1px solid #193653; padding:8px 14px; border-radius:6px; cursor:pointer;">Not now</button>' +
            '</span>';
        document.body.appendChild(bar);

        document.getElementById('afInstallBtn').addEventListener('click', function () {
            bar.remove();
            if (deferredPrompt) { deferredPrompt.prompt(); deferredPrompt = null; }
        });
        document.getElementById('afInstallDismiss').addEventListener('click', function () {
            bar.remove();
            localStorage.setItem('af_install_dismissed', '1');
        });
    }
})();

/* ---- Install App button (works before or after registering; never blocks Join) ---- */
(function () {
    var deferred = null;
    var standalone = window.matchMedia && window.matchMedia('(display-mode: standalone)').matches;
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; });
    window.addEventListener('appinstalled', function () { deferred = null; });
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-af-install]').forEach(function (b) {
            b.hidden = false;
            if (standalone) { b.hidden = true; }
        });
    });
    document.addEventListener('click', function (ev) {
        var btn = ev.target.closest('[data-af-install]');
        if (!btn) return;
        ev.preventDefault();
        var t = window.AF_I18N || {};
        if (deferred) {
            deferred.prompt();
            deferred.userChoice.finally(function () { deferred = null; });
        } else if (/iphone|ipad|ipod/i.test(navigator.userAgent)) {
            window.alert(t.install_ios || 'Tap Share, then Add to Home Screen.');
        } else {
            window.alert(t.install_generic || 'Use your browser menu to install this app.');
        }
    });
})();
