/**
 * ALPHA FORGE HUB - Trading Simulator front end.
 * Prices come from the server (simulator_api.php action=price / state),
 * which reads sim_prices (see cron/sim_price_tick.php). This file never
 * sends a price to the server for opening or closing a trade, and never
 * makes up its own; it only polls for the current one and displays it.
 */
(function () {
    if (!window.AF_SIM) return;

    var price = null;
    var pair = 'EURUSD';
    var openTrades = [];
    var account = { balance: 0, equity: 0 };

    function pipSize(p) { return p.indexOf('JPY') !== -1 ? 0.01 : 0.0001; }
    function decimals(p) { return p.indexOf('JPY') !== -1 ? 3 : 5; }
    function money(n) { return '$' + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

    function api(action, extra) {
        var body = new URLSearchParams(Object.assign({ action: action, csrf_token: window.AF_SIM.csrf }, extra || {}));
        return fetch(window.AF_SIM.apiUrl, { method: 'POST', body: body }).then(function (r) { return r.json(); });
    }

    function showMsg(text, ok) {
        var el = document.getElementById('simMsg');
        el.hidden = false;
        el.className = 'af-lab-result ' + (ok ? 'is-correct' : 'is-wrong');
        el.textContent = text;
    }

    function refreshPrice() {
        api('price', { pair: pair }).then(function (res) {
            if (!res.ok) { showMsg(res.error || 'Could not load the market price. Try again.', false); return; }
            price = res.price;
            document.getElementById('simPrice').textContent = price.toFixed(res.decimals || decimals(pair));
        });
    }

    function refreshState() {
        api('state').then(function (res) {
            if (!res.ok) return;
            account = res.account;
            openTrades = (res.trades || []).filter(function (t) { return t.status === 'open'; });
            var closed = (res.trades || []).filter(function (t) { return t.status === 'closed'; });
            document.getElementById('simBalance').textContent = money(account.balance);
            renderOpen(res.prices || {});
            renderClosed(closed);
        });
    }

    function renderOpen(prices) {
        var totalFloat = 0;
        var rows = '';
        openTrades.forEach(function (t) {
            var p = (prices[t.pair] !== undefined) ? prices[t.pair] : parseFloat(t.entry_price);
            var diff = t.direction === 'buy' ? (p - t.entry_price) : (t.entry_price - p);
            var pips = diff / pipSize(t.pair);
            var pnl = pips * 10 * parseFloat(t.lot_size);
            totalFloat += pnl;
            rows += '<tr data-id="' + t.id + '">' +
                '<td>' + t.pair + '</td><td>' + t.direction.toUpperCase() + '</td><td>' + t.lot_size + '</td>' +
                '<td>' + parseFloat(t.entry_price).toFixed(decimals(t.pair)) + '</td>' +
                '<td>' + (t.stop_loss || '-') + ' / ' + (t.take_profit || '-') + '</td>' +
                '<td style="color:' + (pnl >= 0 ? '#2ecc71' : '#e74c3c') + ';">' + money(pnl) + '</td>' +
                '<td><button class="af-btn af-btn-ghost af-btn-sm" data-close-id="' + t.id + '">Close</button></td></tr>';
        });
        document.querySelector('#simOpenTable tbody').innerHTML = rows || '<tr><td colspan="7" class="af-muted">No open positions.</td></tr>';
        document.getElementById('simFloating').textContent = money(totalFloat);
        document.getElementById('simEquity').textContent = money((account.balance || 0) + totalFloat);
    }

    function renderClosed(closed) {
        var rows = '';
        closed.slice(0, 20).forEach(function (t) {
            rows += '<tr><td>' + t.pair + '</td><td>' + t.direction.toUpperCase() + '</td><td>' + t.lot_size + '</td>' +
                '<td>' + parseFloat(t.entry_price).toFixed(decimals(t.pair)) + '</td>' +
                '<td>' + (t.exit_price ? parseFloat(t.exit_price).toFixed(decimals(t.pair)) : '-') + '</td>' +
                '<td style="color:' + (t.pnl >= 0 ? '#2ecc71' : '#e74c3c') + ';">' + money(t.pnl) + '</td>' +
                '<td>' + (t.closed_at || '-') + '</td></tr>';
        });
        document.querySelector('#simClosedTable tbody').innerHTML = rows || '<tr><td colspan="7" class="af-muted">No closed positions yet.</td></tr>';
    }

    // Delegated (inline onclick is blocked by the CSP)
    document.addEventListener('click', function (ev) {
        var b = ev.target.closest('[data-close-id]');
        if (b) { window.AF_SIM_CLOSE(parseInt(b.getAttribute('data-close-id'), 10)); }
    });

    window.AF_SIM_CLOSE = function (tradeId) {
        // No price sent: the server looks up its own current price for this trade's pair.
        api('close', { trade_id: tradeId }).then(function (res) {
            showMsg(res.message || res.error, !!res.ok);
            refreshState();
        });
    };

    document.getElementById('simPair').addEventListener('change', function (e) {
        pair = e.target.value;
        refreshPrice();
    });

    document.getElementById('simBuy').addEventListener('click', function () { openTrade('buy'); });
    document.getElementById('simSell').addEventListener('click', function () { openTrade('sell'); });

    function openTrade(direction) {
        var lots = parseFloat(document.getElementById('simLots').value);
        var sl = document.getElementById('simSL').value;
        var tp = document.getElementById('simTP').value;
        if (!lots || lots <= 0) { showMsg('Enter a valid lot size.', false); return; }
        // No price sent: the server decides the entry price for this pair.
        api('open', { pair: pair, direction: direction, lot_size: lots, stop_loss: sl, take_profit: tp })
            .then(function (res) { showMsg(res.message || res.error, !!res.ok); refreshState(); });
    }

    document.getElementById('simReset').addEventListener('click', function () {
        if (!confirm('Reset your simulator account back to $10,000 and clear all positions?')) return;
        api('reset').then(function (res) { showMsg(res.message || res.error, !!res.ok); refreshState(); });
    });

    refreshPrice();
    refreshState();
    setInterval(refreshPrice, 3000);
    setInterval(refreshState, 5000);
})();
