/** ALPHA FORGE HUB - Backtesting Lab front end */
(function () {
    if (!window.AF_BT) return;

    var candles = [];
    var openTrade = null; // { id, direction, entry_price }
    var lastPrice = 0;

    function api(action, extra) {
        var body = new URLSearchParams(Object.assign({ action: action, csrf_token: window.AF_BT.csrf }, extra || {}));
        return fetch(window.AF_BT.apiUrl, { method: 'POST', body: body }).then(function (r) { return r.json(); });
    }

    function showMsg(text, ok) {
        var el = document.getElementById('btMsg');
        el.hidden = false;
        el.className = 'af-lab-result ' + (ok ? 'is-correct' : 'is-wrong');
        el.textContent = text;
    }

    function renderCandles() {
        var min = Math.min.apply(null, candles.map(function (c) { return c.l; }));
        var max = Math.max.apply(null, candles.map(function (c) { return c.h; }));
        var range = (max - min) || 0.0001;
        var html = '';
        candles.forEach(function (c) {
            var up = c.c >= c.o;
            var topPct = ((max - Math.max(c.o, c.c)) / range) * 100;
            var bodyPct = (Math.abs(c.c - c.o) / range) * 100;
            var wickTopPct = ((max - c.h) / range) * 100;
            var wickHeightPct = ((c.h - c.l) / range) * 100;
            html += '<div style="position:relative; width:6px; height:100%; flex:none;">' +
                '<div style="position:absolute; left:2px; width:2px; top:' + wickTopPct + '%; height:' + wickHeightPct + '%; background:rgba(255,255,255,0.4);"></div>' +
                '<div style="position:absolute; left:0; width:6px; top:' + topPct + '%; height:' + Math.max(bodyPct, 1) + '%; background:' + (up ? '#2ecc71' : '#e74c3c') + ';"></div>' +
                '</div>';
        });
        var strip = document.getElementById('btCandleStrip');
        strip.innerHTML = html;
        strip.scrollLeft = strip.scrollWidth;
        lastPrice = candles[candles.length - 1].c;
        document.getElementById('btLastClose').textContent = lastPrice.toFixed(5);
    }

    document.getElementById('btStart').addEventListener('click', function () {
        api('start', { pair: document.getElementById('btPair').value, timeframe: document.getElementById('btTf').value, strategy_notes: document.getElementById('btNotes').value })
            .then(function (res) {
                if (!res.ok) { alert(res.error || 'Could not start session.'); return; }
                candles = res.visible;
                document.getElementById('btSetup').hidden = true;
                document.getElementById('btBoard').hidden = false;
                document.getElementById('btResults').hidden = true;
                renderCandles();
            });
    });

    document.getElementById('btNext').addEventListener('click', function () {
        api('next_candle').then(function (res) {
            if (!res.ok) { showMsg(res.error, false); return; }
            candles.push(res.candle);
            if (candles.length > 60) candles.shift();
            renderCandles();
        });
    });

    function armTrade(direction) {
        if (openTrade) { showMsg('Close your open trade before opening another.', false); return; }
        api('open_trade', { direction: direction, entry_price: lastPrice }).then(function (res) {
            if (!res.ok) { showMsg(res.error, false); return; }
            openTrade = { id: res.trade_id, direction: direction, entry_price: lastPrice };
            document.getElementById('btCloseTrade').disabled = false;
            showMsg((direction === 'buy' ? 'Bought' : 'Sold') + ' at ' + lastPrice.toFixed(5) + '. Reveal more candles, then close when ready.', true);
        });
    }
    document.getElementById('btBuy').addEventListener('click', function () { armTrade('buy'); });
    document.getElementById('btSell').addEventListener('click', function () { armTrade('sell'); });

    document.getElementById('btCloseTrade').addEventListener('click', function () {
        if (!openTrade) return;
        api('close_trade', { trade_id: openTrade.id, exit_price: lastPrice }).then(function (res) {
            if (!res.ok) { showMsg(res.error, false); return; }
            showMsg('Trade closed: ' + res.result.toUpperCase() + ' (' + res.r + 'R)', res.result === 'win');
            openTrade = null;
            document.getElementById('btCloseTrade').disabled = true;
        });
    });

    document.getElementById('btFinish').addEventListener('click', function () {
        api('finish').then(function (res) {
            if (!res.ok) { showMsg(res.error, false); return; }
            var box = document.getElementById('btResults');
            box.hidden = false;
            box.innerHTML = '<h2>Session Results</h2>' +
                '<p>Trades: ' + res.total_trades + ' &middot; Wins: ' + res.wins + ' &middot; Losses: ' + res.losses + '</p>' +
                '<p>Win rate: ' + res.win_rate + '% &middot; Total: ' + res.total_r + 'R</p>' +
                '<button class="af-btn af-btn-gold" data-af-reload>Start New Session</button>';
            document.getElementById('btBoard').hidden = true;
        });
    });
})();
