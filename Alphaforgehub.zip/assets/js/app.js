// ALPHA FORGE — front-end interactions (progressive enhancement only;
// nothing here is trusted for security/premium decisions — that is
// always enforced server-side in PHP).

document.addEventListener('DOMContentLoaded', function () {
    // ---- CSP-safe replacements for inline on*="" handlers ----
    document.addEventListener('click', function (ev) {
        var conf = ev.target.closest('[data-confirm-click]');
        if (conf && !window.confirm(conf.getAttribute('data-confirm-click'))) {
            ev.preventDefault();
            return;
        }
        if (ev.target.closest('[data-af-print]')) { ev.preventDefault(); window.print(); return; }
        var call = ev.target.closest('[data-af-call]');
        if (call && window.AF_TOOLS && typeof window.AF_TOOLS[call.getAttribute('data-af-call')] === 'function') {
            ev.preventDefault();
            var arg = call.getAttribute('data-af-arg');
            window.AF_TOOLS[call.getAttribute('data-af-call')](arg === null ? undefined : arg);
        }
        var reload = ev.target.closest('[data-af-reload]');
        if (reload) { ev.preventDefault(); window.location.reload(); }
    });

    var toggle = document.getElementById('afMenuToggle');
    var nav = document.getElementById('afNav');
    if (toggle && nav) {
        toggle.addEventListener('click', function () {
            nav.classList.toggle('open');
        });
    }

    // Quiz UI: highlight selected option, enable submit only once an option is chosen
    document.querySelectorAll('[data-quiz-question]').forEach(function (q) {
        var inputs = q.querySelectorAll('input[type="radio"]');
        inputs.forEach(function (input) {
            input.addEventListener('change', function () {
                q.querySelectorAll('.af-quiz-option').forEach(function (opt) { opt.classList.remove('selected'); });
                input.closest('.af-quiz-option').classList.add('selected');
            });
        });
    });

    // Filter dropdowns: <select data-autosubmit> submits its form when changed.
    // (Inline onchange="" is blocked by the site's Content-Security-Policy.)
    document.querySelectorAll('select[data-autosubmit]').forEach(function (sel) {
        sel.addEventListener('change', function () {
            if (sel.form) { sel.form.submit(); }
        });
    });

    // Delete / cancel buttons: <form data-confirm="Are you sure?"> asks first.
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (ev) {
            if (!window.confirm(form.getAttribute('data-confirm'))) {
                ev.preventDefault();
            }
        });
    });

    // Payment method toggle on the subscribe page
    var providerInputs = document.querySelectorAll('input[name="provider"]');
    var phoneField = document.getElementById('afPhoneField');
    providerInputs.forEach(function (input) {
        input.addEventListener('change', function () {
            if (phoneField) {
                phoneField.style.display = 'block';
            }
        });
    });
});
