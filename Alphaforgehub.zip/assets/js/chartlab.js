// ALPHA FORGE - Chart Lab (front end)
//
// This file only draws the chart and lets the student mark a zone. It never
// decides whether the zone is right: every verdict comes from the server
// (chart_lab_api.php), which is the only place the answer zone lives.
(function () {
    'use strict';

    var root = document.getElementById('chartLab');
    if (!root) { return; }

    var ex;
    try {
        ex = JSON.parse(root.getAttribute('data-exercise'));
    } catch (err) {
        return;
    }
    var candles = ex.candles || [];
    var N = candles.length;
    if (!N) { return; }

    // ---------- Elements ----------
    var stage     = document.getElementById('labStage');
    var canvas    = document.getElementById('labCanvas');
    var btnSubmit = document.getElementById('labSubmit');
    var btnClear  = document.getElementById('labClear');
    var btnHint   = document.getElementById('labHint');
    var btnReveal = document.getElementById('labReveal');
    var linkNext  = document.getElementById('labNext');
    var helpEl    = document.getElementById('labHelp');
    var hintBox   = document.getElementById('labHintBox');
    var resultBox = document.getElementById('labResult');
    var explainBox = document.getElementById('labExplain');
    if (!stage || !canvas || !btnSubmit || !btnClear) { return; }
    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }

    var API      = root.getAttribute('data-api');
    var LAB_URL  = root.getAttribute('data-lab-url');
    var CSRF     = root.getAttribute('data-csrf');

    // ---------- Constants ----------
    var MIN_W = 2;            // candles
    var MIN_H = 0.02;         // fraction of the visible price range
    var COLORS = {
        up: '#3CBF83', down: '#E2604F', gold: '#D8AE45', goldSoft: '#F0D998',
        grid: 'rgba(157,176,196,0.13)', axis: '#9DB0C4', text: '#EEF4FB',
        green: '#3CBF83', amber: '#E8A93B', red: '#E2604F'
    };

    // ---------- State ----------
    var pmin = ex.view.min, pmax = ex.view.max;
    var isLine = ex.mode === 'trendline';
    var zone = null;          // { x1, x2, p1, p2 } in chart units (x = candle index, p = price)
    var zoneTone = 'idle';    // idle | close | wrong | right
    var answers = [];         // official zones, only after the server reveals them
    var locked = false;       // true once solved
    var busy = false;
    var drag = null;
    var hover = null;
    var hintShown = false;
    var attempts = ex.attempts || 0;

    // Layout (CSS pixels)
    var cssW = 0, cssH = 0, PL = 10, PR = 64, PT = 12, PB = 14, pw = 0, ph = 0;

    // ---------- Coordinate helpers ----------
    function xToPx(u) { return PL + (u / N) * pw; }
    function pxToX(px) { return ((px - PL) / pw) * N; }
    function pToPy(p) { return PT + ((pmax - p) / (pmax - pmin)) * ph; }
    function pyToP(py) { return pmax - ((py - PT) / ph) * (pmax - pmin); }
    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
    function clampX(u) { return clamp(u, 0, N); }
    function clampP(p) { return clamp(p, pmin, pmax); }
    function fmtPrice(p) { return p.toFixed(ex.decimals); }

    function normalise(z) {
        if (isLine) {
            // A line has a direction: swap the WHOLE point (x and p
            // together), never sort price alone, or the slope is lost.
            if (z.x1 <= z.x2) { return { x1: z.x1, x2: z.x2, p1: z.p1, p2: z.p2 }; }
            return { x1: z.x2, x2: z.x1, p1: z.p2, p2: z.p1 };
        }
        return {
            x1: Math.min(z.x1, z.x2), x2: Math.max(z.x1, z.x2),
            p1: Math.min(z.p1, z.p2), p2: Math.max(z.p1, z.p2)
        };
    }
    function copyZone(z) { return { x1: z.x1, x2: z.x2, p1: z.p1, p2: z.p2 }; }
    function isValid() {
        if (!zone) { return false; }
        if (isLine) {
            return (zone.x2 - zone.x1) >= MIN_W && Math.abs(zone.p2 - zone.p1) >= (pmax - pmin) * MIN_H;
        }
        return (zone.x2 - zone.x1) >= MIN_W && (zone.p2 - zone.p1) >= (pmax - pmin) * MIN_H;
    }
    function rectOf(z) {
        return { x1: xToPx(z.x1), x2: xToPx(z.x2), y1: pToPy(z.p2), y2: pToPy(z.p1) };
    }
    // For trendline mode: the two literal pixel endpoints of the line,
    // in the same order as the chart-space points (not sorted by price).
    function lineOf(z) {
        return { x1: xToPx(z.x1), y1: pToPy(z.p1), x2: xToPx(z.x2), y2: pToPy(z.p2) };
    }
    function distToSegment(px, py, x1, y1, x2, y2) {
        var dx = x2 - x1, dy = y2 - y1;
        var len2 = dx * dx + dy * dy;
        var t = len2 > 0 ? ((px - x1) * dx + (py - y1) * dy) / len2 : 0;
        t = clamp(t, 0, 1);
        var cx = x1 + t * dx, cy = y1 + t * dy;
        return Math.hypot(px - cx, py - cy);
    }

    // ---------- Layout ----------
    function layout() {
        var w = Math.max(280, Math.floor(stage.clientWidth));
        var h = w < 520 ? Math.round(w * 0.95) : Math.round(clamp(w * 0.52, 340, 500));
        var dpr = window.devicePixelRatio || 1;
        cssW = w; cssH = h;
        PR = w < 520 ? 54 : 66;
        pw = w - PL - PR;
        ph = h - PT - PB;
        canvas.style.height = h + 'px';
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    // ---------- Drawing ----------
    function niceStep(range, target) {
        var raw = range / target;
        var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
        var n = raw / mag;
        var s = n < 1.5 ? 1 : (n < 3 ? 2 : (n < 7 ? 5 : 10));
        return s * mag;
    }

    function drawZoneRect(r, fill, stroke, dashed, lineWidth) {
        var x = Math.min(r.x1, r.x2), y = Math.min(r.y1, r.y2);
        var w = Math.abs(r.x2 - r.x1), h = Math.abs(r.y2 - r.y1);
        ctx.fillStyle = fill;
        ctx.fillRect(x, y, w, h);
        ctx.strokeStyle = stroke;
        ctx.lineWidth = lineWidth || 2;
        ctx.setLineDash(dashed ? [7, 5] : []);
        ctx.strokeRect(x + 0.5, y + 0.5, w, h);
        ctx.setLineDash([]);
    }

    function drawLine(l, stroke, dashed, lineWidth) {
        ctx.strokeStyle = stroke;
        ctx.lineWidth = lineWidth || 3;
        ctx.setLineDash(dashed ? [7, 5] : []);
        ctx.beginPath();
        ctx.moveTo(l.x1, l.y1);
        ctx.lineTo(l.x2, l.y2);
        ctx.stroke();
        ctx.setLineDash([]);
    }

    function drawHandle(x, y, size, color) {
        ctx.fillStyle = color;
        ctx.strokeStyle = '#071426';
        ctx.lineWidth = 1.5;
        ctx.fillRect(x - size / 2, y - size / 2, size, size);
        ctx.strokeRect(x - size / 2, y - size / 2, size, size);
    }

    function toneColor() {
        if (zoneTone === 'right') { return COLORS.green; }
        if (zoneTone === 'close') { return COLORS.amber; }
        if (zoneTone === 'wrong') { return COLORS.red; }
        return COLORS.gold;
    }
    function toneFill() {
        if (zoneTone === 'right') { return 'rgba(60,191,131,0.20)'; }
        if (zoneTone === 'close') { return 'rgba(232,169,59,0.20)'; }
        if (zoneTone === 'wrong') { return 'rgba(226,96,79,0.18)'; }
        return 'rgba(216,174,69,0.20)';
    }

    function draw() {
        if (!cssW) { return; }
        var i, y, x;

        // Background
        var bg = ctx.createLinearGradient(0, 0, 0, cssH);
        bg.addColorStop(0, '#0E2440');
        bg.addColorStop(1, '#0A1A2F');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, cssW, cssH);

        // Price grid + axis labels
        var step = niceStep(pmax - pmin, 6);
        var first = Math.ceil(pmin / step) * step;
        ctx.font = '11px Inter, system-ui, sans-serif';
        ctx.textBaseline = 'middle';
        ctx.textAlign = 'left';
        for (var p = first; p <= pmax; p += step) {
            y = Math.round(pToPy(p)) + 0.5;
            ctx.strokeStyle = COLORS.grid;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(PL, y);
            ctx.lineTo(PL + pw, y);
            ctx.stroke();
            ctx.fillStyle = COLORS.axis;
            ctx.fillText(fmtPrice(p), PL + pw + 8, y);
        }
        // Light vertical grid
        var slot = pw / N;
        for (i = 6; i < N; i += 6) {
            x = Math.round(PL + i * slot) + 0.5;
            ctx.strokeStyle = 'rgba(157,176,196,0.07)';
            ctx.beginPath();
            ctx.moveTo(x, PT);
            ctx.lineTo(x, PT + ph);
            ctx.stroke();
        }

        // Clip everything inside the plot area
        ctx.save();
        ctx.beginPath();
        ctx.rect(PL, PT, pw, ph);
        ctx.clip();

        // Candles
        var bodyW = Math.max(2, slot * 0.62);
        for (i = 0; i < N; i++) {
            var c = candles[i];
            var xc = PL + (i + 0.5) * slot;
            var isUp = c[3] >= c[0];
            ctx.strokeStyle = isUp ? COLORS.up : COLORS.down;
            ctx.fillStyle = isUp ? COLORS.up : COLORS.down;
            ctx.lineWidth = 1.4;
            ctx.beginPath();
            ctx.moveTo(xc, pToPy(c[1]));
            ctx.lineTo(xc, pToPy(c[2]));
            ctx.stroke();
            var yo = pToPy(c[0]), yc = pToPy(c[3]);
            ctx.fillRect(xc - bodyW / 2, Math.min(yo, yc), bodyW, Math.max(1.5, Math.abs(yo - yc)));
        }

        // Official answer zone(s), only after the server has revealed them
        for (i = 0; i < answers.length; i++) {
            if (isLine) {
                drawLine(lineOf(answers[i]), COLORS.green, true, 3);
            } else {
                var ar = rectOf(answers[i]);
                drawZoneRect(ar, 'rgba(60,191,131,0.16)', COLORS.green, true, 2);
            }
        }

        // Student's zone
        if (zone) {
            if (isLine) {
                drawLine(lineOf(zone), toneColor(), false, 3);
            } else {
                drawZoneRect(rectOf(zone), toneFill(), toneColor(), false, 2);
            }
        }

        // Crosshair (mouse only)
        if (hover && !locked) {
            ctx.strokeStyle = 'rgba(238,244,251,0.28)';
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 4]);
            ctx.beginPath();
            ctx.moveTo(PL, Math.round(hover.y) + 0.5);
            ctx.lineTo(PL + pw, Math.round(hover.y) + 0.5);
            ctx.moveTo(Math.round(hover.x) + 0.5, PT);
            ctx.lineTo(Math.round(hover.x) + 0.5, PT + ph);
            ctx.stroke();
            ctx.setLineDash([]);
        }
        ctx.restore();

        // Labels for answer zones
        ctx.font = '600 11px Inter, system-ui, sans-serif';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'alphabetic';
        for (i = 0; i < answers.length; i++) {
            if (isLine) {
                var ll = lineOf(answers[i]);
                var llx = Math.max(PL + 4, Math.min(ll.x1, ll.x2) + 4);
                var lly = Math.max(PT + 12, Math.min(ll.y1, ll.y2) - 5);
                ctx.fillStyle = COLORS.green;
                ctx.fillText('Answer line', llx, lly);
            } else {
                var lr = rectOf(answers[i]);
                var lx = Math.max(PL + 4, Math.min(lr.x1, lr.x2) + 4);
                var ly = Math.max(PT + 12, Math.min(lr.y1, lr.y2) - 5);
                ctx.fillStyle = COLORS.green;
                ctx.fillText('Answer zone', lx, ly);
            }
        }

        // Handles for the student's zone
        if (zone && !locked && isLine) {
            var rl = lineOf(zone);
            drawHandle(rl.x1, rl.y1, 10, COLORS.gold);
            drawHandle(rl.x2, rl.y2, 10, COLORS.gold);
            ctx.font = '600 11px Inter, system-ui, sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            var lEdges = [[zone.p1, rl.y1], [zone.p2, rl.y2]];
            for (var m = 0; m < lEdges.length; m++) {
                var lLabel = fmtPrice(lEdges[m][0]);
                var lLw = ctx.measureText(lLabel).width + 10;
                var lEy = clamp(lEdges[m][1], PT + 8, PT + ph - 8);
                ctx.fillStyle = toneColor();
                ctx.fillRect(PL + pw + 2, lEy - 9, lLw, 18);
                ctx.fillStyle = '#17110a';
                ctx.fillText(lLabel, PL + pw + 7, lEy);
            }
        } else if (zone && !locked) {
            var r = rectOf(zone);
            var mx = (r.x1 + r.x2) / 2, my = (r.y1 + r.y2) / 2;
            drawHandle(r.x1, r.y1, 9, COLORS.gold);
            drawHandle(r.x2, r.y1, 9, COLORS.gold);
            drawHandle(r.x1, r.y2, 9, COLORS.gold);
            drawHandle(r.x2, r.y2, 9, COLORS.gold);
            if (Math.abs(r.x2 - r.x1) > 46) {
                drawHandle(mx, r.y1, 7, COLORS.goldSoft);
                drawHandle(mx, r.y2, 7, COLORS.goldSoft);
            }
            if (Math.abs(r.y2 - r.y1) > 46) {
                drawHandle(r.x1, my, 7, COLORS.goldSoft);
                drawHandle(r.x2, my, 7, COLORS.goldSoft);
            }
            // Price labels for the zone edges
            ctx.font = '600 11px Inter, system-ui, sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            var edges = [[zone.p2, r.y1], [zone.p1, r.y2]];
            for (var k = 0; k < edges.length; k++) {
                var label = fmtPrice(edges[k][0]);
                var lw = ctx.measureText(label).width + 10;
                var ey = clamp(edges[k][1], PT + 8, PT + ph - 8);
                ctx.fillStyle = toneColor();
                ctx.fillRect(PL + pw + 2, ey - 9, lw, 18);
                ctx.fillStyle = '#17110a';
                ctx.fillText(label, PL + pw + 7, ey);
            }
        }

        // Crosshair price tag
        if (hover && !locked && !drag) {
            var tag = fmtPrice(pyToP(hover.y));
            ctx.font = '600 11px Inter, system-ui, sans-serif';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            var tw = ctx.measureText(tag).width + 10;
            var ty = clamp(hover.y, PT + 8, PT + ph - 8);
            ctx.fillStyle = 'rgba(238,244,251,0.92)';
            ctx.fillRect(PL + pw + 2, ty - 9, tw, 18);
            ctx.fillStyle = '#071426';
            ctx.fillText(tag, PL + pw + 7, ty);
        }

        // Empty-state prompt
        if (!zone && !drag && !locked && !answers.length) {
            var msg = isLine ? 'Drag to draw the trend line' : 'Drag on the chart to draw a zone';
            ctx.font = '600 13px Inter, system-ui, sans-serif';
            if (ctx.measureText(msg).width + 28 > pw - 12) {
                msg = 'Drag to draw a zone';
                ctx.font = '600 12px Inter, system-ui, sans-serif';
            }
            var mw = ctx.measureText(msg).width + 28;
            var mxp = PL + pw / 2 - mw / 2, myp = PT + 14;
            ctx.fillStyle = 'rgba(7,20,38,0.78)';
            ctx.fillRect(mxp, myp, mw, 30);
            ctx.strokeStyle = 'rgba(216,174,69,0.5)';
            ctx.lineWidth = 1;
            ctx.strokeRect(mxp + 0.5, myp + 0.5, mw, 30);
            ctx.fillStyle = COLORS.goldSoft;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(msg, PL + pw / 2, myp + 15);
        }
    }

    // ---------- Hit testing ----------
    function hitTest(pos, pointerType) {
        if (!zone || locked) { return null; }
        var t = pointerType === 'touch' ? 18 : 9;

        if (isLine) {
            var l = lineOf(zone);
            var d1 = Math.hypot(pos.x - l.x1, pos.y - l.y1);
            var d2 = Math.hypot(pos.x - l.x2, pos.y - l.y2);
            if (d1 <= t && d1 <= d2) { return { type: 'resize', point: 'a' }; }
            if (d2 <= t) { return { type: 'resize', point: 'b' }; }
            if (distToSegment(pos.x, pos.y, l.x1, l.y1, l.x2, l.y2) <= t) { return { type: 'move' }; }
            return null;
        }

        var r = rectOf(zone);
        var t = pointerType === 'touch' ? 18 : 9;
        var left = Math.min(r.x1, r.x2), right = Math.max(r.x1, r.x2);
        var top = Math.min(r.y1, r.y2), bottom = Math.max(r.y1, r.y2);

        if (pos.x < left - t || pos.x > right + t || pos.y < top - t || pos.y > bottom + t) { return null; }

        var dl = Math.abs(pos.x - left), dr = Math.abs(pos.x - right);
        var dt = Math.abs(pos.y - top), db = Math.abs(pos.y - bottom);
        var edges = { l: false, r: false, t: false, b: false };

        if (dl <= t || dr <= t) {
            if (dl <= dr) { edges.l = true; } else { edges.r = true; }
        }
        if (dt <= t || db <= t) {
            if (dt <= db) { edges.t = true; } else { edges.b = true; }
        }
        if (edges.l || edges.r || edges.t || edges.b) {
            return { type: 'resize', edges: edges };
        }
        if (pos.x > left && pos.x < right && pos.y > top && pos.y < bottom) {
            return { type: 'move' };
        }
        return null;
    }

    function cursorFor(hit) {
        if (!hit) { return 'crosshair'; }
        if (hit.type === 'move') { return 'move'; }
        if (isLine) { return 'pointer'; }
        var e = hit.edges;
        if ((e.l && e.t) || (e.r && e.b)) { return 'nwse-resize'; }
        if ((e.r && e.t) || (e.l && e.b)) { return 'nesw-resize'; }
        if (e.l || e.r) { return 'ew-resize'; }
        return 'ns-resize';
    }

    // ---------- Pointer interaction ----------
    function posFromEvent(e) {
        var rect = canvas.getBoundingClientRect();
        // Scale in case CSS size differs from the layout size
        var sx = rect.width ? cssW / rect.width : 1;
        var sy = rect.height ? cssH / rect.height : 1;
        return { x: (e.clientX - rect.left) * sx, y: (e.clientY - rect.top) * sy };
    }

    function onDown(e) {
        if (locked || busy) { return; }
        if (e.pointerType === 'mouse' && e.button !== 0) { return; }
        e.preventDefault();
        try { canvas.focus({ preventScroll: true }); } catch (err) { /* older browsers */ }

        var pos = posFromEvent(e);
        var hit = hitTest(pos, e.pointerType);
        zoneTone = 'idle';

        if (hit) {
            drag = { mode: hit.type, edges: hit.edges || null, point: hit.point || null, start: pos, startZone: copyZone(zone), moved: true };
        } else {
            drag = { mode: 'draw', start: pos, anchorX: clampX(pxToX(pos.x)), anchorP: clampP(pyToP(pos.y)), moved: false };
        }
        try { canvas.setPointerCapture(e.pointerId); } catch (err2) { /* ignore */ }
        hover = e.pointerType === 'mouse' ? pos : null;
        draw();
    }

    function onMove(e) {
        var pos = posFromEvent(e);

        if (!drag) {
            if (e.pointerType === 'mouse') {
                hover = pos;
                canvas.style.cursor = locked ? 'default' : cursorFor(hitTest(pos, 'mouse'));
                draw();
            }
            return;
        }

        e.preventDefault();
        hover = e.pointerType === 'mouse' ? pos : null;
        var cx = clampX(pxToX(pos.x));
        var cp = clampP(pyToP(pos.y));

        if (drag.mode === 'draw') {
            var dist = Math.abs(pos.x - drag.start.x) + Math.abs(pos.y - drag.start.y);
            if (!drag.moved && dist < 4) { return; }
            drag.moved = true;
            zone = normalise({ x1: drag.anchorX, x2: cx, p1: drag.anchorP, p2: cp });
        } else if (drag.mode === 'move') {
            var s = drag.startZone;
            var dxU = ((pos.x - drag.start.x) / pw) * N;
            var dpU = -((pos.y - drag.start.y) / ph) * (pmax - pmin);
            dxU = clamp(dxU, -s.x1, N - s.x2);
            var pLo = Math.min(s.p1, s.p2), pHi = Math.max(s.p1, s.p2);
            dpU = clamp(dpU, pmin - pLo, pmax - pHi);
            zone = { x1: s.x1 + dxU, x2: s.x2 + dxU, p1: s.p1 + dpU, p2: s.p2 + dpU };
        } else if (drag.mode === 'resize') {
            if (isLine) {
                var zl = copyZone(drag.startZone);
                if (drag.point === 'a') { zl.x1 = cx; zl.p1 = cp; } else { zl.x2 = cx; zl.p2 = cp; }
                zone = normalise(zl);
            } else {
                var z = copyZone(drag.startZone);
                if (drag.edges.l) { z.x1 = cx; }
                if (drag.edges.r) { z.x2 = cx; }
                if (drag.edges.t) { z.p2 = cp; }
                if (drag.edges.b) { z.p1 = cp; }
                zone = normalise(z);
            }
        }
        draw();
    }

    function onUp(e) {
        if (!drag) { return; }
        try { canvas.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        var wasDraw = drag.mode === 'draw';
        var moved = drag.moved;
        drag = null;
        if (wasDraw && !moved) {
            // A simple tap/click: nothing to draw, keep whatever was there.
            draw();
            return;
        }
        if (e.pointerType !== 'mouse') { hover = null; }
        refreshUI();
        draw();
    }

    function onLeave() {
        if (!drag) {
            hover = null;
            draw();
        }
    }

    canvas.addEventListener('pointerdown', onDown);
    canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerup', onUp);
    canvas.addEventListener('pointercancel', onUp);
    canvas.addEventListener('pointerleave', onLeave);
    canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });

    canvas.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            submitZone();
        } else if (e.key === 'Escape' && !locked) {
            e.preventDefault();
            clearZone();
        }
    });

    // ---------- UI state ----------
    function setHelp(text) { if (helpEl) { helpEl.textContent = text; } }

    function refreshUI() {
        var valid = isValid();
        btnSubmit.disabled = !(valid && !busy && !locked);
        btnSubmit.textContent = busy ? 'Submitting...' : (isLine ? 'Submit Line' : 'Submit Zone');

        if (locked) {
            btnClear.textContent = 'Practice Again';
            btnClear.disabled = busy;
        } else {
            btnClear.textContent = 'Clear';
            btnClear.disabled = busy || !(zone || answers.length);
        }

        if (locked) {
            setHelp('Solved. Press Practice Again to try it once more, or move on to the next exercise.');
        } else if (!zone) {
            setHelp(isLine
                ? 'Drag from an early swing point to a later one to draw the trend line. Drag either end afterwards to fine-tune it.'
                : 'Drag on the chart to draw a zone. Drag inside it to move it, or drag an edge or corner to resize.');
        } else if (!valid) {
            setHelp(isLine ? 'That line is too short or too flat. Make it longer and give it a clearer slope, then submit.'
                           : 'That zone is too small. Make it a little larger, then submit.');
        } else {
            setHelp(isLine ? 'Adjust the line if you like, then press Submit Line.' : 'Adjust the zone if you like, then press Submit Zone.');
        }
        canvas.style.cursor = locked ? 'default' : 'crosshair';
    }

    function hideResult() {
        if (resultBox) { resultBox.hidden = true; resultBox.textContent = ''; resultBox.className = 'af-lab-result'; }
    }

    function showResult(kind, title, message, meta) {
        if (!resultBox) { return; }
        resultBox.textContent = '';
        resultBox.className = 'af-lab-result is-' + kind;
        var h = document.createElement('div');
        h.className = 'af-lab-result-title';
        h.textContent = title;
        var p = document.createElement('p');
        p.textContent = message;
        resultBox.appendChild(h);
        resultBox.appendChild(p);
        if (meta) {
            var m = document.createElement('small');
            m.textContent = meta;
            resultBox.appendChild(m);
        }
        resultBox.hidden = false;
    }

    function showExplanation(text) {
        if (!explainBox || !text) { return; }
        explainBox.textContent = '';
        var h = document.createElement('h3');
        h.textContent = 'Why this zone';
        var p = document.createElement('p');
        p.textContent = text;
        explainBox.appendChild(h);
        explainBox.appendChild(p);
        explainBox.hidden = false;
    }

    function hideExplanation() {
        if (explainBox) { explainBox.hidden = true; explainBox.textContent = ''; }
    }

    // ---------- Buttons ----------
    function clearZone() {
        if (busy) { return; }
        if (locked) {
            // "Practice Again"
            locked = false;
            answers = [];
            zone = null;
            zoneTone = 'idle';
            hideResult();
            hideExplanation();
            refreshUI();
            draw();
            canvas.focus({ preventScroll: true });
            return;
        }
        zone = null;
        zoneTone = 'idle';
        answers = [];
        hideResult();
        hideExplanation();
        refreshUI();
        draw();
    }

    function toggleHint() {
        hintShown = !hintShown;
        if (hintBox) {
            hintBox.hidden = !hintShown;
            hintBox.textContent = hintShown ? ('Hint: ' + ex.hint) : '';
        }
        btnHint.textContent = hintShown ? 'Hide Hint' : 'Hint';
    }

    function postToApi(fields) {
        var body = new URLSearchParams();
        body.set('csrf_token', CSRF);
        body.set('exercise_id', String(ex.id));
        Object.keys(fields).forEach(function (k) { body.set(k, fields[k]); });
        return fetch(API, {
            method: 'POST',
            body: body,
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        }).then(function (res) {
            return res.text().then(function (text) {
                var data = null;
                try { data = JSON.parse(text); } catch (err) { data = null; }
                return { status: res.status, data: data };
            });
        });
    }

    function friendlyError(result) {
        if (result.data && result.data.error) { return result.data.error; }
        return 'The server sent an unexpected reply. Reload the page and try again. Your zone has not been judged.';
    }

    function updateSolvedInList(stats) {
        var item = document.querySelector('.af-lab-item[data-exercise-id="' + ex.id + '"]');
        if (item && !item.classList.contains('solved')) {
            item.classList.add('solved');
            var num = item.querySelector('.af-lab-item-num');
            if (num) { num.textContent = '\u2713'; }
        }
        var counter = document.getElementById('labSolved');
        if (counter && stats && typeof stats.solved === 'number') {
            counter.textContent = String(stats.solved);
        }
    }

    function submitZone() {
        if (busy || locked || !isValid()) { return; }
        busy = true;
        hideResult();
        refreshUI();

        var sent = copyZone(zone);
        postToApi({
            action: 'submit',
            x1: sent.x1.toFixed(4),
            x2: sent.x2.toFixed(4),
            p1: sent.p1.toFixed(ex.decimals + 3),
            p2: sent.p2.toFixed(ex.decimals + 3)
        }).then(function (result) {
            var d = result.data;
            if (!d || !d.ok) {
                showResult('info', 'Could not submit', friendlyError(result) + (d && d.login ? '' : ' Your zone is still on the chart.'));
                return;
            }
            attempts = d.attempts || (attempts + 1);
            var meta = 'Attempt ' + attempts;

            if (d.verdict === 'correct') {
                locked = true;
                zoneTone = 'right';
                answers = d.answers || [];
                showResult('correct', 'Correct', d.message, 'Accuracy ' + d.score + '%  \u00b7  ' + meta);
                showExplanation(d.explanation);
                if (linkNext) {
                    if (d.next_id) {
                        linkNext.href = LAB_URL + '?ex=' + encodeURIComponent(d.next_id);
                        linkNext.textContent = 'Next Exercise';
                    } else {
                        linkNext.href = LAB_URL;
                        linkNext.textContent = 'See All Exercises';
                    }
                    linkNext.hidden = false;
                }
                updateSolvedInList(d.stats);
                if (btnReveal) { btnReveal.hidden = true; }
            } else if (d.verdict === 'close') {
                zoneTone = 'close';
                showResult('close', 'Almost there', d.message, meta);
            } else {
                zoneTone = 'wrong';
                showResult('wrong', 'Not correct', d.message, meta);
            }

            if (d.can_reveal && btnReveal && !locked) { btnReveal.hidden = false; }
        }).catch(function () {
            showResult('info', 'Could not submit', 'We could not reach the server. Check your connection and press Submit Zone again. Your zone is still on the chart.');
        }).then(function () {
            busy = false;
            refreshUI();
            draw();
        });
    }

    function revealAnswer() {
        if (busy) { return; }
        busy = true;
        refreshUI();
        postToApi({ action: 'reveal' }).then(function (result) {
            var d = result.data;
            if (!d || !d.ok) {
                showResult('info', 'Answer not available yet', friendlyError(result));
                return;
            }
            answers = d.answers || [];
            showExplanation(d.explanation);
            showResult('info', 'Answer shown', 'The green dashed box marks the official zone. Study it, then press Clear and try again from scratch.');
        }).catch(function () {
            showResult('info', 'Could not load the answer', 'We could not reach the server. Please try again.');
        }).then(function () {
            busy = false;
            refreshUI();
            draw();
        });
    }

    btnSubmit.addEventListener('click', submitZone);
    btnClear.addEventListener('click', clearZone);
    if (btnHint) {
        if (ex.hint) { btnHint.addEventListener('click', toggleHint); } else { btnHint.hidden = true; }
    }
    if (btnReveal) {
        btnReveal.addEventListener('click', revealAnswer);
        if (attempts >= 2) { btnReveal.hidden = false; }
    }

    // ---------- Sizing ----------
    var resizeTimer = null;
    function onResize() {
        layout();
        draw();
    }
    if (typeof ResizeObserver !== 'undefined') {
        new ResizeObserver(function () {
            if (resizeTimer) { window.cancelAnimationFrame(resizeTimer); }
            resizeTimer = window.requestAnimationFrame(onResize);
        }).observe(stage);
    } else {
        window.addEventListener('resize', onResize);
    }

    layout();
    refreshUI();
    draw();
})();
