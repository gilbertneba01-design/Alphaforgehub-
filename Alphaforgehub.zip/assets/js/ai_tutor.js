/**
 * ALPHA FORGE HUB - AI Tutor front-end
 * Talks only to /api/ai/chat.php. Never holds an API key - all AI calls
 * happen server-side.
 */
(function () {
    var cfg = window.AF_TUTOR_INIT || {};
    var csrfInput = document.querySelector('#afTutorForm input[name="csrf_token"]');
    var csrfToken = csrfInput ? csrfInput.value : '';

    var els = {
        form: document.getElementById('afTutorForm'),
        input: document.getElementById('afTutorInput'),
        sendBtn: document.getElementById('afTutorSendBtn'),
        messages: document.getElementById('afTutorMessages'),
        empty: document.getElementById('afTutorEmpty'),
        convList: document.getElementById('afTutorConvList'),
        newBtn: document.getElementById('afTutorNewBtn'),
        modes: document.getElementById('afTutorModes'),
        quota: document.getElementById('afTutorQuota')
    };

    if (!els.form) {
        return; // AI Tutor not configured / page not rendered
    }

    var state = {
        conversationId: cfg.conversationId || null,
        mode: 'explain',
        sending: false
    };

    function post(action, extra) {
        var body = new URLSearchParams(Object.assign({ action: action, csrf_token: csrfToken }, extra || {}));
        return fetch(cfg.apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(function (r) { return r.json(); });
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function renderMessage(role, content) {
        if (els.empty) {
            els.empty.style.display = 'none';
        }
        var wrap = document.createElement('div');
        wrap.className = 'af-tutor-msg ' + (role === 'assistant' ? 'af-tutor-msg-ai' : 'af-tutor-msg-user');
        var bubble = document.createElement('div');
        bubble.className = 'af-tutor-bubble';
        bubble.innerHTML = escapeHtml(content).replace(/\n/g, '<br>');
        wrap.appendChild(bubble);
        els.messages.appendChild(wrap);
        els.messages.scrollTop = els.messages.scrollHeight;
    }

    function clearMessages() {
        els.messages.querySelectorAll('.af-tutor-msg').forEach(function (n) { n.remove(); });
        if (els.empty) {
            els.empty.style.display = '';
        }
    }

    function setActiveModeButton(mode) {
        if (!els.modes) return;
        els.modes.querySelectorAll('.af-tutor-mode-btn').forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-mode') === mode);
        });
    }

    function updateQuota(remaining) {
        if (typeof remaining === 'number' && els.quota) {
            els.quota.textContent = remaining + ' / ' + (cfg.dailyLimit || remaining) + ' messages left today';
        }
    }

    function loadConversation(id) {
        state.conversationId = id;
        clearMessages();
        post('load', { conversation_id: id }).then(function (res) {
            if (!res.ok) {
                return;
            }
            state.mode = res.conversation.mode || 'explain';
            setActiveModeButton(state.mode);
            res.messages.forEach(function (m) { renderMessage(m.role, m.content); });
            updateQuota(res.quota_remaining);
            highlightActiveConversation(id);
        });
    }

    function highlightActiveConversation(id) {
        if (!els.convList) return;
        els.convList.querySelectorAll('.af-tutor-conv-item').forEach(function (n) {
            n.classList.toggle('active', parseInt(n.getAttribute('data-id'), 10) === id);
        });
    }

    function renderConversationList(list) {
        if (!els.convList) return;
        if (!list.length) {
            els.convList.innerHTML = '<p class="af-muted" style="padding:8px;">No conversations yet.</p>';
            return;
        }
        els.convList.innerHTML = '';
        list.forEach(function (c) {
            var item = document.createElement('div');
            item.className = 'af-tutor-conv-item';
            item.setAttribute('data-id', c.id);
            item.textContent = c.title;
            item.addEventListener('click', function () { loadConversation(c.id); });
            els.convList.appendChild(item);
        });
        highlightActiveConversation(state.conversationId);
    }

    function refreshConversationList() {
        post('list').then(function (res) {
            if (res.ok) {
                renderConversationList(res.conversations);
            }
        });
    }

    function startNewConversation(lessonId, courseId) {
        var payload = { mode: state.mode };
        if (lessonId) payload.lesson_id = lessonId;
        if (courseId) payload.course_id = courseId;
        post('new', payload).then(function (res) {
            if (!res.ok) {
                alert(res.error || 'Could not start a new conversation.');
                return;
            }
            clearMessages();
            state.conversationId = res.conversation_id;
            updateQuota(res.quota_remaining);
            refreshConversationList();
        });
    }

    function sendMessage(text) {
        if (state.sending) return;
        if (!state.conversationId) {
            // Lazily create a conversation on first message if none exists yet.
            post('new', { mode: state.mode }).then(function (res) {
                if (!res.ok) {
                    alert(res.error || 'Could not start a conversation.');
                    return;
                }
                state.conversationId = res.conversation_id;
                refreshConversationList();
                doSend(text);
            });
            return;
        }
        doSend(text);
    }

    function doSend(text) {
        state.sending = true;
        els.sendBtn.disabled = true;
        renderMessage('user', text);

        var thinking = document.createElement('div');
        thinking.className = 'af-tutor-msg af-tutor-msg-ai af-tutor-thinking';
        thinking.innerHTML = '<div class="af-tutor-bubble">Thinking&hellip;</div>';
        els.messages.appendChild(thinking);
        els.messages.scrollTop = els.messages.scrollHeight;

        post('send', { conversation_id: state.conversationId, message: text, mode: state.mode }).then(function (res) {
            thinking.remove();
            state.sending = false;
            els.sendBtn.disabled = false;
            if (!res.ok) {
                renderMessage('assistant', res.error || 'Something went wrong. Please try again.');
                if (res.quota_exceeded) {
                    els.input.disabled = true;
                    els.sendBtn.disabled = true;
                }
                return;
            }
            renderMessage('assistant', res.reply);
            updateQuota(res.quota_remaining);
        }).catch(function () {
            thinking.remove();
            state.sending = false;
            els.sendBtn.disabled = false;
            renderMessage('assistant', 'Network error. Please check your connection and try again.');
        });
    }

    els.form.addEventListener('submit', function (e) {
        e.preventDefault();
        var text = els.input.value.trim();
        if (!text) return;
        els.input.value = '';
        sendMessage(text);
    });

    els.input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            els.form.requestSubmit();
        }
    });

    if (els.newBtn) {
        els.newBtn.addEventListener('click', function () { startNewConversation(); });
    }

    if (els.modes) {
        els.modes.querySelectorAll('.af-tutor-mode-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                state.mode = btn.getAttribute('data-mode');
                setActiveModeButton(state.mode);
            });
        });
    }

    // ---- Boot ----
    refreshConversationList();
    if (cfg.conversationId) {
        loadConversation(cfg.conversationId);
    } else if (cfg.lessonId) {
        startNewConversation(cfg.lessonId, cfg.courseId);
    }
})();
