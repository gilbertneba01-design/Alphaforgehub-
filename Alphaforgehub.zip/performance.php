<?php
/**
 * ALPHA FORGE HUB - My Performance (STUDENT)
 * Trading performance analytics, computed from the student's own journal.
 * This is different from course progress - this measures trading results.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/journal.php';
require_once __DIR__ . '/config/performance.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

$filters = [
    'pair'      => trim((string) ($_GET['pair'] ?? '')),
    'strategy'  => trim((string) ($_GET['strategy'] ?? '')),
    'session'   => (string) ($_GET['session'] ?? ''),
    'direction' => (string) ($_GET['direction'] ?? ''),
    'result'    => (string) ($_GET['result'] ?? ''),
    'date_from' => trim((string) ($_GET['date_from'] ?? '')),
    'date_to'   => trim((string) ($_GET['date_to'] ?? '')),
];

$stats = performance_compute($userId, $filters);
$pairOptions     = journal_pairs_used($userId);
$strategyOptions = journal_strategies_used($userId);

function perf_bar_rows(array $rows, string $valueKey = 'pl'): void {
    if (!$rows) {
        echo '<p class="af-muted">No data yet.</p>';
        return;
    }
    $max = max(array_map(fn($r) => abs($r[$valueKey]), $rows)) ?: 1;
    foreach ($rows as $r) {
        $pct = min(100, round((abs($r[$valueKey]) / $max) * 100));
        $isNeg = $r[$valueKey] < 0;
        echo '<div class="af-perf-bar-row">';
        echo '<span class="af-perf-bar-label">' . e($r['label']) . '</span>';
        echo '<div class="af-perf-bar-track"><div class="af-perf-bar-fill' . ($isNeg ? ' negative' : '') . '" style="width:' . $pct . '%;"></div></div>';
        echo '<span class="af-perf-bar-value">' . number_format($r[$valueKey], 2) . '</span>';
        echo '</div>';
    }
}

function perf_winrate_rows(array $rows): void {
    if (!$rows) {
        echo '<p class="af-muted">No data yet.</p>';
        return;
    }
    foreach ($rows as $r) {
        echo '<div class="af-perf-bar-row">';
        echo '<span class="af-perf-bar-label">' . e($r['label']) . ' (' . (int) $r['count'] . ')</span>';
        echo '<div class="af-perf-bar-track"><div class="af-perf-bar-fill" style="width:' . (float) $r['win_rate'] . '%;"></div></div>';
        echo '<span class="af-perf-bar-value">' . e((string) $r['win_rate']) . '%</span>';
        echo '</div>';
    }
}

$pageTitle = 'My Performance';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>My Performance</h1>
            <p class="af-muted">Trading performance, computed from your Trading Journal. This is separate from your course progress.</p>

            <form method="get" class="af-card" style="margin:18px 0;">
                <div class="af-grid af-grid-3" style="gap:12px;">
                    <div class="af-field"><label>Pair</label>
                        <select name="pair"><option value="">All</option>
                            <?php foreach ($pairOptions as $p): ?><option value="<?= e($p) ?>" <?= $filters['pair'] === $p ? 'selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Strategy</label>
                        <select name="strategy"><option value="">All</option>
                            <?php foreach ($strategyOptions as $s): ?><option value="<?= e($s) ?>" <?= $filters['strategy'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Direction</label>
                        <select name="direction"><option value="">Buy &amp; Sell</option>
                            <?php foreach (JOURNAL_DIRECTIONS as $k => $l): ?><option value="<?= e($k) ?>" <?= $filters['direction'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>From</label><input type="date" name="date_from" value="<?= e($filters['date_from']) ?>"></div>
                    <div class="af-field"><label>To</label><input type="date" name="date_to" value="<?= e($filters['date_to']) ?>"></div>
                    <div class="af-field"><label>Result</label>
                        <select name="result"><option value="">All</option>
                            <?php foreach (JOURNAL_RESULTS as $k => $l): ?><option value="<?= e($k) ?>" <?= $filters['result'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field" style="align-self:end;"><button type="submit" class="af-btn af-btn-gold af-btn-block">Apply</button></div>
                </div>
            </form>

            <div class="af-grid af-grid-3" style="gap:16px;">
                <div class="af-stat-card"><span class="af-stat-label">Total Trades</span><span class="af-stat-value"><?= (int) $stats['total_trades'] ?></span></div>
                <div class="af-stat-card"><span class="af-stat-label">Win Rate</span><span class="af-stat-value"><?= e((string) $stats['win_rate']) ?>%</span></div>
                <div class="af-stat-card"><span class="af-stat-label">Total P/L</span><span class="af-stat-value" style="color:<?= $stats['total_pl'] >= 0 ? 'var(--green)' : 'var(--red)' ?>;"><?= number_format($stats['total_pl'], 2) ?></span></div>
                <div class="af-stat-card"><span class="af-stat-label">Wins</span><span class="af-stat-value"><?= (int) $stats['wins'] ?></span></div>
                <div class="af-stat-card"><span class="af-stat-label">Losses</span><span class="af-stat-value"><?= (int) $stats['losses'] ?></span></div>
                <div class="af-stat-card"><span class="af-stat-label">Avg R:R</span><span class="af-stat-value"><?= $stats['avg_rr'] !== null ? '1:' . e((string) $stats['avg_rr']) : '&mdash;' ?></span></div>
            </div>

            <div class="af-grid af-grid-2" style="gap:20px; margin-top:24px;">
                <div class="af-card">
                    <h3>P/L by Pair</h3>
                    <?php perf_bar_rows($stats['by_pair']); ?>
                    <?php if ($stats['best_pair']): ?><p class="af-muted">Best pair: <strong><?= e($stats['best_pair']['label']) ?></strong></p><?php endif; ?>
                    <?php if ($stats['worst_pair'] && $stats['worst_pair'] !== $stats['best_pair']): ?><p class="af-muted">Needs attention: <strong><?= e($stats['worst_pair']['label']) ?></strong></p><?php endif; ?>
                </div>
                <div class="af-card">
                    <h3>P/L by Strategy</h3>
                    <?php perf_bar_rows($stats['by_strategy']); ?>
                    <?php if ($stats['best_strategy']): ?><p class="af-muted">Best strategy: <strong><?= e($stats['best_strategy']['label']) ?></strong></p><?php endif; ?>
                </div>
                <div class="af-card">
                    <h3>Win Rate by Session</h3>
                    <?php perf_winrate_rows($stats['by_session']); ?>
                </div>
                <div class="af-card">
                    <h3>Win Rate by Timeframe</h3>
                    <?php perf_winrate_rows($stats['by_timeframe']); ?>
                </div>
                <div class="af-card">
                    <h3>Win Rate by Direction</h3>
                    <?php perf_winrate_rows($stats['by_direction']); ?>
                </div>
                <div class="af-card">
                    <h3>Psychology Patterns</h3>
                    <p class="af-muted" style="margin-top:-6px;">Win rate grouped by the emotion you felt before entering.</p>
                    <?php perf_winrate_rows($stats['psychology']); ?>
                </div>
            </div>

            <div class="af-card" style="margin-top:20px;">
                <span class="af-badge">Educational tool</span>
                <p style="margin-top:10px;">This page reflects your own recorded trades and is for self-reflection, not financial advice. Use it alongside your <a href="<?= APP_URL ?>/trading_journal.php">Trading Journal</a> and the <a href="<?= APP_URL ?>/ai_tutor.php">AI Tutor</a> to spot patterns and revisit relevant lessons.</p>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
