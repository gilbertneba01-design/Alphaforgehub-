<?php
require_once __DIR__ . '/config/functions.php';
$pageTitle = 'About';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:720px;">
        <div class="af-ladder"><span></span><span></span><span></span><span></span><span></span></div>
        <h1>About Alpha Forge</h1>
        <p>Alpha Forge exists to teach Forex the way a disciplined trading desk would — one foundational concept at a time, with real accountability for progress along the way.</p>
        <p>We believe most beginners don't fail because the market is unknowable; they fail because they skip the fundamentals and manage risk poorly. Alpha Forge is built to close both gaps: structured lessons that build on each other, and a risk management track that's treated as core curriculum, not an afterthought.</p>
        <p>Every lesson you complete is recorded against your account, so your dashboard always shows real progress — never a guess.</p>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
