<?php
/**
 * ALPHA FORGE HUB - Add / Edit Trade (STUDENT)
 * ?id=N to edit an existing trade (ownership-checked); no id to add a new one.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/journal.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

$tradeId = (int) ($_GET['id'] ?? 0) ?: null;
$trade   = $tradeId ? journal_get($userId, $tradeId) : null;
if ($tradeId && !$trade) {
    flash_set('error', 'Trade not found.');
    redirect('/trading_journal.php');
}

$errors = [];
$input  = $trade ?: [
    'pair' => '', 'direction' => 'buy', 'entry_price' => '', 'stop_loss' => '', 'take_profit' => '',
    'lot_size' => '', 'risk_amount' => '', 'risk_percent' => '', 'result' => 'open', 'profit_loss' => '',
    'strategy' => '', 'timeframe' => '', 'session' => '', 'entry_reason' => '', 'exit_reason' => '',
    'emotion_before' => '', 'emotion_during' => '', 'emotion_after' => '', 'notes' => '',
    'trade_date' => date('Y-m-d'), 'screenshots' => [],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (isset($_POST['delete_screenshot_id'])) {
        journal_delete_screenshot($userId, (int) $_POST['delete_screenshot_id']);
        redirect('/journal_entry.php?id=' . $tradeId);
    }

    $input = [
        'pair'           => trim((string) ($_POST['pair'] ?? '')),
        'direction'      => (string) ($_POST['direction'] ?? ''),
        'entry_price'    => trim((string) ($_POST['entry_price'] ?? '')),
        'stop_loss'      => trim((string) ($_POST['stop_loss'] ?? '')),
        'take_profit'    => trim((string) ($_POST['take_profit'] ?? '')),
        'lot_size'       => trim((string) ($_POST['lot_size'] ?? '')),
        'risk_amount'    => trim((string) ($_POST['risk_amount'] ?? '')),
        'risk_percent'   => trim((string) ($_POST['risk_percent'] ?? '')),
        'result'         => (string) ($_POST['result'] ?? 'open'),
        'profit_loss'    => trim((string) ($_POST['profit_loss'] ?? '')),
        'strategy'       => trim((string) ($_POST['strategy'] ?? '')),
        'timeframe'      => trim((string) ($_POST['timeframe'] ?? '')),
        'session'        => (string) ($_POST['session'] ?? ''),
        'entry_reason'   => trim((string) ($_POST['entry_reason'] ?? '')),
        'exit_reason'    => trim((string) ($_POST['exit_reason'] ?? '')),
        'emotion_before' => (string) ($_POST['emotion_before'] ?? ''),
        'emotion_during' => (string) ($_POST['emotion_during'] ?? ''),
        'emotion_after'  => (string) ($_POST['emotion_after'] ?? ''),
        'notes'          => trim((string) ($_POST['notes'] ?? '')),
        'trade_date'     => trim((string) ($_POST['trade_date'] ?? '')),
    ];

    $errors = journal_validate($input);

    if (!$errors) {
        if ($tradeId) {
            journal_update($userId, $tradeId, $input);
        } else {
            $tradeId = journal_create($userId, $input);
        }

        if (!empty($_FILES['screenshot']['name'])) {
            $up = journal_save_screenshot($userId, $tradeId, $_FILES['screenshot']);
            if (!$up['success'] && $up['error']) {
                flash_set('error', $up['error']);
            }
        }

        flash_set('success', 'Trade saved.');
        redirect('/journal_entry.php?id=' . $tradeId);
    }

    $input['screenshots'] = $trade['screenshots'] ?? [];
}

$pageTitle = $tradeId ? 'Edit Trade' : 'Add Trade';
require_once __DIR__ . '/includes/header.php';

function jsel(string $current, string $value): string {
    return $current === $value ? 'selected' : '';
}
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1><?= $tradeId ? 'Edit Trade' : 'Add Trade' ?></h1>
            <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

            <form method="post" enctype="multipart/form-data" class="af-form-card" style="max-width:820px;">
                <?= csrf_field() ?>
                <div class="af-grid af-grid-3" style="gap:14px;">
                    <div class="af-field"><label>Currency Pair *</label><input type="text" name="pair" value="<?= e($input['pair']) ?>" placeholder="EUR/USD" required></div>
                    <div class="af-field"><label>Direction *</label>
                        <select name="direction" required>
                            <?php foreach (JOURNAL_DIRECTIONS as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= jsel($input['direction'], $k) ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Trade Date *</label><input type="date" name="trade_date" value="<?= e($input['trade_date']) ?>" required></div>

                    <div class="af-field"><label>Entry Price *</label><input type="text" name="entry_price" value="<?= e($input['entry_price']) ?>" required></div>
                    <div class="af-field"><label>Stop Loss</label><input type="text" name="stop_loss" value="<?= e($input['stop_loss']) ?>"></div>
                    <div class="af-field"><label>Take Profit</label><input type="text" name="take_profit" value="<?= e($input['take_profit']) ?>"></div>

                    <div class="af-field"><label>Lot Size</label><input type="text" name="lot_size" value="<?= e($input['lot_size']) ?>"></div>
                    <div class="af-field"><label>Risk Amount</label><input type="text" name="risk_amount" value="<?= e($input['risk_amount']) ?>"></div>
                    <div class="af-field"><label>Risk %</label><input type="text" name="risk_percent" value="<?= e($input['risk_percent']) ?>"></div>

                    <div class="af-field"><label>Result</label>
                        <select name="result">
                            <?php foreach (JOURNAL_RESULTS as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= jsel($input['result'], $k) ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Profit / Loss</label><input type="text" name="profit_loss" value="<?= e($input['profit_loss']) ?>"></div>
                    <div class="af-field"><label>Timeframe</label><input type="text" name="timeframe" value="<?= e($input['timeframe']) ?>" placeholder="H1, H4, D1..."></div>

                    <div class="af-field"><label>Strategy</label><input type="text" name="strategy" value="<?= e($input['strategy']) ?>" placeholder="Trend pullback, breakout..."></div>
                    <div class="af-field"><label>Trading Session</label>
                        <select name="session">
                            <option value="">&mdash;</option>
                            <?php foreach (JOURNAL_SESSIONS as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= jsel($input['session'], $k) ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div></div>
                </div>

                <h3 style="margin-top:22px;">Psychology</h3>
                <div class="af-grid af-grid-3" style="gap:14px;">
                    <div class="af-field"><label>Emotion Before</label>
                        <select name="emotion_before"><option value="">&mdash;</option>
                            <?php foreach (JOURNAL_EMOTIONS as $k => $label): ?><option value="<?= e($k) ?>" <?= jsel($input['emotion_before'], $k) ?>><?= e($label) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Emotion During</label>
                        <select name="emotion_during"><option value="">&mdash;</option>
                            <?php foreach (JOURNAL_EMOTIONS as $k => $label): ?><option value="<?= e($k) ?>" <?= jsel($input['emotion_during'], $k) ?>><?= e($label) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Emotion After</label>
                        <select name="emotion_after"><option value="">&mdash;</option>
                            <?php foreach (JOURNAL_EMOTIONS as $k => $label): ?><option value="<?= e($k) ?>" <?= jsel($input['emotion_after'], $k) ?>><?= e($label) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="af-field"><label>Entry Reason</label><textarea name="entry_reason" rows="2"><?= e($input['entry_reason']) ?></textarea></div>
                <div class="af-field"><label>Exit Reason</label><textarea name="exit_reason" rows="2"><?= e($input['exit_reason']) ?></textarea></div>
                <div class="af-field"><label>Notes</label><textarea name="notes" rows="3"><?= e($input['notes']) ?></textarea></div>

                <div class="af-field">
                    <label>Screenshot (JPG/PNG/WEBP, max 3&nbsp;MB)</label>
                    <input type="file" name="screenshot" accept="image/jpeg,image/png,image/webp">
                </div>

                <?php if (!empty($input['screenshots'])): ?>
                    <div style="display:flex; gap:10px; flex-wrap:wrap; margin:10px 0;">
                        <?php foreach ($input['screenshots'] as $shot): ?>
                            <div style="position:relative;">
                                <a href="<?= APP_URL . e($shot['file_path']) ?>" target="_blank">
                                    <img src="<?= APP_URL . e($shot['file_path']) ?>" alt="Trade screenshot" style="width:120px; height:80px; object-fit:cover; border-radius:6px; border:1px solid var(--border);">
                                </a>
                                <form method="post" style="position:absolute; top:2px; right:2px;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="delete_screenshot_id" value="<?= (int) $shot['id'] ?>">
                                    <button type="submit" class="af-btn af-btn-ghost" style="padding:2px 6px; font-size:11px;" data-confirm-click="Remove this screenshot?">&times;</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div style="display:flex; gap:12px; margin-top:16px;">
                    <button type="submit" class="af-btn af-btn-gold">Save Trade</button>
                    <a href="<?= APP_URL ?>/trading_journal.php" class="af-btn af-btn-ghost">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
