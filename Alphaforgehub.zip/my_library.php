<?php
/** ALPHA FORGE HUB - My Library (STUDENT) - purchased ebooks/bundles */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

$stmt = db()->prepare("SELECT sp.*, p.title, p.description, p.image, p.file_path FROM store_purchases sp
    JOIN store_products p ON p.id = sp.product_id
    WHERE sp.user_id = ? AND sp.status = 'paid' ORDER BY sp.purchased_at DESC");
$stmt->execute([$user['id']]);
$purchases = $stmt->fetchAll();

$pageTitle = 'My Library';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>My Library</h1>
            <p class="af-muted">Ebooks and bundles you've purchased.</p>

            <?php if (empty($purchases)): ?>
                <div class="af-card" style="padding:24px;">
                    <p>You haven't purchased anything yet.</p>
                    <a href="<?= APP_URL ?>/store.php" class="af-btn af-btn-gold">Visit the Store</a>
                </div>
            <?php else: ?>
                <div class="af-grid af-grid-3" style="gap:16px;">
                    <?php foreach ($purchases as $p): ?>
                        <div class="af-card" style="padding:16px;">
                            <?php if ($p['image']): ?><img src="<?= e(asset_url($p['image'])) ?>" alt="" style="width:100%; aspect-ratio:3/4; object-fit:cover; border-radius:6px;"><?php endif; ?>
                            <h3 style="margin:10px 0 6px;"><?= e($p['title']) ?></h3>
                            <?php if ($p['file_path']): ?>
                                <a href="<?= APP_URL ?>/download.php?type=store&id=<?= (int) $p['id'] ?>" class="af-btn af-btn-gold af-btn-sm">Download</a>
                            <?php else: ?>
                                <span class="af-muted">File not uploaded yet — contact support.</span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
