<?php
$pageTitle = 'Subscriptions';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_plan') {
        $id = (int) $_POST['plan_id'];
        $name = trim($_POST['name'] ?? '');
        $price = (float) ($_POST['price'] ?? 0);
        $days = (int) ($_POST['duration_days'] ?? 30);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        db()->prepare('UPDATE subscription_plans SET name=?, price=?, duration_days=?, is_active=? WHERE id=?')
            ->execute([$name, $price, $days, $isActive, $id]);
        flash_set('success', 'Plan updated.');
    } elseif ($action === 'cancel_subscription') {
        $id = (int) $_POST['subscription_id'];
        db()->prepare("UPDATE subscriptions SET status = 'cancelled' WHERE id = ?")->execute([$id]);
        flash_set('success', 'Subscription cancelled.');
    }
    redirect('/admin/subscriptions.php');
}

$plans = db()->query('SELECT * FROM subscription_plans ORDER BY duration_days')->fetchAll();

$subs = db()->query(
    "SELECT s.*, u.full_name, u.email, p.name AS plan_name
     FROM subscriptions s
     JOIN users u ON u.id = s.user_id
     JOIN subscription_plans p ON p.id = s.plan_id
     ORDER BY s.created_at DESC LIMIT 100"
)->fetchAll();
?>
<h1>Subscription Plans</h1>
<div class="af-grid af-grid-3">
    <?php foreach ($plans as $p): ?>
        <form method="post" class="af-card">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_plan">
            <input type="hidden" name="plan_id" value="<?= (int) $p['id'] ?>">
            <div class="af-field"><label>Name</label><input type="text" name="name" value="<?= e($p['name']) ?>"></div>
            <div class="af-field"><label>Price (<?= e($p['currency']) ?>)</label><input type="number" step="0.01" name="price" value="<?= e($p['price']) ?>"></div>
            <div class="af-field"><label>Duration (days)</label><input type="number" name="duration_days" value="<?= (int) $p['duration_days'] ?>"></div>
            <div class="af-field"><label><input type="checkbox" name="is_active" value="1" <?= $p['is_active'] ? 'checked' : '' ?>> Active</label></div>
            <button type="submit" class="af-btn af-btn-gold">Save</button>
        </form>
    <?php endforeach; ?>
</div>

<h2 style="margin-top:36px;">All Subscriptions</h2>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Student</th><th>Plan</th><th>Status</th><th>Starts</th><th>Ends</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($subs as $s): ?>
            <tr>
                <td><?= e($s['full_name']) ?><br><span class="af-muted"><?= e($s['email']) ?></span></td>
                <td><?= e($s['plan_name']) ?></td>
                <td style="text-transform:capitalize;"><?= e($s['status']) ?></td>
                <td><?= $s['starts_at'] ? e(date('d M Y', strtotime($s['starts_at']))) : '—' ?></td>
                <td><?= $s['ends_at'] ? e(date('d M Y', strtotime($s['ends_at']))) : '—' ?></td>
                <td>
                    <?php if ($s['status'] === 'active'): ?>
                        <form method="post" data-confirm="Cancel this subscription?">
                            <?= csrf_field() ?><input type="hidden" name="action" value="cancel_subscription">
                            <input type="hidden" name="subscription_id" value="<?= (int) $s['id'] ?>">
                            <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px; color:var(--red);">Cancel</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$subs): ?><tr><td colspan="6" class="af-muted">No subscriptions yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
