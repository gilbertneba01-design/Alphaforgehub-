<?php
/**
 * ALPHA FORGE HUB (ADMIN) - Community Moderation
 * Admins can pin/unpin and delete any post or comment. Regular moderation
 * of one's own content happens on community.php / community_post.php.
 */
$pageTitle = 'Community';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'toggle_pin') {
        $id = (int) $_POST['id'];
        $stmt = db()->prepare('SELECT is_pinned FROM community_posts WHERE id = ?');
        $stmt->execute([$id]);
        $current = (int) $stmt->fetchColumn();
        db()->prepare('UPDATE community_posts SET is_pinned = ? WHERE id = ?')->execute([$current ? 0 : 1, $id]);
    } elseif ($action === 'delete_post') {
        db()->prepare('DELETE FROM community_posts WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Post deleted.');
    } elseif ($action === 'delete_comment') {
        db()->prepare('DELETE FROM community_comments WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Comment deleted.');
    } elseif ($action === 'toggle_lock') {
        db()->prepare('UPDATE community_posts SET is_locked = 1 - is_locked WHERE id = ?')->execute([(int) $_POST['id']]);
    } elseif ($action === 'toggle_hide') {
        db()->prepare('UPDATE community_posts SET is_hidden = 1 - is_hidden WHERE id = ?')->execute([(int) $_POST['id']]);
    } elseif ($action === 'hide_comment') {
        db()->prepare('UPDATE community_comments SET is_hidden = 1 WHERE id = ?')->execute([(int) $_POST['id']]);
    } elseif ($action === 'resolve_report') {
        db()->prepare("UPDATE community_reports SET status='resolved' WHERE id = ?")->execute([(int) $_POST['id']]);
    }
    redirect('/admin/community.php');
}

$posts = db()->query(
    "SELECT p.*, u.full_name, (SELECT COUNT(*) FROM community_comments c WHERE c.post_id = p.id) AS comment_count
     FROM community_posts p JOIN users u ON u.id = p.user_id ORDER BY p.created_at DESC LIMIT 200"
)->fetchAll();

$recentComments = db()->query(
    "SELECT c.*, u.full_name, p.title AS post_title
     FROM community_comments c JOIN users u ON u.id = c.user_id JOIN community_posts p ON p.id = c.post_id
     ORDER BY c.created_at DESC LIMIT 50"
)->fetchAll();
try {
    $reports = db()->query(
        "SELECT r.*, u.full_name AS reporter_name, p.title AS post_title
         FROM community_reports r JOIN users u ON u.id = r.reporter_id LEFT JOIN community_posts p ON p.id = r.post_id
         WHERE r.status = 'open' ORDER BY r.created_at DESC"
    )->fetchAll();
} catch (Throwable $ex) { $reports = []; }
?>
<h3 style="margin-top:0;">Open Reports (<?= count($reports) ?>)</h3>
<?php if (!$reports): ?><p class="af-muted">No open reports.</p><?php endif; ?>
<?php foreach ($reports as $r): ?>
    <div class="af-card" style="margin-bottom:8px;">
        <p class="af-muted" style="margin:0 0 4px;">Reported by <?= e($r['reporter_name']) ?><?= $r['post_title'] ? ' on "' . e($r['post_title']) . '"' : '' ?></p>
        <p style="margin:0;"><?= e($r['reason']) ?></p>
        <form method="post" style="margin-top:8px;"><?= csrf_field() ?><input type="hidden" name="action" value="resolve_report"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
            <button type="submit" class="af-btn af-btn-ghost af-btn-sm">Mark Resolved</button></form>
    </div>
<?php endforeach; ?>
<h1>Community Moderation</h1>

<h3 style="margin-top:20px;">Posts</h3>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Title</th><th>Author</th><th>Category</th><th>Replies</th><th>Pinned</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($posts as $p): ?>
            <tr>
                <td><a href="<?= APP_URL ?>/community_post.php?id=<?= (int) $p['id'] ?>" target="_blank"><?= e($p['title']) ?></a></td>
                <td><?= e($p['full_name']) ?></td>
                <td style="text-transform:capitalize;"><?= e(str_replace('_', ' ', $p['category'])) ?></td>
                <td><?= (int) $p['comment_count'] ?></td>
                <td><?= $p['is_pinned'] ? 'Yes' : 'No' ?></td>
                <td style="white-space:nowrap;">
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_pin"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px;"><?= $p['is_pinned'] ? 'Unpin' : 'Pin' ?></button>
                    </form>
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_lock"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px;"><?= !empty($p['is_locked']) ? 'Unlock' : 'Lock' ?></button>
                    </form>
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_hide"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px;"><?= !empty($p['is_hidden']) ? 'Unhide' : 'Hide' ?></button>
                    </form>
                    <form method="post" style="display:inline;" data-confirm="Delete this post and its comments?"><?= csrf_field() ?><input type="hidden" name="action" value="delete_post"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$posts): ?><tr><td colspan="6" class="af-muted">No posts yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<h3 style="margin-top:30px;">Recent Comments</h3>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Comment</th><th>Author</th><th>On Post</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($recentComments as $c): ?>
            <tr>
                <td style="max-width:320px;"><?= e(mb_substr($c['body'], 0, 140)) ?></td>
                <td><?= e($c['full_name']) ?></td>
                <td><?= e($c['post_title']) ?></td>
                <td>
                    <form method="post" data-confirm="Delete this comment?"><?= csrf_field() ?><input type="hidden" name="action" value="delete_comment"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$recentComments): ?><tr><td colspan="4" class="af-muted">No comments yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
