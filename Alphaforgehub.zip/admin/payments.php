<?php
$pageTitle = 'Payments';
require_once __DIR__ . '/includes/admin_header.php';

$statusFilter = $_GET['status'] ?? '';
$sql = "SELECT p.*, u.full_name, u.email FROM payments p JOIN users u ON u.id = p.user_id";
$params = [];
if ($statusFilter !== '') {
    $sql .= " WHERE p.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY p.created_at DESC LIMIT 200";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();
?>
<h1>Payments</h1>

<form method="get" style="max-width:260px; margin-bottom:16px;">
    <div class="af-field"><label>Filter by status</label>
        <select name="status" data-autosubmit>
            <option value="">All</option>
            <?php foreach (['initiated','pending','successful','failed','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Student</th><th>Amount</th><th>Provider</th><th>Reference</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <?php foreach ($payments as $p): ?>
            <tr>
                <td><?= e($p['full_name']) ?><br><span class="af-muted"><?= e($p['email']) ?></span></td>
                <td><?= format_money((float) $p['amount'], $p['currency']) ?></td>
                <td><?= e(str_replace('_', ' ', $p['provider'])) ?></td>
                <td class="af-muted"><?= e($p['provider_reference'] ?? '—') ?></td>
                <td style="text-transform:capitalize;"><?= e($p['status']) ?></td>
                <td><?= e(date('d M Y, H:i', strtotime($p['created_at']))) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$payments): ?><tr><td colspan="6" class="af-muted">No payments found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
