<?php
$pageTitle = 'Courses';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $id = (int) ($_POST['course_id'] ?? 0);

    if (isset($_POST['toggle_status'])) {
        $stmt = db()->prepare('SELECT status FROM courses WHERE id = ?');
        $stmt->execute([$id]);
        $current = $stmt->fetchColumn();
        $new = $current === 'published' ? 'draft' : 'published';
        db()->prepare('UPDATE courses SET status = ? WHERE id = ?')->execute([$new, $id]);
        flash_set('success', 'Course status updated.');
    } elseif (isset($_POST['delete_course'])) {
        db()->prepare('DELETE FROM courses WHERE id = ?')->execute([$id]);
        flash_set('success', 'Course deleted.');
    }
    redirect('/admin/courses.php');
}

$courses = db()->query('SELECT * FROM courses ORDER BY sort_order')->fetchAll();
?>
<div style="display:flex; justify-content:space-between; align-items:center;">
    <h1>Courses</h1>
    <a href="<?= APP_URL ?>/admin/add_course.php" class="af-btn af-btn-gold">Add Course</a>
</div>

<div class="af-table-wrap" style="margin-top:16px;">
    <table class="af-table">
        <thead><tr><th>Title</th><th>Level</th><th>Premium</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($courses as $c): ?>
            <tr>
                <td><?= e($c['title']) ?></td>
                <td><?= e($c['level']) ?></td>
                <td><?= $c['is_premium'] ? 'Yes' : 'No' ?></td>
                <td style="text-transform:capitalize;"><?= e($c['status']) ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/edit_course.php?id=<?= (int) $c['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">Edit</a>
                    <form method="post" style="display:inline;">
                        <?= csrf_field() ?><input type="hidden" name="course_id" value="<?= (int) $c['id'] ?>">
                        <button type="submit" name="toggle_status" value="1" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;"><?= $c['status'] === 'published' ? 'Unpublish' : 'Publish' ?></button>
                    </form>
                    <form method="post" style="display:inline;" data-confirm="Delete this course and all its modules/lessons?">
                        <?= csrf_field() ?><input type="hidden" name="course_id" value="<?= (int) $c['id'] ?>">
                        <button type="submit" name="delete_course" value="1" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$courses): ?><tr><td colspan="5" class="af-muted">No courses yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
