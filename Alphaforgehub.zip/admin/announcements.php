<?php
/** ALPHA FORGE HUB - Announcements management (ADMIN ONLY). Enforced by require_admin() in admin_header AND re-checked before every write. */
require_once __DIR__ . '/../config/functions.php';
require_admin();
$admin = current_user();
const ANN_KINDS = ['maintenance', 'feature', 'academic', 'course', 'system'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    if (!is_admin()) { http_response_code(403); die('Access denied.'); } // belt and braces: server-side rule
    $action = (string) ($_POST['action'] ?? '');
    if ($action === 'create' || $action === 'update') {
        $title = post_text('title', 190);
        $body  = post_text('body', 5000);
        $kind  = in_array($_POST['kind'] ?? '', ANN_KINDS, true) ? $_POST['kind'] : 'system';
        $pin   = !empty($_POST['is_pinned']) ? 1 : 0;
        $status = ($_POST['status'] ?? 'published') === 'draft' ? 'draft' : 'published';
        if ($title === '' || $body === '') {
            flash_set('error', t('err_required'));
        } elseif ($action === 'create') {
            db()->prepare('INSERT INTO announcements (title, body, kind, is_pinned, status, created_by) VALUES (?,?,?,?,?,?)')
                ->execute([$title, $body, $kind, $pin, $status, $admin['id']]);
            if ($status === 'published') notify_all_students('announcement', t('ann_notified') . ': ' . $title, mb_substr($body, 0, 200), '/announcements.php');
            flash_set('success', t('ok_saved'));
        } else {
            db()->prepare('UPDATE announcements SET title=?, body=?, kind=?, is_pinned=?, status=? WHERE id=?')
                ->execute([$title, $body, $kind, $pin, $status, (int) $_POST['id']]);
            flash_set('success', t('ok_saved'));
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM announcements WHERE id = ?')->execute([(int) ($_POST['id'] ?? 0)]);
        flash_set('success', t('ok_deleted'));
    }
    redirect('/admin/announcements.php');
}

$editing = null;
if (!empty($_GET['edit'])) {
    $s = db()->prepare('SELECT * FROM announcements WHERE id = ?'); $s->execute([(int) $_GET['edit']]); $editing = $s->fetch() ?: null;
}
try { $rows = db()->query('SELECT * FROM announcements ORDER BY is_pinned DESC, created_at DESC')->fetchAll(); }
catch (Throwable $ex) { $rows = []; flash_set('error', 'Run database/migration_v3_audit.sql first.'); }

$pageTitle = t('ann_title');
require_once __DIR__ . '/includes/admin_header.php';
?>
<div>
    <h1><?= te('ann_title') ?></h1>
    <form method="post" class="af-card" style="margin-bottom:18px;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editing ? 'update' : 'create' ?>">
        <?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><?php endif; ?>
        <h3 style="margin-top:0;"><?= $editing ? te('btn_edit') : te('ann_new') ?></h3>
        <div class="af-field"><label><?= te('ann_field_title') ?></label><input type="text" name="title" maxlength="190" required value="<?= e($editing['title'] ?? '') ?>"></div>
        <div class="af-field"><label><?= te('ann_field_kind') ?></label>
            <select name="kind"><?php foreach (ANN_KINDS as $k): ?><option value="<?= $k ?>" <?= ($editing['kind'] ?? 'system') === $k ? 'selected' : '' ?>><?= te('ann_kind_' . $k) ?></option><?php endforeach; ?></select></div>
        <div class="af-field"><label><?= te('ann_field_body') ?></label><textarea name="body" rows="5" maxlength="5000" required><?= e($editing['body'] ?? '') ?></textarea></div>
        <div class="af-field"><label><input type="checkbox" name="is_pinned" value="1" <?= !empty($editing['is_pinned']) ? 'checked' : '' ?>> <?= te('ann_pinned') ?></label></div>
        <div class="af-field"><label>Status</label>
            <select name="status"><option value="published" <?= ($editing['status'] ?? 'published') === 'published' ? 'selected' : '' ?>>Published</option><option value="draft" <?= ($editing['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option></select></div>
        <button class="af-btn af-btn-gold" type="submit"><?= te('btn_save') ?></button>
        <?php if ($editing): ?><a class="af-btn af-btn-ghost" href="<?= APP_URL ?>/admin/announcements.php"><?= te('btn_cancel') ?></a><?php endif; ?>
    </form>
    <?php if (!$rows): ?><p class="af-muted"><?= te('ann_empty') ?></p><?php endif; ?>
    <div class="af-table-wrap"><table class="af-table">
        <?php if ($rows): ?><thead><tr><th><?= te('ann_field_title') ?></th><th><?= te('ann_field_kind') ?></th><th>Status</th><th></th></tr></thead><?php endif; ?>
        <tbody>
        <?php foreach ($rows as $a): ?>
            <tr>
                <td><?= $a['is_pinned'] ? '&#128204; ' : '' ?><?= e($a['title']) ?></td>
                <td><?= te('ann_kind_' . $a['kind']) ?></td>
                <td><?= e($a['status']) ?></td>
                <td style="white-space:nowrap;">
                    <a class="af-btn af-btn-ghost af-btn-sm" href="?edit=<?= (int) $a['id'] ?>"><?= te('btn_edit') ?></a>
                    <form method="post" style="display:inline;" data-confirm="<?= te('confirm_delete') ?>">
                        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
                        <button class="af-btn af-btn-ghost af-btn-sm" style="color:var(--red);" type="submit"><?= te('btn_delete') ?></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
