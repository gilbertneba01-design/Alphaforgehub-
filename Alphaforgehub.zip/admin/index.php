<?php
$pageTitle = 'Admin Dashboard';
require_once __DIR__ . '/includes/admin_header.php';

$pdo = db();
$stats = [
    'students' => $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn(),
    'active_subs' => $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status = 'active' AND (ends_at IS NULL OR ends_at > NOW())")->fetchColumn(),
    'expired_subs' => $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status = 'expired'")->fetchColumn(),
    'courses' => $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn(),
    'lessons' => $pdo->query("SELECT COUNT(*) FROM lessons")->fetchColumn(),
    'subscriptions' => $pdo->query("SELECT COUNT(*) FROM subscriptions")->fetchColumn(),
    'successful_payments' => $pdo->query("SELECT COUNT(*) FROM payments WHERE status = 'successful'")->fetchColumn(),
    'pending_payments' => $pdo->query("SELECT COUNT(*) FROM payments WHERE status IN ('initiated','pending')")->fetchColumn(),
];

$recentUsers = $pdo->query("SELECT full_name, email, created_at FROM users WHERE role = 'student' ORDER BY created_at DESC LIMIT 6")->fetchAll();
$recentPayments = $pdo->query(
    "SELECT p.*, u.full_name FROM payments p JOIN users u ON u.id = p.user_id ORDER BY p.created_at DESC LIMIT 6"
)->fetchAll();
?>
<h1>Admin Dashboard</h1>
<div class="af-grid af-grid-3" style="margin-top:20px;">
    <div class="af-card"><p class="af-muted" style="margin:0;">Total Students</p><h3 style="font-size:28px;"><?= (int) $stats['students'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Active Subscribers</p><h3 style="font-size:28px; color:var(--green);"><?= (int) $stats['active_subs'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Expired Subscribers</p><h3 style="font-size:28px;"><?= (int) $stats['expired_subs'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Total Courses</p><h3 style="font-size:28px;"><?= (int) $stats['courses'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Total Lessons</p><h3 style="font-size:28px;"><?= (int) $stats['lessons'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Total Subscriptions</p><h3 style="font-size:28px;"><?= (int) $stats['subscriptions'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Successful Payments</p><h3 style="font-size:28px; color:var(--green);"><?= (int) $stats['successful_payments'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Pending Payments</p><h3 style="font-size:28px;"><?= (int) $stats['pending_payments'] ?></h3></div>
</div>

<h2 style="margin-top:36px;">Recent Users</h2>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Name</th><th>Email</th><th>Registered</th></tr></thead>
        <tbody>
        <?php foreach ($recentUsers as $u): ?>
            <tr><td><?= e($u['full_name']) ?></td><td><?= e($u['email']) ?></td><td><?= e(date('d M Y', strtotime($u['created_at']))) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<h2 style="margin-top:36px;">Recent Transactions</h2>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Student</th><th>Amount</th><th>Provider</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <?php foreach ($recentPayments as $p): ?>
            <tr>
                <td><?= e($p['full_name']) ?></td>
                <td><?= format_money((float) $p['amount'], $p['currency']) ?></td>
                <td><?= e(str_replace('_', ' ', $p['provider'])) ?></td>
                <td style="text-transform:capitalize;"><?= e($p['status']) ?></td>
                <td><?= e(date('d M Y', strtotime($p['created_at']))) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
