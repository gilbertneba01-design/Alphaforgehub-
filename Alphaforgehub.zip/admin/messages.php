<?php
$pageTitle = 'Messages';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $id = (int) ($_POST['id'] ?? 0);
    if (isset($_POST['mark_read'])) {
        db()->prepare('UPDATE contact_messages SET is_read = 1 WHERE id = ?')->execute([$id]);
    } elseif (isset($_POST['delete'])) {
        db()->prepare('DELETE FROM contact_messages WHERE id = ?')->execute([$id]);
        flash_set('success', 'Message deleted.');
    }
    redirect('/admin/messages.php');
}

$messages = db()->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll();
?>
<h1>Contact Messages</h1>

<?php foreach ($messages as $m): ?>
    <div class="af-card" style="margin-bottom:14px; <?= $m['is_read'] ? 'opacity:0.7;' : '' ?>">
        <div style="display:flex; justify-content:space-between;">
            <h3 style="font-size:16px;"><?= e($m['name']) ?> &lt;<?= e($m['email']) ?>&gt;</h3>
            <span class="af-muted"><?= e(date('d M Y, H:i', strtotime($m['created_at']))) ?></span>
        </div>
        <p><?= nl2br(e($m['message'])) ?></p>
        <div style="display:flex; gap:10px;">
            <?php if (!$m['is_read']): ?>
                <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><button type="submit" name="mark_read" value="1" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">Mark Read</button></form>
            <?php endif; ?>
            <form method="post" data-confirm="Delete this message?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><button type="submit" name="delete" value="1" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px; color:var(--red);">Delete</button></form>
        </div>
    </div>
<?php endforeach; ?>
<?php if (!$messages): ?><p class="af-muted">No messages yet.</p><?php endif; ?>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
