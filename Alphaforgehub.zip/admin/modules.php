<?php
$pageTitle = 'Modules';
require_once __DIR__ . '/includes/admin_header.php';

$courses = db()->query('SELECT id, title FROM courses ORDER BY sort_order')->fetchAll();
$selectedCourseId = (int) ($_GET['course_id'] ?? ($courses[0]['id'] ?? 0));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $courseId = (int) $_POST['course_id'];
        if ($title !== '') {
            $stmt = db()->prepare('SELECT COALESCE(MAX(sort_order),0) FROM modules WHERE course_id = ?');
            $stmt->execute([$courseId]);
            $maxOrder = (int) $stmt->fetchColumn();
            $ins = db()->prepare('INSERT INTO modules (course_id, title, description, sort_order) VALUES (?, ?, ?, ?)');
            $ins->execute([$courseId, $title, $description, $maxOrder + 1]);
            flash_set('success', 'Module created.');
        }
        redirect('/admin/modules.php?course_id=' . $courseId);
    } elseif ($action === 'update') {
        $id = (int) $_POST['module_id'];
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        db()->prepare('UPDATE modules SET title = ?, description = ? WHERE id = ?')->execute([$title, $description, $id]);
        flash_set('success', 'Module updated.');
        redirect('/admin/modules.php?course_id=' . $selectedCourseId);
    } elseif ($action === 'delete') {
        $id = (int) $_POST['module_id'];
        db()->prepare('DELETE FROM modules WHERE id = ?')->execute([$id]);
        flash_set('success', 'Module deleted.');
        redirect('/admin/modules.php?course_id=' . $selectedCourseId);
    }
}

$modStmt = db()->prepare('SELECT * FROM modules WHERE course_id = ? ORDER BY sort_order');
$modStmt->execute([$selectedCourseId]);
$modules = $modStmt->fetchAll();
?>
<h1>Modules</h1>

<form method="get" style="max-width:320px; margin-bottom:20px;">
    <div class="af-field"><label>Course</label>
        <select name="course_id" data-autosubmit>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['id'] ?>" <?= $selectedCourseId === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<?php foreach ($modules as $m): ?>
    <div class="af-card" style="margin-bottom:14px;">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="module_id" value="<?= (int) $m['id'] ?>">
            <div class="af-field"><label>Title</label><input type="text" name="title" value="<?= e($m['title']) ?>"></div>
            <div class="af-field"><label>Description</label><textarea name="description" rows="2"><?= e($m['description']) ?></textarea></div>
            <div style="display:flex; gap:10px;">
                <button type="submit" class="af-btn af-btn-ghost">Save</button>
            </div>
        </form>
        <form method="post" style="margin-top:10px;" data-confirm="Delete this module and all its lessons?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="module_id" value="<?= (int) $m['id'] ?>">
            <button type="submit" class="af-btn af-btn-ghost" style="color:var(--red);">Delete Module</button>
        </form>
    </div>
<?php endforeach; ?>
<?php if (!$modules): ?><p class="af-muted">No modules yet for this course.</p><?php endif; ?>

<div class="af-card" style="max-width:520px; margin-top:24px;">
    <h3>Add Module</h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <input type="hidden" name="course_id" value="<?= $selectedCourseId ?>">
        <div class="af-field"><label>Title</label><input type="text" name="title" required></div>
        <div class="af-field"><label>Description</label><textarea name="description" rows="2"></textarea></div>
        <button type="submit" class="af-btn af-btn-gold">Add Module</button>
    </form>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
