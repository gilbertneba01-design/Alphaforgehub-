<?php
$pageTitle = 'Settings';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $keys = ['site_name', 'site_tagline', 'contact_email'];
    foreach ($keys as $key) {
        $value = trim($_POST[$key] ?? '');
        $stmt = db()->prepare('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?');
        $stmt->execute([$value, $key]);
    }
    flash_set('success', 'Settings saved.');
    redirect('/admin/settings.php');
}

$settings = [];
foreach (db()->query('SELECT setting_key, setting_value FROM site_settings')->fetchAll() as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>
<h1>Site Settings</h1>
<form method="post" class="af-card" style="max-width:560px;">
    <?= csrf_field() ?>
    <div class="af-field"><label>Site Name</label><input type="text" name="site_name" value="<?= e($settings['site_name'] ?? '') ?>"></div>
    <div class="af-field"><label>Tagline</label><input type="text" name="site_tagline" value="<?= e($settings['site_tagline'] ?? '') ?>"></div>
    <div class="af-field"><label>Contact Email</label><input type="email" name="contact_email" value="<?= e($settings['contact_email'] ?? '') ?>"></div>
    <button type="submit" class="af-btn af-btn-gold">Save Settings</button>
</form>

<h2 style="margin-top:32px;">Payment Provider Status</h2>
<div class="af-card" style="max-width:560px;">
    <p>MTN Mobile Money: <strong><?= (MTN_MOMO_API_KEY !== '' && MTN_MOMO_API_USER !== '' && MTN_MOMO_SUBSCRIPTION_KEY !== '') ? 'Configured' : 'Not configured' ?></strong></p>
    <p>Orange Money: <strong><?= (ORANGE_MONEY_CLIENT_ID !== '' && ORANGE_MONEY_CLIENT_SECRET !== '' && ORANGE_MONEY_MERCHANT_KEY !== '') ? 'Configured' : 'Not configured' ?></strong></p>
    <p class="af-muted">Provider credentials are set as environment variables (or in config/.env.php) — see the installation instructions for the exact keys required.</p>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
