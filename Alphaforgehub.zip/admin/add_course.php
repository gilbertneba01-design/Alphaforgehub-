<?php
$pageTitle = 'Add Course';
require_once __DIR__ . '/includes/admin_header.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $level = $_POST['level'] ?? 'Beginner';
    $price = (float) ($_POST['price'] ?? 0);
    $isPremium = isset($_POST['is_premium']) ? 1 : 0;
    $status = $_POST['status'] ?? 'draft';

    if ($title === '') $errors[] = 'Title is required.';

    if (!$errors) {
        $slug = slugify($title);
        $check = db()->prepare('SELECT id FROM courses WHERE slug = ?');
        $check->execute([$slug]);
        if ($check->fetch()) {
            $slug .= '-' . substr(bin2hex(random_bytes(2)), 0, 4);
        }
        $maxOrder = (int) db()->query('SELECT COALESCE(MAX(sort_order),0) FROM courses')->fetchColumn();

        $stmt = db()->prepare(
            'INSERT INTO courses (title, slug, description, level, price, is_premium, status, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$title, $slug, $description, $level, $price, $isPremium, $status, $maxOrder + 1]);
        flash_set('success', 'Course created.');
        redirect('/admin/courses.php');
    }
}
?>
<h1>Add Course</h1>
<?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" class="af-card" style="max-width:560px;">
    <?= csrf_field() ?>
    <div class="af-field"><label>Title</label><input type="text" name="title" value="<?= e($_POST['title'] ?? '') ?>" required></div>
    <div class="af-field"><label>Description</label><textarea name="description" rows="4"><?= e($_POST['description'] ?? '') ?></textarea></div>
    <div class="af-field"><label>Level</label>
        <select name="level">
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
        </select>
    </div>
    <div class="af-field"><label>Price</label><input type="number" step="0.01" name="price" value="0"></div>
    <div class="af-field"><label><input type="checkbox" name="is_premium" value="1"> Premium course (requires active subscription)</label></div>
    <div class="af-field"><label>Status</label>
        <select name="status"><option value="draft">Draft</option><option value="published">Published</option></select>
    </div>
    <button type="submit" class="af-btn af-btn-gold">Create Course</button>
</form>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
