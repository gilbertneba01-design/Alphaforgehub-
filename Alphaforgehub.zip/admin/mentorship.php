<?php
$pageTitle = 'Mentorship';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_mentor') {
        db()->prepare('INSERT INTO mentors (name, headline, bio, status) VALUES (?,?,?,?)')
            ->execute([trim($_POST['name']), trim($_POST['headline']) ?: null, trim($_POST['bio']) ?: null, 'active']);
        flash_set('success', 'Mentor added.');
    } elseif ($action === 'link_user') {
        // Links a mentor profile to a login account with role='mentor'. This is what lets
        // that person sign in and see the Mentor Dashboard / private chat / feedback tools.
        $mentorId = (int) $_POST['mentor_id'];
        $userId   = (int) $_POST['user_id'];
        if ($mentorId && $userId) {
            db()->prepare("UPDATE users SET role = 'mentor' WHERE id = ?")->execute([$userId]);
            db()->prepare('UPDATE mentors SET user_id = ? WHERE id = ?')->execute([$userId, $mentorId]);
            flash_set('success', 'Mentor profile linked to that account.');
        }
    } elseif ($action === 'unlink_user') {
        $mentorId = (int) $_POST['mentor_id'];
        $s = db()->prepare('SELECT user_id FROM mentors WHERE id = ?'); $s->execute([$mentorId]); $uid = $s->fetchColumn();
        db()->prepare('UPDATE mentors SET user_id = NULL WHERE id = ?')->execute([$mentorId]);
        if ($uid) db()->prepare("UPDATE users SET role = 'student' WHERE id = ? AND role = 'mentor'")->execute([$uid]);
        flash_set('success', 'Mentor account unlinked (reverted to student).');
    } elseif ($action === 'toggle_mentor') {
        $id = (int) $_POST['id'];
        $stmt = db()->prepare('SELECT status FROM mentors WHERE id = ?');
        $stmt->execute([$id]);
        $cur = $stmt->fetchColumn();
        db()->prepare('UPDATE mentors SET status = ? WHERE id = ?')->execute([$cur === 'active' ? 'inactive' : 'active', $id]);
        flash_set('success', 'Mentor status updated.');
    } elseif ($action === 'update_request') {
        $id = (int) $_POST['id'];
        $status = $_POST['status'];
        $notes = trim($_POST['admin_notes'] ?? '');
        if (in_array($status, ['pending', 'scheduled', 'completed', 'declined'], true)) {
            db()->prepare('UPDATE mentorship_requests SET status = ?, admin_notes = ? WHERE id = ?')->execute([$status, $notes ?: null, $id]);
            flash_set('success', 'Request updated.');
        }
    }
    redirect('/admin/mentorship.php');
}

$mentors = db()->query("SELECT m.*, u.full_name AS linked_name, u.email AS linked_email FROM mentors m LEFT JOIN users u ON u.id = m.user_id ORDER BY m.name")->fetchAll();
$linkableUsers = db()->query("SELECT id, full_name, email FROM users WHERE role IN ('student','mentor') ORDER BY full_name")->fetchAll();
$requests = db()->query('SELECT mr.*, u.full_name, m.name AS mentor_name FROM mentorship_requests mr JOIN users u ON u.id = mr.user_id JOIN mentors m ON m.id = mr.mentor_id ORDER BY mr.created_at DESC LIMIT 50')->fetchAll();
?>
<h1>Mentorship</h1>

<div class="af-card" style="padding:20px; margin-bottom:20px;">
    <h2>Add Mentor</h2>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_mentor">
        <div class="af-field"><label>Name</label><input type="text" name="name" required></div>
        <div class="af-field"><label>Headline</label><input type="text" name="headline" placeholder="e.g. 8 years prop-firm trading"></div>
        <div class="af-field"><label>Bio</label><textarea name="bio" rows="3"></textarea></div>
        <button type="submit" class="af-btn af-btn-gold">Add Mentor</button>
    </form>
</div>

<div class="af-table-wrap" style="margin-bottom:24px;">
    <table class="af-table">
        <thead><tr><th>Name</th><th>Headline</th><th>Status</th><th>Login Account</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($mentors as $m): ?>
            <tr>
                <td><?= e($m['name']) ?></td><td><?= e($m['headline'] ?? '') ?></td><td><?= e($m['status']) ?></td>
                <td>
                    <?php if ($m['user_id']): ?>
                        Linked: <?= e($m['linked_name']) ?> (<?= e($m['linked_email']) ?>)
                        <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="unlink_user"><input type="hidden" name="mentor_id" value="<?= $m['id'] ?>"><button class="af-btn af-btn-ghost af-btn-sm">Unlink</button></form>
                    <?php else: ?>
                        <form method="post" style="display:flex;gap:6px;"><?= csrf_field() ?><input type="hidden" name="action" value="link_user"><input type="hidden" name="mentor_id" value="<?= $m['id'] ?>">
                            <select name="user_id" required><option value="">Select login account...</option>
                                <?php foreach ($linkableUsers as $u): ?><option value="<?= (int) $u['id'] ?>"><?= e($u['full_name']) ?> (<?= e($u['email']) ?>)</option><?php endforeach; ?>
                            </select>
                            <button class="af-btn af-btn-gold af-btn-sm">Link</button>
                        </form>
                    <?php endif; ?>
                </td>
                <td><form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_mentor"><input type="hidden" name="id" value="<?= $m['id'] ?>"><button class="af-btn af-btn-ghost af-btn-sm">Toggle Active</button></form></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<h2>Requests</h2>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Student</th><th>Mentor</th><th>Message</th><th>Status</th><th>Update</th></tr></thead>
        <tbody>
        <?php foreach ($requests as $r): ?>
            <tr>
                <td><?= e($r['full_name']) ?></td>
                <td><?= e($r['mentor_name']) ?></td>
                <td style="max-width:280px;"><?= e($r['message']) ?></td>
                <td><?= e($r['status']) ?></td>
                <td>
                    <form method="post" style="display:flex; gap:6px;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update_request">
                        <input type="hidden" name="id" value="<?= $r['id'] ?>">
                        <select name="status">
                            <?php foreach (['pending','scheduled','completed','declined'] as $s): ?>
                                <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="admin_notes" placeholder="notes" value="<?= e($r['admin_notes'] ?? '') ?>">
                        <button class="af-btn af-btn-ghost af-btn-sm">Save</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
