<?php
$pageTitle = 'Security Log';
require_once __DIR__ . '/includes/admin_header.php';

$typeFilter = $_GET['type'] ?? '';
$sql = "SELECT sl.*, u.email AS user_email FROM security_log sl LEFT JOIN users u ON u.id = sl.user_id";
$params = [];
if ($typeFilter !== '') {
    $sql .= " WHERE sl.event_type = ?";
    $params[] = $typeFilter;
}
$sql .= " ORDER BY sl.created_at DESC LIMIT 300";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

$types = db()->query("SELECT DISTINCT event_type FROM security_log ORDER BY event_type")->fetchAll(PDO::FETCH_COLUMN);
?>
<h1>Security Log</h1>
<p class="af-muted">Failed logins, rate-limit blocks, and 2FA activity, most recent first.</p>

<form method="get" style="max-width:280px; margin:16px 0;">
    <div class="af-field"><label>Filter by event type</label>
        <select name="type" data-autosubmit>
            <option value="">All</option>
            <?php foreach ($types as $t): ?>
                <option value="<?= e($t) ?>" <?= $typeFilter === $t ? 'selected' : '' ?>><?= e($t) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Event</th><th>IP Address</th><th>Account</th><th>Detail</th><th>When</th></tr></thead>
        <tbody>
        <?php foreach ($events as $ev): ?>
            <tr>
                <td><?= e($ev['event_type']) ?></td>
                <td class="af-muted"><?= e($ev['ip_address']) ?></td>
                <td><?= e($ev['user_email'] ?? '—') ?></td>
                <td class="af-muted"><?= e($ev['detail'] ?? '') ?></td>
                <td><?= e(date('d M Y, H:i', strtotime($ev['created_at']))) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$events): ?><tr><td colspan="5" class="af-muted">No events recorded yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
