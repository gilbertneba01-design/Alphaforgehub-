<?php
/**
 * ALPHA FORGE HUB (ADMIN) - Live Sessions
 */
$pageTitle = 'Live Sessions';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id       = (int) ($_POST['id'] ?? 0);
        $title    = trim($_POST['title'] ?? '');
        $desc     = trim($_POST['description'] ?? '');
        $datetime = trim($_POST['session_datetime'] ?? '');
        $joinUrl  = trim($_POST['join_url'] ?? '');
        $recUrl   = trim($_POST['recording_url'] ?? '');
        $status   = in_array($_POST['status'] ?? '', ['scheduled', 'completed', 'cancelled'], true) ? $_POST['status'] : 'scheduled';

        if ($title !== '' && $datetime !== '') {
            $params = [$title, $desc ?: null, date('Y-m-d H:i:s', strtotime($datetime)), $joinUrl ?: null, $recUrl ?: null, $status];
            if ($id) {
                db()->prepare('UPDATE live_sessions SET title=?, description=?, session_datetime=?, join_url=?, recording_url=?, status=? WHERE id=?')
                    ->execute([...$params, $id]);
                flash_set('success', 'Session updated.');
            } else {
                db()->prepare('INSERT INTO live_sessions (title, description, session_datetime, join_url, recording_url, status) VALUES (?,?,?,?,?,?)')
                    ->execute($params);
                flash_set('success', 'Session scheduled.');
            }
        } else {
            flash_set('error', 'Title and date/time are required.');
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM live_sessions WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Session deleted.');
    }
    redirect('/admin/live_sessions.php');
}

$editing = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM live_sessions WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$sessions = db()->query('SELECT * FROM live_sessions ORDER BY session_datetime DESC LIMIT 200')->fetchAll();
?>
<h1>Live Sessions</h1>

<div class="af-card" style="max-width:700px; margin:18px 0;">
    <h3><?= $editing ? 'Edit Session' : 'Schedule Session' ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing ? (int) $editing['id'] : 0 ?>">
        <div class="af-field"><label>Title</label><input type="text" name="title" value="<?= e($editing['title'] ?? '') ?>" required></div>
        <div class="af-field"><label>Description</label><textarea name="description" rows="3"><?= e($editing['description'] ?? '') ?></textarea></div>
        <div class="af-grid af-grid-2" style="gap:12px;">
            <div class="af-field"><label>Date &amp; Time</label><input type="datetime-local" name="session_datetime" value="<?= $editing ? date('Y-m-d\TH:i', strtotime($editing['session_datetime'])) : '' ?>" required></div>
            <div class="af-field"><label>Status</label>
                <select name="status">
                    <?php foreach (['scheduled' => 'Scheduled', 'completed' => 'Completed', 'cancelled' => 'Cancelled'] as $k => $l): ?>
                        <option value="<?= e($k) ?>" <?= ($editing['status'] ?? 'scheduled') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="af-field"><label>Join URL (Zoom, Meet, etc.)</label><input type="url" name="join_url" value="<?= e($editing['join_url'] ?? '') ?>"></div>
        <div class="af-field"><label>Recording URL (after it's over)</label><input type="url" name="recording_url" value="<?= e($editing['recording_url'] ?? '') ?>"></div>
        <button type="submit" class="af-btn af-btn-gold"><?= $editing ? 'Save Changes' : 'Schedule Session' ?></button>
        <?php if ($editing): ?><a href="<?= APP_URL ?>/admin/live_sessions.php" class="af-btn af-btn-ghost">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Date</th><th>Title</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($sessions as $s): ?>
            <tr>
                <td><?= e(date('d M Y H:i', strtotime($s['session_datetime']))) ?></td>
                <td><?= e($s['title']) ?></td>
                <td style="text-transform:capitalize;"><?= e($s['status']) ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/live_sessions.php?edit=<?= (int) $s['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 10px;">Edit</a>
                    <form method="post" style="display:inline;" data-confirm="Delete this session?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$sessions): ?><tr><td colspan="4" class="af-muted">No sessions yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
