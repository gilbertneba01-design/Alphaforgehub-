<?php
require_once __DIR__ . '/../config/functions.php';

if (is_logged_in() && is_admin()) {
    redirect('/admin/index.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!enforce_rate_limit('admin_login', 5, 300, 600)) {
        rate_limit_block_response();
    }

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        log_security_event('admin_login_failed', 'unknown email');
        $errors[] = 'Invalid credentials.';
    } elseif (is_account_locked($user)) {
        $errors[] = 'This account is temporarily locked. Try again shortly.';
    } elseif (!password_verify($password, $user['password_hash'])) {
        register_failed_login((int) $user['id'], (int) $user['failed_login_count']);
        log_security_event('admin_login_failed', 'wrong password', (int) $user['id']);
        $errors[] = 'Invalid credentials.';
    } else {
        reset_failed_login((int) $user['id']);

        if ((int) $user['two_factor_enabled'] === 1) {
            // Password confirmed, but don't create the session yet - the
            // 2FA step below is what actually authenticates the admin.
            session_regenerate_id(true);
            $_SESSION['pending_admin_id'] = (int) $user['id'];
            redirect('/admin/verify_2fa.php');
        }

        login_user((int) $user['id']);
        log_security_event('admin_login_success', null, (int) $user['id']);
        redirect('/admin/index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login | Alpha Forge</title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<section class="af-section">
<div class="af-container">
    <form method="post" class="af-form-card">
        <h2 style="text-align:center;">Admin Login</h2>
        <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
        <?= csrf_field() ?>
        <div class="af-field"><label>Email</label><input type="email" name="email" required></div>
        <div class="af-field"><label>Password</label><input type="password" name="password" required></div>
        <button type="submit" class="af-btn af-btn-gold af-btn-block">Login</button>
    </form>
</div>
</section>
</body>
</html>
