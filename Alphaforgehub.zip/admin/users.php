<?php
$pageTitle = 'Students';
require_once __DIR__ . '/includes/admin_header.php';

$search = trim($_GET['q'] ?? '');
$sql = "SELECT u.*, s.status AS sub_status, s.ends_at, p.name AS plan_name
        FROM users u
        LEFT JOIN subscriptions s ON s.id = (SELECT id FROM subscriptions WHERE user_id = u.id ORDER BY created_at DESC LIMIT 1)
        LEFT JOIN subscription_plans p ON p.id = s.plan_id
        WHERE u.role = 'student'";
$params = [];
if ($search !== '') {
    $sql .= " AND (u.full_name LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$sql .= " ORDER BY u.created_at DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll();
?>
<h1>Students</h1>
<form method="get" style="max-width:360px; margin:16px 0;">
    <div class="af-field"><input type="text" name="q" placeholder="Search by name or email" value="<?= e($search) ?>"></div>
    <button type="submit" class="af-btn af-btn-ghost">Search</button>
</form>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Name</th><th>Email</th><th>Registered</th><th>Plan</th><th>Status</th><th>Expires</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($students as $s): ?>
            <tr>
                <td><?= e($s['full_name']) ?></td>
                <td><?= e($s['email']) ?></td>
                <td><?= e(date('d M Y', strtotime($s['created_at']))) ?></td>
                <td><?= e($s['plan_name'] ?? '—') ?></td>
                <td style="text-transform:capitalize;"><?= e($s['sub_status'] ?? 'none') ?></td>
                <td><?= $s['ends_at'] ? e(date('d M Y', strtotime($s['ends_at']))) : '—' ?></td>
                <td><a href="<?= APP_URL ?>/admin/user.php?id=<?= (int) $s['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">View</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$students): ?><tr><td colspan="7" class="af-muted">No students found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
