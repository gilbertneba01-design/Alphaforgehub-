<?php
$pageTitle = 'Two-Factor Authentication';
require_once __DIR__ . '/includes/admin_header.php';

$admin = current_user();
$adminId = (int) $admin['id'];

$stmt = db()->prepare('SELECT two_factor_secret, two_factor_enabled FROM users WHERE id = ?');
$stmt->execute([$adminId]);
$row = $stmt->fetch();
$enabled = (int) $row['two_factor_enabled'] === 1;

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'enable') {
        $secret = $_POST['secret'] ?? '';
        $code = trim($_POST['code'] ?? '');

        if (totp_verify($secret, $code)) {
            db()->prepare('UPDATE users SET two_factor_secret = ?, two_factor_enabled = 1 WHERE id = ?')
                ->execute([$secret, $adminId]);
            log_security_event('twofa_enabled', null, $adminId);
            flash_set('success', 'Two-factor authentication is now enabled on your account.');
            redirect('/admin/2fa_setup.php');
        }
        $errors[] = 'That code did not match. Please scan/enter the secret again and try the current code.';
    } elseif ($action === 'disable') {
        $currentPassword = $_POST['current_password'] ?? '';
        $stmt = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([$adminId]);
        $hash = $stmt->fetchColumn();

        if (!password_verify($currentPassword, $hash)) {
            $errors[] = 'Current password is incorrect.';
        } else {
            db()->prepare('UPDATE users SET two_factor_secret = NULL, two_factor_enabled = 0 WHERE id = ?')->execute([$adminId]);
            log_security_event('twofa_disabled', null, $adminId);
            flash_set('success', 'Two-factor authentication has been disabled.');
            redirect('/admin/2fa_setup.php');
        }
    }
}

// Generate a fresh secret to display whenever we're not yet enabled.
$newSecret = $enabled ? null : totp_generate_secret();
$provisioningUri = $newSecret ? totp_provisioning_uri($newSecret, $admin['email']) : null;
?>
<h1>Two-Factor Authentication</h1>

<?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

<?php if ($enabled): ?>
    <div class="af-card" style="max-width:480px;">
        <h3 style="color:var(--green);">2FA is enabled on your account</h3>
        <p class="af-muted">Every login now requires a code from your authenticator app in addition to your password.</p>
        <form method="post" style="margin-top:14px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="disable">
            <div class="af-field"><label>Confirm your current password to disable</label><input type="password" name="current_password" required></div>
            <button type="submit" class="af-btn af-btn-ghost" style="color:var(--red);">Disable 2FA</button>
        </form>
    </div>
<?php else: ?>
    <div class="af-card" style="max-width:520px;">
        <h3>Set Up 2FA</h3>
        <p>1. Install an authenticator app (Google Authenticator, Microsoft Authenticator, Authy, etc.) on your phone.</p>
        <p>2. In the app, choose "Enter setup key manually" and enter this secret key:</p>
        <p style="font-family:monospace; font-size:18px; background:var(--bg); padding:10px 14px; border-radius:8px; border:1px solid var(--border); word-break:break-all;"><?= e($newSecret) ?></p>
        <p class="af-muted">Account name: Alpha Forge:<?= e($admin['email']) ?> &middot; Type: Time-based &middot; Digits: 6</p>

        <form method="post" style="margin-top:16px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="enable">
            <input type="hidden" name="secret" value="<?= e($newSecret) ?>">
            <div class="af-field"><label>3. Enter the 6-digit code the app is now showing</label><input type="text" name="code" inputmode="numeric" maxlength="6" required></div>
            <button type="submit" class="af-btn af-btn-gold">Enable 2FA</button>
        </form>
    </div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
