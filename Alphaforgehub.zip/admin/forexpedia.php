<?php
$pageTitle = 'Forexpedia';
require_once __DIR__ . '/includes/admin_header.php';

function fp_slugify(string $s): string {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $term      = trim($_POST['term'] ?? '');
        $slug      = fp_slugify($_POST['slug'] !== '' ? $_POST['slug'] : $term);
        $short     = trim($_POST['short_definition'] ?? '');
        $full      = trim($_POST['full_explanation'] ?? '');
        $example   = trim($_POST['example'] ?? '');
        $related   = trim($_POST['related_terms'] ?? '');
        $lessonId  = (int) ($_POST['related_lesson_id'] ?? 0) ?: null;
        $status    = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'published';
        $letter    = strtoupper(substr($term, 0, 1));

        if ($term === '' || $short === '') {
            flash_set('error', 'Term and short definition are required.');
        } elseif ($action === 'create') {
            db()->prepare('INSERT INTO forexpedia_terms (term, slug, letter, short_definition, full_explanation, example, related_lesson_id, related_terms, status) VALUES (?,?,?,?,?,?,?,?,?)')
                ->execute([$term, $slug, $letter, $short, $full ?: null, $example ?: null, $lessonId, $related ?: null, $status]);
            flash_set('success', 'Term added.');
        } else {
            $id = (int) $_POST['id'];
            db()->prepare('UPDATE forexpedia_terms SET term=?, slug=?, letter=?, short_definition=?, full_explanation=?, example=?, related_lesson_id=?, related_terms=?, status=? WHERE id=?')
                ->execute([$term, $slug, $letter, $short, $full ?: null, $example ?: null, $lessonId, $related ?: null, $status, $id]);
            flash_set('success', 'Term updated.');
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM forexpedia_terms WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Term deleted.');
    }
    redirect('/admin/forexpedia.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$editing = null;
if ($editId) {
    $stmt = db()->prepare('SELECT * FROM forexpedia_terms WHERE id = ?');
    $stmt->execute([$editId]);
    $editing = $stmt->fetch();
}

$terms = db()->query('SELECT ft.*, l.title AS lesson_title FROM forexpedia_terms ft LEFT JOIN lessons l ON l.id = ft.related_lesson_id ORDER BY ft.term')->fetchAll();
$lessons = db()->query('SELECT id, title FROM lessons ORDER BY title')->fetchAll();
?>
<h1>Forexpedia Glossary</h1>
<p class="af-muted">Manage the searchable glossary shown at /forexpedia.php.</p>

<div class="af-card" style="padding:20px; margin-bottom:24px;">
    <h2><?= $editing ? 'Edit Term' : 'Add New Term' ?></h2>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editing ? 'update' : 'create' ?>">
        <?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><?php endif; ?>
        <div class="af-grid af-grid-2" style="gap:12px;">
            <div class="af-field"><label>Term</label><input type="text" name="term" required value="<?= e($editing['term'] ?? '') ?>"></div>
            <div class="af-field"><label>Slug (optional, auto from term)</label><input type="text" name="slug" value="<?= e($editing['slug'] ?? '') ?>"></div>
        </div>
        <div class="af-field"><label>Short Definition (one sentence)</label><input type="text" name="short_definition" required value="<?= e($editing['short_definition'] ?? '') ?>"></div>
        <div class="af-field"><label>Full Explanation</label><textarea name="full_explanation" rows="3"><?= e($editing['full_explanation'] ?? '') ?></textarea></div>
        <div class="af-field"><label>Example</label><textarea name="example" rows="2"><?= e($editing['example'] ?? '') ?></textarea></div>
        <div class="af-grid af-grid-2" style="gap:12px;">
            <div class="af-field"><label>Related Terms (comma-separated slugs)</label><input type="text" name="related_terms" value="<?= e($editing['related_terms'] ?? '') ?>"></div>
            <div class="af-field"><label>Related Lesson</label>
                <select name="related_lesson_id"><option value="">None</option>
                    <?php foreach ($lessons as $l): ?><option value="<?= $l['id'] ?>" <?= ($editing['related_lesson_id'] ?? 0) == $l['id'] ? 'selected' : '' ?>><?= e($l['title']) ?></option><?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="af-field"><label>Status</label>
            <select name="status">
                <option value="published" <?= ($editing['status'] ?? 'published') === 'published' ? 'selected' : '' ?>>Published</option>
                <option value="draft" <?= ($editing['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
            </select>
        </div>
        <button type="submit" class="af-btn af-btn-gold"><?= $editing ? 'Save Changes' : 'Add Term' ?></button>
        <?php if ($editing): ?><a href="<?= APP_URL ?>/admin/forexpedia.php" class="af-btn af-btn-ghost">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Term</th><th>Definition</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($terms as $t): ?>
            <tr>
                <td><?= e($t['term']) ?></td>
                <td style="max-width:360px;"><?= e($t['short_definition']) ?></td>
                <td><?= e($t['status']) ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/forexpedia.php?edit=<?= $t['id'] ?>" class="af-btn af-btn-ghost af-btn-sm">Edit</a>
                    <form method="post" style="display:inline;" data-confirm="Delete this term?">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $t['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost af-btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
