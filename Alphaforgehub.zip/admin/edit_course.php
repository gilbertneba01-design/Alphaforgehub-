<?php
$pageTitle = 'Edit Course';
require_once __DIR__ . '/includes/admin_header.php';

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM courses WHERE id = ?');
$stmt->execute([$id]);
$course = $stmt->fetch();

if (!$course) {
    echo '<p>Course not found. <a href="' . APP_URL . '/admin/courses.php">Back</a></p>';
    require_once __DIR__ . '/includes/admin_footer.php';
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $level = $_POST['level'] ?? 'Beginner';
    $price = (float) ($_POST['price'] ?? 0);
    $isPremium = isset($_POST['is_premium']) ? 1 : 0;
    $status = $_POST['status'] ?? 'draft';

    if ($title === '') $errors[] = 'Title is required.';

    if (!$errors) {
        $stmt = db()->prepare(
            'UPDATE courses SET title = ?, description = ?, level = ?, price = ?, is_premium = ?, status = ? WHERE id = ?'
        );
        $stmt->execute([$title, $description, $level, $price, $isPremium, $status, $id]);
        flash_set('success', 'Course updated.');
        redirect('/admin/courses.php');
    }
}
?>
<h1>Edit Course</h1>
<?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" class="af-card" style="max-width:560px;">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int) $course['id'] ?>">
    <div class="af-field"><label>Title</label><input type="text" name="title" value="<?= e($_POST['title'] ?? $course['title']) ?>" required></div>
    <div class="af-field"><label>Description</label><textarea name="description" rows="4"><?= e($_POST['description'] ?? $course['description']) ?></textarea></div>
    <div class="af-field"><label>Level</label>
        <select name="level">
            <?php foreach (['Beginner','Intermediate','Advanced'] as $lvl): ?>
                <option value="<?= $lvl ?>" <?= $course['level'] === $lvl ? 'selected' : '' ?>><?= $lvl ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="af-field"><label>Price</label><input type="number" step="0.01" name="price" value="<?= e((string) $course['price']) ?>"></div>
    <div class="af-field"><label><input type="checkbox" name="is_premium" value="1" <?= $course['is_premium'] ? 'checked' : '' ?>> Premium course</label></div>
    <div class="af-field"><label>Status</label>
        <select name="status">
            <option value="draft" <?= $course['status'] === 'draft' ? 'selected' : '' ?>>Draft</option>
            <option value="published" <?= $course['status'] === 'published' ? 'selected' : '' ?>>Published</option>
        </select>
    </div>
    <button type="submit" class="af-btn af-btn-gold">Save Changes</button>
</form>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
