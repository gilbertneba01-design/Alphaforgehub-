<?php
require_once __DIR__ . '/../config/functions.php';

if (is_logged_in() && is_admin()) {
    redirect('/admin/index.php');
}

$pendingId = $_SESSION['pending_admin_id'] ?? null;
if (!$pendingId) {
    redirect('/admin/login.php');
}

$stmt = db()->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin' AND two_factor_enabled = 1 LIMIT 1");
$stmt->execute([$pendingId]);
$user = $stmt->fetch();

if (!$user) {
    unset($_SESSION['pending_admin_id']);
    redirect('/admin/login.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!enforce_rate_limit('admin_2fa', 6, 300, 600)) {
        rate_limit_block_response();
    }

    $code = trim($_POST['code'] ?? '');

    if (totp_verify($user['two_factor_secret'], $code)) {
        unset($_SESSION['pending_admin_id']);
        login_user((int) $user['id']);
        log_security_event('admin_login_success', '2fa verified', (int) $user['id']);
        redirect('/admin/index.php');
    }

    log_security_event('admin_2fa_failed', null, (int) $user['id']);
    $errors[] = 'Incorrect code. Please try again.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verify Identity | Alpha Forge Admin</title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<section class="af-section">
<div class="af-container">
    <form method="post" class="af-form-card">
        <h2 style="text-align:center;">Enter Your 2FA Code</h2>
        <p class="af-muted" style="text-align:center;">Open your authenticator app and enter the current 6-digit code.</p>
        <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
        <?= csrf_field() ?>
        <div class="af-field"><label>6-digit code</label><input type="text" name="code" inputmode="numeric" pattern="[0-9]*" maxlength="6" autofocus required></div>
        <button type="submit" class="af-btn af-btn-gold af-btn-block">Verify</button>
    </form>
</div>
</section>
</body>
</html>
