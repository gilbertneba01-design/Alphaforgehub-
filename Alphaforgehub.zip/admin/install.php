<?php
/**
 * ALPHA FORGE - First Admin installation
 *
 * Run this ONCE, immediately after importing database/schema.sql, to create
 * the first Admin account. As soon as an admin account exists in the database,
 * this script refuses to run again - delete it from the server afterward for
 * extra safety, but it is safe to leave in place either way.
 */

require_once __DIR__ . '/../config/functions.php';

$adminExists = (int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() > 0;

$errors = [];
$done = false;

if (!$adminExists && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';

    if ($fullName === '') $errors[] = 'Please enter a name.';
    if (!valid_email($email)) $errors[] = 'Please enter a valid email.';
    $pwError = password_strength_error($password);
    if ($pwError) $errors[] = $pwError;
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $check = db()->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'That email is already registered.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = db()->prepare("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, 'admin')");
        $stmt->execute([$fullName, $email, $hash]);
        $done = true;
        $adminExists = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Alpha Forge — Install</title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<section class="af-section">
<div class="af-container" style="max-width:480px;">
    <?php if ($done): ?>
        <div class="af-card">
            <h2 style="color:var(--green);">Admin account created</h2>
            <p>You can now log in at <a href="<?= APP_URL ?>/admin/login.php">/admin/login.php</a>.</p>
            <p class="af-muted">For security, delete this file (admin/install.php) from the server now. It will also refuse to run again on its own.</p>
        </div>
    <?php elseif ($adminExists): ?>
        <div class="af-card">
            <h2>Installation already complete</h2>
            <p>An Admin account already exists. This script has disabled itself. Go to <a href="<?= APP_URL ?>/admin/login.php">/admin/login.php</a> to sign in, or delete this file.</p>
        </div>
    <?php else: ?>
        <form method="post" class="af-form-card">
            <h2 style="text-align:center;">Create the First Admin Account</h2>
            <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
            <?= csrf_field() ?>
            <div class="af-field"><label>Full Name</label><input type="text" name="full_name" required></div>
            <div class="af-field"><label>Email</label><input type="email" name="email" required></div>
            <div class="af-field"><label>Password</label><input type="password" name="password" required></div>
            <div class="af-field"><label>Confirm Password</label><input type="password" name="password_confirm" required></div>
            <button type="submit" class="af-btn af-btn-gold af-btn-block">Create Admin Account</button>
        </form>
    <?php endif; ?>
</div>
</section>
</body>
</html>
