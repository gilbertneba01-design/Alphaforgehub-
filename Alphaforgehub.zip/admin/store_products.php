<?php
$pageTitle = 'Store Products';
require_once __DIR__ . '/includes/admin_header.php';

function store_slugify(string $s): string {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-');
}

$uploadDir = __DIR__ . '/../uploads/store/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $title = trim($_POST['title'] ?? '');
        $slug = store_slugify($_POST['slug'] !== '' ? $_POST['slug'] : $title);
        $type = in_array($_POST['type'] ?? '', ['ebook', 'bundle', 'premium_content'], true) ? $_POST['type'] : 'ebook';
        $desc = trim($_POST['description'] ?? '');
        $price = (float) ($_POST['price'] ?? 0);
        $currency = trim($_POST['currency'] ?? 'XAF') ?: 'XAF';
        $status = in_array($_POST['status'] ?? '', ['draft', 'published'], true) ? $_POST['status'] : 'draft';

        $filePath = trim($_POST['existing_file'] ?? '') ?: null;
        if (!empty($_FILES['product_file']['name'])) {
            $ext = strtolower(pathinfo($_FILES['product_file']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['pdf', 'epub', 'zip'], true)) {
                flash_set('error', 'Only PDF, EPUB or ZIP files are allowed.');
                redirect('/admin/store_products.php');
            }
            if ($_FILES['product_file']['size'] > 50 * 1024 * 1024) {
                flash_set('error', 'File too large (50MB max).');
                redirect('/admin/store_products.php');
            }
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $safeName = bin2hex(random_bytes(8)) . '.' . $ext;
            if (move_uploaded_file($_FILES['product_file']['tmp_name'], $uploadDir . $safeName)) {
                $filePath = $safeName;
            } else {
                flash_set('error', 'File upload failed.');
                redirect('/admin/store_products.php');
            }
        }

        $imagePath = trim($_POST['image_url'] ?? '') ?: null;

        if ($title === '' || $price < 0) {
            flash_set('error', 'Title and a valid price are required.');
        } elseif ($action === 'create') {
            db()->prepare('INSERT INTO store_products (type, title, slug, description, price, currency, image, file_path, status) VALUES (?,?,?,?,?,?,?,?,?)')
                ->execute([$type, $title, $slug, $desc ?: null, $price, $currency, $imagePath, $filePath, $status]);
            flash_set('success', 'Product added.');
        } else {
            $id = (int) $_POST['id'];
            db()->prepare('UPDATE store_products SET type=?, title=?, slug=?, description=?, price=?, currency=?, image=?, file_path=?, status=? WHERE id=?')
                ->execute([$type, $title, $slug, $desc ?: null, $price, $currency, $imagePath, $filePath, $status, $id]);
            flash_set('success', 'Product updated.');
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM store_products WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Product deleted.');
    }
    redirect('/admin/store_products.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$editing = null;
if ($editId) {
    $stmt = db()->prepare('SELECT * FROM store_products WHERE id = ?');
    $stmt->execute([$editId]);
    $editing = $stmt->fetch();
}

$products = db()->query('SELECT * FROM store_products ORDER BY sort_order, title')->fetchAll();
?>
<h1>Store Products</h1>
<p class="af-muted">Ebooks, bundles and premium content sold directly on Alpha Forge. Files are stored privately and only served to buyers who paid (see download.php).</p>

<div class="af-card" style="padding:20px; margin-bottom:24px;">
    <h2><?= $editing ? 'Edit Product' : 'Add Product' ?></h2>
    <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editing ? 'update' : 'create' ?>">
        <?php if ($editing): ?><input type="hidden" name="id" value="<?= (int) $editing['id'] ?>"><input type="hidden" name="existing_file" value="<?= e($editing['file_path'] ?? '') ?>"><?php endif; ?>
        <div class="af-grid af-grid-2" style="gap:12px;">
            <div class="af-field"><label>Title</label><input type="text" name="title" required value="<?= e($editing['title'] ?? '') ?>"></div>
            <div class="af-field"><label>Slug (optional)</label><input type="text" name="slug" value="<?= e($editing['slug'] ?? '') ?>"></div>
        </div>
        <div class="af-field"><label>Description</label><textarea name="description" rows="3"><?= e($editing['description'] ?? '') ?></textarea></div>
        <div class="af-grid af-grid-3" style="gap:12px;">
            <div class="af-field"><label>Type</label>
                <select name="type">
                    <option value="ebook" <?= ($editing['type'] ?? '') === 'ebook' ? 'selected' : '' ?>>Ebook</option>
                    <option value="bundle" <?= ($editing['type'] ?? '') === 'bundle' ? 'selected' : '' ?>>Bundle</option>
                    <option value="premium_content" <?= ($editing['type'] ?? '') === 'premium_content' ? 'selected' : '' ?>>Premium Content</option>
                </select>
            </div>
            <div class="af-field"><label>Price</label><input type="number" step="0.01" name="price" required value="<?= e($editing['price'] ?? '0') ?>"></div>
            <div class="af-field"><label>Currency</label><input type="text" name="currency" value="<?= e($editing['currency'] ?? 'XAF') ?>"></div>
        </div>
        <div class="af-grid af-grid-2" style="gap:12px;">
            <div class="af-field"><label>Cover Image URL</label><input type="text" name="image_url" value="<?= e($editing['image'] ?? '') ?>" placeholder="/assets/img/books/cover.jpg"></div>
            <div class="af-field"><label>Upload File (PDF/EPUB/ZIP, max 50MB)</label><input type="file" name="product_file">
                <?php if (!empty($editing['file_path'])): ?><p class="af-muted" style="font-size:12px;">Current file: <?= e($editing['file_path']) ?> (leave blank to keep it)</p><?php endif; ?>
            </div>
        </div>
        <div class="af-field"><label>Status</label>
            <select name="status">
                <option value="draft" <?= ($editing['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                <option value="published" <?= ($editing['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
            </select>
        </div>
        <button type="submit" class="af-btn af-btn-gold"><?= $editing ? 'Save Changes' : 'Add Product' ?></button>
        <?php if ($editing): ?><a href="<?= APP_URL ?>/admin/store_products.php" class="af-btn af-btn-ghost">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Title</th><th>Type</th><th>Price</th><th>File</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($products as $p): ?>
            <tr>
                <td><?= e($p['title']) ?></td>
                <td><?= e($p['type']) ?></td>
                <td><?= number_format($p['price'], 2) ?> <?= e($p['currency']) ?></td>
                <td><?= $p['file_path'] ? 'Uploaded' : '—' ?></td>
                <td><?= e($p['status']) ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/store_products.php?edit=<?= $p['id'] ?>" class="af-btn af-btn-ghost af-btn-sm">Edit</a>
                    <form method="post" style="display:inline;" data-confirm="Delete this product?">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost af-btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
