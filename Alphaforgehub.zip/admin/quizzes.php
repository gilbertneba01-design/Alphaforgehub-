<?php
$pageTitle = 'Quizzes';
require_once __DIR__ . '/includes/admin_header.php';

$lessonId = (int) ($_GET['lesson_id'] ?? $_POST['lesson_id'] ?? 0);

$lessonStmt = db()->prepare(
    "SELECT l.*, c.title AS course_title FROM lessons l
     JOIN modules m ON m.id = l.module_id JOIN courses c ON c.id = m.course_id
     WHERE l.id = ?"
);
$lessonStmt->execute([$lessonId]);
$lesson = $lessonStmt->fetch();

if (!$lesson) {
    echo '<p>Select a lesson from the <a href="' . APP_URL . '/admin/lessons.php">Lessons</a> page to manage its quiz.</p>';
    require_once __DIR__ . '/includes/admin_footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $question = trim($_POST['question'] ?? '');
        $a = trim($_POST['option_a'] ?? '');
        $b = trim($_POST['option_b'] ?? '');
        $c = trim($_POST['option_c'] ?? '');
        $d = trim($_POST['option_d'] ?? '');
        $correct = $_POST['correct_answer'] ?? 'A';

        if ($question !== '' && $a !== '' && $b !== '' && $c !== '' && $d !== '') {
            $ordStmt = db()->prepare('SELECT COALESCE(MAX(sort_order),0) FROM quizzes WHERE lesson_id = ?');
            $ordStmt->execute([$lessonId]);
            $maxOrder = (int) $ordStmt->fetchColumn();
            $ins = db()->prepare(
                'INSERT INTO quizzes (lesson_id, question, option_a, option_b, option_c, option_d, correct_answer, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $ins->execute([$lessonId, $question, $a, $b, $c, $d, $correct, $maxOrder + 1]);
            flash_set('success', 'Question added.');
        }
    } elseif ($action === 'update') {
        $id = (int) $_POST['question_id'];
        $stmt = db()->prepare(
            'UPDATE quizzes SET question=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_answer=? WHERE id=?'
        );
        $stmt->execute([
            trim($_POST['question'] ?? ''), trim($_POST['option_a'] ?? ''), trim($_POST['option_b'] ?? ''),
            trim($_POST['option_c'] ?? ''), trim($_POST['option_d'] ?? ''), $_POST['correct_answer'] ?? 'A', $id,
        ]);
        flash_set('success', 'Question updated.');
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM quizzes WHERE id = ?')->execute([(int) $_POST['question_id']]);
        flash_set('success', 'Question deleted.');
    }
    redirect('/admin/quizzes.php?lesson_id=' . $lessonId);
}

$qStmt = db()->prepare('SELECT * FROM quizzes WHERE lesson_id = ? ORDER BY sort_order');
$qStmt->execute([$lessonId]);
$questions = $qStmt->fetchAll();
?>
<p class="af-muted"><?= e($lesson['course_title']) ?></p>
<h1>Quiz: <?= e($lesson['title']) ?></h1>

<?php foreach ($questions as $q): ?>
    <form method="post" class="af-card" style="margin-bottom:16px;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="question_id" value="<?= (int) $q['id'] ?>">
        <div class="af-field"><label>Question</label><textarea name="question" rows="2"><?= e($q['question']) ?></textarea></div>
        <div class="af-field"><label>Option A</label><input type="text" name="option_a" value="<?= e($q['option_a']) ?>"></div>
        <div class="af-field"><label>Option B</label><input type="text" name="option_b" value="<?= e($q['option_b']) ?>"></div>
        <div class="af-field"><label>Option C</label><input type="text" name="option_c" value="<?= e($q['option_c']) ?>"></div>
        <div class="af-field"><label>Option D</label><input type="text" name="option_d" value="<?= e($q['option_d']) ?>"></div>
        <div class="af-field"><label>Correct Answer</label>
            <select name="correct_answer">
                <?php foreach (['A','B','C','D'] as $opt): ?>
                    <option value="<?= $opt ?>" <?= $q['correct_answer'] === $opt ? 'selected' : '' ?>><?= $opt ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="display:flex; gap:10px;">
            <button type="submit" class="af-btn af-btn-ghost">Save</button>
        </div>
    </form>
    <form method="post" style="margin:-8px 0 20px;" data-confirm="Delete this question?">
        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="question_id" value="<?= (int) $q['id'] ?>">
        <button type="submit" class="af-btn af-btn-ghost" style="color:var(--red);">Delete Question</button>
    </form>
<?php endforeach; ?>
<?php if (!$questions): ?><p class="af-muted">No quiz questions yet for this lesson.</p><?php endif; ?>

<div class="af-card" style="max-width:560px; margin-top:10px;">
    <h3>Add Question</h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="af-field"><label>Question</label><textarea name="question" rows="2" required></textarea></div>
        <div class="af-field"><label>Option A</label><input type="text" name="option_a" required></div>
        <div class="af-field"><label>Option B</label><input type="text" name="option_b" required></div>
        <div class="af-field"><label>Option C</label><input type="text" name="option_c" required></div>
        <div class="af-field"><label>Option D</label><input type="text" name="option_d" required></div>
        <div class="af-field"><label>Correct Answer</label>
            <select name="correct_answer"><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option></select>
        </div>
        <button type="submit" class="af-btn af-btn-gold">Add Question</button>
    </form>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
