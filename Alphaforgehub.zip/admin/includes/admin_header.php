<?php
if (!ob_get_level()) { ob_start(); }
require_once __DIR__ . '/../../config/functions.php';
require_admin();
$__admin = current_user();
$__p = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? e($pageTitle) . ' | Alpha Forge Admin' : 'Alpha Forge Admin' ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<header class="af-header">
    <div class="af-container af-header-inner">
        <a href="<?= APP_URL ?>/admin/index.php" class="af-logo">ALPHA <span>FORGE</span> <span class="af-badge" style="margin-left:8px;">Admin</span></a>
        <div class="af-muted"><?= e($__admin['full_name']) ?> &middot; <a href="<?= APP_URL ?>/admin/logout.php">Logout</a></div>
    </div>
</header>
<?php $__s = flash_get('success'); $__e = flash_get('error'); ?>
<?php if ($__s): ?><div class="af-container"><div class="af-alert af-alert-success"><?= e($__s) ?></div></div><?php endif; ?>
<?php if ($__e): ?><div class="af-container"><div class="af-alert af-alert-error"><?= e($__e) ?></div></div><?php endif; ?>
<section class="af-section" style="padding-top:32px;">
<div class="af-container af-dash-grid">
<aside class="af-sidebar">
    <a href="<?= APP_URL ?>/admin/index.php" class="<?= $__p === 'index.php' ? 'active' : '' ?>">Dashboard</a>
    <a href="<?= APP_URL ?>/admin/users.php" class="<?= $__p === 'users.php' || $__p === 'user.php' ? 'active' : '' ?>">Students</a>
    <a href="<?= APP_URL ?>/admin/courses.php" class="<?= in_array($__p, ['courses.php','add_course.php','edit_course.php']) ? 'active' : '' ?>">Courses</a>
    <a href="<?= APP_URL ?>/admin/modules.php" class="<?= $__p === 'modules.php' ? 'active' : '' ?>">Modules</a>
    <a href="<?= APP_URL ?>/admin/lessons.php" class="<?= $__p === 'lessons.php' ? 'active' : '' ?>">Lessons</a>
    <a href="<?= APP_URL ?>/admin/quizzes.php" class="<?= $__p === 'quizzes.php' ? 'active' : '' ?>">Quizzes</a>
    <a href="<?= APP_URL ?>/admin/chart_exercises.php" class="<?= $__p === 'chart_exercises.php' ? 'active' : '' ?>">Chart Lab</a>
    <a href="<?= APP_URL ?>/admin/forexpedia.php" class="<?= $__p === 'forexpedia.php' ? 'active' : '' ?>">Forexpedia</a>
    <a href="<?= APP_URL ?>/admin/market_data.php" class="<?= $__p === 'market_data.php' ? 'active' : '' ?>">Market Data</a>
    <a href="<?= APP_URL ?>/admin/economic_calendar.php" class="<?= $__p === 'economic_calendar.php' ? 'active' : '' ?>">Economic Calendar</a>
    <a href="<?= APP_URL ?>/admin/market_news.php" class="<?= $__p === 'market_news.php' ? 'active' : '' ?>">Market News</a>
    <a href="<?= APP_URL ?>/admin/mentorship.php" class="<?= $__p === 'mentorship.php' ? 'active' : '' ?>">Mentorship</a>
    <a href="<?= APP_URL ?>/admin/store_products.php" class="<?= $__p === 'store_products.php' ? 'active' : '' ?>">Store Products</a>
    <a href="<?= APP_URL ?>/admin/community.php" class="<?= $__p === 'community.php' ? 'active' : '' ?>">Community</a>
    <a href="<?= APP_URL ?>/admin/study_groups.php" class="<?= $__p === 'study_groups.php' ? 'active' : '' ?>">Study Groups</a>
    <a href="<?= APP_URL ?>/admin/announcements.php" class="<?= $__p === 'announcements.php' ? 'active' : '' ?>">Announcements</a>
    <a href="<?= APP_URL ?>/admin/challenges.php" class="<?= in_array($__p, ['challenges.php','edit_challenge.php']) ? 'active' : '' ?>">Challenges</a>
    <a href="<?= APP_URL ?>/admin/live_sessions.php" class="<?= $__p === 'live_sessions.php' ? 'active' : '' ?>">Live Sessions</a>
    <a href="<?= APP_URL ?>/admin/subscriptions.php" class="<?= $__p === 'subscriptions.php' ? 'active' : '' ?>">Subscriptions</a>
    <a href="<?= APP_URL ?>/admin/payments.php" class="<?= $__p === 'payments.php' ? 'active' : '' ?>">Payments</a>
    <a href="<?= APP_URL ?>/admin/testimonials.php" class="<?= $__p === 'testimonials.php' ? 'active' : '' ?>">Testimonials</a>
    <a href="<?= APP_URL ?>/admin/messages.php" class="<?= $__p === 'messages.php' ? 'active' : '' ?>">Messages</a>
    <a href="<?= APP_URL ?>/admin/settings.php" class="<?= $__p === 'settings.php' ? 'active' : '' ?>">Settings</a>
    <a href="<?= APP_URL ?>/admin/security_log.php" class="<?= $__p === 'security_log.php' ? 'active' : '' ?>">Security Log</a>
    <a href="<?= APP_URL ?>/admin/2fa_setup.php" class="<?= $__p === '2fa_setup.php' ? 'active' : '' ?>">Two-Factor Auth</a>
</aside>
<div style="min-width:0;">
