<?php
/**
 * ALPHA FORGE - Admin: Chart Lab exercises
 * Add, edit, publish, reorder and delete the practice charts students see in
 * the Chart Lab. The admin pastes (or generates) candles, then DRAWS the
 * correct answer zone(s) on the chart. Nothing here is sent to students until
 * the exercise is published.
 */
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/chartlab.php';
require_admin();

$pageTitle = 'Chart Lab Exercises';
$available = chartlab_available();

$TIMEFRAMES   = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1'];
$DIFFICULTIES = ['Beginner', 'Intermediate', 'Advanced'];

$courses = db()->query('SELECT id, title, slug, is_premium FROM courses ORDER BY sort_order')->fetchAll();
$defaultCourseId = 0;
foreach ($courses as $c) {
    if ($c['slug'] === 'technical-analysis') {
        $defaultCourseId = (int) $c['id'];
    }
}

$filterCourse = (int) ($_GET['course_id'] ?? $_POST['filter_course'] ?? 0);
$listUrl = '/admin/chart_exercises.php' . ($filterCourse ? '?course_id=' . $filterCourse : '');

$errors = [];
$form = null;            // set when the add/edit form should be shown
$screen = 'list';

// ------------------------------------------------------------------
// Actions (handled before any HTML is sent, so redirects always work)
// ------------------------------------------------------------------
if ($available && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $id = (int) ($_POST['exercise_id'] ?? 0);
        db()->prepare('DELETE FROM chartlab_exercises WHERE id = ?')->execute([$id]);
        flash_set('success', 'Exercise deleted.');
        redirect($listUrl);
    }

    if ($action === 'toggle') {
        $id = (int) ($_POST['exercise_id'] ?? 0);
        db()->prepare("UPDATE chartlab_exercises SET status = IF(status = 'published', 'draft', 'published') WHERE id = ?")
            ->execute([$id]);
        flash_set('success', 'Exercise status updated.');
        redirect($listUrl);
    }

    if ($action === 'move') {
        $id = (int) ($_POST['exercise_id'] ?? 0);
        $direction = ($_POST['direction'] ?? '') === 'up' ? 'up' : 'down';
        $stmt = db()->prepare('SELECT id, sort_order FROM chartlab_exercises WHERE id = ?');
        $stmt->execute([$id]);
        $me = $stmt->fetch();
        if ($me) {
            $cmp = $direction === 'up' ? '<' : '>';
            $ord = $direction === 'up' ? 'DESC' : 'ASC';
            $nb = db()->prepare(
                "SELECT id, sort_order FROM chartlab_exercises WHERE sort_order $cmp ? ORDER BY sort_order $ord, id $ord LIMIT 1"
            );
            $nb->execute([(int) $me['sort_order']]);
            $other = $nb->fetch();
            if ($other) {
                $upd = db()->prepare('UPDATE chartlab_exercises SET sort_order = ? WHERE id = ?');
                $upd->execute([(int) $other['sort_order'], (int) $me['id']]);
                $upd->execute([(int) $me['sort_order'], (int) $other['id']]);
            }
        }
        redirect($listUrl);
    }

    if ($action === 'save') {
        $id          = (int) ($_POST['exercise_id'] ?? 0);
        $courseId    = (int) ($_POST['course_id'] ?? 0);
        $title       = trim((string) ($_POST['title'] ?? ''));
        $pair        = trim((string) ($_POST['pair_label'] ?? ''));
        $timeframe   = (string) ($_POST['timeframe_label'] ?? 'H1');
        $difficulty  = (string) ($_POST['difficulty'] ?? 'Beginner');
        $modeSel     = (string) ($_POST['mode'] ?? 'band');
        $instruction = trim((string) ($_POST['instruction'] ?? ''));
        $hint        = trim((string) ($_POST['hint'] ?? ''));
        $explanation = trim((string) ($_POST['explanation'] ?? ''));
        $isPremium   = isset($_POST['is_premium']) ? 1 : 0;
        $status      = ($_POST['status'] ?? 'published') === 'draft' ? 'draft' : 'published';
        $tolP        = max(0.0, min(2.0, (float) ($_POST['tol_price'] ?? 0.5)));
        $tolX        = max(0.0, min(6.0, (float) ($_POST['tol_candles'] ?? 1.5)));
        $candlesText = (string) ($_POST['candles_text'] ?? '');
        $targetsJson = (string) ($_POST['targets_json'] ?? '');

        // Keep what the admin typed so the form can be shown again on error.
        $form = [
            'id' => $id, 'course_id' => $courseId, 'title' => $title, 'pair_label' => $pair,
            'timeframe_label' => $timeframe, 'difficulty' => $difficulty, 'mode' => $modeSel,
            'instruction' => $instruction, 'hint' => $hint, 'explanation' => $explanation,
            'is_premium' => $isPremium, 'status' => $status, 'tol_price' => $tolP,
            'tol_candles' => $tolX, 'candles_text' => $candlesText, 'targets_json' => $targetsJson,
        ];

        // ---- Validate the simple fields ----
        if ($courseId > 0) {
            $found = false;
            foreach ($courses as $c) {
                if ((int) $c['id'] === $courseId) {
                    $found = true;
                }
            }
            if (!$found) {
                $errors[] = 'Please choose a valid course.';
            }
        }
        if ($title === '' || strlen($title) > 190) {
            $errors[] = 'Give the exercise a title (up to 190 characters).';
        }
        if (!preg_match('/^[A-Za-z0-9\/ ._-]{2,20}$/', $pair)) {
            $errors[] = 'Enter the currency pair or market, for example EUR/USD.';
        }
        if (!in_array($timeframe, $TIMEFRAMES, true)) {
            $errors[] = 'Choose a timeframe.';
        }
        if (!in_array($difficulty, $DIFFICULTIES, true)) {
            $errors[] = 'Choose a difficulty.';
        }
        if (!in_array($modeSel, ['band', 'box', 'trendline'], true)) {
            $errors[] = 'Choose how the answer is judged.';
        }
        if (strlen($instruction) < 10) {
            $errors[] = 'Write the instruction students will read (at least 10 characters).';
        }
        if ($explanation === '') {
            $errors[] = 'Write the explanation students see after solving it.';
        }

        // ---- Candles ----
        [$candles, $decimals, $candleError] = chartlab_parse_candles_text($candlesText);
        if ($candleError !== null) {
            $errors[] = $candleError;
        }

        // ---- Answer zones ----
        $targets = null;
        if ($candles !== null) {
            $view = chartlab_view_range($candles);
            $rawTargets = json_decode($targetsJson, true);
            [$targets, $targetError] = chartlab_clean_targets($rawTargets, count($candles), $view, $modeSel);
            if ($targetError !== null) {
                $errors[] = $targetError;
            } elseif (!$errors) {
                $selfCheck = chartlab_self_check($targets, $modeSel, $tolP, $tolX, count($candles), $view);
                if ($selfCheck !== null) {
                    $errors[] = $selfCheck;
                }
            }
        }

        if (!$errors && $candles !== null && $targets !== null) {
            $candlesJson = json_encode($candles);
            $targetsOut  = json_encode($targets);
            $courseVal   = $courseId > 0 ? $courseId : null;

            if ($id > 0) {
                $chk = db()->prepare('SELECT id FROM chartlab_exercises WHERE id = ?');
                $chk->execute([$id]);
                if (!$chk->fetch()) {
                    flash_set('error', 'That exercise no longer exists.');
                    redirect($listUrl);
                }
                db()->prepare(
                    'UPDATE chartlab_exercises
                        SET course_id = ?, title = ?, pair_label = ?, timeframe_label = ?, difficulty = ?, mode = ?,
                            instruction = ?, hint = ?, explanation = ?, price_decimals = ?, candles = ?, targets = ?,
                            tol_price = ?, tol_candles = ?, is_premium = ?, status = ?
                      WHERE id = ?'
                )->execute([
                    $courseVal, $title, $pair, $timeframe, $difficulty, $modeSel,
                    $instruction, $hint !== '' ? $hint : null, $explanation, $decimals, $candlesJson, $targetsOut,
                    $tolP, $tolX, $isPremium, $status, $id,
                ]);
                flash_set('success', 'Exercise updated.');
            } else {
                $slug = slugify($title);
                $slugChk = db()->prepare('SELECT id FROM chartlab_exercises WHERE slug = ?');
                $slugChk->execute([$slug]);
                if ($slugChk->fetch()) {
                    $slug .= '-' . substr(bin2hex(random_bytes(3)), 0, 6);
                }
                $maxOrder = (int) db()->query('SELECT COALESCE(MAX(sort_order), 0) FROM chartlab_exercises')->fetchColumn();

                db()->prepare(
                    'INSERT INTO chartlab_exercises
                        (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint,
                         explanation, price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                )->execute([
                    $courseVal, $title, $slug, $pair, $timeframe, $difficulty, $modeSel, $instruction,
                    $hint !== '' ? $hint : null, $explanation, $decimals, $candlesJson, $targetsOut,
                    $tolP, $tolX, $isPremium, $status, $maxOrder + 1,
                ]);
                flash_set('success', 'Exercise created' . ($status === 'draft' ? ' as a draft. Publish it when you are ready.' : ' and published.'));
            }
            redirect($listUrl);
        }

        $screen = 'form';
    }
}

// ------------------------------------------------------------------
// Which screen? (list, blank form, or edit form)
// ------------------------------------------------------------------
if ($available && $screen === 'list') {
    if (isset($_GET['new'])) {
        $screen = 'form';
        $form = [
            'id' => 0, 'course_id' => $filterCourse ?: $defaultCourseId, 'title' => '', 'pair_label' => 'EUR/USD',
            'timeframe_label' => 'H1', 'difficulty' => 'Beginner', 'mode' => 'band', 'instruction' => '',
            'hint' => '', 'explanation' => '', 'is_premium' => 0, 'status' => 'published', 'tol_price' => 0.5,
            'tol_candles' => 1.5, 'candles_text' => '', 'targets_json' => '',
        ];
    } elseif (isset($_GET['edit'])) {
        $stmt = db()->prepare('SELECT * FROM chartlab_exercises WHERE id = ?');
        $stmt->execute([(int) $_GET['edit']]);
        $row = $stmt->fetch();
        if (!$row) {
            flash_set('error', 'Exercise not found.');
            redirect($listUrl);
        }
        $rawCandles = json_decode((string) $row['candles'], true);
        $screen = 'form';
        $form = [
            'id' => (int) $row['id'], 'course_id' => (int) $row['course_id'], 'title' => (string) $row['title'],
            'pair_label' => (string) $row['pair_label'], 'timeframe_label' => (string) $row['timeframe_label'],
            'difficulty' => (string) $row['difficulty'], 'mode' => (string) $row['mode'],
            'instruction' => (string) $row['instruction'], 'hint' => (string) ($row['hint'] ?? ''),
            'explanation' => (string) $row['explanation'], 'is_premium' => (int) $row['is_premium'],
            'status' => (string) $row['status'], 'tol_price' => (float) $row['tol_price'],
            'tol_candles' => (float) $row['tol_candles'],
            'candles_text' => is_array($rawCandles) ? chartlab_candles_to_text($rawCandles, (int) $row['price_decimals']) : '',
            'targets_json' => (string) $row['targets'],
        ];
    }
}

$exercises = [];
if ($available && $screen === 'list') {
    $sql = 'SELECT e.*, c.title AS course_title,
                   (SELECT COUNT(*) FROM chartlab_attempts a WHERE a.exercise_id = e.id) AS attempt_count,
                   (SELECT COUNT(DISTINCT a.user_id) FROM chartlab_attempts a
                     WHERE a.exercise_id = e.id AND a.result = \'correct\') AS solver_count
              FROM chartlab_exercises e
              LEFT JOIN courses c ON c.id = e.course_id';
    if ($filterCourse) {
        $stmt = db()->prepare($sql . ' WHERE e.course_id = ? ORDER BY e.sort_order, e.id');
        $stmt->execute([$filterCourse]);
    } else {
        $stmt = db()->query($sql . ' ORDER BY e.sort_order, e.id');
    }
    $exercises = $stmt->fetchAll();
}

require_once __DIR__ . '/includes/admin_header.php';
?>

<?php if (!$available): ?>
    <h1>Chart Lab Exercises</h1>
    <div class="af-card" style="max-width:560px;">
        <h3 style="margin-top:0;">The Chart Lab is not set up yet</h3>
        <p>Import <code>database/migration_chartlab.sql</code> in phpMyAdmin first. It creates the tables that store the exercises.</p>
    </div>

<?php elseif ($screen === 'form'): ?>
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <h1><?= $form['id'] ? 'Edit exercise' : 'New Chart Lab exercise' ?></h1>
        <a href="<?= APP_URL . e($listUrl) ?>" class="af-btn af-btn-ghost">&larr; Back to exercises</a>
    </div>

    <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

    <form method="post" id="exForm" class="af-ed-form" autocomplete="off">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="exercise_id" value="<?= (int) $form['id'] ?>">
        <input type="hidden" name="filter_course" value="<?= (int) $filterCourse ?>">

        <div class="af-card af-ed-card">
            <h3>1. About the exercise</h3>
            <div class="af-ed-grid">
                <div class="af-field"><label>Course</label>
                    <select name="course_id">
                        <option value="0">No course</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['id'] ?>" <?= (int) $form['course_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="af-field"><label>Title</label>
                    <input type="text" name="title" id="exTitle" maxlength="190" required value="<?= e($form['title']) ?>" placeholder="e.g. Mark the Support Zone">
                </div>
                <div class="af-field"><label>Pair / market</label>
                    <input type="text" name="pair_label" maxlength="20" required value="<?= e($form['pair_label']) ?>" placeholder="EUR/USD">
                </div>
                <div class="af-field"><label>Timeframe</label>
                    <select name="timeframe_label">
                        <?php foreach ($TIMEFRAMES as $tf): ?>
                            <option value="<?= e($tf) ?>" <?= $form['timeframe_label'] === $tf ? 'selected' : '' ?>><?= e($tf) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="af-field"><label>Difficulty</label>
                    <select name="difficulty">
                        <?php foreach ($DIFFICULTIES as $d): ?>
                            <option value="<?= e($d) ?>" <?= $form['difficulty'] === $d ? 'selected' : '' ?>><?= e($d) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="af-field"><label>How is the answer judged?</label>
                    <select name="mode" id="exMode">
                        <option value="band" <?= $form['mode'] === 'band' ? 'selected' : '' ?>>Price level only (support / resistance)</option>
                        <option value="box" <?= $form['mode'] === 'box' ? 'selected' : '' ?>>Price and time (range, supply / demand)</option>
                        <option value="trendline" <?= $form['mode'] === 'trendline' ? 'selected' : '' ?>>Trendline (draw the trend)</option>
                    </select>
                </div>
                <div class="af-field" id="exDirectionWrap" hidden><label>Trend direction</label>
                    <select id="exDirection">
                        <option value="up">Upward (draw along the higher lows)</option>
                        <option value="down">Downward (draw along the lower highs)</option>
                    </select>
                </div>
            </div>
            <div class="af-field"><label>Instruction (what the student is asked to do)</label>
                <textarea name="instruction" id="exInstruction" rows="3" required><?= e($form['instruction']) ?></textarea>
            </div>
            <div class="af-field"><label>Hint (optional)</label>
                <textarea name="hint" id="exHint" rows="2"><?= e($form['hint']) ?></textarea>
            </div>
            <div class="af-field"><label>Explanation (shown after they solve it or reveal the answer)</label>
                <textarea name="explanation" id="exExplanation" rows="3" required><?= e($form['explanation']) ?></textarea>
            </div>
            <div class="af-ed-grid">
                <div class="af-field"><label>Status</label>
                    <select name="status">
                        <option value="published" <?= $form['status'] === 'published' ? 'selected' : '' ?>>Published (students can see it)</option>
                        <option value="draft" <?= $form['status'] === 'draft' ? 'selected' : '' ?>>Draft (hidden)</option>
                    </select>
                </div>
                <div class="af-field"><label>&nbsp;</label>
                    <label class="af-ed-check"><input type="checkbox" name="is_premium" value="1" <?= $form['is_premium'] ? 'checked' : '' ?>> Premium exercise (needs a subscription)</label>
                </div>
            </div>
        </div>

        <div class="af-card af-ed-card">
            <h3>2. The chart (candles)</h3>
            <p class="af-muted">Paste one candle per line as <strong>open, high, low, close</strong>. You can copy them from a spreadsheet or a TradingView / MetaTrader export (a date column before the prices is fine). Use 20 to 150 candles. Or let the tool build a practice chart for you:</p>
            <div class="af-ed-gen">
                <div class="af-field"><label>Pattern</label>
                    <select id="genPattern">
                        <option value="support">Support bounce</option>
                        <option value="resistance">Resistance rejection</option>
                        <option value="range">Consolidation range</option>
                        <option value="demand">Demand zone</option>
                        <option value="supply">Supply zone</option>
                        <option value="uptrend">Uptrend (higher lows)</option>
                        <option value="downtrend">Downtrend (lower highs)</option>
                    </select>
                </div>
                <div class="af-field"><label>Start price</label><input type="number" id="genBase" step="any" value="1.0850"></div>
                <div class="af-field"><label>Decimals</label><input type="number" id="genDecimals" min="2" max="6" value="5"></div>
                <div class="af-field"><label>Variation</label><input type="number" id="genSeed" min="1" max="999999" value="1"></div>
                <div class="af-field"><label>&nbsp;</label><button type="button" class="af-btn af-btn-ghost" id="genBtn">Generate chart</button></div>
            </div>
            <div class="af-field"><label>Candles <span class="af-muted" id="edCount"></span></label>
                <textarea name="candles_text" id="edCandles" rows="8" spellcheck="false" placeholder="1.08500,1.08620,1.08430,1.08590"><?= e($form['candles_text']) ?></textarea>
            </div>
        </div>

        <div class="af-card af-ed-card">
            <h3>3. Draw the correct answer zone</h3>
            <p class="af-muted">Drag on the chart to draw the zone a student should mark. Drag inside a zone to move it, and drag its edges or corners to resize. If two different zones would both be correct, add a second zone.</p>
            <div class="af-ed-zones" id="edZones"></div>
            <div class="af-ed-stage" id="edStage"><canvas id="edCanvas" aria-label="Chart for drawing the answer zone"></canvas></div>
            <p class="af-muted" id="edInfo" role="status"></p>
            <input type="hidden" name="targets_json" id="edTargets" value="<?= e($form['targets_json']) ?>">
        </div>

        <details class="af-card af-ed-card">
            <summary style="cursor:pointer; font-weight:600;">Advanced: how forgiving the marking is</summary>
            <p class="af-muted" style="margin-top:10px;">The defaults work well. Raise a value to accept sloppier zones, lower it to be stricter. Saving is blocked if the settings would accept a clearly wrong zone.</p>
            <div class="af-ed-grid">
                <div class="af-field"><label>Price tolerance (0 to 2)</label><input type="number" name="tol_price" step="0.05" min="0" max="2" value="<?= e((string) $form['tol_price']) ?>"></div>
                <div class="af-field"><label>Time tolerance, in candles (0 to 6)</label><input type="number" name="tol_candles" step="0.25" min="0" max="6" value="<?= e((string) $form['tol_candles']) ?>"></div>
            </div>
        </details>

        <div style="display:flex; gap:12px; flex-wrap:wrap; margin-top:18px;">
            <button type="submit" class="af-btn af-btn-gold"><?= $form['id'] ? 'Save changes' : 'Create exercise' ?></button>
            <a href="<?= APP_URL . e($listUrl) ?>" class="af-btn af-btn-ghost">Cancel</a>
        </div>
    </form>
    <script src="<?= APP_URL ?>/assets/js/admin_chartlab.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/admin_chartlab.js') ?>"></script>

<?php else: ?>
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <h1>Chart Lab Exercises</h1>
        <a href="<?= APP_URL ?>/admin/chart_exercises.php?new=1<?= $filterCourse ? '&amp;course_id=' . $filterCourse : '' ?>" class="af-btn af-btn-gold">Add exercise</a>
    </div>

    <form method="get" style="max-width:320px; margin:16px 0;">
        <div class="af-field"><label>Show</label>
            <select name="course_id" data-autosubmit>
                <option value="0">All courses</option>
                <?php foreach ($courses as $c): ?>
                    <option value="<?= (int) $c['id'] ?>" <?= $filterCourse === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <?php if (!$exercises): ?>
        <div class="af-card" style="max-width:560px;">
            <h3 style="margin-top:0;">No exercises here yet</h3>
            <p>Create the first one. You paste or generate the candles, then draw the correct zone on the chart.</p>
            <a href="<?= APP_URL ?>/admin/chart_exercises.php?new=1<?= $filterCourse ? '&amp;course_id=' . $filterCourse : '' ?>" class="af-btn af-btn-gold">Add exercise</a>
        </div>
    <?php else: ?>
        <div class="af-table-wrap">
            <table class="af-table">
                <thead><tr><th>Exercise</th><th>Course</th><th>Level</th><th>Access</th><th>Status</th><th>Attempts</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($exercises as $x): ?>
                    <tr>
                        <td><strong><?= e($x['title']) ?></strong><br><span class="af-muted"><?= e($x['pair_label']) ?> &middot; <?= e($x['timeframe_label']) ?> &middot; <?= $x['mode'] === 'box' ? 'price + time' : ($x['mode'] === 'trendline' ? 'trendline' : 'price level') ?></span></td>
                        <td><?= e($x['course_title'] ?? 'None') ?></td>
                        <td><?= e($x['difficulty']) ?></td>
                        <td><?= $x['is_premium'] ? 'Premium' : 'Free' ?></td>
                        <td style="text-transform:capitalize;"><?= e($x['status']) ?></td>
                        <td><?= (int) $x['attempt_count'] ?> <span class="af-muted">(<?= (int) $x['solver_count'] ?> solved)</span></td>
                        <td style="white-space:nowrap;">
                            <a href="<?= APP_URL ?>/admin/chart_exercises.php?edit=<?= (int) $x['id'] ?><?= $filterCourse ? '&amp;course_id=' . $filterCourse : '' ?>" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">Edit</a>
                            <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="filter_course" value="<?= (int) $filterCourse ?>"><input type="hidden" name="action" value="move"><input type="hidden" name="exercise_id" value="<?= (int) $x['id'] ?>"><input type="hidden" name="direction" value="up"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; font-size:13px;" aria-label="Move up">&uarr;</button></form>
                            <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="filter_course" value="<?= (int) $filterCourse ?>"><input type="hidden" name="action" value="move"><input type="hidden" name="exercise_id" value="<?= (int) $x['id'] ?>"><input type="hidden" name="direction" value="down"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; font-size:13px;" aria-label="Move down">&darr;</button></form>
                            <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="filter_course" value="<?= (int) $filterCourse ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="exercise_id" value="<?= (int) $x['id'] ?>"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;"><?= $x['status'] === 'published' ? 'Unpublish' : 'Publish' ?></button></form>
                            <form method="post" style="display:inline;" data-confirm="Delete this exercise and all student attempts on it?"><?= csrf_field() ?><input type="hidden" name="filter_course" value="<?= (int) $filterCourse ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="exercise_id" value="<?= (int) $x['id'] ?>"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px; color:var(--red);">Delete</button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
