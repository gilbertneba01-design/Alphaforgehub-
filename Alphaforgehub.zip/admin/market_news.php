<?php
/**
 * ALPHA FORGE HUB (ADMIN) - Market News
 * Admin manually curates news items. No fabricated headlines - only real
 * items the admin has verified and pasted in (with a source link).
 */
$pageTitle = 'Market News';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id        = (int) ($_POST['id'] ?? 0);
        $headline  = trim($_POST['headline'] ?? '');
        $source    = trim($_POST['source'] ?? '');
        $sourceUrl = trim($_POST['source_url'] ?? '');
        $currency  = strtoupper(trim($_POST['currency'] ?? ''));
        $summary   = trim($_POST['summary'] ?? '');
        $published = trim($_POST['published_at'] ?? '');

        if ($headline && $source && $published) {
            $params = [$headline, $source, $sourceUrl ?: null, $currency ?: null, $summary ?: null, date('Y-m-d H:i:s', strtotime($published))];
            if ($id) {
                db()->prepare('UPDATE market_news SET headline=?, source=?, source_url=?, currency=?, summary=?, published_at=? WHERE id=?')
                    ->execute([...$params, $id]);
                flash_set('success', 'News item updated.');
            } else {
                db()->prepare('INSERT INTO market_news (headline, source, source_url, currency, summary, published_at) VALUES (?,?,?,?,?,?)')
                    ->execute($params);
                flash_set('success', 'News item added.');
            }
        } else {
            flash_set('error', 'Headline, source and published date/time are required.');
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM market_news WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'News item deleted.');
    }
    redirect('/admin/market_news.php');
}

$editing = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM market_news WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$news = db()->query('SELECT * FROM market_news ORDER BY published_at DESC LIMIT 300')->fetchAll();
?>
<h1>Market News</h1>
<p class="af-muted">Curated by admin - paste real headlines with a source link. No invented news.</p>

<div class="af-card" style="max-width:720px; margin:18px 0;">
    <h3><?= $editing ? 'Edit News Item' : 'Add News Item' ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing ? (int) $editing['id'] : 0 ?>">
        <div class="af-field"><label>Headline</label><input type="text" name="headline" value="<?= e($editing['headline'] ?? '') ?>" required></div>
        <div class="af-grid af-grid-3" style="gap:12px;">
            <div class="af-field"><label>Source</label><input type="text" name="source" value="<?= e($editing['source'] ?? '') ?>" placeholder="Reuters, Bloomberg..." required></div>
            <div class="af-field"><label>Related Currency (optional)</label><input type="text" name="currency" maxlength="3" style="text-transform:uppercase;" value="<?= e($editing['currency'] ?? '') ?>"></div>
            <div class="af-field"><label>Published</label><input type="datetime-local" name="published_at" value="<?= $editing ? date('Y-m-d\TH:i', strtotime($editing['published_at'])) : '' ?>" required></div>
        </div>
        <div class="af-field"><label>Source URL</label><input type="url" name="source_url" value="<?= e($editing['source_url'] ?? '') ?>" placeholder="https://..."></div>
        <div class="af-field"><label>Short Summary</label><textarea name="summary" rows="3"><?= e($editing['summary'] ?? '') ?></textarea></div>
        <button type="submit" class="af-btn af-btn-gold"><?= $editing ? 'Save Changes' : 'Add News Item' ?></button>
        <?php if ($editing): ?><a href="<?= APP_URL ?>/admin/market_news.php" class="af-btn af-btn-ghost">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Published</th><th>Headline</th><th>Source</th><th>Currency</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($news as $n): ?>
            <tr>
                <td><?= e(date('d M Y H:i', strtotime($n['published_at']))) ?></td>
                <td><?= e($n['headline']) ?></td>
                <td><?= e($n['source']) ?></td>
                <td><?= e($n['currency'] ?? '—') ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/market_news.php?edit=<?= (int) $n['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 10px;">Edit</a>
                    <form method="post" style="display:inline;" data-confirm="Delete this news item?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $n['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$news): ?><tr><td colspan="5" class="af-muted">No news items yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
