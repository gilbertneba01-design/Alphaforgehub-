<?php
$pageTitle = 'Lessons';
require_once __DIR__ . '/includes/admin_header.php';

$courses = db()->query('SELECT id, title, is_premium FROM courses ORDER BY sort_order')->fetchAll();
$selectedCourseId = (int) ($_GET['course_id'] ?? ($courses[0]['id'] ?? 0));
$selectedCoursePremium = false;
foreach ($courses as $__c) {
    if ((int) $__c['id'] === $selectedCourseId) { $selectedCoursePremium = (bool) $__c['is_premium']; }
}

$modStmt = db()->prepare('SELECT id, title FROM modules WHERE course_id = ? ORDER BY sort_order');
$modStmt->execute([$selectedCourseId]);
$modulesForCourse = $modStmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $moduleId = (int) $_POST['module_id'];
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $duration = (int) ($_POST['duration_minutes'] ?? 10);
        $isPremium = isset($_POST['is_premium']) ? 1 : 0;
        $status = $_POST['status'] ?? 'published';

        if ($title !== '' && $moduleId > 0) {
            $slug = slugify($title);
            $check = db()->prepare('SELECT id FROM lessons WHERE module_id = ? AND slug = ?');
            $check->execute([$moduleId, $slug]);
            if ($check->fetch()) {
                $slug .= '-' . substr(bin2hex(random_bytes(2)), 0, 4);
            }
            $ordStmt = db()->prepare('SELECT COALESCE(MAX(sort_order),0) FROM lessons WHERE module_id = ?');
            $ordStmt->execute([$moduleId]);
            $maxOrder = (int) $ordStmt->fetchColumn();

            $ins = db()->prepare(
                'INSERT INTO lessons (module_id, title, slug, content, duration_minutes, is_premium, status, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $ins->execute([$moduleId, $title, $slug, $content, $duration, $isPremium, $status, $maxOrder + 1]);
            flash_set('success', 'Lesson created.');
        }
        redirect('/admin/lessons.php?course_id=' . $selectedCourseId);
    } elseif ($action === 'update') {
        $id = (int) $_POST['lesson_id'];
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $duration = (int) ($_POST['duration_minutes'] ?? 10);
        $isPremium = isset($_POST['is_premium']) ? 1 : 0;
        $status = $_POST['status'] ?? 'published';

        db()->prepare(
            'UPDATE lessons SET title=?, content=?, duration_minutes=?, is_premium=?, status=? WHERE id=?'
        )->execute([$title, $content, $duration, $isPremium, $status, $id]);
        flash_set('success', 'Lesson updated.');
        redirect('/admin/lessons.php?course_id=' . $selectedCourseId);
    } elseif ($action === 'delete') {
        $id = (int) $_POST['lesson_id'];
        db()->prepare('DELETE FROM lessons WHERE id = ?')->execute([$id]);
        flash_set('success', 'Lesson deleted.');
        redirect('/admin/lessons.php?course_id=' . $selectedCourseId);
    } elseif ($action === 'move') {
        $id = (int) $_POST['lesson_id'];
        $direction = $_POST['direction'] ?? '';
        $stmt = db()->prepare('SELECT * FROM lessons WHERE id = ?');
        $stmt->execute([$id]);
        $lesson = $stmt->fetch();
        if ($lesson) {
            $cmp = $direction === 'up' ? '<' : '>';
            $order = $direction === 'up' ? 'DESC' : 'ASC';
            $swapStmt = db()->prepare(
                "SELECT * FROM lessons WHERE module_id = ? AND sort_order $cmp ? ORDER BY sort_order $order LIMIT 1"
            );
            $swapStmt->execute([$lesson['module_id'], $lesson['sort_order']]);
            $swap = $swapStmt->fetch();
            if ($swap) {
                db()->prepare('UPDATE lessons SET sort_order = ? WHERE id = ?')->execute([$swap['sort_order'], $lesson['id']]);
                db()->prepare('UPDATE lessons SET sort_order = ? WHERE id = ?')->execute([$lesson['sort_order'], $swap['id']]);
            }
        }
        redirect('/admin/lessons.php?course_id=' . $selectedCourseId);
    }
}

$lessons = [];
foreach ($modulesForCourse as $mod) {
    $lesStmt = db()->prepare('SELECT * FROM lessons WHERE module_id = ? ORDER BY sort_order');
    $lesStmt->execute([$mod['id']]);
    $lessons[$mod['id']] = ['module' => $mod, 'lessons' => $lesStmt->fetchAll()];
}
?>
<h1>Lessons</h1>

<form method="get" style="max-width:320px; margin-bottom:20px;">
    <div class="af-field"><label>Course</label>
        <select name="course_id" data-autosubmit>
            <?php foreach ($courses as $c): ?>
                <option value="<?= (int) $c['id'] ?>" <?= $selectedCourseId === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<?php if (!$modulesForCourse): ?>
    <div class="af-card" style="max-width:560px; border-color:var(--gold);">
        <h3 style="margin-top:0;">This course has no modules yet</h3>
        <p>Lessons are added inside modules (like chapters). Create the first module for this course, then come back here to add its lessons.</p>
        <a href="<?= APP_URL ?>/admin/modules.php?course_id=<?= $selectedCourseId ?>" class="af-btn af-btn-gold">Add the first module</a>
    </div>
<?php endif; ?>

<?php foreach ($lessons as $group): ?>
    <h2 style="margin-top:28px;"><?= e($group['module']['title']) ?></h2>
    <?php foreach ($group['lessons'] as $l): ?>
        <div class="af-card" style="margin-bottom:14px;">
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="lesson_id" value="<?= (int) $l['id'] ?>">
                <div class="af-field"><label>Title</label><input type="text" name="title" value="<?= e($l['title']) ?>"></div>
                <div class="af-field"><label>Content</label><textarea name="content" rows="4"><?= e($l['content']) ?></textarea></div>
                <div class="af-field"><label>Duration (minutes)</label><input type="number" name="duration_minutes" value="<?= (int) $l['duration_minutes'] ?>"></div>
                <div class="af-field"><label><input type="checkbox" name="is_premium" value="1" <?= $l['is_premium'] ? 'checked' : '' ?>> Premium lesson</label></div>
                <div class="af-field"><label>Status</label>
                    <select name="status">
                        <option value="published" <?= $l['status'] === 'published' ? 'selected' : '' ?>>Published</option>
                        <option value="draft" <?= $l['status'] === 'draft' ? 'selected' : '' ?>>Draft</option>
                    </select>
                </div>
                <button type="submit" class="af-btn af-btn-ghost">Save</button>
            </form>
            <div style="display:flex; gap:8px; margin-top:10px;">
                <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="move"><input type="hidden" name="lesson_id" value="<?= (int) $l['id'] ?>"><input type="hidden" name="direction" value="up"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">Move Up</button></form>
                <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="move"><input type="hidden" name="lesson_id" value="<?= (int) $l['id'] ?>"><input type="hidden" name="direction" value="down"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">Move Down</button></form>
                <a href="<?= APP_URL ?>/admin/quizzes.php?lesson_id=<?= (int) $l['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;">Manage Quiz</a>
                <form method="post" data-confirm="Delete this lesson?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="lesson_id" value="<?= (int) $l['id'] ?>"><button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px; color:var(--red);">Delete</button></form>
            </div>
        </div>
    <?php endforeach; ?>
    <?php if (!$group['lessons']): ?><p class="af-muted">No lessons in this module yet.</p><?php endif; ?>

    <div class="af-card" style="max-width:560px; margin-top:10px;">
        <h3>Add Lesson to "<?= e($group['module']['title']) ?>"</h3>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <input type="hidden" name="module_id" value="<?= (int) $group['module']['id'] ?>">
            <div class="af-field"><label>Title</label><input type="text" name="title" required></div>
            <div class="af-field"><label>Content</label><textarea name="content" rows="3"></textarea></div>
            <div class="af-field"><label>Duration (minutes)</label><input type="number" name="duration_minutes" value="10"></div>
            <div class="af-field"><label><input type="checkbox" name="is_premium" value="1" <?= $selectedCoursePremium ? 'checked' : '' ?>> Premium lesson</label></div>
            <div class="af-field"><label>Status</label>
                <select name="status"><option value="published">Published</option><option value="draft">Draft</option></select>
            </div>
            <button type="submit" class="af-btn af-btn-gold">Add Lesson</button>
        </form>
    </div>
<?php endforeach; ?>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
