<?php
$pageTitle = 'Testimonials';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name = trim($_POST['name'] ?? '');
        $role = trim($_POST['role_title'] ?? '');
        $message = trim($_POST['message'] ?? '');
        if ($name !== '' && $message !== '') {
            db()->prepare('INSERT INTO testimonials (name, role_title, message, is_approved) VALUES (?, ?, ?, 0)')
                ->execute([$name, $role ?: null, $message]);
            flash_set('success', 'Testimonial added.');
        }
    } elseif ($action === 'toggle_approval') {
        $id = (int) $_POST['id'];
        $stmt = db()->prepare('SELECT is_approved FROM testimonials WHERE id = ?');
        $stmt->execute([$id]);
        $current = (int) $stmt->fetchColumn();
        db()->prepare('UPDATE testimonials SET is_approved = ? WHERE id = ?')->execute([$current ? 0 : 1, $id]);
        flash_set('success', 'Testimonial visibility updated.');
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM testimonials WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Testimonial deleted.');
    }
    redirect('/admin/testimonials.php');
}

$testimonials = db()->query('SELECT * FROM testimonials ORDER BY created_at DESC')->fetchAll();
?>
<h1>Testimonials</h1>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Name</th><th>Message</th><th>Approved</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($testimonials as $t): ?>
            <tr>
                <td><?= e($t['name']) ?><?php if ($t['role_title']): ?><br><span class="af-muted"><?= e($t['role_title']) ?></span><?php endif; ?></td>
                <td style="max-width:360px;"><?= e($t['message']) ?></td>
                <td><?= $t['is_approved'] ? 'Yes' : 'No' ?></td>
                <td style="white-space:nowrap;">
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_approval"><input type="hidden" name="id" value="<?= (int) $t['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px;"><?= $t['is_approved'] ? 'Hide' : 'Approve' ?></button>
                    </form>
                    <form method="post" style="display:inline;" data-confirm="Delete this testimonial?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $t['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 12px; font-size:13px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$testimonials): ?><tr><td colspan="4" class="af-muted">No testimonials yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<div class="af-card" style="max-width:520px; margin-top:24px;">
    <h3>Add Testimonial</h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="af-field"><label>Name</label><input type="text" name="name" required></div>
        <div class="af-field"><label>Role / Title (optional)</label><input type="text" name="role_title"></div>
        <div class="af-field"><label>Message</label><textarea name="message" rows="3" required></textarea></div>
        <button type="submit" class="af-btn af-btn-gold">Add Testimonial</button>
    </form>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
