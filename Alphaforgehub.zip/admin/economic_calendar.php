<?php
/**
 * ALPHA FORGE HUB (ADMIN) - Economic Calendar
 * Admin manually enters events (or, later, a scheduled job using a real
 * economic-calendar API can insert rows here). No fake/invented data.
 */
$pageTitle = 'Economic Calendar';
require_once __DIR__ . '/includes/admin_header.php';

const ECON_IMPACTS = ['low' => 'Low', 'medium' => 'Medium', 'high' => 'High'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id       = (int) ($_POST['id'] ?? 0);
        $date     = trim($_POST['event_date'] ?? '');
        $time     = trim($_POST['event_time'] ?? '');
        $currency = strtoupper(trim($_POST['currency'] ?? ''));
        $name     = trim($_POST['event_name'] ?? '');
        $impact   = $_POST['impact'] ?? 'medium';

        if ($date && $currency && $name && isset(ECON_IMPACTS[$impact])) {
            $params = [
                $date, $time ?: null, $currency, $name, $impact,
                trim($_POST['forecast'] ?? '') ?: null,
                trim($_POST['previous'] ?? '') ?: null,
                trim($_POST['actual'] ?? '') ?: null,
            ];
            if ($id) {
                db()->prepare('UPDATE economic_events SET event_date=?, event_time=?, currency=?, event_name=?, impact=?, forecast=?, previous=?, actual=? WHERE id=?')
                    ->execute([...$params, $id]);
                flash_set('success', 'Event updated.');
            } else {
                db()->prepare('INSERT INTO economic_events (event_date, event_time, currency, event_name, impact, forecast, previous, actual) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute($params);
                flash_set('success', 'Event added.');
            }
        } else {
            flash_set('error', 'Please fill in date, currency, event name and a valid impact.');
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM economic_events WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Event deleted.');
    }
    redirect('/admin/economic_calendar.php');
}

$editing = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM economic_events WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$events = db()->query('SELECT * FROM economic_events ORDER BY event_date DESC, event_time DESC LIMIT 300')->fetchAll();
?>
<h1>Economic Calendar</h1>
<p class="af-muted">Add events manually below. When a live calendar API is connected in future, it can insert rows into this same table.</p>

<div class="af-card" style="max-width:720px; margin:18px 0;">
    <h3><?= $editing ? 'Edit Event' : 'Add Event' ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing ? (int) $editing['id'] : 0 ?>">
        <div class="af-grid af-grid-3" style="gap:12px;">
            <div class="af-field"><label>Date</label><input type="date" name="event_date" value="<?= e($editing['event_date'] ?? '') ?>" required></div>
            <div class="af-field"><label>Time (optional)</label><input type="time" name="event_time" value="<?= e($editing['event_time'] ?? '') ?>"></div>
            <div class="af-field"><label>Currency</label><input type="text" name="currency" maxlength="3" style="text-transform:uppercase;" value="<?= e($editing['currency'] ?? '') ?>" required></div>
            <div class="af-field" style="grid-column:span 2;"><label>Event Name</label><input type="text" name="event_name" value="<?= e($editing['event_name'] ?? '') ?>" required></div>
            <div class="af-field"><label>Impact</label>
                <select name="impact">
                    <?php foreach (ECON_IMPACTS as $k => $l): ?><option value="<?= e($k) ?>" <?= ($editing['impact'] ?? 'medium') === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="af-field"><label>Forecast</label><input type="text" name="forecast" value="<?= e($editing['forecast'] ?? '') ?>"></div>
            <div class="af-field"><label>Previous</label><input type="text" name="previous" value="<?= e($editing['previous'] ?? '') ?>"></div>
            <div class="af-field"><label>Actual</label><input type="text" name="actual" value="<?= e($editing['actual'] ?? '') ?>"></div>
        </div>
        <button type="submit" class="af-btn af-btn-gold"><?= $editing ? 'Save Changes' : 'Add Event' ?></button>
        <?php if ($editing): ?><a href="<?= APP_URL ?>/admin/economic_calendar.php" class="af-btn af-btn-ghost">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Date</th><th>Currency</th><th>Event</th><th>Impact</th><th>Forecast</th><th>Previous</th><th>Actual</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($events as $ev): ?>
            <tr>
                <td><?= e($ev['event_date']) ?><?= $ev['event_time'] ? ' ' . e(substr($ev['event_time'], 0, 5)) : '' ?></td>
                <td><?= e($ev['currency']) ?></td>
                <td><?= e($ev['event_name']) ?></td>
                <td style="text-transform:capitalize;"><?= e($ev['impact']) ?></td>
                <td><?= e($ev['forecast'] ?? '—') ?></td>
                <td><?= e($ev['previous'] ?? '—') ?></td>
                <td><?= e($ev['actual'] ?? '—') ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/economic_calendar.php?edit=<?= (int) $ev['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 10px;">Edit</a>
                    <form method="post" style="display:inline;" data-confirm="Delete this event?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $ev['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$events): ?><tr><td colspan="8" class="af-muted">No events yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
