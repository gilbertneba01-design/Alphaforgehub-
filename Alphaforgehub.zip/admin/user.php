<?php
$pageTitle = 'Student Profile';
require_once __DIR__ . '/includes/admin_header.php';

$userId = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM users WHERE id = ? AND role = 'student'");
$stmt->execute([$userId]);
$student = $stmt->fetch();

if (!$student) {
    echo '<p>Student not found. <a href="' . APP_URL . '/admin/users.php">Back</a></p>';
    require_once __DIR__ . '/includes/admin_footer.php';
    exit;
}

// Admin can suspend/reactivate a student account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_mute'])) {
    require_csrf();
    db()->prepare('UPDATE users SET community_muted = 1 - community_muted WHERE id = ?')->execute([$userId]);
    flash_set('success', 'Community posting permission updated.');
    redirect('/admin/user.php?id=' . $userId);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
    require_csrf();
    $newStatus = $student['status'] === 'active' ? 'suspended' : 'active';
    db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$newStatus, $userId]);
    flash_set('success', 'Student status updated.');
    redirect('/admin/user.php?id=' . $userId);
}

$progress = get_student_progress($userId);
$subscription = get_effective_subscription($userId);

$subsStmt = db()->prepare(
    "SELECT s.*, p.name AS plan_name FROM subscriptions s JOIN subscription_plans p ON p.id = s.plan_id
     WHERE s.user_id = ? ORDER BY s.created_at DESC"
);
$subsStmt->execute([$userId]);
$allSubs = $subsStmt->fetchAll();

$completedStmt = db()->prepare(
    "SELECT l.title, lp.completed_at FROM lesson_progress lp
     JOIN lessons l ON l.id = lp.lesson_id
     WHERE lp.user_id = ? ORDER BY lp.completed_at DESC"
);
$completedStmt->execute([$userId]);
$completedLessons = $completedStmt->fetchAll();
?>
<a href="<?= APP_URL ?>/admin/users.php" class="af-muted">&larr; Back to Students</a>
<h1><?= e($student['full_name']) ?></h1>
<p class="af-muted"><?= e($student['email']) ?> &middot; Registered <?= e(date('d M Y', strtotime($student['created_at']))) ?> &middot; Status: <?= e($student['status']) ?></p>

<form method="post" style="margin:12px 0 24px;">
    <?= csrf_field() ?>
    <button type="submit" name="toggle_status" value="1" class="af-btn af-btn-ghost">
        <?= $student['status'] === 'active' ? 'Suspend Account' : 'Reactivate Account' ?>
    </button>
</form>
<form method="post" style="display:inline-block;margin-left:8px;">
    <?= csrf_field() ?>
    <button type="submit" name="toggle_mute" value="1" class="af-btn af-btn-ghost">
        <?= !empty($student['community_muted']) ? 'Unmute in Community' : 'Mute in Community' ?>
    </button>
</form>

<div class="af-grid af-grid-3">
    <div class="af-card"><p class="af-muted" style="margin:0;">Lessons Completed</p><h3 style="font-size:26px;"><?= $progress['completed'] ?> / <?= $progress['total'] ?></h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Progress</p><h3 style="font-size:26px;"><?= $progress['percent'] ?>%</h3></div>
    <div class="af-card"><p class="af-muted" style="margin:0;">Current Subscription</p><h3 style="font-size:20px; text-transform:capitalize;"><?= $subscription ? e($subscription['status']) : 'None' ?></h3></div>
</div>

<h2 style="margin-top:32px;">Subscription History</h2>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Plan</th><th>Status</th><th>Starts</th><th>Ends</th></tr></thead>
        <tbody>
        <?php foreach ($allSubs as $s): ?>
            <tr>
                <td><?= e($s['plan_name']) ?></td>
                <td style="text-transform:capitalize;"><?= e($s['status']) ?></td>
                <td><?= $s['starts_at'] ? e(date('d M Y', strtotime($s['starts_at']))) : '—' ?></td>
                <td><?= $s['ends_at'] ? e(date('d M Y', strtotime($s['ends_at']))) : '—' ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$allSubs): ?><tr><td colspan="4" class="af-muted">No subscriptions yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>

<h2 style="margin-top:32px;">Completed Lessons</h2>
<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Lesson</th><th>Completed</th></tr></thead>
        <tbody>
        <?php foreach ($completedLessons as $l): ?>
            <tr><td><?= e($l['title']) ?></td><td><?= e(date('d M Y, H:i', strtotime($l['completed_at']))) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$completedLessons): ?><tr><td colspan="2" class="af-muted">No lessons completed yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
