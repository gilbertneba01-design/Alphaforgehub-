<?php
$pageTitle = 'Market Data';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_strength') {
        db()->prepare('INSERT INTO currency_strength_snapshots (currency, strength_score, snapshot_date, source) VALUES (?,?,?,?)
            ON DUPLICATE KEY UPDATE strength_score = VALUES(strength_score), source = VALUES(source)')
            ->execute([strtoupper(trim($_POST['currency'])), (float) $_POST['strength_score'], $_POST['snapshot_date'], trim($_POST['source']) ?: 'manual']);
        flash_set('success', 'Currency strength entry saved.');
    } elseif ($action === 'add_correlation') {
        db()->prepare('INSERT INTO currency_correlations (pair_a, pair_b, correlation_value, timeframe, snapshot_date, source) VALUES (?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE correlation_value = VALUES(correlation_value), source = VALUES(source)')
            ->execute([strtoupper(trim($_POST['pair_a'])), strtoupper(trim($_POST['pair_b'])), (float) $_POST['correlation_value'], trim($_POST['timeframe']) ?: '1M', $_POST['snapshot_date'], trim($_POST['source']) ?: 'manual']);
        flash_set('success', 'Correlation entry saved.');
    } elseif ($action === 'add_sentiment') {
        db()->prepare('INSERT INTO market_sentiment_snapshots (snapshot_date, sentiment, summary, source) VALUES (?,?,?,?)
            ON DUPLICATE KEY UPDATE sentiment = VALUES(sentiment), summary = VALUES(summary)')
            ->execute([$_POST['snapshot_date'], $_POST['sentiment'], trim($_POST['summary']), trim($_POST['source']) ?: 'manual']);
        flash_set('success', 'Sentiment snapshot saved.');
    }
    redirect('/admin/market_data.php');
}

$strengthRows = db()->query('SELECT * FROM currency_strength_snapshots ORDER BY snapshot_date DESC, currency LIMIT 20')->fetchAll();
$corrRows = db()->query('SELECT * FROM currency_correlations ORDER BY snapshot_date DESC LIMIT 20')->fetchAll();
$sentRows = db()->query('SELECT * FROM market_sentiment_snapshots ORDER BY snapshot_date DESC LIMIT 10')->fetchAll();
?>
<h1>Market Data</h1>
<p class="af-muted">Manually record Market Center snapshots. Never fabricate figures — leave a section empty until a real source/provider is available.</p>

<div class="af-grid af-grid-2" style="gap:20px;">
    <div class="af-card" style="padding:20px;">
        <h2>Currency Strength</h2>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_strength">
            <div class="af-field"><label>Currency (3-letter)</label><input type="text" name="currency" maxlength="3" required></div>
            <div class="af-field"><label>Strength Score (-100 to 100)</label><input type="number" step="0.01" name="strength_score" required></div>
            <div class="af-field"><label>Date</label><input type="date" name="snapshot_date" value="<?= date('Y-m-d') ?>" required></div>
            <div class="af-field"><label>Source</label><input type="text" name="source" placeholder="manual"></div>
            <button type="submit" class="af-btn af-btn-gold">Save</button>
        </form>
        <table class="af-table" style="margin-top:16px;"><thead><tr><th>Date</th><th>Ccy</th><th>Score</th></tr></thead><tbody>
        <?php foreach ($strengthRows as $r): ?><tr><td><?= e($r['snapshot_date']) ?></td><td><?= e($r['currency']) ?></td><td><?= e($r['strength_score']) ?></td></tr><?php endforeach; ?>
        </tbody></table>
    </div>

    <div class="af-card" style="padding:20px;">
        <h2>Currency Correlation</h2>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_correlation">
            <div class="af-field"><label>Pair A</label><input type="text" name="pair_a" required placeholder="EURUSD"></div>
            <div class="af-field"><label>Pair B</label><input type="text" name="pair_b" required placeholder="GBPUSD"></div>
            <div class="af-field"><label>Correlation (-1.000 to 1.000)</label><input type="number" step="0.001" name="correlation_value" required></div>
            <div class="af-field"><label>Timeframe</label><input type="text" name="timeframe" value="1M"></div>
            <div class="af-field"><label>Date</label><input type="date" name="snapshot_date" value="<?= date('Y-m-d') ?>" required></div>
            <div class="af-field"><label>Source</label><input type="text" name="source" placeholder="manual"></div>
            <button type="submit" class="af-btn af-btn-gold">Save</button>
        </form>
        <table class="af-table" style="margin-top:16px;"><thead><tr><th>Date</th><th>Pair A</th><th>Pair B</th><th>Value</th></tr></thead><tbody>
        <?php foreach ($corrRows as $r): ?><tr><td><?= e($r['snapshot_date']) ?></td><td><?= e($r['pair_a']) ?></td><td><?= e($r['pair_b']) ?></td><td><?= e($r['correlation_value']) ?></td></tr><?php endforeach; ?>
        </tbody></table>
    </div>
</div>

<div class="af-card" style="padding:20px; margin-top:20px;">
    <h2>Market Sentiment</h2>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_sentiment">
        <div class="af-grid af-grid-3" style="gap:12px;">
            <div class="af-field"><label>Date</label><input type="date" name="snapshot_date" value="<?= date('Y-m-d') ?>" required></div>
            <div class="af-field"><label>Sentiment</label>
                <select name="sentiment"><option value="risk_on">Risk-On</option><option value="risk_off">Risk-Off</option><option value="neutral">Neutral</option></select>
            </div>
            <div class="af-field"><label>Source</label><input type="text" name="source" placeholder="manual"></div>
        </div>
        <div class="af-field"><label>Summary</label><textarea name="summary" rows="2" required></textarea></div>
        <button type="submit" class="af-btn af-btn-gold">Save</button>
    </form>
    <table class="af-table" style="margin-top:16px;"><thead><tr><th>Date</th><th>Sentiment</th><th>Summary</th></tr></thead><tbody>
    <?php foreach ($sentRows as $r): ?><tr><td><?= e($r['snapshot_date']) ?></td><td><?= e($r['sentiment']) ?></td><td><?= e($r['summary']) ?></td></tr><?php endforeach; ?>
    </tbody></table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
