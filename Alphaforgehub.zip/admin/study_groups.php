<?php
/** ALPHA FORGE HUB - Study Groups management (ADMIN) */
require_once __DIR__ . '/../config/functions.php';
require_admin();
$admin = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $name = post_text('name', 150); $desc = post_text('description', 2000);
        if ($name !== '') db()->prepare('INSERT INTO study_groups (name, description, created_by) VALUES (?,?,?)')->execute([$name, $desc, $admin['id']]);
    } elseif ($action === 'status') {
        $status = in_array($_POST['status'] ?? '', ['open','locked','closed'], true) ? $_POST['status'] : 'open';
        db()->prepare('UPDATE study_groups SET status=? WHERE id=?')->execute([$status, (int) $_POST['id']]);
    } elseif ($action === 'remove_member') {
        db()->prepare("UPDATE study_group_members SET status='removed' WHERE group_id=? AND user_id=?")
            ->execute([(int) $_POST['group_id'], (int) $_POST['user_id']]);
    } elseif ($action === 'delete_post') {
        db()->prepare('UPDATE study_group_posts SET is_hidden=1 WHERE id=?')->execute([(int) $_POST['post_id']]);
    }
    redirect('/admin/study_groups.php' . (!empty($_POST['group_id']) ? '?view=' . (int) $_POST['group_id'] : ''));
}

$viewId = (int) ($_GET['view'] ?? 0);
try {
    $groups = db()->query('SELECT g.*, (SELECT COUNT(*) FROM study_group_members m WHERE m.group_id=g.id AND m.status="active") AS member_count FROM study_groups g ORDER BY g.created_at DESC')->fetchAll();
} catch (Throwable $ex) { $groups = []; flash_set('error', 'Run database/migration_v3_audit.sql first.'); }

$members = []; $posts = []; $viewGroup = null;
if ($viewId) {
    $s = db()->prepare('SELECT * FROM study_groups WHERE id=?'); $s->execute([$viewId]); $viewGroup = $s->fetch();
    if ($viewGroup) {
        $ms = db()->prepare("SELECT u.id, u.full_name FROM study_group_members m JOIN users u ON u.id=m.user_id WHERE m.group_id=? AND m.status='active' ORDER BY u.full_name");
        $ms->execute([$viewId]); $members = $ms->fetchAll();
        $ps = db()->prepare('SELECT p.*, u.full_name FROM study_group_posts p JOIN users u ON u.id=p.user_id WHERE p.group_id=? ORDER BY p.created_at DESC LIMIT 100');
        $ps->execute([$viewId]); $posts = $ps->fetchAll();
    }
}
$pageTitle = 'Study Groups';
require_once __DIR__ . '/includes/admin_header.php';
?>
<div>
    <h1>Study Groups</h1>
    <form method="post" class="af-card">
        <?= csrf_field() ?><input type="hidden" name="action" value="create">
        <div class="af-field"><label>Group name</label><input type="text" name="name" maxlength="150" required></div>
        <div class="af-field"><label>Description</label><textarea name="description" rows="2" maxlength="2000"></textarea></div>
        <button class="af-btn af-btn-gold" type="submit">Create Group</button>
    </form>
    <div class="af-table-wrap"><table class="af-table">
        <thead><tr><th>Name</th><th>Members</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($groups as $g): ?>
            <tr>
                <td><a href="?view=<?= (int) $g['id'] ?>"><?= e($g['name']) ?></a></td>
                <td><?= (int) $g['member_count'] ?></td>
                <td><?= e($g['status']) ?></td>
                <td style="white-space:nowrap;">
                    <?php foreach (['open'=>'Unlock','locked'=>'Lock','closed'=>'Close'] as $st=>$label): if ($st===$g['status']) continue; ?>
                    <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="status">
                        <input type="hidden" name="id" value="<?= (int) $g['id'] ?>"><input type="hidden" name="status" value="<?= $st ?>">
                        <button class="af-btn af-btn-ghost af-btn-sm" type="submit"><?= $label ?></button></form>
                    <?php endforeach; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$groups): ?><tr><td colspan="4" class="af-muted">No groups yet.</td></tr><?php endif; ?>
        </tbody>
    </table></div>

    <?php if ($viewGroup): ?>
        <h2 style="margin-top:24px;"><?= e($viewGroup['name']) ?> &middot; Members</h2>
        <div class="af-table-wrap"><table class="af-table"><tbody>
        <?php foreach ($members as $m): ?>
            <tr><td><?= e($m['full_name']) ?></td><td>
                <form method="post" data-confirm="Remove this member?"><?= csrf_field() ?><input type="hidden" name="action" value="remove_member">
                    <input type="hidden" name="group_id" value="<?= (int) $viewId ?>"><input type="hidden" name="user_id" value="<?= (int) $m['id'] ?>">
                    <button class="af-btn af-btn-ghost af-btn-sm" style="color:var(--red);" type="submit">Remove</button></form>
            </td></tr>
        <?php endforeach; ?>
        <?php if (!$members): ?><tr><td class="af-muted">No members.</td></tr><?php endif; ?>
        </tbody></table></div>

        <h2 style="margin-top:24px;">Recent messages</h2>
        <?php foreach ($posts as $p): ?>
            <div class="af-card" style="margin-bottom:8px;">
                <strong><?= e($p['full_name']) ?></strong> <small class="af-muted"><?= e($p['created_at']) ?></small>
                <p style="margin:4px 0;"><?= $p['is_hidden'] ? '<em>hidden</em>' : nl2br(e($p['body'])) ?></p>
                <?php if (!$p['is_hidden']): ?>
                <form method="post" style="display:inline;"><?= csrf_field() ?><input type="hidden" name="action" value="delete_post">
                    <input type="hidden" name="post_id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="group_id" value="<?= (int) $viewId ?>">
                    <button class="af-btn af-btn-ghost af-btn-sm" style="color:var(--red);" type="submit">Hide</button></form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
