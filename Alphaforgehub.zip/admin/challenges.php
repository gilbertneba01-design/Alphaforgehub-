<?php
/**
 * ALPHA FORGE HUB (ADMIN) - Trading Challenges
 */
$pageTitle = 'Challenges';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id       = (int) ($_POST['id'] ?? 0);
        $title    = trim($_POST['title'] ?? '');
        $desc     = trim($_POST['description'] ?? '');
        $duration = max(1, (int) ($_POST['duration_days'] ?? 7));
        $status   = ($_POST['status'] ?? 'active') === 'draft' ? 'draft' : 'active';

        if ($title !== '') {
            if ($id) {
                db()->prepare('UPDATE challenges SET title=?, description=?, duration_days=?, status=? WHERE id=?')
                    ->execute([$title, $desc, $duration, $status, $id]);
                flash_set('success', 'Challenge updated.');
            } else {
                db()->prepare('INSERT INTO challenges (title, description, duration_days, status) VALUES (?,?,?,?)')
                    ->execute([$title, $desc, $duration, $status]);
                flash_set('success', 'Challenge added.');
            }
        } else {
            flash_set('error', 'Title is required.');
        }
    } elseif ($action === 'delete') {
        db()->prepare('DELETE FROM challenges WHERE id = ?')->execute([(int) $_POST['id']]);
        flash_set('success', 'Challenge deleted.');
    }
    redirect('/admin/challenges.php');
}

$editing = null;
if (!empty($_GET['edit'])) {
    $stmt = db()->prepare('SELECT * FROM challenges WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$challenges = db()->query(
    "SELECT ch.*, (SELECT COUNT(*) FROM challenge_progress cp WHERE cp.challenge_id = ch.id) AS joined_count,
            (SELECT COUNT(*) FROM challenge_progress cp WHERE cp.challenge_id = ch.id AND cp.completed_at IS NOT NULL) AS completed_count
     FROM challenges ch ORDER BY ch.created_at DESC"
)->fetchAll();
?>
<h1>Trading Challenges</h1>

<div class="af-card" style="max-width:640px; margin:18px 0;">
    <h3><?= $editing ? 'Edit Challenge' : 'Add Challenge' ?></h3>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= $editing ? (int) $editing['id'] : 0 ?>">
        <div class="af-field"><label>Title</label><input type="text" name="title" value="<?= e($editing['title'] ?? '') ?>" placeholder="7-Day Risk Management Challenge" required></div>
        <div class="af-field"><label>Description</label><textarea name="description" rows="3"><?= e($editing['description'] ?? '') ?></textarea></div>
        <div class="af-grid af-grid-2" style="gap:12px;">
            <div class="af-field"><label>Duration (days)</label><input type="number" name="duration_days" value="<?= e((string) ($editing['duration_days'] ?? 7)) ?>" min="1"></div>
            <div class="af-field"><label>Status</label>
                <select name="status">
                    <option value="active" <?= ($editing['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="draft" <?= ($editing['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
                </select>
            </div>
        </div>
        <button type="submit" class="af-btn af-btn-gold"><?= $editing ? 'Save Changes' : 'Add Challenge' ?></button>
        <?php if ($editing): ?><a href="<?= APP_URL ?>/admin/challenges.php" class="af-btn af-btn-ghost">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="af-table-wrap">
    <table class="af-table">
        <thead><tr><th>Title</th><th>Duration</th><th>Status</th><th>Joined</th><th>Completed</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($challenges as $c): ?>
            <tr>
                <td><?= e($c['title']) ?></td>
                <td><?= (int) $c['duration_days'] ?> days</td>
                <td style="text-transform:capitalize;"><?= e($c['status']) ?></td>
                <td><?= (int) $c['joined_count'] ?></td>
                <td><?= (int) $c['completed_count'] ?></td>
                <td style="white-space:nowrap;">
                    <a href="<?= APP_URL ?>/admin/challenges.php?edit=<?= (int) $c['id'] ?>" class="af-btn af-btn-ghost" style="padding:6px 10px;">Edit</a>
                    <form method="post" style="display:inline;" data-confirm="Delete this challenge?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                        <button type="submit" class="af-btn af-btn-ghost" style="padding:6px 10px; color:var(--red);">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$challenges): ?><tr><td colspan="6" class="af-muted">No challenges yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
