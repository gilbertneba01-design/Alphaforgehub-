<?php
/**
 * ALPHA FORGE HUB - View / Claim Certificate (STUDENT)
 * ?code=AF-XXXXXXXX to view an existing certificate, or
 * ?course_id=N to claim (issue) one the first time - only succeeds if the
 * course is genuinely 100% complete for this student.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/certificates.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

$code = trim((string) ($_GET['code'] ?? ''));
$cert = null;

if ($code !== '') {
    $cert = certificate_get_for_view($userId, $code);
} elseif (!empty($_GET['course_id'])) {
    $issued = certificate_get_or_issue($userId, (int) $_GET['course_id']);
    if ($issued) {
        redirect('/certificate_view.php?code=' . urlencode($issued['certificate_code']));
    }
}

if (!$cert) {
    flash_set('error', 'Certificate not found, or the course is not fully completed yet.');
    redirect('/certificates.php');
}

$pageTitle = 'Certificate';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:900px;">
        <div class="af-cert-actions">
            <a href="<?= APP_URL ?>/certificates.php" class="af-btn af-btn-ghost">&larr; My Certificates</a>
            <button type="button" class="af-btn af-btn-gold" data-af-print>Print / Save as PDF</button>
        </div>

        <div class="af-certificate">
            <div class="af-cert-border">
                <p class="af-cert-brand">ALPHA FORGE <span>HUB</span></p>
                <p class="af-cert-eyebrow">Certificate of Completion</p>
                <p class="af-cert-presented">This certifies that</p>
                <h1 class="af-cert-name"><?= e($cert['student_name']) ?></h1>
                <p class="af-cert-presented">has successfully completed the course</p>
                <h2 class="af-cert-course"><?= e($cert['course_title']) ?></h2>
                <div class="af-cert-meta">
                    <div><span>Date Issued</span><strong><?= e(date('d F Y', strtotime($cert['issued_at']))) ?></strong></div>
                    <div><span>Certificate ID</span><strong><?= e($cert['certificate_code']) ?></strong></div>
                </div>
                <p class="af-cert-verify">Verify this certificate at <?= e(APP_URL) ?>/certificate_verify.php</p>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
