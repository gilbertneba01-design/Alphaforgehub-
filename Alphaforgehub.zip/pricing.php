<?php
require_once __DIR__ . '/config/functions.php';
$plans = db()->query("SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY duration_days")->fetchAll();
$pageTitle = 'Pricing';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <div class="af-ladder"><span></span><span></span><span></span><span></span><span></span></div>
        <h1>Pricing</h1>
        <p style="max-width:560px;">Unlock every Premium lesson, quiz, and module with a subscription. Cancel anytime — access simply runs to the end of your paid period.</p>

        <?php if (($_GET['reason'] ?? '') === 'premium'): ?>
            <div class="af-alert af-alert-error">That lesson requires an active subscription.</div>
        <?php endif; ?>

        <div class="af-grid af-grid-3" style="margin-top:30px;">
            <?php foreach ($plans as $p): ?>
                <div class="af-card">
                    <span class="af-badge"><?= e($p['name']) ?></span>
                    <h3 style="margin-top:14px; font-size:30px;"><?= format_money((float) $p['price'], $p['currency']) ?></h3>
                    <p><?= (int) $p['duration_days'] ?> days of full Premium access.</p>
                    <a href="<?= APP_URL ?>/subscribe.php?plan=<?= (int) $p['id'] ?>" class="af-btn af-btn-gold af-btn-block">Choose <?= e($p['name']) ?></a>
                </div>
            <?php endforeach; ?>
        </div>

        <p class="af-muted" style="margin-top:30px;">Payments are processed via MTN Mobile Money or Orange Money. Your subscription activates automatically once payment is confirmed by the provider.</p>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
