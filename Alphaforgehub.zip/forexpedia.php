<?php
/**
 * ALPHA FORGE HUB - Forexpedia (PUBLIC + STUDENT)
 * Searchable Forex glossary. Public so it's discoverable and useful to
 * visitors before they register; logged-in students additionally see
 * links back into related lessons.
 */
require_once __DIR__ . '/config/functions.php';

$letters = range('A', 'Z');
$active  = strtoupper(trim((string) ($_GET['letter'] ?? '')));
$search  = trim((string) ($_GET['q'] ?? ''));
$slug    = trim((string) ($_GET['term'] ?? ''));

$single = null;
if ($slug !== '') {
    $stmt = db()->prepare("SELECT * FROM forexpedia_terms WHERE slug = ? AND status = 'published' LIMIT 1");
    $stmt->execute([$slug]);
    $single = $stmt->fetch();
}

$terms = [];
if (!$single) {
    if ($search !== '') {
        $stmt = db()->prepare("SELECT * FROM forexpedia_terms WHERE status = 'published' AND (term LIKE ? OR short_definition LIKE ?) ORDER BY term LIMIT 100");
        $like = '%' . $search . '%';
        $stmt->execute([$like, $like]);
        $terms = $stmt->fetchAll();
    } elseif ($active !== '' && strlen($active) === 1) {
        $stmt = db()->prepare("SELECT * FROM forexpedia_terms WHERE status = 'published' AND letter = ? ORDER BY term");
        $stmt->execute([$active]);
        $terms = $stmt->fetchAll();
    } else {
        $terms = db()->query("SELECT * FROM forexpedia_terms WHERE status = 'published' ORDER BY term LIMIT 30")->fetchAll();
    }
}

$pageTitle = $single ? ($single['term'] . ' - Forexpedia') : 'Forexpedia - Forex Glossary';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:920px;">
        <span class="af-eyebrow">Forexpedia</span>
        <h1>Forex Glossary</h1>
        <p class="af-muted">Plain-English definitions of the terms you'll meet across Alpha Forge, with examples and related lessons.</p>

        <form method="get" class="af-card" style="display:flex; gap:10px; margin:18px 0; padding:16px;">
            <input type="text" name="q" value="<?= e($search) ?>" placeholder="Search a term, e.g. Fibonacci" style="flex:1;">
            <button type="submit" class="af-btn af-btn-gold">Search</button>
            <?php if ($search !== ''): ?><a href="<?= APP_URL ?>/forexpedia.php" class="af-btn af-btn-ghost">Clear</a><?php endif; ?>
        </form>

        <?php if ($single): ?>
            <div class="af-card" style="padding:24px;">
                <a href="<?= APP_URL ?>/forexpedia.php" class="af-muted" style="font-size:14px;">&larr; Back to Forexpedia</a>
                <h2 style="margin-top:10px;"><?= e($single['term']) ?></h2>
                <p style="font-size:17px;"><?= e($single['short_definition']) ?></p>
                <?php if ($single['full_explanation']): ?><p><?= nl2br(e($single['full_explanation'])) ?></p><?php endif; ?>
                <?php if ($single['example']): ?>
                    <div style="background:rgba(212,175,55,0.08); border-left:3px solid var(--af-gold,#D4AF37); padding:12px 16px; border-radius:6px;">
                        <strong>Example:</strong> <?= e($single['example']) ?>
                    </div>
                <?php endif; ?>
                <?php if ($single['related_terms']): ?>
                    <p style="margin-top:16px;"><strong>Related terms:</strong>
                        <?php foreach (array_filter(array_map('trim', explode(',', $single['related_terms']))) as $rs): ?>
                            <a href="<?= APP_URL ?>/forexpedia.php?term=<?= urlencode($rs) ?>" class="af-badge" style="margin-right:6px;"><?= e($rs) ?></a>
                        <?php endforeach; ?>
                    </p>
                <?php endif; ?>
                <?php if ($single['related_lesson_id']):
                    $lstmt = db()->prepare('SELECT id, title FROM lessons WHERE id = ?');
                    $lstmt->execute([$single['related_lesson_id']]);
                    $lesson = $lstmt->fetch();
                    if ($lesson): ?>
                    <p style="margin-top:16px;"><a href="<?= APP_URL ?>/lesson.php?id=<?= (int) $lesson['id'] ?>" class="af-btn af-btn-ghost">Related lesson: <?= e($lesson['title']) ?></a></p>
                <?php endif; endif; ?>
            </div>
        <?php else: ?>
            <div class="af-az-index" style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:20px;">
                <a href="<?= APP_URL ?>/forexpedia.php" class="af-badge <?= $active === '' && $search === '' ? 'is-active' : '' ?>">All</a>
                <?php foreach ($letters as $l): ?>
                    <a href="<?= APP_URL ?>/forexpedia.php?letter=<?= $l ?>" class="af-badge <?= $active === $l ? 'is-active' : '' ?>"><?= $l ?></a>
                <?php endforeach; ?>
            </div>

            <?php if (empty($terms)): ?>
                <div class="af-card" style="padding:24px; text-align:center;">
                    <p class="af-muted">No terms found<?= $search !== '' ? ' for "' . e($search) . '"' : '' ?>.</p>
                </div>
            <?php else: ?>
                <div class="af-grid af-grid-2" style="gap:14px;">
                    <?php foreach ($terms as $t): ?>
                        <a href="<?= APP_URL ?>/forexpedia.php?term=<?= urlencode($t['slug']) ?>" class="af-card" style="padding:18px; text-decoration:none; color:inherit;">
                            <h3 style="margin:0 0 6px;"><?= e($t['term']) ?></h3>
                            <p class="af-muted" style="margin:0;"><?= e($t['short_definition']) ?></p>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
