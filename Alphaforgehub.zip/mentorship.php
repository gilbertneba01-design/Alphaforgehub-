<?php
/** ALPHA FORGE HUB - Mentorship (STUDENT) - admin-managed booking, no auto-scheduling yet */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $mentorId = (int) ($_POST['mentor_id'] ?? 0);
    $message  = trim((string) ($_POST['message'] ?? ''));
    $preferred = trim((string) ($_POST['preferred_time'] ?? ''));
    if ($mentorId && $message !== '') {
        db()->prepare('INSERT INTO mentorship_requests (user_id, mentor_id, message, preferred_time) VALUES (?,?,?,?)')
            ->execute([$user['id'], $mentorId, $message, $preferred ?: null]);
        flash_set('success', 'Your mentorship request has been sent. We will reach out to schedule a session.');
    } else {
        flash_set('error', 'Please write a short message describing what you would like help with.');
    }
    redirect('/mentorship.php');
}

$mentors = db()->query("SELECT * FROM mentors WHERE status = 'active' ORDER BY name")->fetchAll();
$myRequests = db()->prepare('SELECT mr.*, m.name AS mentor_name FROM mentorship_requests mr JOIN mentors m ON m.id = mr.mentor_id WHERE mr.user_id = ? ORDER BY mr.created_at DESC');
$myRequests->execute([$user['id']]);
$myRequests = $myRequests->fetchAll();

$pageTitle = 'Mentorship';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Mentorship</h1>
            <p class="af-muted">Request a 1:1 session with a mentor for trade review, questions or guidance. Requests are reviewed and scheduled by our team.</p>

            <?php if (empty($mentors)): ?>
                <div class="af-card" style="padding:24px;"><strong>STATUS:</strong> No mentors are listed yet. Check back soon.</div>
            <?php else: ?>
                <div class="af-grid af-grid-2" style="gap:14px; margin:18px 0;">
                    <?php foreach ($mentors as $m): ?>
                        <div class="af-card" style="padding:18px;">
                            <h3 style="margin:0 0 4px;"><?= e($m['name']) ?></h3>
                            <p class="af-muted" style="margin:0 0 8px;"><?= e($m['headline'] ?? '') ?></p>
                            <p style="font-size:14px;"><?= nl2br(e($m['bio'] ?? '')) ?></p>
                            <details>
                                <summary class="af-btn af-btn-ghost" style="cursor:pointer;">Request a Session</summary>
                                <form method="post" style="margin-top:10px;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="mentor_id" value="<?= $m['id'] ?>">
                                    <div class="af-field"><label>What would you like help with?</label><textarea name="message" rows="3" required></textarea></div>
                                    <div class="af-field"><label>Preferred time (optional)</label><input type="text" name="preferred_time" placeholder="e.g. weekday evenings"></div>
                                    <button type="submit" class="af-btn af-btn-gold">Send Request</button>
                                </form>
                            </details>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($myRequests): ?>
                <h2>My Requests</h2>
                <div class="af-table-wrap"><table class="af-table">
                    <thead><tr><th>Mentor</th><th>Message</th><th>Status</th><th>Sent</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($myRequests as $r): ?>
                        <tr><td><?= e($r['mentor_name']) ?></td><td style="max-width:300px;"><?= e($r['message']) ?></td>
                            <td><?= te('mt_status_' . $r['status']) ?></td><td><?= e($r['created_at']) ?></td>
                            <td><?php if (in_array($r['status'], ['scheduled','completed'], true)): ?><a class="af-btn af-btn-ghost af-btn-sm" href="<?= APP_URL ?>/mentor/chat.php?id=<?= (int) $r['id'] ?>"><?= te('mt_open_chat') ?></a><?php endif; ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
