# What was added - Practice Exercises Pack

## 1. Setup (do this first)
In phpMyAdmin, import:
`database/migration_practice_exercises.sql`
(run it once, after your existing `migration_chartlab.sql`)

## 2. Draw the Upward Trend / Draw the Downward Trend
New Chart Lab exercise type: **trendline**. Unlike the existing
support/resistance/range zones, this grades a diagonal line against
two swing points.
- Two ready-to-use exercises are seeded (EUR/USD uptrend, USD/JPY
  downtrend), both under Technical Analysis, both free.
- Admin > Chart Exercises now has a "Trendline" mode option with an
  Up/Down direction selector, and two new "Generate chart" patterns
  (Uptrend / Downtrend) so you can create more of these yourself.
- Existing support/resistance/range/supply/demand exercises are
  untouched - the trendline code is fully separate.

## 3. Identify the Bid, Ask and Spread
6 new quiz questions added to the existing quiz system, split across
the "Reading a Forex Quote" and "Understanding the Spread" lessons.

## 4. Identify the Trading Session
4 new quiz questions added to "Forex Trading Sessions".

## 5. Pips & Lots Calculator (practice)
New page: `pips_lots_calculator.php`. Generates a random risk-sizing
scenario (balance / risk % / stop-loss pips); the student calculates
the dollar risk and lot size themselves and checks their answer.
Linked from the "Pips, Lots and Leverage" lesson. Respects that
lesson's Premium gating.

## 6. Build Your First Trade (practice)
New page: `first_trade.php`. A guided checklist: pick direction, set
entry/stop/target, set balance and risk %, then get feedback on
whether the stop/target are on the correct side, the risk:reward
ratio, and the resulting position size. No real prices or outcomes -
it checks the STRUCTURE of the plan. Linked from "Risk Per Trade" and
"Stop Loss and Take Profit".

## Files touched
- database/migration_practice_exercises.sql (new)
- config/chartlab.php (trendline grading, additive only)
- chart_lab_api.php (passes mode through)
- admin/chart_exercises.php (trendline mode + direction UI)
- assets/js/chartlab.js (student-facing line drawing)
- assets/js/admin_chartlab.js (admin line authoring + 2 generators)
- lesson.php (practice tool links)
- pips_lots_calculator.php (new)
- first_trade.php (new)

## Notes / things to check on your machine
- I don't have PHP or MySQL available in my sandbox, so I checked
  everything I could by hand (brace/paren balance, JSON validity,
  the trendline grading math re-implemented and tested in Node) but
  I could not actually run this code. Please test on your XAMPP setup
  before relying on it, especially the trendline drawing/grading
  flow end to end.
- The pip-value assumption in the calculator ($10/lot) is stated in
  the UI and only applies to USD-quoted major pairs.
