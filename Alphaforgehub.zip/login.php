<?php
require_once __DIR__ . '/config/functions.php';

if (is_logged_in()) {
    redirect('/dashboard.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!enforce_rate_limit('login', 10, 300, 300)) {
        rate_limit_block_response();
    }

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare("SELECT * FROM users WHERE email = ? AND role IN ('student','mentor') LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        log_security_event('login_failed', 'unknown email');
        $errors[] = 'Invalid email or password.';
    } elseif (is_account_locked($user)) {
        $errors[] = 'This account is temporarily locked due to repeated failed logins. Try again in a few minutes.';
    } elseif (!password_verify($password, $user['password_hash'])) {
        register_failed_login((int) $user['id'], (int) $user['failed_login_count']);
        log_security_event('login_failed', 'wrong password', (int) $user['id']);
        $errors[] = 'Invalid email or password.';
    } elseif ($user['status'] !== 'active') {
        $errors[] = 'This account has been suspended. Contact support for help.';
    } else {
        reset_failed_login((int) $user['id']);
        login_user((int) $user['id']);
        redirect(home_for_role($user['role']));
    }
}

$pageTitle = 'Login';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <form method="post" class="af-form-card">
            <h2 style="text-align:center;">Welcome Back</h2>
            <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>
            <?= csrf_field() ?>
            <div class="af-field"><label>Email</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
            <div class="af-field"><label>Password</label><input type="password" name="password" required></div>
            <button type="submit" class="af-btn af-btn-gold af-btn-block">Login</button>
            <p class="af-muted" style="text-align:center; margin-top:16px;">No account? <a href="<?= APP_URL ?>/register.php">Register</a></p>
        </form>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
