<?php
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/payment/PaymentManager.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];

$slug = trim((string) ($_GET['product'] ?? ''));
$stmt = db()->prepare("SELECT * FROM store_products WHERE slug = ? AND status = 'published'");
$stmt->execute([$slug]);
$product = $stmt->fetch();
if (!$product) redirect('/store.php');

// Already purchased?
$ownedStmt = db()->prepare("SELECT id FROM store_purchases WHERE user_id = ? AND product_id = ? AND status = 'paid' LIMIT 1");
$ownedStmt->execute([$userId, $product['id']]);
$alreadyOwned = (bool) $ownedStmt->fetch();

$errors = [];
$initiated = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$alreadyOwned) {
    require_csrf();
    if (!enforce_rate_limit('store_payment', 8, 600, 600)) {
        rate_limit_block_response();
    }
    $provider = $_POST['provider'] ?? '';
    $phone = trim($_POST['phone'] ?? '');

    if (!in_array($provider, ['mtn_momo', 'orange_money'], true)) {
        $errors[] = 'Please choose a payment method.';
    } elseif ($provider === 'mtn_momo' && $phone === '') {
        $errors[] = 'Please enter the Mobile Money phone number to receive the payment prompt.';
    }

    if (!$errors) {
        $result = PaymentManager::startProductPayment($userId, (int) $product['id'], $provider, $phone);
        if (!$result['success']) {
            $errors[] = $result['message'];
        } elseif ($result['redirect_url']) {
            header('Location: ' . $result['redirect_url']);
            exit;
        } else {
            $initiated = $result;
        }
    }
}

$pageTitle = 'Checkout — ' . $product['title'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:520px;">
        <h1><?= e($product['title']) ?></h1>
        <p class="af-muted"><?= format_money((float) $product['price'], $product['currency']) ?></p>

        <?php if ($alreadyOwned): ?>
            <div class="af-card">
                <h3>You already own this</h3>
                <a href="<?= APP_URL ?>/my_library.php" class="af-btn af-btn-gold">Go to My Library</a>
            </div>
        <?php else: ?>
            <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

            <?php if ($initiated): ?>
                <div class="af-card">
                    <h3>Approve the payment on your phone</h3>
                    <p><?= e($initiated['message']) ?></p>
                    <a href="<?= APP_URL ?>/payment_return.php?payment_id=<?= $initiated['payment_id'] ?>" class="af-btn af-btn-gold">Check Payment Status</a>
                </div>
            <?php else: ?>
                <form method="post" class="af-form-card">
                    <?= csrf_field() ?>
                    <div class="af-field">
                        <label>Payment Method</label>
                        <label style="display:block; margin-bottom:8px;"><input type="radio" name="provider" value="mtn_momo" required> MTN Mobile Money</label>
                        <label style="display:block;"><input type="radio" name="provider" value="orange_money"> Orange Money</label>
                    </div>
                    <div class="af-field">
                        <label>Mobile Money Phone Number</label>
                        <input type="text" name="phone" placeholder="e.g. 6XXXXXXXX" value="<?= e($user['phone'] ?? '') ?>">
                    </div>
                    <button type="submit" class="af-btn af-btn-gold af-btn-block">Pay <?= format_money((float) $product['price'], $product['currency']) ?></button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
