<?php
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/payment/PaymentManager.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];

$planId = (int) ($_GET['plan'] ?? $_POST['plan_id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1');
$stmt->execute([$planId]);
$plan = $stmt->fetch();

if (!$plan) {
    redirect('/pricing.php');
}

$errors = [];
$initiated = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!enforce_rate_limit('subscribe_payment', 8, 600, 600)) {
        rate_limit_block_response();
    }
    $provider = $_POST['provider'] ?? '';
    $phone = trim($_POST['phone'] ?? '');

    if (!in_array($provider, ['mtn_momo', 'orange_money'], true)) {
        $errors[] = 'Please choose a payment method.';
    } elseif ($provider === 'mtn_momo' && $phone === '') {
        $errors[] = 'Please enter the Mobile Money phone number to receive the payment prompt.';
    }

    if (!$errors) {
        $result = PaymentManager::startSubscriptionPayment($userId, $planId, $provider, $phone);
        if (!$result['success']) {
            $errors[] = $result['message'];
        } elseif ($result['redirect_url']) {
            header('Location: ' . $result['redirect_url']);
            exit;
        } else {
            $initiated = $result;
        }
    }
}

$pageTitle = 'Subscribe — ' . $plan['name'];
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:520px;">
        <h1>Subscribe: <?= e($plan['name']) ?></h1>
        <p class="af-muted"><?= format_money((float) $plan['price'], $plan['currency']) ?> &middot; <?= (int) $plan['duration_days'] ?> days</p>

        <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

        <?php if ($initiated): ?>
            <div class="af-card">
                <h3>Approve the payment on your phone</h3>
                <p><?= e($initiated['message']) ?></p>
                <p class="af-muted">Your subscription will activate automatically as soon as the payment is confirmed. You can safely refresh your dashboard to check.</p>
                <a href="<?= APP_URL ?>/payment_return.php?payment_id=<?= $initiated['payment_id'] ?>" class="af-btn af-btn-gold">Check Payment Status</a>
            </div>
        <?php else: ?>
            <form method="post" class="af-form-card">
                <?= csrf_field() ?>
                <input type="hidden" name="plan_id" value="<?= (int) $plan['id'] ?>">

                <div class="af-field">
                    <label>Payment Method</label>
                    <label style="display:block; margin-bottom:8px;"><input type="radio" name="provider" value="mtn_momo" required> MTN Mobile Money</label>
                    <label style="display:block;"><input type="radio" name="provider" value="orange_money"> Orange Money</label>
                </div>

                <div class="af-field" id="afPhoneField">
                    <label>Mobile Money Phone Number</label>
                    <input type="text" name="phone" placeholder="e.g. 6XXXXXXXX" value="<?= e($user['phone'] ?? '') ?>">
                </div>

                <button type="submit" class="af-btn af-btn-gold af-btn-block">Pay <?= format_money((float) $plan['price'], $plan['currency']) ?></button>
            </form>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
