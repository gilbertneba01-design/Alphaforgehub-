<?php
/** ALPHA FORGE HUB - Backtesting Lab (STUDENT) */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$hasAccess = is_admin() || has_active_subscription((int) $user['id']);
$pageTitle = 'Backtesting Lab';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section af-lab-page">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <div class="af-lab-hero">
                <span class="af-badge">Practice Data &middot; Synthetic</span>
                <h1>Backtesting Lab</h1>
                <p>Reveal candles one at a time and make real trade decisions, exactly like manual backtesting. This session uses generated practice data, not real historical prices — the skill you're building (reading price action candle-by-candle, sizing risk in R) transfers directly.</p>
            </div>

            <?php if (!$hasAccess): ?>
                <div class="af-card af-lab-locked">
                    <span class="af-badge">Premium</span>
                    <h2>Backtesting Lab</h2>
                    <p>Subscribe to unlock the Backtesting Lab.</p>
                    <a href="<?= APP_URL ?>/pricing.php?reason=premium" class="af-btn af-btn-gold">Unlock Premium</a>
                </div>
            <?php else: ?>

            <div class="af-card" style="padding:20px;" id="btSetup">
                <div class="af-grid af-grid-3" style="gap:12px;">
                    <div class="af-field"><label>Pair</label>
                        <select id="btPair"><option>EURUSD</option><option>GBPUSD</option><option>USDJPY</option><option>AUDUSD</option></select>
                    </div>
                    <div class="af-field"><label>Timeframe</label>
                        <select id="btTf"><option>M15</option><option selected>H1</option><option>H4</option><option>D1</option></select>
                    </div>
                    <div class="af-field"><label>Strategy Notes (optional)</label><input type="text" id="btNotes" placeholder="e.g. trend-following pullback"></div>
                </div>
                <button class="af-btn af-btn-gold" id="btStart">Start Historical Session</button>
            </div>

            <div class="af-card" style="padding:20px; margin-top:16px;" id="btBoard" hidden>
                <div id="btCandleStrip" style="display:flex; gap:2px; align-items:flex-end; height:140px; overflow-x:auto; border-bottom:1px solid rgba(255,255,255,0.1); margin-bottom:12px;"></div>
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div>Last close: <strong id="btLastClose">&mdash;</strong></div>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <button class="af-btn af-btn-ghost" id="btNext">Reveal Next Candle</button>
                        <button class="af-btn af-btn-gold" id="btBuy" style="background:#2ecc71; border-color:#2ecc71;">Buy Here</button>
                        <button class="af-btn af-btn-gold" id="btSell" style="background:#e74c3c; border-color:#e74c3c;">Sell Here</button>
                        <button class="af-btn af-btn-ghost" id="btCloseTrade" disabled>Close Open Trade</button>
                        <button class="af-btn af-btn-ghost" id="btFinish">Finish & Review Results</button>
                    </div>
                </div>
                <div id="btMsg" class="af-lab-result" hidden style="margin-top:12px;"></div>
            </div>

            <div class="af-card" style="padding:20px; margin-top:16px;" id="btResults" hidden></div>

            <p class="af-lab-legal" style="margin-top:20px;">Generated practice data for skill-building only — not a prediction or guarantee of real-market results.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php if ($hasAccess): ?>
<script nonce="<?= CSP_NONCE ?>">window.AF_BT = { apiUrl: <?= json_encode(APP_URL . '/backtest_api.php') ?>, csrf: <?= json_encode(csrf_token()) ?> };</script>
<script src="<?= APP_URL ?>/assets/js/backtest.js"></script>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
