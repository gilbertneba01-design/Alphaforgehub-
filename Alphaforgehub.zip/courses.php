<?php
require_once __DIR__ . '/config/functions.php';
$courses = db()->query("SELECT * FROM courses WHERE status = 'published' ORDER BY sort_order")->fetchAll();
$pageTitle = 'Courses';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container">
        <div class="af-ladder"><span></span><span></span><span></span><span></span><span></span></div>
        <h1>Courses</h1>
        <p style="max-width:560px;">Every course follows the same path: modules, then lessons, then a short quiz to confirm what stuck.</p>

        <div class="af-grid af-grid-3" style="margin-top:32px;">
            <?php foreach ($courses as $c): ?>
                <div class="af-card">
                    <span class="af-badge af-badge-muted"><?= e($c['level']) ?></span>
                    <span class="af-badge <?= $c['is_premium'] ? '' : 'af-badge-muted' ?>"><?= $c['is_premium'] ? 'Premium' : 'Free' ?></span>
                    <h3 style="margin-top:12px;"><?= e($c['title']) ?></h3>
                    <p><?= e($c['description']) ?></p>
                    <a href="<?= APP_URL ?>/course.php?slug=<?= urlencode($c['slug']) ?>" class="af-btn af-btn-ghost">View Course</a>
                </div>
            <?php endforeach; ?>
            <?php if (!$courses): ?>
                <p class="af-muted">No courses published yet — check back soon.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
