<?php
/** ALPHA FORGE HUB - Study Groups list + join/leave (STUDENT) */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $gid = (int) ($_POST['group_id'] ?? 0);
    $s = db()->prepare("SELECT * FROM study_groups WHERE id = ?"); $s->execute([$gid]); $g = $s->fetch();
    if ($g) {
        if (($_POST['action'] ?? '') === 'join' && $g['status'] === 'open') {
            db()->prepare("INSERT INTO study_group_members (group_id, user_id, status) VALUES (?,?, 'active')
                           ON DUPLICATE KEY UPDATE status='active'")->execute([$gid, $user['id']]);
            flash_set('success', t('sg_joined'));
        } elseif (($_POST['action'] ?? '') === 'leave') {
            db()->prepare("UPDATE study_group_members SET status='removed' WHERE group_id=? AND user_id=?")->execute([$gid, $user['id']]);
            flash_set('success', t('sg_left'));
        }
    }
    redirect('/study_groups.php');
}

try {
    $groups = db()->prepare(
        "SELECT g.*, (SELECT COUNT(*) FROM study_group_members m WHERE m.group_id=g.id AND m.status='active') AS member_count,
                EXISTS(SELECT 1 FROM study_group_members m2 WHERE m2.group_id=g.id AND m2.user_id=? AND m2.status='active') AS joined
         FROM study_groups g WHERE g.status != 'closed' ORDER BY g.created_at DESC");
    $groups->execute([$user['id']]);
    $groups = $groups->fetchAll();
} catch (Throwable $ex) { $groups = []; }

$pageTitle = t('sg_title');
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div style="min-width:0;">
            <h1><?= te('sg_title') ?></h1>
            <p class="af-muted"><?= te('sg_intro') ?></p>
            <?php if (!$groups): ?><div class="af-card" style="padding:24px;"><?= te('sg_empty') ?></div><?php endif; ?>
            <div class="af-grid af-grid-2" style="gap:14px;margin-top:14px;">
            <?php foreach ($groups as $g): ?>
                <div class="af-card">
                    <h3 style="margin:0 0 4px;"><?= e($g['name']) ?></h3>
                    <p class="af-muted" style="margin:0 0 8px;"><?= (int) $g['member_count'] ?> <?= te('sg_members') ?><?= $g['status'] === 'locked' ? ' &middot; &#128274;' : '' ?></p>
                    <p style="font-size:14px;"><?= nl2br(e($g['description'] ?? '')) ?></p>
                    <?php if ($g['joined']): ?>
                        <div style="display:flex;gap:8px;">
                            <a class="af-btn af-btn-gold af-btn-sm" href="<?= APP_URL ?>/study_group.php?id=<?= (int) $g['id'] ?>"><?= te('btn_view') ?></a>
                            <form method="post"><?= csrf_field() ?><input type="hidden" name="group_id" value="<?= (int) $g['id'] ?>"><input type="hidden" name="action" value="leave">
                                <button class="af-btn af-btn-ghost af-btn-sm" type="submit"><?= te('btn_leave') ?></button></form>
                        </div>
                    <?php else: ?>
                        <form method="post"><?= csrf_field() ?><input type="hidden" name="group_id" value="<?= (int) $g['id'] ?>"><input type="hidden" name="action" value="join">
                            <button class="af-btn af-btn-gold af-btn-sm" type="submit" <?= $g['status'] !== 'open' ? 'disabled' : '' ?>><?= te('btn_join') ?></button></form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
