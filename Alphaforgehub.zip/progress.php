<?php
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];

$courses = db()->query("SELECT * FROM courses WHERE status = 'published' ORDER BY sort_order")->fetchAll();

foreach ($courses as &$c) {
    $totalStmt = db()->prepare(
        "SELECT COUNT(*) FROM lessons l JOIN modules m ON m.id = l.module_id WHERE m.course_id = ? AND l.status = 'published'"
    );
    $totalStmt->execute([$c['id']]);
    $total = (int) $totalStmt->fetchColumn();

    $doneStmt = db()->prepare(
        "SELECT COUNT(*) FROM lesson_progress lp
         JOIN lessons l ON l.id = lp.lesson_id
         JOIN modules m ON m.id = l.module_id
         WHERE m.course_id = ? AND lp.user_id = ?"
    );
    $doneStmt->execute([$c['id'], $userId]);
    $done = (int) $doneStmt->fetchColumn();

    $c['total'] = $total;
    $c['done'] = $done;
    $c['percent'] = $total > 0 ? round(($done / $total) * 100) : 0;
}
unset($c);

$overall = get_student_progress($userId);
$pageTitle = 'My Progress';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>My Progress</h1>
            <p class="af-muted">Overall: <?= $overall['completed'] ?> / <?= $overall['total'] ?> lessons (<?= $overall['percent'] ?>%)</p>
            <div class="af-progress-bar" style="max-width:400px;"><span style="width:<?= $overall['percent'] ?>%;"></span></div>

            <div style="margin-top:26px;">
                <?php foreach ($courses as $c): ?>
                    <div class="af-card" style="margin-bottom:16px;">
                        <h3><?= e($c['title']) ?></h3>
                        <p class="af-muted"><?= $c['done'] ?> / <?= $c['total'] ?> lessons &middot; <?= $c['percent'] ?>%</p>
                        <div class="af-progress-bar"><span style="width:<?= $c['percent'] ?>%;"></span></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
