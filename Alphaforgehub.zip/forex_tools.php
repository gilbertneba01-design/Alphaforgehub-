<?php
/**
 * ALPHA FORGE HUB - Forex Tools (STUDENT)
 * All calculators run client-side except the currency converter, which asks
 * a secure server-side proxy for a live rate (see api/tools/fx_rate.php).
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$pageTitle = 'Forex Tools';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Forex Tools</h1>
            <p class="af-muted">Quick calculators for planning and reviewing trades. Estimates only &mdash; always confirm against your broker's platform before trading.</p>

            <div class="af-tools-grid">

                <!-- PIP CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Pip Calculator</h3>
                    <p class="af-muted">Find the value of one pip for a given pair and lot size.</p>
                    <div class="af-field"><label>Currency Pair</label><input type="text" id="pipPair" value="EURUSD" placeholder="EURUSD"></div>
                    <div class="af-field"><label>Lot Size (standard lots)</label><input type="number" id="pipLots" value="1" step="0.01"></div>
                    <div class="af-field"><label>Conversion rate to account currency <span class="af-muted">(leave 1 if quote = account currency)</span></label><input type="number" id="pipConv" value="1" step="0.0001"></div>
                    <div class="af-tool-result" id="pipResult">Pip value: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="pip">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="pip">Reset</button></div>
                </div>

                <!-- LOT SIZE CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Lot Size Calculator</h3>
                    <p class="af-muted">Work out a position size that matches how much you're willing to risk.</p>
                    <div class="af-field"><label>Currency Pair</label><input type="text" id="lotPair" value="EURUSD"></div>
                    <div class="af-field"><label>Account Balance</label><input type="number" id="lotBalance" value="1000" step="0.01"></div>
                    <div class="af-field"><label>Risk % of Balance</label><input type="number" id="lotRiskPct" value="1" step="0.1"></div>
                    <div class="af-field"><label>Stop Loss (pips)</label><input type="number" id="lotSlPips" value="20" step="0.1"></div>
                    <div class="af-field"><label>Conversion rate to account currency</label><input type="number" id="lotConv" value="1" step="0.0001"></div>
                    <div class="af-tool-result" id="lotResult">Suggested lot size: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="lotSize">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="lot">Reset</button></div>
                </div>

                <!-- RISK CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Risk Calculator</h3>
                    <p class="af-muted">Convert between risk percentage and risk amount.</p>
                    <div class="af-field"><label>Account Balance</label><input type="number" id="riskBalance" value="1000" step="0.01"></div>
                    <div class="af-field"><label>Risk %</label><input type="number" id="riskPct" step="0.1" placeholder="e.g. 1"></div>
                    <div class="af-field"><label>Risk Amount</label><input type="number" id="riskAmount" step="0.01" placeholder="e.g. 10"></div>
                    <div class="af-tool-result" id="riskResult">Fill either field above.</div>
                    <div class="af-tool-actions">
                        <button type="button" class="af-btn af-btn-gold" data-af-call="riskFromPct">% &rarr; Amount</button>
                        <button type="button" class="af-btn af-btn-gold" data-af-call="riskFromAmount">Amount &rarr; %</button>
                        <button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="risk">Reset</button>
                    </div>
                </div>

                <!-- RISK/REWARD CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Risk/Reward Calculator</h3>
                    <p class="af-muted">Check the risk-to-reward ratio of a planned trade.</p>
                    <div class="af-field"><label>Direction</label>
                        <select id="rrDirection"><option value="buy">Buy</option><option value="sell">Sell</option></select>
                    </div>
                    <div class="af-field"><label>Entry Price</label><input type="number" id="rrEntry" step="0.00001"></div>
                    <div class="af-field"><label>Stop Loss Price</label><input type="number" id="rrStop" step="0.00001"></div>
                    <div class="af-field"><label>Take Profit Price</label><input type="number" id="rrTarget" step="0.00001"></div>
                    <div class="af-tool-result" id="rrResult">Risk/Reward: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="riskReward">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="rr">Reset</button></div>
                </div>

                <!-- PROFIT/LOSS CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Profit/Loss Calculator</h3>
                    <p class="af-muted">Estimate the outcome of a trade from entry to exit.</p>
                    <div class="af-field"><label>Currency Pair</label><input type="text" id="plPair" value="EURUSD"></div>
                    <div class="af-field"><label>Direction</label>
                        <select id="plDirection"><option value="buy">Buy</option><option value="sell">Sell</option></select>
                    </div>
                    <div class="af-field"><label>Entry Price</label><input type="number" id="plEntry" step="0.00001"></div>
                    <div class="af-field"><label>Exit Price</label><input type="number" id="plExit" step="0.00001"></div>
                    <div class="af-field"><label>Lot Size</label><input type="number" id="plLots" value="1" step="0.01"></div>
                    <div class="af-field"><label>Conversion rate to account currency</label><input type="number" id="plConv" value="1" step="0.0001"></div>
                    <div class="af-tool-result" id="plResult">Estimated result: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="profitLoss">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="pl">Reset</button></div>
                </div>

                <!-- MARGIN CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Margin Calculator</h3>
                    <p class="af-muted">Estimate the margin required to open a position. Check your broker for the exact figure.</p>
                    <div class="af-field"><label>Lot Size</label><input type="number" id="marLots" value="1" step="0.01"></div>
                    <div class="af-field"><label>Current Price</label><input type="number" id="marPrice" step="0.00001" value="1.0"></div>
                    <div class="af-field"><label>Leverage (e.g. 100 for 1:100)</label><input type="number" id="marLeverage" value="100" step="1"></div>
                    <div class="af-field"><label>Conversion rate to account currency</label><input type="number" id="marConv" value="1" step="0.0001"></div>
                    <div class="af-tool-result" id="marResult">Required margin: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="margin">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="mar">Reset</button></div>
                </div>

                <!-- CURRENCY CONVERTER -->
                <div class="af-card af-tool-card">
                    <h3>Currency Converter</h3>
                    <p class="af-muted">Uses live reference rates where available. You can also enter a rate manually.</p>
                    <div class="af-field"><label>Amount</label><input type="number" id="fxAmount" value="100" step="0.01"></div>
                    <div class="af-field"><label>From</label><input type="text" id="fxFrom" value="USD" maxlength="3" style="text-transform:uppercase;"></div>
                    <div class="af-field"><label>To</label><input type="text" id="fxTo" value="EUR" maxlength="3" style="text-transform:uppercase;"></div>
                    <div class="af-field"><label>Rate <span class="af-muted">(auto-filled by "Get Live Rate", or type your own)</span></label><input type="number" id="fxRate" step="0.000001"></div>
                    <div class="af-tool-result" id="fxResult">Converted amount: &mdash;</div>
                    <div class="af-tool-actions">
                        <button type="button" class="af-btn af-btn-ghost" data-af-call="fetchRate">Get Live Rate</button>
                        <button type="button" class="af-btn af-btn-gold" data-af-call="convert">Convert</button>
                        <button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="fx">Reset</button>
                    </div>
                </div>

                <!-- SWAP CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Swap Calculator</h3>
                    <p class="af-muted">Enter the swap rate your broker quotes for this pair (per standard lot, per night).</p>
                    <div class="af-field"><label>Swap Rate per Lot per Night <span class="af-muted">(account currency; negative = you pay)</span></label><input type="number" id="swapRate" step="0.01" placeholder="e.g. -4.50"></div>
                    <div class="af-field"><label>Lot Size</label><input type="number" id="swapLots" value="1" step="0.01"></div>
                    <div class="af-field"><label>Nights Held</label><input type="number" id="swapNights" value="1" step="1"></div>
                    <div class="af-tool-result" id="swapResult">Total swap: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="swap">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="swap">Reset</button></div>
                </div>

                <!-- PIVOT POINT CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Pivot Point Calculator</h3>
                    <p class="af-muted">Classic pivot points from the prior period's High, Low and Close.</p>
                    <div class="af-field"><label>Prior High</label><input type="number" id="pivHigh" step="0.00001"></div>
                    <div class="af-field"><label>Prior Low</label><input type="number" id="pivLow" step="0.00001"></div>
                    <div class="af-field"><label>Prior Close</label><input type="number" id="pivClose" step="0.00001"></div>
                    <div class="af-tool-result" id="pivResult">Pivot: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="pivot">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="piv">Reset</button></div>
                </div>

                <!-- GAIN/LOSS CALCULATOR -->
                <div class="af-card af-tool-card">
                    <h3>Gain/Loss Calculator</h3>
                    <p class="af-muted">See the % change between two account balances, and the recovery gain needed after a loss.</p>
                    <div class="af-field"><label>Starting Balance</label><input type="number" id="glStart" step="0.01"></div>
                    <div class="af-field"><label>Ending Balance</label><input type="number" id="glEnd" step="0.01"></div>
                    <div class="af-tool-result" id="glResult">Result: &mdash;</div>
                    <div class="af-tool-actions"><button type="button" class="af-btn af-btn-gold" data-af-call="gainLoss">Calculate</button><button type="button" class="af-btn af-btn-ghost" data-af-call="resetCard" data-af-arg="gl">Reset</button></div>
                </div>

            </div>
        </div>
    </div>
</section>
<script nonce="<?= CSP_NONCE ?>">window.AF_TOOLS_API = <?= json_encode(APP_URL . '/api/tools/fx_rate.php') ?>;</script>
<?php
$extraScripts = ['/assets/js/forex_tools.js'];
require_once __DIR__ . '/includes/footer.php';
?>
