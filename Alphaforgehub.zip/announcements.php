<?php
/** ALPHA FORGE HUB - Announcements (READ-ONLY for students; only admins write, see admin/announcements.php) */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

try {
    $rows = db()->query("SELECT a.*, u.full_name FROM announcements a JOIN users u ON u.id = a.created_by
                         WHERE a.status = 'published' ORDER BY a.is_pinned DESC, a.created_at DESC LIMIT 100")->fetchAll();
} catch (Throwable $ex) { $rows = []; }

$pageTitle = t('ann_title');
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div style="min-width:0;">
            <h1><?= te('ann_title') ?></h1>
            <p class="af-muted"><?= te('ann_intro') ?></p>
            <?php if (!$rows): ?>
                <div class="af-card" style="padding:24px;"><?= te('ann_empty') ?></div>
            <?php endif; ?>
            <?php foreach ($rows as $a): ?>
                <article class="af-card" style="margin-bottom:12px;">
                    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                        <span class="af-badge"><?= te('ann_kind_' . $a['kind']) ?></span>
                        <?php if ($a['is_pinned']): ?><span class="af-badge af-badge-muted">&#128204; <?= te('ann_pinned') ?></span><?php endif; ?>
                    </div>
                    <h3 style="margin:8px 0 4px;"><?= e($a['title']) ?></h3>
                    <p class="af-muted" style="margin:0 0 8px;"><?= e(date('d M Y H:i', strtotime($a['created_at']))) ?></p>
                    <p style="white-space:pre-wrap;margin:0;"><?= e($a['body']) ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
