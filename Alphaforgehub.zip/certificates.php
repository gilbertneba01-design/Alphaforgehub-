<?php
/**
 * ALPHA FORGE HUB - My Certificates (STUDENT)
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/certificates.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

$courses = db()->query("SELECT * FROM courses WHERE status = 'published' ORDER BY sort_order")->fetchAll();
foreach ($courses as &$c) {
    $c['completion'] = course_completion($userId, (int) $c['id']);
    $c['certificate'] = certificate_find($userId, (int) $c['id']);
}
unset($c);

$pageTitle = 'Certificates';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>My Certificates</h1>
            <p class="af-muted">A certificate is issued automatically once you complete 100% of a course's lessons.</p>

            <div style="margin-top:20px;">
                <?php foreach ($courses as $c): ?>
                    <div class="af-card" style="display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap; margin-bottom:14px;">
                        <div>
                            <h3 style="margin:0 0 6px;"><?= e($c['title']) ?></h3>
                            <p class="af-muted" style="margin:0;"><?= $c['completion']['done'] ?> / <?= $c['completion']['total'] ?> lessons &middot; <?= $c['completion']['percent'] ?>%</p>
                        </div>
                        <?php if ($c['certificate']): ?>
                            <a href="<?= APP_URL ?>/certificate_view.php?code=<?= urlencode($c['certificate']['certificate_code']) ?>" class="af-btn af-btn-gold">View Certificate</a>
                        <?php elseif ($c['completion']['percent'] >= 100): ?>
                            <a href="<?= APP_URL ?>/certificate_view.php?course_id=<?= (int) $c['id'] ?>" class="af-btn af-btn-gold">Claim Certificate</a>
                        <?php else: ?>
                            <span class="af-badge af-badge-muted">Complete the course to unlock</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
