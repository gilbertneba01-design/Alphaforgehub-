<?php $__p = basename($_SERVER['SCRIPT_NAME']); ?>
<aside class="af-sidebar">
    <a href="<?= APP_URL ?>/dashboard.php" class="<?= $__p === 'dashboard.php' ? 'active' : '' ?>"><?= te('nav_dashboard') ?></a>
    <a href="<?= APP_URL ?>/courses.php" class="<?= $__p === 'courses.php' ? 'active' : '' ?>"><?= te('nav_courses') ?></a>
    <a href="<?= APP_URL ?>/progress.php" class="<?= $__p === 'progress.php' ? 'active' : '' ?>"><?= te('nav_progress') ?></a>
    <a href="<?= APP_URL ?>/chart_lab.php" class="<?= $__p === 'chart_lab.php' ? 'active' : '' ?>"><?= te('nav_chart_lab') ?></a>
    <a href="<?= APP_URL ?>/simulator.php" class="<?= $__p === 'simulator.php' ? 'active' : '' ?>"><?= te('nav_simulator') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/backtest.php" class="<?= $__p === 'backtest.php' ? 'active' : '' ?>"><?= te('nav_backtesting') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/ai_tutor.php" class="<?= $__p === 'ai_tutor.php' ? 'active' : '' ?>">&#129302; <?= te('nav_ai_tutor') ?></a>
    <a href="<?= APP_URL ?>/trading_journal.php" class="<?= in_array($__p, ['trading_journal.php', 'journal_entry.php'], true) ? 'active' : '' ?>"><?= te('nav_journal') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/performance.php" class="<?= $__p === 'performance.php' ? 'active' : '' ?>"><?= te('nav_performance') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/forexpedia.php" class="<?= $__p === 'forexpedia.php' ? 'active' : '' ?>"><?= te('nav_forexpedia') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/forex_tools.php" class="<?= $__p === 'forex_tools.php' ? 'active' : '' ?>"><?= te('nav_tools') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/market_center.php" class="<?= in_array($__p, ['market_center.php','economic_calendar.php','market_news.php','market_hours.php','currency_strength.php','currency_correlation.php','market_sentiment.php'], true) ? 'active' : '' ?>"><?= te('nav_market_center') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/certificates.php" class="<?= $__p === 'certificates.php' ? 'active' : '' ?>"><?= te('nav_certificates') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/announcements.php" class="<?= $__p === 'announcements.php' ? 'active' : '' ?>"><?= te('nav_announcements') ?></a>
    <a href="<?= APP_URL ?>/study_groups.php" class="<?= in_array($__p, ['study_groups.php','study_group.php'], true) ? 'active' : '' ?>"><?= te('nav_study_groups') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/notifications.php" class="<?= $__p === 'notifications.php' ? 'active' : '' ?>"><?= te('nav_notifications') ?></a>
    <a href="<?= APP_URL ?>/community.php" class="<?= $__p === 'community.php' ? 'active' : '' ?>"><?= te('nav_community') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/challenges.php" class="<?= $__p === 'challenges.php' ? 'active' : '' ?>"><?= te('nav_challenges') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/live_sessions.php" class="<?= $__p === 'live_sessions.php' ? 'active' : '' ?>"><?= te('nav_live_sessions') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/mentorship.php" class="<?= $__p === 'mentorship.php' ? 'active' : '' ?>"><?= te('nav_mentorship') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/prop_firm_academy.php" class="<?= $__p === 'prop_firm_academy.php' ? 'active' : '' ?>"><?= te('nav_prop_firm') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/store.php" class="<?= $__p === 'store.php' ? 'active' : '' ?>"><?= te('nav_store') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/my_library.php" class="<?= $__p === 'my_library.php' ? 'active' : '' ?>"><?= te('nav_my_library') ?> <span class="af-new"><?= te('badge_new') ?></span></a>
    <a href="<?= APP_URL ?>/pricing.php" class="<?= $__p === 'pricing.php' ? 'active' : '' ?>"><?= te('nav_subscription') ?></a>
    <a href="<?= APP_URL ?>/profile.php" class="<?= $__p === 'profile.php' ? 'active' : '' ?>"><?= te('nav_profile') ?></a>
    <a href="<?= APP_URL ?>/logout.php"><?= te('nav_logout') ?></a>
</aside>
