<?php
/** Expects config/functions.php already loaded by the including page. */
$__user = current_user();
$__page = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="<?= e(current_language()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? e($pageTitle) . ' | Alpha Forge' : 'Alpha Forge — Forex Education' ?></title>
<meta name="description" content="Alpha Forge — structured Forex education. Build your trading foundation with discipline.">
<link rel="manifest" href="<?= APP_URL ?>/manifest.json">
<link rel="icon" href="<?= APP_URL ?>/favicon.ico">
<meta name="theme-color" content="#071426">
<link rel="apple-touch-icon" href="<?= APP_URL ?>/assets/icons/icon-192.png">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css?v=<?= (int) @filemtime(__DIR__ . '/../assets/css/style.css') ?>">
</head>
<body>

<header class="af-header">
    <div class="af-container af-header-inner">
        <a href="<?= APP_URL ?>/index.php" class="af-logo">ALPHA <span>FORGE</span></a>

        <button class="af-menu-toggle" id="afMenuToggle" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>

        <nav class="af-nav" id="afNav">
            <a href="<?= APP_URL ?>/index.php" class="<?= $__page === 'index.php' ? 'active' : '' ?>"><?= t('nav_home') ?></a>
            <a href="<?= APP_URL ?>/courses.php" class="<?= $__page === 'courses.php' ? 'active' : '' ?>"><?= t('nav_courses') ?></a>
            <a href="<?= APP_URL ?>/pricing.php" class="<?= $__page === 'pricing.php' ? 'active' : '' ?>"><?= t('nav_pricing') ?></a>
            <a href="<?= APP_URL ?>/about.php" class="<?= $__page === 'about.php' ? 'active' : '' ?>"><?= t('nav_about') ?></a>
            <a href="<?= APP_URL ?>/testimonials.php" class="<?= $__page === 'testimonials.php' ? 'active' : '' ?>"><?= te('nav_testimonials') ?></a>
            <a href="<?= APP_URL ?>/contact.php" class="<?= $__page === 'contact.php' ? 'active' : '' ?>"><?= t('nav_contact') ?></a>
            <a href="<?= APP_URL ?>/search.php" class="<?= $__page === 'search.php' ? 'active' : '' ?>" aria-label="<?= t('btn_search') ?>">&#128269;</a>
            <a href="<?= APP_URL ?>/<?= basename($_SERVER['PHP_SELF']) ?>?lang=<?= current_language() === 'en' ? 'fr' : 'en' ?>" class="af-lang-switch" title="<?= current_language() === 'en' ? 'Passer en français' : 'Switch to English' ?>"><?= current_language() === 'en' ? 'FR' : 'EN' ?></a>

            <?php if ($__user): ?>
                <a href="<?= APP_URL ?>/chart_lab.php" class="<?= $__page === 'chart_lab.php' ? 'active' : '' ?>"><?= t('nav_chart_lab') ?></a>
                <?php if ($__user['role'] === 'mentor'): ?>
                    <a href="<?= APP_URL ?>/mentor/index.php" class="af-btn af-btn-ghost"><?= te('nav_mentor_dashboard') ?></a>
                <?php elseif ($__user['role'] === 'admin'): ?>
                    <a href="<?= APP_URL ?>/admin/index.php" class="af-btn af-btn-ghost"><?= te('nav_admin') ?></a>
                <?php else: ?>
                    <a href="<?= APP_URL ?>/dashboard.php" class="af-btn af-btn-ghost"><?= te('nav_dashboard') ?></a>
                <?php endif; ?>
                <?php $__unread = unread_notification_count(); ?>
                <a href="<?= APP_URL ?>/notifications.php" class="af-bell" aria-label="<?= te('nav_notifications') ?>">&#128276;<?php if ($__unread > 0): ?><span class="af-bell-count"><?= (int) $__unread ?></span><?php endif; ?></a>
                <a href="<?= APP_URL ?>/logout.php" class="af-btn af-btn-gold"><?= t('nav_logout') ?></a>
            <?php else: ?>
                <a href="<?= APP_URL ?>/login.php" class="af-btn af-btn-ghost"><?= t('nav_login') ?></a>
                <a href="<?= APP_URL ?>/register.php" class="af-btn af-btn-gold"><?= te('nav_join') ?></a>
                <button type="button" class="af-btn af-btn-ghost" data-af-install hidden><?= te('nav_install') ?></button>
            <?php endif; ?>
        </nav>
    </div>
</header>

<?php $__flashSuccess = flash_get('success'); $__flashError = flash_get('error'); ?>
<?php if ($__flashSuccess): ?>
    <div class="af-container"><div class="af-alert af-alert-success"><?= e($__flashSuccess) ?></div></div>
<?php endif; ?>
<?php if ($__flashError): ?>
    <div class="af-container"><div class="af-alert af-alert-error"><?= e($__flashError) ?></div></div>
<?php endif; ?>

<main>
