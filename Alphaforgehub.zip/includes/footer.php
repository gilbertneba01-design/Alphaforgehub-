</main>

<footer class="af-footer">
    <div class="af-container af-footer-inner">
        <div>
            <div class="af-logo">ALPHA <span>FORGE</span></div>
            <p class="af-muted"><?= te('footer_tagline') ?></p>
        </div>
        <div class="af-footer-links">
            <a href="<?= APP_URL ?>/about.php"><?= t('nav_about') ?></a>
            <a href="<?= APP_URL ?>/courses.php"><?= t('nav_courses') ?></a>
            <a href="<?= APP_URL ?>/pricing.php"><?= t('nav_pricing') ?></a>
            <a href="<?= APP_URL ?>/contact.php"><?= t('nav_contact') ?></a>
        </div>
        <div class="af-muted">&copy; <?= date('Y') ?> Alpha Forge. <?= t('footer_rights') ?></div>
    </div>
</footer>

<script src="<?= APP_URL ?>/assets/js/app.js?v=<?= (int) @filemtime(__DIR__ . '/../assets/js/app.js') ?>"></script>
<?php foreach (($extraScripts ?? []) as $__src): ?>
<script src="<?= e(APP_URL . $__src) ?>?v=<?= (int) @filemtime(__DIR__ . '/..' . $__src) ?>"></script>
<?php endforeach; ?>
<script nonce="<?= CSP_NONCE ?>">window.AF_APP_URL = <?= json_encode(APP_URL) ?>;window.AF_I18N = <?= json_encode(['install_ios' => t('install_ios'), 'install_generic' => t('install_generic'), 'install_done' => t('install_done')], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;</script>
<script src="<?= APP_URL ?>/assets/js/pwa.js"></script>
</body>
</html>
