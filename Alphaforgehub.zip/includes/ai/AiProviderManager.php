<?php
/**
 * ALPHA FORGE HUB - AI Tutor provider manager
 *
 * The only place AI Tutor business logic touches a specific AI backend.
 * Switch providers by changing AI_PROVIDER in config/.env.php - nothing
 * else in the app needs to change. Mirrors payment/PaymentManager.php.
 */
require_once __DIR__ . '/AiProviderInterface.php';
require_once __DIR__ . '/OpenAiProvider.php';
require_once __DIR__ . '/AnthropicProvider.php';

class AiProviderManager {
    public static function getProvider(): AiProviderInterface {
        return match (AI_TUTOR_PROVIDER) {
            'anthropic' => new AnthropicProvider(),
            'openai'    => new OpenAiProvider(),
            default     => throw new InvalidArgumentException('Unsupported AI provider: ' . AI_TUTOR_PROVIDER),
        };
    }
}
