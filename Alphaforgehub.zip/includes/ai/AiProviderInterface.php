<?php
/**
 * ALPHA FORGE HUB - AI Tutor provider contract
 *
 * Every AI backend (OpenAI, Anthropic, etc.) implements this interface.
 * Nothing else in the application talks to a provider's raw API directly -
 * it always goes through this contract, so switching or adding providers
 * never touches AI Tutor business logic (api/ai/chat.php, config/ai_tutor.php).
 */

interface AiProviderInterface {

    /**
     * Sends a conversation to the AI provider and returns its reply.
     *
     * @param string $systemPrompt The Alpha Forge AI Tutor system instructions for this turn.
     * @param array  $history      Ordered list (oldest first) of
     *                             ['role' => 'user'|'assistant', 'content' => string].
     *                             The last entry is the student's newest message.
     * @return array{success: bool, reply: ?string, error: ?string}
     */
    public function chat(string $systemPrompt, array $history): array;
}
