<?php
/**
 * ALPHA FORGE HUB - Anthropic provider for the AI Tutor
 * Talks to Anthropic's Messages API. Server-side only - the API key never
 * reaches the browser.
 */
require_once __DIR__ . '/AiProviderInterface.php';

class AnthropicProvider implements AiProviderInterface {

    public function chat(string $systemPrompt, array $history): array {
        if (ANTHROPIC_API_KEY === '') {
            return ['success' => false, 'reply' => null, 'error' => 'AI Tutor is not configured yet. Add ANTHROPIC_API_KEY in config/.env.php.'];
        }

        $messages = [];
        foreach ($history as $m) {
            $messages[] = [
                'role'    => ($m['role'] ?? 'user') === 'assistant' ? 'assistant' : 'user',
                'content' => (string) ($m['content'] ?? ''),
            ];
        }
        if (empty($messages)) {
            return ['success' => false, 'reply' => null, 'error' => 'No message to send.'];
        }

        $payload = [
            'model'      => ANTHROPIC_MODEL,
            'system'     => $systemPrompt,
            'messages'   => $messages,
            'max_tokens' => 700,
        ];

        [$raw, $err, $code] = $this->post('https://api.anthropic.com/v1/messages', $payload, [
            'Content-Type: application/json',
            'x-api-key: ' . ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01',
        ]);

        if ($raw === false) {
            return ['success' => false, 'reply' => null, 'error' => 'Could not reach the AI service: ' . $err];
        }

        $data = json_decode((string) $raw, true);
        if ($code >= 400 || !is_array($data)) {
            $msg = $data['error']['message'] ?? ('The AI service returned an error (HTTP ' . $code . ').');
            return ['success' => false, 'reply' => null, 'error' => (string) $msg];
        }

        $reply = '';
        foreach (($data['content'] ?? []) as $block) {
            if (($block['type'] ?? '') === 'text') {
                $reply .= (string) ($block['text'] ?? '');
            }
        }
        $reply = trim($reply);
        if ($reply === '') {
            return ['success' => false, 'reply' => null, 'error' => 'The AI service returned an empty response.'];
        }

        return ['success' => true, 'reply' => $reply, 'error' => null];
    }

    /** @return array{0: string|false, 1: string, 2: int} [rawBody, curlError, httpCode] */
    private function post(string $url, array $payload, array $headers): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => AI_TUTOR_TIMEOUT_SECONDS,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]);
        $raw  = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$raw, $err, $code];
    }
}
