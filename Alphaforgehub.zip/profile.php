<?php
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();
$userId = (int) $user['id'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $fullName = trim($_POST['full_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        if ($fullName === '') {
            $errors[] = 'Full name cannot be empty.';
        } else {
            $stmt = db()->prepare('UPDATE users SET full_name = ?, phone = ? WHERE id = ?');
            $stmt->execute([$fullName, $phone ?: null, $userId]);
            flash_set('success', 'Profile updated.');
            redirect('/profile.php');
        }
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['new_password_confirm'] ?? '';

        $stmt = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        $hash = $stmt->fetchColumn();

        if (!password_verify($current, $hash)) {
            $errors[] = 'Current password is incorrect.';
        } elseif (password_strength_error($new)) {
            $errors[] = password_strength_error($new);
        } elseif ($new !== $confirm) {
            $errors[] = 'New passwords do not match.';
        } else {
            $newHash = password_hash($new, PASSWORD_DEFAULT);
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([$newHash, $userId]);
            flash_set('success', 'Password changed.');
            redirect('/profile.php');
        }
    }
}

// refresh user after potential update
$stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$userId]);
$user = $stmt->fetch();

$payStmt = db()->prepare(
    "SELECT p.*, sp.name AS plan_name FROM payments p
     JOIN subscriptions s ON s.id = p.subscription_id
     JOIN subscription_plans sp ON sp.id = s.plan_id
     WHERE p.user_id = ? ORDER BY p.created_at DESC LIMIT 20"
);
$payStmt->execute([$userId]);
$payments = $payStmt->fetchAll();

$pageTitle = 'Profile';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Profile</h1>
            <?php foreach ($errors as $err): ?><div class="af-alert af-alert-error"><?= e($err) ?></div><?php endforeach; ?>

            <div class="af-card" style="max-width:480px;">
                <h3>Account Information</h3>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_profile">
                    <div class="af-field"><label>Full Name</label><input type="text" name="full_name" value="<?= e($user['full_name']) ?>" required></div>
                    <div class="af-field"><label>Email</label><input type="email" value="<?= e($user['email']) ?>" disabled></div>
                    <div class="af-field"><label>Phone</label><input type="text" name="phone" value="<?= e($user['phone']) ?>"></div>
                    <button type="submit" class="af-btn af-btn-gold">Save Changes</button>
                </form>
            </div>

            <div class="af-card" style="max-width:480px; margin-top:22px;">
                <h3>Change Password</h3>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="change_password">
                    <div class="af-field"><label>Current Password</label><input type="password" name="current_password" required></div>
                    <div class="af-field"><label>New Password</label><input type="password" name="new_password" required></div>
                    <div class="af-field"><label>Confirm New Password</label><input type="password" name="new_password_confirm" required></div>
                    <button type="submit" class="af-btn af-btn-ghost">Update Password</button>
                </form>
            </div>

            <h2 style="margin-top:36px;">Payment / Subscription History</h2>
            <div class="af-table-wrap">
                <table class="af-table">
                    <thead><tr><th>Date</th><th>Plan</th><th>Amount</th><th>Provider</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ($payments as $p): ?>
                        <tr>
                            <td><?= e(date('d M Y', strtotime($p['created_at']))) ?></td>
                            <td><?= e($p['plan_name']) ?></td>
                            <td><?= format_money((float) $p['amount'], $p['currency']) ?></td>
                            <td><?= e(str_replace('_', ' ', $p['provider'])) ?></td>
                            <td style="text-transform:capitalize;"><?= e($p['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$payments): ?><tr><td colspan="5" class="af-muted">No payments yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
