<?php
/**
 * ALPHA FORGE HUB - Trading Challenges (STUDENT)
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$user   = current_user();
$userId = (int) $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $challengeId = (int) ($_POST['challenge_id'] ?? 0);
    if (isset($_POST['join'])) {
        $stmt = db()->prepare('INSERT IGNORE INTO challenge_progress (challenge_id, user_id) VALUES (?, ?)');
        $stmt->execute([$challengeId, $userId]);
    } elseif (isset($_POST['complete'])) {
        db()->prepare('UPDATE challenge_progress SET completed_at = NOW() WHERE challenge_id = ? AND user_id = ? AND completed_at IS NULL')
            ->execute([$challengeId, $userId]);
    }
    redirect('/challenges.php');
}

$stmt = db()->prepare(
    "SELECT ch.*, cp.started_at, cp.completed_at
     FROM challenges ch
     LEFT JOIN challenge_progress cp ON cp.challenge_id = ch.id AND cp.user_id = ?
     WHERE ch.status = 'active' ORDER BY ch.created_at DESC"
);
$stmt->execute([$userId]);
$challenges = $stmt->fetchAll();

$pageTitle = 'Challenges';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Trading Challenges</h1>
            <p class="af-muted">Educational challenges to build discipline - not tied to real trading profits.</p>

            <div class="af-grid af-grid-2" style="gap:16px; margin-top:18px;">
                <?php foreach ($challenges as $c): ?>
                    <div class="af-card">
                        <h3><?= e($c['title']) ?></h3>
                        <p class="af-muted"><?= (int) $c['duration_days'] ?> days</p>
                        <?php if ($c['description']): ?><p><?= nl2br(e($c['description'])) ?></p><?php endif; ?>

                        <form method="post">
                            <?= csrf_field() ?>
                            <input type="hidden" name="challenge_id" value="<?= (int) $c['id'] ?>">
                            <?php if (!$c['started_at']): ?>
                                <button type="submit" name="join" value="1" class="af-btn af-btn-gold">Join Challenge</button>
                            <?php elseif (!$c['completed_at']): ?>
                                <span class="af-badge">In progress since <?= e(date('d M', strtotime($c['started_at']))) ?></span>
                                <button type="submit" name="complete" value="1" class="af-btn af-btn-gold" style="margin-top:8px;">Mark Complete</button>
                            <?php else: ?>
                                <span class="af-badge" style="border-color:var(--green); color:var(--green);">Completed <?= e(date('d M Y', strtotime($c['completed_at']))) ?></span>
                            <?php endif; ?>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if (!$challenges): ?><p class="af-muted" style="margin-top:20px;">No active challenges right now - check back soon.</p><?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
