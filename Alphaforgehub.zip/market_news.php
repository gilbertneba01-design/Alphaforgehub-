<?php
/**
 * ALPHA FORGE HUB - Market News (STUDENT)
 */
require_once __DIR__ . '/config/functions.php';
require_login();

$currency = strtoupper(trim((string) ($_GET['currency'] ?? '')));
$where  = '1=1';
$params = [];
if ($currency !== '') {
    $where = 'currency = ?';
    $params[] = $currency;
}
$stmt = db()->prepare("SELECT * FROM market_news WHERE $where ORDER BY published_at DESC LIMIT 100");
$stmt->execute($params);
$news = $stmt->fetchAll();

$currencies = array_column(db()->query("SELECT DISTINCT currency FROM market_news WHERE currency IS NOT NULL ORDER BY currency")->fetchAll(), 'currency');

$pageTitle = 'Market News';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Market News</h1>

            <form method="get" style="margin:14px 0; display:flex; gap:10px; align-items:end;">
                <div class="af-field" style="margin:0;"><label>Currency</label>
                    <select name="currency"><option value="">All</option>
                        <?php foreach ($currencies as $c): ?><option value="<?= e($c) ?>" <?= $currency === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="af-btn af-btn-gold">Filter</button>
            </form>

            <?php foreach ($news as $n): ?>
                <div class="af-card" style="margin-bottom:14px;">
                    <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
                        <h3 style="margin:0;"><?= e($n['headline']) ?></h3>
                        <?php if ($n['currency']): ?><span class="af-badge"><?= e($n['currency']) ?></span><?php endif; ?>
                    </div>
                    <p class="af-muted" style="margin:6px 0;"><?= e($n['source']) ?> &middot; <?= e(date('d M Y H:i', strtotime($n['published_at']))) ?></p>
                    <?php if ($n['summary']): ?><p><?= nl2br(e($n['summary'])) ?></p><?php endif; ?>
                    <?php if ($n['source_url']): ?><a href="<?= e($n['source_url']) ?>" target="_blank" rel="noopener">Read full story &rarr;</a><?php endif; ?>
                </div>
            <?php endforeach; ?>
            <?php if (!$news): ?><p class="af-muted">No news items yet.</p><?php endif; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
