<?php
/** ALPHA FORGE HUB - Notifications (each user sees ONLY their own rows) */
require_once __DIR__ . '/config/functions.php';
require_login();
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    try {
        if (($_POST['action'] ?? '') === 'read_all') {
            db()->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?')->execute([$user['id']]);
        } elseif (($_POST['action'] ?? '') === 'open') {
            $id = (int) ($_POST['id'] ?? 0);
            $s = db()->prepare('SELECT link FROM notifications WHERE id = ? AND user_id = ?'); // ownership check (no IDOR)
            $s->execute([$id, $user['id']]);
            $n = $s->fetch();
            if ($n) {
                db()->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([$id, $user['id']]);
                $link = (string) $n['link'];
                if ($link !== '' && $link[0] === '/' && strpos($link, '//') !== 0) redirect($link); // internal links only
            }
        }
    } catch (Throwable $ex) { }
    redirect('/notifications.php');
}

try {
    $s = db()->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100');
    $s->execute([$user['id']]);
    $rows = $s->fetchAll();
} catch (Throwable $ex) { $rows = []; }

$pageTitle = t('notif_title');
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php if ($user['role'] === 'student') include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div style="min-width:0;<?= $user['role'] !== 'student' ? 'grid-column:1/-1;' : '' ?>">
            <h1><?= te('notif_title') ?></h1>
            <?php if ($rows): ?>
                <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read_all">
                    <button class="af-btn af-btn-ghost af-btn-sm" type="submit"><?= te('btn_mark_all_read') ?></button></form>
            <?php else: ?>
                <div class="af-card" style="padding:24px;margin-top:12px;"><?= te('notif_empty') ?></div>
            <?php endif; ?>
            <?php foreach ($rows as $n): ?>
                <form method="post" class="af-card" style="margin-top:10px;<?= $n['is_read'] ? 'opacity:.7;' : 'border-left:3px solid var(--gold,#d4af37);' ?>">
                    <?= csrf_field() ?><input type="hidden" name="action" value="open"><input type="hidden" name="id" value="<?= (int) $n['id'] ?>">
                    <strong><?= e($n['title']) ?></strong>
                    <?php if ($n['body']): ?><p style="margin:4px 0;"><?= e($n['body']) ?></p><?php endif; ?>
                    <small class="af-muted"><?= e(date('d M Y H:i', strtotime($n['created_at']))) ?></small>
                    <div style="margin-top:6px;"><button class="af-btn af-btn-ghost af-btn-sm" type="submit"><?= te('btn_view') ?></button></div>
                </form>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
