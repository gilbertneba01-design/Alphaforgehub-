<?php
/**
 * ALPHA FORGE HUB - Economic Calendar (STUDENT)
 */
require_once __DIR__ . '/config/functions.php';
require_login();

const CAL_IMPACT_DOT = ['low' => '&#128994;', 'medium' => '&#128993;', 'high' => '&#128308;'];

$currency = strtoupper(trim((string) ($_GET['currency'] ?? '')));
$impact   = (string) ($_GET['impact'] ?? '');
$dateFrom = trim((string) ($_GET['date_from'] ?? date('Y-m-d')));
$dateTo   = trim((string) ($_GET['date_to'] ?? date('Y-m-d', strtotime('+7 days'))));

$where  = ['event_date BETWEEN ? AND ?'];
$params = [$dateFrom, $dateTo];
if ($currency !== '') {
    $where[]  = 'currency = ?';
    $params[] = $currency;
}
if (in_array($impact, ['low', 'medium', 'high'], true)) {
    $where[]  = 'impact = ?';
    $params[] = $impact;
}

$stmt = db()->prepare('SELECT * FROM economic_events WHERE ' . implode(' AND ', $where) . ' ORDER BY event_date, event_time');
$stmt->execute($params);
$events = $stmt->fetchAll();

$currencies = array_column(db()->query('SELECT DISTINCT currency FROM economic_events ORDER BY currency')->fetchAll(), 'currency');

$pageTitle = 'Economic Calendar';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container af-dash-grid">
        <?php include __DIR__ . '/includes/student_sidebar.php'; ?>
        <div>
            <h1>Economic Calendar</h1>
            <p class="af-muted">&#128994; Low impact &nbsp; &#128993; Medium impact &nbsp; &#128308; High impact</p>

            <form method="get" class="af-card" style="margin:16px 0;">
                <div class="af-grid af-grid-3" style="gap:12px;">
                    <div class="af-field"><label>From</label><input type="date" name="date_from" value="<?= e($dateFrom) ?>"></div>
                    <div class="af-field"><label>To</label><input type="date" name="date_to" value="<?= e($dateTo) ?>"></div>
                    <div class="af-field"><label>Currency</label>
                        <select name="currency"><option value="">All</option>
                            <?php foreach ($currencies as $c): ?><option value="<?= e($c) ?>" <?= $currency === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="af-field"><label>Impact</label>
                        <select name="impact"><option value="">All</option>
                            <?php foreach (['low' => 'Low', 'medium' => 'Medium', 'high' => 'High'] as $k => $l): ?>
                                <option value="<?= e($k) ?>" <?= $impact === $k ? 'selected' : '' ?>><?= e($l) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="af-btn af-btn-gold" style="margin-top:10px;">Filter</button>
            </form>

            <div class="af-table-wrap">
                <table class="af-table">
                    <thead><tr><th>Date</th><th>Time</th><th>Currency</th><th>Event</th><th>Impact</th><th>Forecast</th><th>Previous</th><th>Actual</th></tr></thead>
                    <tbody>
                    <?php foreach ($events as $ev): ?>
                        <tr>
                            <td><?= e(date('d M Y', strtotime($ev['event_date']))) ?></td>
                            <td><?= $ev['event_time'] ? e(substr($ev['event_time'], 0, 5)) : '&mdash;' ?></td>
                            <td><strong><?= e($ev['currency']) ?></strong></td>
                            <td><?= e($ev['event_name']) ?></td>
                            <td><?= CAL_IMPACT_DOT[$ev['impact']] ?? '' ?> <span style="text-transform:capitalize;"><?= e($ev['impact']) ?></span></td>
                            <td><?= e($ev['forecast'] ?? '—') ?></td>
                            <td><?= e($ev['previous'] ?? '—') ?></td>
                            <td><?= e($ev['actual'] ?? '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$events): ?><tr><td colspan="8" class="af-muted">No events in this range yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
