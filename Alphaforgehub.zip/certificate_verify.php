<?php
/**
 * ALPHA FORGE HUB - Public Certificate Verification
 * No login required - anyone with a certificate ID (e.g. an employer) can
 * confirm it was genuinely issued by Alpha Forge HUB. Only non-sensitive
 * fields are shown: student name, course, code and issue date.
 */
require_once __DIR__ . '/config/functions.php';
require_once __DIR__ . '/config/certificates.php';

$code   = trim((string) ($_GET['code'] ?? ($_POST['code'] ?? '')));
$result = $code !== '' ? certificate_verify_public($code) : null;
$searched = $code !== '';

$pageTitle = 'Verify Certificate';
require_once __DIR__ . '/includes/header.php';
?>
<section class="af-section">
    <div class="af-container" style="max-width:600px;">
        <h1>Verify a Certificate</h1>
        <p class="af-muted">Enter an Alpha Forge HUB certificate ID to confirm it's genuine.</p>

        <form method="get" class="af-card" style="display:flex; gap:10px; margin:18px 0;">
            <input type="text" name="code" value="<?= e($code) ?>" placeholder="AF-XXXXXXXX" style="flex:1;">
            <button type="submit" class="af-btn af-btn-gold">Verify</button>
        </form>

        <?php if ($searched): ?>
            <?php if ($result): ?>
                <div class="af-card" style="border-color:var(--green);">
                    <span class="af-badge" style="border-color:var(--green); color:var(--green);">Valid Certificate</span>
                    <p style="margin-top:12px;"><strong><?= e($result['student_name']) ?></strong> completed <strong><?= e($result['course_title']) ?></strong> on <?= e(date('d F Y', strtotime($result['issued_at']))) ?>.</p>
                    <p class="af-muted">Certificate ID: <?= e($result['certificate_code']) ?></p>
                </div>
            <?php else: ?>
                <div class="af-alert af-alert-error">No certificate found with that ID. Double-check the code and try again.</div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
