-- =========================================================
-- ALPHA FORGE HUB - Certificates migration (Phase 5)
-- Run this ONCE in phpMyAdmin, AFTER migration_trading_journal.sql.
-- =========================================================

USE alpha_forge;

CREATE TABLE IF NOT EXISTS certificates (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    course_id INT UNSIGNED NOT NULL,
    certificate_code VARCHAR(20) NOT NULL,
    issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cert_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cert_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_cert_user_course (user_id, course_id),
    UNIQUE KEY uniq_cert_code (certificate_code)
) ENGINE=InnoDB;
