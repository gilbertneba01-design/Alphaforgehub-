-- =========================================================
-- ALPHA FORGE HUB - AI Tutor migration (Phase 1)
-- Run this ONCE in phpMyAdmin (SQL tab or Import) against your
-- existing alpha_forge database, AFTER schema.sql and the
-- chartlab / practice-exercises migrations.
--
-- Adds:
--   ai_conversations - one row per tutor conversation a student starts
--   ai_messages      - every message (student + AI) inside a conversation
--
-- Safe to re-run: tables use IF NOT EXISTS.
-- =========================================================

USE alpha_forge;

CREATE TABLE IF NOT EXISTS ai_conversations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    course_id INT UNSIGNED DEFAULT NULL,
    lesson_id INT UNSIGNED DEFAULT NULL,
    title VARCHAR(190) NOT NULL DEFAULT 'New conversation',
    mode VARCHAR(30) NOT NULL DEFAULT 'explain',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ai_conv_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_ai_conv_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    CONSTRAINT fk_ai_conv_lesson FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE SET NULL,
    INDEX idx_ai_conv_user_updated (user_id, updated_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    role ENUM('user','assistant') NOT NULL,
    mode VARCHAR(30) DEFAULT NULL,
    content MEDIUMTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ai_msg_conversation FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE,
    CONSTRAINT fk_ai_msg_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_ai_msg_conversation (conversation_id, id),
    INDEX idx_ai_msg_user_created (user_id, created_at)
) ENGINE=InnoDB;
