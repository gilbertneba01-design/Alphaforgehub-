-- =========================================================
-- ALPHA FORGE HUB - Trading Journal migration (Phase 2)
-- Run this ONCE in phpMyAdmin, AFTER migration_ai_tutor.sql.
-- Safe to re-run: tables use IF NOT EXISTS.
-- =========================================================

USE alpha_forge;

CREATE TABLE IF NOT EXISTS trading_journal (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    pair VARCHAR(20) NOT NULL,
    direction ENUM('buy','sell') NOT NULL,
    entry_price DECIMAL(14,6) NOT NULL,
    stop_loss DECIMAL(14,6) DEFAULT NULL,
    take_profit DECIMAL(14,6) DEFAULT NULL,
    lot_size DECIMAL(10,3) DEFAULT NULL,
    risk_amount DECIMAL(12,2) DEFAULT NULL,
    risk_percent DECIMAL(6,3) DEFAULT NULL,
    result ENUM('open','win','loss','breakeven') NOT NULL DEFAULT 'open',
    profit_loss DECIMAL(12,2) DEFAULT NULL,
    strategy VARCHAR(100) DEFAULT NULL,
    timeframe VARCHAR(10) DEFAULT NULL,
    session ENUM('sydney','tokyo','london','new_york','overlap') DEFAULT NULL,
    entry_reason TEXT,
    exit_reason TEXT,
    emotion_before VARCHAR(30) DEFAULT NULL,
    emotion_during VARCHAR(30) DEFAULT NULL,
    emotion_after VARCHAR(30) DEFAULT NULL,
    notes TEXT,
    trade_date DATE NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_journal_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_journal_user_date (user_id, trade_date),
    INDEX idx_journal_user_pair (user_id, pair),
    INDEX idx_journal_user_result (user_id, result)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS trading_journal_screenshots (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    journal_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_journal_shot_trade FOREIGN KEY (journal_id) REFERENCES trading_journal(id) ON DELETE CASCADE,
    CONSTRAINT fk_journal_shot_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_journal_shot_trade (journal_id)
) ENGINE=InnoDB;
