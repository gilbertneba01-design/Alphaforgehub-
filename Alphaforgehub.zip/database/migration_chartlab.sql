-- =========================================================
-- ALPHA FORGE - Chart Lab migration
-- Run this ONCE in phpMyAdmin (SQL tab or Import) against your
-- existing alpha_forge database, AFTER schema.sql.
--
-- Adds:
--   chartlab_exercises  - the exercises (candles + the hidden answer zones)
--   chartlab_attempts   - every zone a student submits, and the verdict
--   6 starter exercises (2 free, 4 premium) linked to the
--   Technical Analysis course
--
-- Safe to re-run: tables use IF NOT EXISTS and exercises use
-- INSERT IGNORE on the unique slug, so nothing is duplicated.
-- =========================================================

USE alpha_forge;

CREATE TABLE IF NOT EXISTS chartlab_exercises (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    course_id INT UNSIGNED DEFAULT NULL,
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(190) NOT NULL UNIQUE,
    pair_label VARCHAR(20) NOT NULL DEFAULT 'EUR/USD',
    timeframe_label VARCHAR(10) NOT NULL DEFAULT 'H1',
    difficulty ENUM('Beginner','Intermediate','Advanced') NOT NULL DEFAULT 'Beginner',
    mode ENUM('band','box') NOT NULL DEFAULT 'band',
    instruction TEXT NOT NULL,
    hint TEXT DEFAULT NULL,
    explanation TEXT NOT NULL,
    price_decimals TINYINT UNSIGNED NOT NULL DEFAULT 5,
    candles LONGTEXT NOT NULL,
    targets LONGTEXT NOT NULL,
    tol_price DECIMAL(4,2) NOT NULL DEFAULT 0.50,
    tol_candles DECIMAL(4,2) NOT NULL DEFAULT 1.50,
    is_premium TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('draft','published') NOT NULL DEFAULT 'published',
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_chartlab_ex_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    INDEX idx_chartlab_ex_status (status, sort_order)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS chartlab_attempts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    exercise_id INT UNSIGNED NOT NULL,
    result ENUM('correct','close','incorrect') NOT NULL,
    score TINYINT UNSIGNED NOT NULL DEFAULT 0,
    zone_x1 DECIMAL(8,3) NOT NULL,
    zone_x2 DECIMAL(8,3) NOT NULL,
    zone_p1 DECIMAL(14,6) NOT NULL,
    zone_p2 DECIMAL(14,6) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_chartlab_att_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_chartlab_att_exercise FOREIGN KEY (exercise_id) REFERENCES chartlab_exercises(id) ON DELETE CASCADE,
    INDEX idx_chartlab_att_user_ex (user_id, exercise_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Starter exercises
-- The 'targets' column is the answer. It is only ever read by
-- PHP on the server and never sent to the browser until solved.
-- ---------------------------------------------------------

INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Mark the Support Zone', 'mark-the-support-zone', 'EUR/USD', 'H1', 'Beginner', 'band',
    'Price keeps falling to the same floor and bouncing. Drag a box over the support zone: the price area where buyers stepped in each time. Stretch it across the candles that touched the floor.',
    'Look at the lows. Three separate dips stopped in the same narrow price band, and every one was followed by a rally. Wrap that band.',
    'Buyers defended this floor three times. Each dip printed a long lower wick or a bullish rejection candle at almost the same price, which is what makes it support. A zone (not a single line) is right because real reactions land within a small band, so it should cover the wick lows and the bottoms of the rejection candles.',
    5, '[[1.09449,1.09473,1.09419,1.09442],[1.09442,1.09452,1.09337,1.09347],[1.09345,1.09355,1.09227,1.09251],[1.09247,1.09254,1.09098,1.09117],[1.09116,1.09128,1.08999,1.09016],[1.09015,1.09029,1.08894,1.08905],[1.08901,1.08919,1.08779,1.08797],[1.08801,1.08813,1.08745,1.08758],[1.08757,1.08763,1.08713,1.08728],[1.08728,1.08734,1.08667,1.08686],[1.08681,1.0869,1.08468,1.08648],[1.08645,1.08793,1.08627,1.08785],[1.08787,1.08893,1.08772,1.08876],[1.08876,1.09013,1.08854,1.09001],[1.09003,1.09091,1.08996,1.09085],[1.0908,1.09172,1.09059,1.09149],[1.09152,1.09284,1.09132,1.09266],[1.09269,1.0938,1.0926,1.09371],[1.09374,1.09396,1.09213,1.09227],[1.0923,1.09254,1.09058,1.09079],[1.09078,1.09094,1.08912,1.0893],[1.08928,1.08939,1.08654,1.08675],[1.08671,1.08701,1.08492,1.0869],[1.08686,1.08868,1.08674,1.08846],[1.08842,1.08937,1.08836,1.08915],[1.08916,1.09007,1.089,1.08993],[1.08996,1.09055,1.08978,1.09044],[1.09045,1.09148,1.09022,1.09136],[1.09134,1.09232,1.09121,1.0921],[1.09206,1.09292,1.09197,1.09285],[1.09281,1.09294,1.09156,1.0917],[1.09171,1.0919,1.09061,1.09073],[1.09075,1.09083,1.08943,1.08959],[1.08957,1.08976,1.08849,1.08859],[1.08858,1.0887,1.08691,1.08698],[1.08693,1.08713,1.08474,1.08683],[1.08685,1.0893,1.08662,1.08911],[1.08914,1.09034,1.08891,1.09011],[1.09006,1.09114,1.08995,1.091],[1.09101,1.09205,1.0908,1.09186],[1.09181,1.09291,1.09164,1.0928],[1.09282,1.09399,1.0927,1.09379],[1.09381,1.09477,1.09367,1.09459],[1.09456,1.09559,1.09436,1.09549],[1.09545,1.09676,1.09536,1.09667],[1.09669,1.09776,1.09647,1.09758],[1.09757,1.09865,1.09742,1.09856],[1.09858,1.0997,1.09848,1.09955]]',
    '[{"x1":9,"x2":37,"p1":1.08463,"p2":1.08673}]',
    0.50, 2.00, 0, 'published', 1
);

INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Mark the Resistance Zone', 'mark-the-resistance-zone', 'GBP/USD', 'H4', 'Beginner', 'band',
    'Price rallies, stalls at the same ceiling, and drops back. Drag a box over the resistance zone: the price area where sellers pushed price down each time.',
    'Focus on the highs. Three separate rallies were rejected in the same narrow band near the top of the chart. Cover the upper wicks and the tops of those candles.',
    'Sellers defended this ceiling three times. Each push up printed an upper wick or a bearish rejection at almost the same price. The zone spans from the tops of the rejection candle bodies to the highest wicks, because reactions cluster in a band rather than at one exact price.',
    5, '[[1.25415,1.25429,1.25406,1.25416],[1.25418,1.25537,1.25396,1.25523],[1.25519,1.25622,1.25504,1.25612],[1.25613,1.2571,1.25592,1.25695],[1.25693,1.25809,1.25674,1.25795],[1.25797,1.25898,1.25786,1.25888],[1.25888,1.25989,1.25881,1.25978],[1.25982,1.26057,1.25976,1.26037],[1.26034,1.26116,1.26026,1.26094],[1.2609,1.26193,1.26081,1.26172],[1.26177,1.26255,1.26168,1.26238],[1.26236,1.2637,1.26225,1.26346],[1.26345,1.26416,1.26332,1.26406],[1.26407,1.26521,1.26398,1.26509],[1.2651,1.26742,1.26486,1.26553],[1.26554,1.26577,1.26264,1.26287],[1.26286,1.26294,1.26198,1.2622],[1.26217,1.26235,1.26111,1.26135],[1.26133,1.26156,1.26021,1.26029],[1.26026,1.26034,1.25921,1.25928],[1.25923,1.25941,1.25841,1.25855],[1.25856,1.25958,1.2584,1.2595],[1.25947,1.26067,1.25929,1.2606],[1.26064,1.26182,1.26055,1.26176],[1.26178,1.2631,1.26163,1.263],[1.26296,1.26516,1.26281,1.26497],[1.265,1.26718,1.26485,1.26532],[1.26533,1.26547,1.2625,1.26267],[1.26264,1.26271,1.26174,1.26187],[1.26192,1.26207,1.26074,1.26096],[1.26098,1.26111,1.25965,1.25987],[1.25987,1.26,1.25875,1.25883],[1.2588,1.25896,1.25781,1.25801],[1.25801,1.2595,1.2579,1.25934],[1.25939,1.26077,1.25924,1.26066],[1.26069,1.26216,1.26047,1.26198],[1.26201,1.26335,1.26187,1.26321],[1.26317,1.26528,1.26297,1.26512],[1.26511,1.26735,1.26494,1.2654],[1.26538,1.26556,1.26236,1.26254],[1.26251,1.2626,1.26074,1.26097],[1.26096,1.26115,1.25912,1.25933],[1.2593,1.25954,1.25755,1.25763],[1.25768,1.25775,1.25599,1.25611],[1.25613,1.25622,1.25446,1.25453],[1.25448,1.25461,1.25289,1.25307],[1.25304,1.25319,1.25142,1.25154],[1.25156,1.25175,1.24987,1.25005]]',
    '[{"x1":13,"x2":39,"p1":1.26542,"p2":1.26747}]',
    0.50, 2.00, 0, 'published', 2
);

INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Find the Flipped Level', 'find-the-flipped-level', 'USD/JPY', 'H1', 'Intermediate', 'band',
    'A ceiling held price down twice, then price broke through it. Later, price came back to that same area. Mark the zone that was resistance and has now flipped into support.',
    'Find the level price failed to break twice on the left. After the breakout, look for the candle that dips back to that exact area and bounces.',
    'Old resistance often becomes new support once price has clearly broken above it. Traders who missed the breakout buy the retest, and sellers who were trapped below cover, so the same band that capped price now holds it up. The retest candle dipping into the old ceiling and bouncing is the confirmation.',
    3, '[[150.101,150.124,150.081,150.116],[150.12,150.195,150.109,150.182],[150.181,150.327,150.171,150.31],[150.31,150.429,150.303,150.415],[150.414,150.529,150.396,150.511],[150.512,150.615,150.503,150.596],[150.594,150.711,150.577,150.697],[150.699,150.819,150.684,150.803],[150.8,150.93,150.784,150.911],[150.915,151.014,150.899,150.996],[150.999,151.118,150.981,151.11],[151.108,151.155,151.095,151.136],[151.134,151.3,151.116,151.154],[151.159,151.176,150.892,150.905],[150.902,150.908,150.837,150.857],[150.858,150.866,150.757,150.773],[150.768,150.776,150.725,150.733],[150.731,150.737,150.66,150.678],[150.68,150.696,150.599,150.606],[150.603,150.717,150.588,150.699],[150.695,150.829,150.686,150.821],[150.822,150.933,150.813,150.922],[150.921,151.054,150.91,151.042],[151.042,151.132,151.029,151.12],[151.118,151.28,151.105,151.178],[151.178,151.189,150.931,150.945],[150.945,150.954,150.915,150.932],[150.929,150.939,150.901,150.911],[150.91,150.925,150.85,150.869],[150.874,150.892,150.843,150.85],[150.853,150.959,150.838,150.948],[150.948,151.084,150.937,151.073],[151.078,151.168,151.063,151.162],[151.158,151.31,151.151,151.3],[151.299,151.479,151.292,151.461],[151.465,151.588,151.457,151.57],[151.568,151.724,151.552,151.708],[151.706,151.861,151.69,151.844],[151.844,151.954,151.827,151.94],[151.944,152.012,151.935,152.005],[152.009,152.132,151.996,152.12],[152.121,152.224,152.108,152.206],[152.209,152.225,152.048,152.06],[152.06,152.078,151.885,151.893],[151.896,151.902,151.753,151.772],[151.775,151.783,151.599,151.618],[151.618,151.629,151.506,151.512],[151.508,151.515,151.397,151.408],[151.407,151.466,151.22,151.46],[151.457,151.623,151.45,151.612],[151.615,151.799,151.604,151.781],[151.777,151.967,151.758,151.951]]',
    '[{"x1":11,"x2":50,"p1":151.21,"p2":151.31}]',
    0.50, 2.00, 1, 'published', 3
);

INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Mark the Consolidation Range', 'mark-the-consolidation-range', 'GBP/USD', 'M30', 'Intermediate', 'box',
    'After a push up, price paused in a tight sideways range before breaking out. Drag a box around the consolidation: its start, its end, its top and its bottom.',
    'Find the stretch where candles stop trending and bunch together in a narrow band. The box starts where the trend pauses and ends at the candle just before the breakout.',
    'A consolidation is a pause where buyers and sellers are balanced: candles overlap, highs and lows stop stretching, and volatility drops. The box runs from the first candle of the pause to the last candle before price escaped. Breakouts from tight ranges often continue in the direction of the previous trend, but a breakout is never guaranteed.',
    5, '[[1.26471,1.26478,1.26464,1.26472],[1.26473,1.26529,1.26465,1.26516],[1.2652,1.26598,1.26504,1.26583],[1.2658,1.26607,1.26571,1.26588],[1.26584,1.26635,1.26571,1.26627],[1.26625,1.26653,1.26604,1.26641],[1.26642,1.26648,1.26623,1.26631],[1.26636,1.26653,1.2661,1.26626],[1.26629,1.26649,1.26569,1.26589],[1.26587,1.26621,1.2657,1.26609],[1.26606,1.26706,1.26597,1.26683],[1.2668,1.26756,1.2667,1.26741],[1.26736,1.26813,1.2673,1.26799],[1.26804,1.26877,1.2678,1.26862],[1.26864,1.26986,1.26846,1.26963],[1.26964,1.27005,1.26941,1.26994],[1.26994,1.27056,1.26986,1.27047],[1.27048,1.27167,1.27037,1.27154],[1.27153,1.2729,1.27139,1.2728],[1.27282,1.27338,1.27272,1.27324],[1.27327,1.27335,1.27306,1.27319],[1.27321,1.27344,1.27253,1.27267],[1.27263,1.27282,1.27185,1.272],[1.27202,1.27217,1.27147,1.2717],[1.27168,1.27245,1.27145,1.2723],[1.27234,1.27367,1.27222,1.27353],[1.27349,1.27366,1.27324,1.27337],[1.27337,1.27359,1.2722,1.27238],[1.27233,1.27252,1.27156,1.27178],[1.27179,1.27194,1.2714,1.27147],[1.27143,1.27245,1.27131,1.27228],[1.27224,1.2733,1.27213,1.27311],[1.27314,1.27425,1.27308,1.2741],[1.27412,1.27496,1.27392,1.27473],[1.27472,1.27569,1.27449,1.27561],[1.27561,1.27685,1.2755,1.27663],[1.27665,1.27715,1.27652,1.27698],[1.27697,1.27716,1.2766,1.27675],[1.27674,1.27688,1.27649,1.27667],[1.27668,1.27689,1.27652,1.27661],[1.27663,1.27677,1.27611,1.27631],[1.27636,1.27701,1.27628,1.2769],[1.27691,1.27792,1.27667,1.27776],[1.27779,1.27848,1.27763,1.27839],[1.27835,1.27922,1.27821,1.27912],[1.27912,1.27961,1.27896,1.27953],[1.27949,1.28002,1.27925,1.27979],[1.27974,1.28068,1.2795,1.2805],[1.28052,1.28103,1.28036,1.28087],[1.28089,1.28144,1.28069,1.28128]]',
    '[{"x1":18,"x2":32,"p1":1.27126,"p2":1.27372}]',
    0.35, 1.50, 1, 'published', 4
);

INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Mark the Demand Zone', 'mark-the-demand-zone', 'AUD/USD', 'H1', 'Intermediate', 'box',
    'Price left one small area very quickly and rallied hard. Mark the demand zone: the tight base of small candles just before the explosive move up.',
    'Find the big bullish candles that shoot price upward. The demand zone is the small cluster of candles right before them, at the bottom of the move.',
    'A demand zone is the base where buyers overwhelmed sellers so fast that price left the area with a sharp impulse. The tight cluster of small candles before that push marks where unfilled buy orders may still be waiting. Price does not always return to a demand zone, so treat it as an area of interest, not a guarantee.',
    5, '[[0.66906,0.66931,0.66888,0.6692],[0.66918,0.66936,0.66892,0.66899],[0.66904,0.66917,0.66841,0.66857],[0.66859,0.6688,0.66827,0.6685],[0.66855,0.66861,0.66771,0.66782],[0.66779,0.668,0.66755,0.6678],[0.66784,0.66807,0.66746,0.66765],[0.66764,0.66785,0.66703,0.66715],[0.66712,0.6672,0.6667,0.66689],[0.66694,0.66711,0.66646,0.66668],[0.66667,0.66674,0.66609,0.66618],[0.6662,0.66643,0.66587,0.66593],[0.66596,0.66614,0.66556,0.66573],[0.66574,0.66587,0.66488,0.66511],[0.66512,0.66526,0.66501,0.66508],[0.6651,0.66534,0.66429,0.66451],[0.66488,0.66535,0.66443,0.66468],[0.66498,0.66537,0.66425,0.66466],[0.66451,0.66508,0.66408,0.66471],[0.66478,0.66515,0.66412,0.6646],[0.66507,0.66551,0.6645,0.66478],[0.665,0.66665,0.66485,0.6664],[0.6664,0.66885,0.66625,0.6686],[0.6686,0.67055,0.66845,0.6703],[0.6703,0.67165,0.67015,0.6714],[0.67155,0.67226,0.67142,0.67218],[0.67221,0.67268,0.67204,0.67251],[0.67248,0.67304,0.67242,0.67295],[0.67295,0.67312,0.67279,0.67303],[0.67303,0.67314,0.67251,0.67265],[0.67269,0.67277,0.67183,0.67202],[0.67206,0.67226,0.67124,0.67144],[0.67142,0.6715,0.67052,0.67065],[0.6707,0.67077,0.67042,0.67053],[0.67049,0.67058,0.66988,0.66998],[0.67003,0.67015,0.66913,0.66935],[0.66937,0.66995,0.66915,0.66979],[0.66979,0.67047,0.66957,0.6703],[0.67026,0.67081,0.6701,0.67062],[0.67061,0.67117,0.67046,0.67096],[0.67099,0.6719,0.6708,0.67179],[0.67175,0.6723,0.67163,0.67219],[0.67224,0.67266,0.67209,0.67245],[0.67244,0.67316,0.67233,0.67305],[0.6731,0.67378,0.67292,0.67355],[0.67359,0.67401,0.6734,0.67388],[0.67385,0.67472,0.67377,0.67457],[0.67459,0.67483,0.67448,0.67474]]',
    '[{"x1":16,"x2":21,"p1":0.66405,"p2":0.66554}]',
    0.50, 1.50, 1, 'published', 5
);

INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Mark the Supply Zone', 'mark-the-supply-zone', 'EUR/GBP', 'H1', 'Advanced', 'box',
    'Price stalled briefly at the top, then dropped sharply. Mark the supply zone: the tight base of small candles just before the strong move down.',
    'Find the big bearish candles that drive price lower. The supply zone is the small cluster right before them, where the drop began.',
    'A supply zone is the base where sellers overwhelmed buyers so fast that price left with a sharp impulse down. The tight cluster before the drop marks where sell orders may still be waiting. Like every zone, it is an area of interest, not a promise that price will react again.',
    5, '[[0.84022,0.8404,0.83989,0.84006],[0.84003,0.84063,0.83981,0.84054],[0.84056,0.84102,0.84042,0.84083],[0.84079,0.8412,0.84056,0.84107],[0.84103,0.84154,0.84087,0.84134],[0.84131,0.84205,0.84119,0.84188],[0.84191,0.84225,0.84174,0.84203],[0.84199,0.84267,0.84187,0.84243],[0.84239,0.84279,0.84232,0.84272],[0.84275,0.84328,0.84251,0.84316],[0.84316,0.84339,0.84293,0.84321],[0.84322,0.84393,0.84316,0.84378],[0.84382,0.84434,0.84365,0.84414],[0.84415,0.8444,0.84401,0.84433],[0.84433,0.84485,0.84413,0.84476],[0.84473,0.84542,0.84467,0.84522],[0.84539,0.84577,0.84474,0.84509],[0.84529,0.84579,0.84497,0.84547],[0.84493,0.84545,0.84461,0.84511],[0.84504,0.84551,0.84466,0.84521],[0.84516,0.84551,0.8446,0.84487],[0.8448,0.84495,0.84315,0.8434],[0.8434,0.84355,0.84095,0.8412],[0.8412,0.84135,0.83935,0.8396],[0.8396,0.83975,0.83835,0.8386],[0.83849,0.83865,0.83781,0.83796],[0.83799,0.83818,0.83736,0.83754],[0.83754,0.83774,0.83687,0.83707],[0.8371,0.83726,0.8367,0.83683],[0.8368,0.83742,0.83661,0.8372],[0.83721,0.83829,0.83714,0.83818],[0.83817,0.83895,0.83797,0.8388],[0.83884,0.83938,0.83862,0.83921],[0.8392,0.83992,0.83908,0.83979],[0.8398,0.84021,0.83961,0.84004],[0.84007,0.8409,0.84,0.8407],[0.8407,0.84084,0.84013,0.84024],[0.84019,0.8404,0.8398,0.83994],[0.83998,0.84005,0.83906,0.83913],[0.83914,0.83937,0.8387,0.83879],[0.83881,0.83888,0.83799,0.8382],[0.83819,0.83832,0.83743,0.83759],[0.83763,0.83778,0.83719,0.83743],[0.83741,0.83762,0.83703,0.83718],[0.83716,0.83731,0.83636,0.83659],[0.8366,0.8368,0.83585,0.836],[0.83604,0.83614,0.83553,0.83577],[0.83577,0.83592,0.83501,0.83516]]',
    '[{"x1":16,"x2":21,"p1":0.84457,"p2":0.84582}]',
    0.50, 1.50, 1, 'published', 6
);
