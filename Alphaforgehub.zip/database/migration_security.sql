-- =========================================================
-- ALPHA FORGE - Security hardening migration
-- Run this in phpMyAdmin (SQL tab) against your EXISTING alpha_forge
-- database. Safe to run once; re-running is harmless (IF NOT EXISTS
-- guards are used where possible).
-- =========================================================

USE alpha_forge;

-- ---- Two-factor authentication fields for admin accounts ----
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS two_factor_secret VARCHAR(64) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS two_factor_enabled TINYINT(1) NOT NULL DEFAULT 0;

-- ---- IP-based rate limiting (login, register, contact, etc.) ----
CREATE TABLE IF NOT EXISTS rate_limits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    action VARCHAR(50) NOT NULL,
    attempt_count INT UNSIGNED NOT NULL DEFAULT 1,
    window_start DATETIME NOT NULL,
    blocked_until DATETIME DEFAULT NULL,
    UNIQUE KEY uniq_ip_action (ip_address, action)
) ENGINE=InnoDB;

-- ---- Security event log (failed logins, lockouts, 2FA events) ----
CREATE TABLE IF NOT EXISTS security_log (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_id INT UNSIGNED DEFAULT NULL,
    detail VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_seclog_type (event_type),
    INDEX idx_seclog_created (created_at)
) ENGINE=InnoDB;
