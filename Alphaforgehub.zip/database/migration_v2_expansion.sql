-- =========================================================
-- ALPHA FORGE HUB V2 — Expansion migration
-- Adds: Forexpedia, Market Center (strength/correlation/sentiment),
--       Trading Simulator, Backtesting Lab, Mentorship, Store,
--       Prop Firm progress tracking.
-- Safe to run once. Uses CREATE TABLE IF NOT EXISTS throughout.
-- Run AFTER schema.sql and the other migration_*.sql files.
-- =========================================================

-- ---------------------------------------------------------
-- FOREXPEDIA (glossary)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS forexpedia_terms (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    term VARCHAR(150) NOT NULL,
    slug VARCHAR(160) NOT NULL UNIQUE,
    letter CHAR(1) NOT NULL,
    short_definition VARCHAR(500) NOT NULL,
    full_explanation TEXT,
    example TEXT,
    related_lesson_id INT UNSIGNED DEFAULT NULL,
    related_terms VARCHAR(255) DEFAULT NULL COMMENT 'comma-separated slugs',
    status ENUM('draft','published') NOT NULL DEFAULT 'published',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_fp_letter (letter),
    INDEX idx_fp_status (status),
    FOREIGN KEY (related_lesson_id) REFERENCES lessons(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- MARKET CENTER — admin-entered snapshots (never fabricated live data)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS currency_strength_snapshots (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    currency CHAR(3) NOT NULL,
    strength_score DECIMAL(5,2) NOT NULL COMMENT '-100 to 100, admin-entered or provider-calculated',
    snapshot_date DATE NOT NULL,
    source VARCHAR(100) NOT NULL DEFAULT 'manual',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_strength (currency, snapshot_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS currency_correlations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pair_a VARCHAR(10) NOT NULL,
    pair_b VARCHAR(10) NOT NULL,
    correlation_value DECIMAL(4,3) NOT NULL COMMENT '-1.000 to 1.000',
    timeframe VARCHAR(20) NOT NULL DEFAULT '1M',
    snapshot_date DATE NOT NULL,
    source VARCHAR(100) NOT NULL DEFAULT 'manual',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_corr (pair_a, pair_b, timeframe, snapshot_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS market_sentiment_snapshots (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    snapshot_date DATE NOT NULL UNIQUE,
    sentiment ENUM('risk_on','risk_off','neutral') NOT NULL,
    summary VARCHAR(500) NOT NULL,
    source VARCHAR(100) NOT NULL DEFAULT 'manual',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TRADING SIMULATOR (virtual money only)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS simulator_accounts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    balance DECIMAL(14,2) NOT NULL DEFAULT 10000.00,
    equity DECIMAL(14,2) NOT NULL DEFAULT 10000.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_sim_user (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS simulator_trades (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    account_id INT UNSIGNED NOT NULL,
    pair VARCHAR(10) NOT NULL,
    direction ENUM('buy','sell') NOT NULL,
    lot_size DECIMAL(6,2) NOT NULL,
    entry_price DECIMAL(12,5) NOT NULL,
    stop_loss DECIMAL(12,5) DEFAULT NULL,
    take_profit DECIMAL(12,5) DEFAULT NULL,
    exit_price DECIMAL(12,5) DEFAULT NULL,
    status ENUM('open','closed') NOT NULL DEFAULT 'open',
    pnl DECIMAL(12,2) DEFAULT NULL,
    opened_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at DATETIME DEFAULT NULL,
    INDEX idx_sim_trade_account (account_id, status),
    FOREIGN KEY (account_id) REFERENCES simulator_accounts(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- BACKTESTING LAB (historical candle-reveal practice)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS backtest_sessions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    pair VARCHAR(10) NOT NULL,
    timeframe VARCHAR(10) NOT NULL,
    strategy_notes VARCHAR(255) DEFAULT NULL,
    status ENUM('active','completed') NOT NULL DEFAULT 'active',
    started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS backtest_trades (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_id INT UNSIGNED NOT NULL,
    candle_index INT UNSIGNED NOT NULL,
    direction ENUM('buy','sell') NOT NULL,
    entry_price DECIMAL(12,5) NOT NULL,
    exit_price DECIMAL(12,5) DEFAULT NULL,
    result ENUM('win','loss','breakeven','open') NOT NULL DEFAULT 'open',
    pnl_r DECIMAL(6,2) DEFAULT NULL COMMENT 'result expressed in R multiples',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES backtest_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- MENTORSHIP (admin-managed initially)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS mentors (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    headline VARCHAR(255) DEFAULT NULL,
    bio TEXT,
    photo VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mentorship_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    mentor_id INT UNSIGNED NOT NULL,
    message TEXT,
    preferred_time VARCHAR(150) DEFAULT NULL,
    status ENUM('pending','scheduled','completed','declined') NOT NULL DEFAULT 'pending',
    admin_notes TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (mentor_id) REFERENCES mentors(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- STORE (courses + ebooks + bundles unified storefront)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS store_products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    type ENUM('ebook','bundle','premium_content') NOT NULL DEFAULT 'ebook',
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(190) NOT NULL UNIQUE,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'XAF',
    image VARCHAR(255) DEFAULT NULL,
    file_path VARCHAR(255) DEFAULT NULL COMMENT 'delivered only after verified payment',
    status ENUM('draft','published') NOT NULL DEFAULT 'draft',
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS store_purchases (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    product_id INT UNSIGNED NOT NULL,
    payment_id INT UNSIGNED DEFAULT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
    purchased_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES store_products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- STORE PAYMENTS — extend the existing payments table so Store purchases
-- reuse the same MTN/Orange gateway architecture as subscriptions.
-- Additive/backward-compatible: existing subscription payments are unaffected.
-- ---------------------------------------------------------
ALTER TABLE payments MODIFY subscription_id INT UNSIGNED NULL;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS product_id INT UNSIGNED NULL AFTER subscription_id;
ALTER TABLE payments ADD CONSTRAINT fk_pay_product FOREIGN KEY (product_id) REFERENCES store_products(id) ON DELETE CASCADE;

-- ---------------------------------------------------------
-- PROP FIRM ACADEMY — challenge-prep progress (educational only)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS prop_firm_checklist_progress (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    item_key VARCHAR(100) NOT NULL,
    completed TINYINT(1) NOT NULL DEFAULT 0,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_prop_item (user_id, item_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- LANGUAGE PREFERENCE
-- ---------------------------------------------------------
ALTER TABLE users ADD COLUMN IF NOT EXISTS preferred_language VARCHAR(5) NOT NULL DEFAULT 'en';

-- ---------------------------------------------------------
-- SEED: a starter Forexpedia glossary (safe re-run: INSERT IGNORE)
-- ---------------------------------------------------------
INSERT IGNORE INTO forexpedia_terms (term, slug, letter, short_definition, full_explanation, example, status) VALUES
('Pip', 'pip', 'P', 'The smallest standard price move a currency pair can make.', 'Short for "percentage in point." For most pairs a pip is the fourth decimal place (0.0001); for JPY pairs it is the second decimal place (0.01).', 'EUR/USD moves from 1.0850 to 1.0851 — that is a 1 pip move.', 'published'),
('Spread', 'spread', 'S', 'The difference between the bid (sell) and ask (buy) price.', 'The spread is effectively the broker''s transaction cost, quoted in pips. Tighter spreads mean lower cost per trade.', 'If EUR/USD bid is 1.0850 and ask is 1.0852, the spread is 2 pips.', 'published'),
('Leverage', 'leverage', 'L', 'Borrowed capital that lets a trader control a larger position than their own funds.', 'Leverage magnifies both gains and losses. 1:100 leverage means $1,000 of margin can control a $100,000 position.', 'A $1,000 account with 1:100 leverage can open a 1.0 standard lot position.', 'published'),
('Margin', 'margin', 'M', 'The amount of money set aside by your broker to keep a leveraged position open.', 'Margin is not a fee — it is collateral. If your equity falls below the required margin level, a margin call or stop-out can occur.', 'Opening 1 lot of EUR/USD at 1:100 leverage requires roughly $1,000 in margin.', 'published'),
('Liquidity', 'liquidity', 'L', 'How easily an asset can be bought or sold without significantly moving its price.', 'Major pairs like EUR/USD are highly liquid; exotic pairs are less liquid and can have wider spreads and more slippage.', 'The London/New York overlap is typically the most liquid Forex trading window.', 'published'),
('Volatility', 'volatility', 'V', 'A measure of how much and how quickly price moves over a given period.', 'High volatility means larger, faster price swings — more opportunity but also more risk. News events often spike volatility.', 'GBP pairs often show higher volatility around UK economic data releases.', 'published'),
('Drawdown', 'drawdown', 'D', 'The decline in account equity from a peak to a subsequent low.', 'Usually expressed as a percentage. Managing maximum drawdown is central to risk management and prop-firm rules.', 'An account that grows to $12,000 then falls to $10,800 has a 10% drawdown.', 'published'),
('Equity', 'equity', 'E', 'Your account balance adjusted for the floating profit or loss of open trades.', 'Equity = Balance + Floating P/L. It changes in real time while trades are open.', 'A $10,000 balance with a $200 floating loss shows $9,800 equity.', 'published'),
('Stop Loss', 'stop-loss', 'S', 'A pre-set order that automatically closes a trade at a defined loss level.', 'A core risk-management tool that caps how much a single trade can lose.', 'A trader buys at 1.0850 and sets a stop loss at 1.0820 to cap risk at 30 pips.', 'published'),
('Take Profit', 'take-profit', 'T', 'A pre-set order that automatically closes a trade once a target profit level is reached.', 'Used together with a stop loss to define a trade''s risk-to-reward ratio in advance.', 'A trader sets a take profit at 1.0910, 60 pips above a 1.0850 entry.', 'published'),
('Swap', 'swap', 'S', 'The interest paid or earned for holding a position open overnight.', 'Swap is based on the interest-rate differential between the two currencies in the pair, and can be positive or negative.', 'Holding a long AUD/JPY position overnight may earn a positive swap due to the interest-rate gap.', 'published'),
('Bid', 'bid', 'B', 'The price at which the market (your broker) will buy the base currency from you.', 'It is always slightly lower than the ask price. You sell at the bid.', 'If EUR/USD is quoted 1.0850/1.0852, the bid is 1.0850.', 'published'),
('Ask', 'ask', 'A', 'The price at which the market (your broker) will sell the base currency to you.', 'Also called the "offer." You buy at the ask, which is always slightly above the bid.', 'If EUR/USD is quoted 1.0850/1.0852, the ask is 1.0852.', 'published'),
('Base Currency', 'base-currency', 'B', 'The first currency listed in a currency pair.', 'It represents the amount of the second (quote) currency needed to buy one unit of the base currency.', 'In EUR/USD, EUR is the base currency.', 'published'),
('Quote Currency', 'quote-currency', 'Q', 'The second currency listed in a currency pair, also called the counter currency.', 'It shows how much of this currency is needed to buy one unit of the base currency.', 'In EUR/USD, USD is the quote currency.', 'published');
