-- =========================================================
-- ALPHA FORGE HUB - Market Info, Community, Challenges,
-- Live Sessions migration (Phases 6-7)
-- Run this ONCE in phpMyAdmin, AFTER migration_certificates.sql.
-- No fake data is inserted - these tables start empty and are
-- populated by the admin (or, later, by a real data-provider job).
-- =========================================================

USE alpha_forge;

-- ---- Phase 6: Economic Calendar ----
CREATE TABLE IF NOT EXISTS economic_events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_date DATE NOT NULL,
    event_time TIME DEFAULT NULL,
    currency VARCHAR(3) NOT NULL,
    event_name VARCHAR(200) NOT NULL,
    impact ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
    forecast VARCHAR(50) DEFAULT NULL,
    previous VARCHAR(50) DEFAULT NULL,
    actual VARCHAR(50) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_econ_date (event_date),
    INDEX idx_econ_currency (currency)
) ENGINE=InnoDB;

-- ---- Phase 6: Market News ----
CREATE TABLE IF NOT EXISTS market_news (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    headline VARCHAR(255) NOT NULL,
    source VARCHAR(100) NOT NULL,
    source_url VARCHAR(500) DEFAULT NULL,
    currency VARCHAR(3) DEFAULT NULL,
    summary TEXT,
    published_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_news_published (published_at)
) ENGINE=InnoDB;

-- ---- Phase 7: Community ----
CREATE TABLE IF NOT EXISTS community_posts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    category ENUM('discussion','question','study_group','announcement') NOT NULL DEFAULT 'discussion',
    is_pinned TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_post_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_post_category (category),
    INDEX idx_post_pinned_created (is_pinned, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS community_comments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    post_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    body TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_comment_post FOREIGN KEY (post_id) REFERENCES community_posts(id) ON DELETE CASCADE,
    CONSTRAINT fk_comment_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_comment_post (post_id)
) ENGINE=InnoDB;

-- ---- Phase 7: Trading Challenges ----
CREATE TABLE IF NOT EXISTS challenges (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    duration_days INT UNSIGNED NOT NULL DEFAULT 7,
    status ENUM('active','draft') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS challenge_progress (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    challenge_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME DEFAULT NULL,
    CONSTRAINT fk_cp_challenge FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE,
    CONSTRAINT fk_cp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_cp_user_challenge (challenge_id, user_id)
) ENGINE=InnoDB;

-- ---- Phase 7: Live Sessions ----
CREATE TABLE IF NOT EXISTS live_sessions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    session_datetime DATETIME NOT NULL,
    join_url VARCHAR(500) DEFAULT NULL,
    recording_url VARCHAR(500) DEFAULT NULL,
    status ENUM('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_live_datetime (session_datetime)
) ENGINE=InnoDB;
