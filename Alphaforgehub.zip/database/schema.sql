-- =========================================================
-- ALPHA FORGE - Database Schema
-- Database: alpha_forge
-- Engine: MySQL / MariaDB
-- =========================================================

CREATE DATABASE IF NOT EXISTS alpha_forge CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE alpha_forge;

-- ---------------------------------------------------------
-- USERS
-- ---------------------------------------------------------
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student','admin') NOT NULL DEFAULT 'student',
    status ENUM('active','suspended') NOT NULL DEFAULT 'active',
    failed_login_count INT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME DEFAULT NULL,
    two_factor_secret VARCHAR(64) DEFAULT NULL,
    two_factor_enabled TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role),
    INDEX idx_users_email (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- COURSES
-- ---------------------------------------------------------
CREATE TABLE courses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(190) NOT NULL UNIQUE,
    description TEXT,
    level ENUM('Beginner','Intermediate','Advanced') NOT NULL DEFAULT 'Beginner',
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    image VARCHAR(255) DEFAULT NULL,
    is_premium TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('draft','published') NOT NULL DEFAULT 'draft',
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_courses_status (status),
    INDEX idx_courses_slug (slug)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- MODULES
-- ---------------------------------------------------------
CREATE TABLE modules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    course_id INT UNSIGNED NOT NULL,
    title VARCHAR(190) NOT NULL,
    description TEXT,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_modules_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_modules_course (course_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- LESSONS
-- ---------------------------------------------------------
CREATE TABLE lessons (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    module_id INT UNSIGNED NOT NULL,
    title VARCHAR(190) NOT NULL,
    slug VARCHAR(190) NOT NULL,
    content MEDIUMTEXT,
    duration_minutes INT UNSIGNED NOT NULL DEFAULT 10,
    is_premium TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('draft','published') NOT NULL DEFAULT 'published',
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_lessons_module FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_lesson_slug (module_id, slug),
    INDEX idx_lessons_module (module_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- LESSON PROGRESS (per student, per lesson)
-- ---------------------------------------------------------
CREATE TABLE lesson_progress (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    lesson_id INT UNSIGNED NOT NULL,
    completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_progress_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_progress_lesson FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_lesson (user_id, lesson_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- QUIZZES (one quiz question row per question, tied to a lesson)
-- ---------------------------------------------------------
CREATE TABLE quizzes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lesson_id INT UNSIGNED NOT NULL,
    question TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_answer ENUM('A','B','C','D') NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_quiz_lesson FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
    INDEX idx_quiz_lesson (lesson_id)
) ENGINE=InnoDB;

CREATE TABLE quiz_results (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    lesson_id INT UNSIGNED NOT NULL,
    score INT UNSIGNED NOT NULL,
    total_questions INT UNSIGNED NOT NULL,
    taken_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_result_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_result_lesson FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
    INDEX idx_results_user (user_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SUBSCRIPTION PLANS (editable pricing)
-- ---------------------------------------------------------
CREATE TABLE subscription_plans (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'XAF',
    duration_days INT UNSIGNED NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SUBSCRIPTIONS (per student)
-- ---------------------------------------------------------
CREATE TABLE subscriptions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    plan_id INT UNSIGNED NOT NULL,
    status ENUM('none','pending','active','expired','cancelled') NOT NULL DEFAULT 'pending',
    starts_at DATETIME DEFAULT NULL,
    ends_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_sub_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_sub_plan FOREIGN KEY (plan_id) REFERENCES subscription_plans(id),
    INDEX idx_sub_user (user_id),
    INDEX idx_sub_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- PAYMENTS
-- ---------------------------------------------------------
CREATE TABLE payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    subscription_id INT UNSIGNED NOT NULL,
    provider ENUM('mtn_momo','orange_money','card') NOT NULL,
    provider_reference VARCHAR(190) DEFAULT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'XAF',
    status ENUM('initiated','pending','successful','failed','cancelled') NOT NULL DEFAULT 'initiated',
    raw_response TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pay_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_pay_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
    INDEX idx_pay_status (status),
    INDEX idx_pay_reference (provider_reference)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- TESTIMONIALS
-- ---------------------------------------------------------
CREATE TABLE testimonials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    role_title VARCHAR(150) DEFAULT NULL,
    message TEXT NOT NULL,
    is_approved TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- CONTACT MESSAGES
-- ---------------------------------------------------------
CREATE TABLE contact_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SITE SETTINGS (key/value)
-- ---------------------------------------------------------
CREATE TABLE site_settings (
    setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
    setting_value TEXT
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- RATE LIMITS (IP-based throttling for login/register/contact)
-- ---------------------------------------------------------
CREATE TABLE rate_limits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    action VARCHAR(50) NOT NULL,
    attempt_count INT UNSIGNED NOT NULL DEFAULT 1,
    window_start DATETIME NOT NULL,
    blocked_until DATETIME DEFAULT NULL,
    UNIQUE KEY uniq_ip_action (ip_address, action)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SECURITY LOG (failed logins, lockouts, 2FA events)
-- ---------------------------------------------------------
CREATE TABLE security_log (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_id INT UNSIGNED DEFAULT NULL,
    detail VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_seclog_type (event_type),
    INDEX idx_seclog_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SEED DATA
-- ---------------------------------------------------------

INSERT INTO subscription_plans (code, name, price, currency, duration_days) VALUES
('monthly', 'Monthly', 5000.00, 'XAF', 30),
('quarterly', '3 Months', 12000.00, 'XAF', 90),
('annual', 'Annual', 35000.00, 'XAF', 365);

INSERT INTO site_settings (setting_key, setting_value) VALUES
('site_name', 'Alpha Forge'),
('site_tagline', 'Build your trading foundation with discipline.'),
('contact_email', '[email protected]'),
('mtn_momo_enabled', '0'),
('orange_money_enabled', '0');

INSERT INTO courses (title, slug, description, level, price, is_premium, status, sort_order) VALUES
('Forex Fundamentals', 'forex-fundamentals', 'Understand currencies, pips, lots, leverage, spreads and the foundations of the Forex market.', 'Beginner', 0.00, 0, 'published', 1),
('Technical Analysis', 'technical-analysis', 'Learn market structure, support and resistance, trends, candlesticks and technical setups.', 'Intermediate', 0.00, 1, 'published', 2),
('Risk Management', 'risk-management', 'Build disciplined risk rules, position sizing and a professional trading plan.', 'Beginner', 0.00, 0, 'published', 3);

INSERT INTO modules (course_id, title, description, sort_order) VALUES
(1, 'Getting Started', 'The foundations every trader needs before placing a trade.', 1),
(3, 'Managing Risk', 'The core discipline behind every professional trading plan.', 1);

INSERT INTO lessons (module_id, title, slug, content, duration_minutes, is_premium, status, sort_order) VALUES
(1, 'Introduction to Forex Trading', 'introduction-to-forex-trading', 'Forex trading is the buying and selling of currencies against each other in order to profit from changes in their relative value. This lesson introduces the structure of the global currency market, who the major participants are, and why the market operates 24 hours a day across different trading sessions.', 8, 0, 'published', 1),
(1, 'Currency Pairs', 'currency-pairs', 'Currencies are always quoted in pairs, such as EUR/USD or GBP/JPY. This lesson explains base and quote currencies, major/minor/exotic pairs, and how to read a currency pair correctly.', 10, 0, 'published', 2),
(1, 'Pips, Lots and Leverage', 'pips-lots-and-leverage', 'A pip is the smallest standard unit of price movement in Forex. This lesson covers pip value calculation, lot sizes (standard, mini, micro), and how leverage magnifies both gains and losses.', 12, 1, 'published', 3),
(1, 'Reading a Forex Quote', 'reading-a-forex-quote', 'This lesson breaks down a live currency quote, explaining the bid price, the ask price, and how to interpret quote movement in real time.', 8, 1, 'published', 4),
(1, 'Understanding the Spread', 'understanding-the-spread', 'The spread is the difference between the bid and ask price and represents a core trading cost. This lesson explains how spreads work and how they vary between brokers and sessions.', 9, 1, 'published', 5),
(1, 'Forex Trading Sessions', 'forex-trading-sessions', 'The Forex market is divided into the Sydney, Tokyo, London and New York sessions. This lesson explains session overlap, volatility patterns, and which sessions suit different trading styles.', 10, 1, 'published', 6),
(2, 'Risk Per Trade', 'risk-per-trade', 'Professional traders risk a small, fixed percentage of their account on every trade. This lesson explains how to calculate risk per trade and why consistent risk sizing protects a trading account.', 10, 0, 'published', 1),
(2, 'Stop Loss and Take Profit', 'stop-loss-and-take-profit', 'Stop loss and take profit orders define your risk and reward before you enter a trade. This lesson explains how to place them correctly and why removing emotion from exits matters.', 10, 0, 'published', 2);

-- Sample quiz for lesson 1
INSERT INTO quizzes (lesson_id, question, option_a, option_b, option_c, option_d, correct_answer, sort_order) VALUES
(1, 'What is the Forex market primarily used for?', 'Buying and selling stocks', 'Buying and selling currencies', 'Buying and selling commodities', 'Buying and selling bonds', 'B', 1),
(1, 'How many major trading sessions does the Forex market have?', '2', '3', '4', '5', 'C', 2);

-- NOTE: No default admin account is created here for security.
-- Use admin/install.php once, immediately after import, to create the first Admin account.
-- That script disables itself automatically after a successful admin creation.
