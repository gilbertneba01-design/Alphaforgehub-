-- ALPHA FORGE HUB - migration v3 (audit round 2). Safe to run more than once
-- (MariaDB/XAMPP: uses IF NOT EXISTS). Run in phpMyAdmin on the alpha_forge database.
-- Nothing is dropped or renamed; existing data is untouched.

-- 1) Mentor role
ALTER TABLE users MODIFY role ENUM('student','mentor','admin') NOT NULL DEFAULT 'student';
ALTER TABLE users ADD COLUMN IF NOT EXISTS community_muted TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE mentors ADD COLUMN IF NOT EXISTS user_id INT UNSIGNED DEFAULT NULL;
ALTER TABLE mentors ADD INDEX IF NOT EXISTS idx_mentors_user (user_id);
ALTER TABLE mentorship_requests ADD COLUMN IF NOT EXISTS mentor_note TEXT;
ALTER TABLE mentorship_requests ADD COLUMN IF NOT EXISTS updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- 2) Private mentor chat + feedback
CREATE TABLE IF NOT EXISTS mentorship_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    sender_id INT UNSIGNED NOT NULL,
    body TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES mentorship_requests(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_msg_request (request_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mentorship_feedback (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    mentor_user_id INT UNSIGNED NOT NULL,
    body TEXT NOT NULL,
    progress_pct TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES mentorship_requests(id) ON DELETE CASCADE,
    FOREIGN KEY (mentor_user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_fb_request (request_id)
) ENGINE=InnoDB;

-- 3) Announcements (admin-only writes; enforced in PHP)
CREATE TABLE IF NOT EXISTS announcements (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    body TEXT NOT NULL,
    kind ENUM('maintenance','feature','academic','course','system') NOT NULL DEFAULT 'system',
    is_pinned TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('published','draft') NOT NULL DEFAULT 'published',
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_ann_status (status, is_pinned, created_at)
) ENGINE=InnoDB;

-- 4) Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    type VARCHAR(40) NOT NULL,
    title VARCHAR(190) NOT NULL,
    body VARCHAR(500) DEFAULT NULL,
    link VARCHAR(255) DEFAULT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user (user_id, is_read, created_at)
) ENGINE=InnoDB;

-- 5) Community: threaded replies, moderation, reports
ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS is_locked TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE community_posts ADD COLUMN IF NOT EXISTS is_hidden TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE community_comments ADD COLUMN IF NOT EXISTS parent_id INT UNSIGNED DEFAULT NULL;
ALTER TABLE community_comments ADD COLUMN IF NOT EXISTS is_hidden TINYINT(1) NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS community_reports (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reporter_id INT UNSIGNED NOT NULL,
    post_id INT UNSIGNED DEFAULT NULL,
    comment_id INT UNSIGNED DEFAULT NULL,
    reason VARCHAR(300) NOT NULL,
    status ENUM('open','resolved') NOT NULL DEFAULT 'open',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_report_status (status)
) ENGINE=InnoDB;

-- 6) Study groups
CREATE TABLE IF NOT EXISTS study_groups (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    status ENUM('open','locked','closed') NOT NULL DEFAULT 'open',
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS study_group_members (
    group_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    status ENUM('active','removed') NOT NULL DEFAULT 'active',
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (group_id, user_id),
    FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS study_group_posts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    group_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    parent_id INT UNSIGNED DEFAULT NULL,
    body TEXT NOT NULL,
    is_hidden TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES study_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sgp_group (group_id, created_at)
) ENGINE=InnoDB;

-- 7) Translatable course content (English stays in the original columns)
CREATE TABLE IF NOT EXISTS course_translations (
    course_id INT UNSIGNED NOT NULL,
    lang VARCHAR(5) NOT NULL,
    title VARCHAR(190) DEFAULT NULL,
    description TEXT,
    PRIMARY KEY (course_id, lang),
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS lesson_translations (
    lesson_id INT UNSIGNED NOT NULL,
    lang VARCHAR(5) NOT NULL,
    title VARCHAR(190) DEFAULT NULL,
    content MEDIUMTEXT,
    PRIMARY KEY (lesson_id, lang),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8) Simulator: one server-side price per pair (clients no longer supply prices)
CREATE TABLE IF NOT EXISTS sim_prices (
    pair VARCHAR(10) NOT NULL PRIMARY KEY,
    price DECIMAL(12,5) NOT NULL,
    updated_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB;
