-- ============================================================
-- ALPHA FORGE HUB - Practice exercises pack
-- Run this AFTER database/migration_chartlab.sql has already
-- been imported. Safe to run once on a working database.
--
-- Adds:
--   1) A new Chart Lab exercise mode: 'trendline' (draw the
--      trend), plus two ready-to-use exercises using it.
--   2) Quiz questions for "Reading a Forex Quote" / "Understanding
--      the Spread" (identify bid, ask and spread) and for
--      "Forex Trading Sessions" (identify the trading session).
-- ============================================================

-- ------------------------------------------------------------
-- 1) Allow the new 'trendline' mode on chartlab_exercises
-- ------------------------------------------------------------
ALTER TABLE chartlab_exercises
    MODIFY mode ENUM('band','box','trendline') NOT NULL DEFAULT 'band';

-- ------------------------------------------------------------
-- 2) Draw the Upward Trend (EUR/USD, H1)
--    Target line runs from the low of candle 9 (index 8) to the
--    low of candle 27 (index 26) - two rising swing lows.
-- ------------------------------------------------------------
INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Draw the Upward Trend', 'draw-the-upward-trend', 'EUR/USD', 'H1', 'Beginner', 'trendline',
    'Price is making higher highs and higher lows. Draw a line connecting the swing lows: drag from an early pullback low to a later, higher pullback low, following the direction of the trend.',
    'Find two points where price pulled back and bounced, each one higher than the one before it, then connect them with a rising line.',
    'An uptrend line connects a series of rising swing lows. As long as price keeps making higher lows and stays above this line, the uptrend structure is still intact. A trader can use a line like this to time entries on pullbacks, or to spot the moment the trend breaks.',
    5,
    '[[1.09380,1.09390,1.09374,1.09382],[1.09382,1.09399,1.09374,1.09386],[1.09386,1.09403,1.09381,1.09393],[1.09393,1.09412,1.09387,1.09401],[1.09401,1.09427,1.09381,1.09409],[1.09409,1.09434,1.09397,1.09417],[1.09417,1.09438,1.09400,1.09424],[1.09424,1.09442,1.09418,1.09428],[1.09428,1.09437,1.09410,1.09430],[1.09430,1.09461,1.09412,1.09442],[1.09442,1.09488,1.09435,1.09475],[1.09475,1.09535,1.09467,1.09522],[1.09522,1.09594,1.09505,1.09575],[1.09575,1.09635,1.09558,1.09628],[1.09628,1.09686,1.09623,1.09675],[1.09675,1.09712,1.09662,1.09708],[1.09708,1.09737,1.09690,1.09720],[1.09720,1.09735,1.09709,1.09719],[1.09719,1.09732,1.09702,1.09717],[1.09717,1.09732,1.09698,1.09714],[1.09714,1.09733,1.09698,1.09709],[1.09709,1.09715,1.09698,1.09705],[1.09705,1.09716,1.09694,1.09701],[1.09701,1.09717,1.09683,1.09696],[1.09696,1.09713,1.09683,1.09693],[1.09693,1.09701,1.09682,1.09691],[1.09691,1.09696,1.09681,1.09690],[1.09690,1.09712,1.09672,1.09702],[1.09702,1.09754,1.09695,1.09735],[1.09735,1.09801,1.09722,1.09783],[1.09783,1.09850,1.09774,1.09840],[1.09840,1.09906,1.09821,1.09900],[1.09900,1.09963,1.09882,1.09957],[1.09957,1.10021,1.09946,1.10005],[1.10005,1.10053,1.09995,1.10038],[1.10038,1.10056,1.10026,1.10050],[1.10050,1.10056,1.10040,1.10048],[1.10048,1.10062,1.10028,1.10043],[1.10043,1.10055,1.10027,1.10035],[1.10035,1.10043,1.10010,1.10025],[1.10025,1.10043,1.09998,1.10015],[1.10015,1.10030,1.09988,1.10005],[1.10005,1.10015,1.09988,1.09995],[1.09995,1.10002,1.09975,1.09987],[1.09987,1.10002,1.09963,1.09982],[1.09982,1.09993,1.09964,1.09980]]',
    '[{"x1":8.5,"x2":27.5,"p1":1.09410,"p2":1.09681}]',
    0.50, 1.50, 0, 'published', 20
);

-- ------------------------------------------------------------
-- 3) Draw the Downward Trend (USD/JPY, H1)
--    Target line runs from the high of candle 8 (index 7) to the
--    high of candle 27 (index 26) - two falling swing highs.
-- ------------------------------------------------------------
INSERT IGNORE INTO chartlab_exercises
    (course_id, title, slug, pair_label, timeframe_label, difficulty, mode, instruction, hint, explanation,
     price_decimals, candles, targets, tol_price, tol_candles, is_premium, status, sort_order)
VALUES (
    (SELECT id FROM courses WHERE slug = 'technical-analysis' LIMIT 1),
    'Draw the Downward Trend', 'draw-the-downward-trend', 'USD/JPY', 'H1', 'Beginner', 'trendline',
    'Price is making lower highs and lower lows. Draw a line connecting the swing highs: drag from an early pullback high to a later, lower pullback high, following the direction of the trend.',
    'Find two points where price rallied and got rejected, each one lower than the one before it, then connect them with a falling line.',
    'A downtrend line connects a series of falling swing highs. As long as price keeps making lower highs and stays below this line, the downtrend structure is still intact. A break back above this line is often the first warning sign that the downtrend is losing control.',
    3,
    '[[152.400,152.429,152.364,152.391],[152.391,152.437,152.337,152.368],[152.368,152.402,152.288,152.335],[152.335,152.351,152.264,152.296],[152.296,152.354,152.226,152.254],[152.254,152.305,152.173,152.215],[152.215,152.246,152.161,152.182],[152.182,152.227,152.111,152.159],[152.159,152.217,152.094,152.150],[152.150,152.212,152.094,152.131],[152.131,152.193,152.052,152.080],[152.080,152.132,151.975,152.008],[152.008,152.054,151.910,151.925],[151.925,151.956,151.800,151.842],[151.842,151.889,151.743,151.770],[151.770,151.811,151.685,151.719],[151.719,151.771,151.665,151.700],[151.700,151.739,151.636,151.707],[151.707,151.762,151.664,151.726],[151.726,151.815,151.707,151.754],[151.754,151.840,151.731,151.788],[151.788,151.890,151.727,151.825],[151.825,151.921,151.806,151.862],[151.862,151.931,151.803,151.896],[151.896,151.978,151.852,151.924],[151.924,151.967,151.895,151.943],[151.943,152.010,151.886,151.950],[151.950,151.991,151.897,151.928],[151.928,151.991,151.834,151.868],[151.868,151.897,151.749,151.781],[151.781,151.807,151.656,151.679],[151.679,151.699,151.514,151.571],[151.571,151.616,151.431,151.469],[151.469,151.495,151.342,151.382],[151.382,151.437,151.280,151.322],[151.322,151.366,151.242,151.300],[151.300,151.332,151.277,151.307],[151.307,151.377,151.244,151.326],[151.326,151.369,151.263,151.354],[151.354,151.437,151.295,151.388],[151.388,151.456,151.357,151.425],[151.425,151.520,151.375,151.462],[151.462,151.542,151.407,151.496],[151.496,151.563,151.455,151.524],[151.524,151.570,151.483,151.543],[151.543,151.571,151.515,151.550]]',
    '[{"x1":7.5,"x2":26.5,"p1":152.227,"p2":152.010}]',
    0.50, 1.50, 0, 'published', 21
);

-- ------------------------------------------------------------
-- 4) Quiz: identify the bid, ask and spread
--    "Reading a Forex Quote"
-- ------------------------------------------------------------
INSERT INTO quizzes (lesson_id, question, option_a, option_b, option_c, option_d, correct_answer, sort_order) VALUES
((SELECT id FROM lessons WHERE slug = 'reading-a-forex-quote' LIMIT 1),
 'A EUR/USD quote shows 1.0842 / 1.0844. Which of these is the bid price - the price you sell at?',
 '1.0842', '1.0844', '1.0843', '0.0002', 'A', 10),
((SELECT id FROM lessons WHERE slug = 'reading-a-forex-quote' LIMIT 1),
 'On that same 1.0842 / 1.0844 quote, which price would you pay if you wanted to BUY EUR/USD right now?',
 '1.0842', '1.0844', '1.0843', 'Either price, they are the same', 'B', 20),
((SELECT id FROM lessons WHERE slug = 'reading-a-forex-quote' LIMIT 1),
 'In a bid/ask quote, which price is always the higher of the two?',
 'The bid', 'The ask', 'They are always equal', 'It depends on the broker', 'B', 30),
((SELECT id FROM lessons WHERE slug = 'understanding-the-spread' LIMIT 1),
 'A quote shows a bid of 1.0842 and an ask of 1.0845. What is the spread, in pips?',
 '0 pips', '3 pips', '30 pips', '0.3 pips', 'B', 10),
((SELECT id FROM lessons WHERE slug = 'understanding-the-spread' LIMIT 1),
 'The spread is best described as which of the following?',
 'A fee charged once per month', 'The difference between the bid and ask price', 'The broker''s leverage ratio', 'The size of your stop loss', 'B', 20),
((SELECT id FROM lessons WHERE slug = 'understanding-the-spread' LIMIT 1),
 'A trade instantly shows a small loss the moment it is opened. What usually explains this?',
 'The broker made an error', 'You entered at the ask (buy) and the position is already marked at the lower bid (sell) price - the spread', 'The market always drops right after you buy', 'Leverage automatically reduces your balance', 'B', 30);

-- ------------------------------------------------------------
-- 5) Quiz: identify the trading session
--    "Forex Trading Sessions"
-- ------------------------------------------------------------
INSERT INTO quizzes (lesson_id, question, option_a, option_b, option_c, option_d, correct_answer, sort_order) VALUES
((SELECT id FROM lessons WHERE slug = 'forex-trading-sessions' LIMIT 1),
 'Which trading session opens first in the trading day (in UTC time)?',
 'London session', 'New York session', 'Sydney session', 'Tokyo session', 'C', 10),
((SELECT id FROM lessons WHERE slug = 'forex-trading-sessions' LIMIT 1),
 'Which two sessions overlap and typically produce the highest volume and volatility of the day?',
 'Sydney and Tokyo', 'Tokyo and London', 'London and New York', 'New York and Sydney', 'C', 20),
((SELECT id FROM lessons WHERE slug = 'forex-trading-sessions' LIMIT 1),
 'A trader in the chat mentions price on JPY pairs is moving but EUR and GBP pairs are quiet. Which session is most likely active?',
 'Tokyo (Asian) session', 'London session', 'New York session', 'London/New York overlap', 'A', 30),
((SELECT id FROM lessons WHERE slug = 'forex-trading-sessions' LIMIT 1),
 'Which session is generally considered the most important for EUR/USD and GBP/USD volume?',
 'Sydney session', 'Tokyo session', 'London session', 'None, all sessions are identical for these pairs', 'C', 40);
